/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.databind.io.json;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.util.JsonUtil;
import dev.metaschema.databind.io.AbstractProblemHandler;
import dev.metaschema.databind.model.IBoundDefinitionModelComplex;

/**
 * This problem handler implementation handles common issues when parsing
 * JSON-based Metaschema module instances.
 */
public class DefaultJsonProblemHandler
    extends AbstractProblemHandler
    implements IJsonProblemHandler {
  private static final String JSON_SCHEMA_FIELD_NAME = "$schema";
  private static final Set<String> IGNORED_FIELD_NAMES;

  static {
    IGNORED_FIELD_NAMES = new HashSet<>();
    IGNORED_FIELD_NAMES.add(JSON_SCHEMA_FIELD_NAME);
  }

  /**
   * Construct a new problem handler with required field validation enabled.
   */
  public DefaultJsonProblemHandler() {
    super();
  }

  /**
   * Construct a new problem handler with the specified validation setting.
   *
   * @param validateRequiredFields
   *          {@code true} to validate that required fields are present,
   *          {@code false} to skip validation
   */
  public DefaultJsonProblemHandler(boolean validateRequiredFields) {
    super(validateRequiredFields);
  }

  @Override
  public boolean handleUnknownProperty(
      IBoundDefinitionModelComplex classBinding,
      IBoundObject targetObject,
      String fieldName,
      IJsonParsingContext parsingContext) throws IOException {
    boolean retval = false;
    if (IGNORED_FIELD_NAMES.contains(fieldName)) {
      JsonUtil.skipNextValue(parsingContext.getReader(), parsingContext.getSource());
      retval = true;
    }
    return retval;
  }
}
