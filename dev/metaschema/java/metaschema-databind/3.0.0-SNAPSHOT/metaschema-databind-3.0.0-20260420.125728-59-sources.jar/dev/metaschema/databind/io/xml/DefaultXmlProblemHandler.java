/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.databind.io.xml;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashSet;
import java.util.Set;

import javax.xml.stream.events.Attribute;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.util.XmlEventUtil;
import dev.metaschema.core.qname.IEnhancedQName;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.io.AbstractProblemHandler;
import dev.metaschema.databind.model.IBoundDefinitionModelComplex;

/**
 * Handles problems identified in the parsed XML.
 * <p>
 * The default problem handler will report unknown attributes, and provide empty
 * collections for multi-valued model items and default values for flags and
 * single valued fields.
 */
public class DefaultXmlProblemHandler
    extends AbstractProblemHandler
    implements IXmlProblemHandler {
  private static final Logger LOGGER = LogManager.getLogger(DefaultXmlProblemHandler.class);

  /**
   * Construct a new problem handler with required field validation enabled.
   */
  public DefaultXmlProblemHandler() {
    super();
  }

  /**
   * Construct a new problem handler with the specified validation setting.
   *
   * @param validateRequiredFields
   *          {@code true} to validate that required fields are present,
   *          {@code false} to skip validation
   */
  public DefaultXmlProblemHandler(boolean validateRequiredFields) {
    super(validateRequiredFields);
  }

  private static final IEnhancedQName XSI_SCHEMA_LOCATION
      = IEnhancedQName.of("http://www.w3.org/2001/XMLSchema-instance", "schemaLocation");
  private static final Set<IEnhancedQName> IGNORED_QNAMES;

  static {
    IGNORED_QNAMES = new HashSet<>();
    IGNORED_QNAMES.add(XSI_SCHEMA_LOCATION);
  }

  @Override
  public boolean handleUnknownAttribute(
      IBoundDefinitionModelComplex parentDefinition,
      IBoundObject targetObject,
      Attribute attribute,
      IXmlParsingContext parsingContext) {
    IEnhancedQName qname = IEnhancedQName.of(ObjectUtils.requireNonNull(attribute.getName()));
    // check if warning is needed
    if (LOGGER.isWarnEnabled() && !IGNORED_QNAMES.contains(qname)) {
      LOGGER.atWarn().log("Skipping unrecognized attribute '{}'{}.",
          qname,
          XmlEventUtil.generateLocationMessage(
              ObjectUtils.notNull(attribute.getLocation()),
              parsingContext.getSource()));
    }
    // always ignore
    return true;
  }
}
