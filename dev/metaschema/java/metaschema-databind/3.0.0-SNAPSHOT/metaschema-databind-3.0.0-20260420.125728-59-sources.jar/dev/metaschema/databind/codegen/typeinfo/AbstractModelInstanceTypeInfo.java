/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.databind.codegen.typeinfo;

import com.squareup.javapoet.AnnotationSpec;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import dev.metaschema.core.model.IGroupable;
import dev.metaschema.core.model.IModelDefinition;
import dev.metaschema.core.model.IModelInstanceAbsolute;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.XmlGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.codegen.typeinfo.def.IAssemblyDefinitionTypeInfo;
import dev.metaschema.databind.model.annotations.GroupAs;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;

abstract class AbstractModelInstanceTypeInfo<INSTANCE extends IModelInstanceAbsolute>
    extends AbstractInstanceTypeInfo<INSTANCE, IAssemblyDefinitionTypeInfo>
    implements IModelInstanceTypeInfo {

  protected AbstractModelInstanceTypeInfo(
      @NonNull INSTANCE instance,
      @NonNull IAssemblyDefinitionTypeInfo parentDefinition) {
    super(instance, parentDefinition);
  }

  @Override
  public String getBaseName() {
    INSTANCE instance = getInstance();
    String baseName = getInstance().getGroupAsName();
    if (baseName == null) {
      throw new IllegalStateException(String.format(
          "Unable to derive the property name, due to missing group as name, for '%s' in the module '%s'.",
          instance.toCoordinates(),
          instance.getContainingModule().getLocation()));
    }
    return baseName;
  }

  @NonNull
  @Override
  public TypeName getJavaFieldType() {
    TypeName item = getJavaItemType();

    @NonNull
    TypeName retval;
    IModelInstanceAbsolute instance = getInstance();
    int maxOccurance = instance.getMaxOccurs();
    if (maxOccurance == -1 || maxOccurance > 1) {
      if (JsonGroupAsBehavior.KEYED.equals(instance.getJsonGroupAsBehavior())) {
        retval = ObjectUtils.notNull(
            ParameterizedTypeName.get(ClassName.get(Map.class), ClassName.get(String.class), item));
      } else {
        retval = ObjectUtils.notNull(ParameterizedTypeName.get(ClassName.get(List.class), item));
      }
    } else {
      retval = item;
    }

    return retval;
  }

  @Override
  public boolean isCollectionType() {
    IModelInstanceAbsolute instance = getInstance();
    int maxOccurs = instance.getMaxOccurs();
    return maxOccurs == -1 || maxOccurs > 1;
  }

  @Nullable
  @Override
  public Class<?> getCollectionImplementationClass() {
    IModelInstanceAbsolute instance = getInstance();
    int maxOccurs = instance.getMaxOccurs();
    if (maxOccurs == -1 || maxOccurs > 1) {
      // This is a collection - return the appropriate implementation class
      if (JsonGroupAsBehavior.KEYED.equals(instance.getJsonGroupAsBehavior())) {
        return LinkedHashMap.class;
      }
      return LinkedList.class;
    }
    // Not a collection
    return null;
  }

  @NonNull
  protected abstract AnnotationSpec.Builder newBindingAnnotation();

  @Override
  public Set<IModelDefinition> buildField(
      TypeSpec.Builder typeBuilder,
      FieldSpec.Builder fieldBuilder) {
    Set<IModelDefinition> retval = new LinkedHashSet<>(super.buildField(typeBuilder, fieldBuilder));

    AnnotationSpec.Builder annotation = newBindingAnnotation();

    retval.addAll(buildBindingAnnotation(typeBuilder, fieldBuilder, annotation));

    fieldBuilder.addAnnotation(annotation.build());

    return retval;
  }

  @NonNull
  protected AnnotationSpec.Builder generateGroupAsAnnotation() {
    AnnotationSpec.Builder groupAsAnnoation = AnnotationSpec.builder(GroupAs.class);

    IModelInstanceAbsolute modelInstance = getInstance();

    groupAsAnnoation.addMember("name", "$S",
        ObjectUtils.requireNonNull(modelInstance.getGroupAsName(), "The grouping name must be non-null"));

    // FIXME: handle group-as namespace as a prefix

    JsonGroupAsBehavior jsonGroupAsBehavior = modelInstance.getJsonGroupAsBehavior();
    assert jsonGroupAsBehavior != null;
    if (!IGroupable.DEFAULT_JSON_GROUP_AS_BEHAVIOR.equals(jsonGroupAsBehavior)) {
      groupAsAnnoation.addMember("inJson", "$T.$L",
          JsonGroupAsBehavior.class, jsonGroupAsBehavior.toString());
    }

    XmlGroupAsBehavior xmlGroupAsBehavior = modelInstance.getXmlGroupAsBehavior();
    assert xmlGroupAsBehavior != null;
    if (!IGroupable.DEFAULT_XML_GROUP_AS_BEHAVIOR.equals(xmlGroupAsBehavior)) {
      groupAsAnnoation.addMember("inXml", "$T.$L",
          XmlGroupAsBehavior.class, xmlGroupAsBehavior.toString());
    }
    return groupAsAnnoation;
  }
}
