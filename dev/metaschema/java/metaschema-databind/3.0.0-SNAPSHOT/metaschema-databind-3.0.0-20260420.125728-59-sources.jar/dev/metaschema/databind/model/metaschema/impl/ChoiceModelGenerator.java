/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.databind.model.metaschema.impl;

import dev.metaschema.core.metapath.item.node.INodeItemFactory;
import dev.metaschema.core.model.DefaultChoiceModelBuilder;
import dev.metaschema.core.model.IAssemblyInstanceAbsolute;
import dev.metaschema.core.model.IChoiceInstance;
import dev.metaschema.core.model.IContainerModelAbsolute;
import dev.metaschema.core.model.IContainerModelSupport;
import dev.metaschema.core.model.IFieldInstanceAbsolute;
import dev.metaschema.core.model.IModelInstanceAbsolute;
import dev.metaschema.core.model.INamedModelInstanceAbsolute;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.IBoundInstanceModelChoiceGroup;
import dev.metaschema.databind.model.IBoundInstanceModelGroupedAssembly;
import dev.metaschema.databind.model.metaschema.binding.AssemblyModel;
import dev.metaschema.databind.model.metaschema.binding.AssemblyReference;
import dev.metaschema.databind.model.metaschema.binding.FieldReference;
import dev.metaschema.databind.model.metaschema.binding.InlineDefineAssembly;
import dev.metaschema.databind.model.metaschema.binding.InlineDefineField;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;

/**
 * Supports building the model contents of a Metaschema choice instance.
 * <p>
 * This class is not thread safe.
 */
/**
 * Generates choice model structures from binding data.
 * <p>
 * This class handles the creation of choice containers for assemblies that
 * contain exclusive model alternatives.
 */
public final class ChoiceModelGenerator
    extends AbstractAbsoluteModelGenerator<
        IContainerModelAbsolute,
        DefaultChoiceModelBuilder<
            IModelInstanceAbsolute,
            INamedModelInstanceAbsolute,
            IFieldInstanceAbsolute,
            IAssemblyInstanceAbsolute>> {

  /**
   * Construct a new choice model container.
   *
   * @param binding
   *          the choice model object bound to a Java class
   * @param bindingInstance
   *          the Metaschema module instance for the bound model object
   * @param parent
   *          the assembly definition containing this container
   * @param nodeItemFactory
   *          the node item factory used to generate child nodes
   * @return the container
   */
  public static IContainerModelSupport<
      IModelInstanceAbsolute,
      INamedModelInstanceAbsolute,
      IFieldInstanceAbsolute,
      IAssemblyInstanceAbsolute> of(
          @Nullable AssemblyModel.Choice binding,
          @NonNull IBoundInstanceModelGroupedAssembly bindingInstance,
          @NonNull IChoiceInstance parent,
          @NonNull INodeItemFactory nodeItemFactory) {
    return binding == null || binding.getChoices().isEmpty()
        ? IContainerModelSupport.empty()
        : newInstance(
            binding,
            bindingInstance,
            parent,
            nodeItemFactory);
  }

  private static IContainerModelSupport<
      IModelInstanceAbsolute,
      INamedModelInstanceAbsolute,
      IFieldInstanceAbsolute,
      IAssemblyInstanceAbsolute> newInstance(
          @NonNull AssemblyModel.Choice binding,
          @NonNull IBoundInstanceModelGroupedAssembly bindingInstance,
          @NonNull IChoiceInstance parent,
          @NonNull INodeItemFactory nodeItemFactory) {
    ChoiceModelGenerator generator = new ChoiceModelGenerator(parent, nodeItemFactory);

    // TODO: make "instances" a constant
    IBoundInstanceModelChoiceGroup instance = ObjectUtils.requireNonNull(
        bindingInstance.getDefinition().getChoiceGroupInstanceByName("choices"));

    ObjectUtils.notNull(binding.getChoices()).forEach(obj -> {
      assert obj != null;
      IBoundInstanceModelGroupedAssembly objInstance
          = (IBoundInstanceModelGroupedAssembly) instance.getItemInstance(obj);

      if (obj instanceof AssemblyReference) {
        generator.addAssemblyInstance((AssemblyReference) obj, objInstance);
      } else if (obj instanceof InlineDefineAssembly) {
        generator.addAssemblyInstance((InlineDefineAssembly) obj, objInstance);
      } else if (obj instanceof FieldReference) {
        generator.addFieldInstance((FieldReference) obj, objInstance);
      } else if (obj instanceof InlineDefineField) {
        generator.addFieldInstance((InlineDefineField) obj, objInstance);
      } else {
        throw new UnsupportedOperationException(String.format("Unknown model instance class: %s", obj.getClass()));
      }
    });

    return generator.getBuilder().buildChoice();
  }

  private ChoiceModelGenerator(
      @NonNull IContainerModelAbsolute parent,
      @NonNull INodeItemFactory nodeItemFactory) {
    super(
        parent,
        nodeItemFactory,
        new DefaultChoiceModelBuilder<>());
  }
}
