/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.databind.model.annotations;

import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;

import java.util.List;

import dev.metaschema.core.datatype.AbstractDataTypeAdapter;
import dev.metaschema.core.datatype.IDataTypeAdapter;
import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.item.ICollectionValue;
import dev.metaschema.core.metapath.item.atomic.IAnyAtomicItem;
import dev.metaschema.core.metapath.item.function.IMapKey;
import dev.metaschema.core.metapath.type.IItemType;
import dev.metaschema.core.qname.IEnhancedQName;
import dev.metaschema.databind.model.annotations.NullJavaTypeAdapter.VoidItem;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * Used to mark a Java type that has no configured adapter.
 */
public final class NullJavaTypeAdapter
    extends AbstractDataTypeAdapter<Void, VoidItem> {

  private static final String NOT_VALID = "not a valid type";

  /**
   * Construct a new adapter.
   */
  @SuppressWarnings("synthetic-access")
  public NullJavaTypeAdapter() {
    super(Void.class, VoidItem.class, VoidItem::cast);
  }

  @Override
  public JsonFormatTypes getJsonRawType() {
    return JsonFormatTypes.NULL;
  }

  @Override
  public Void copy(@NonNull Object obj) {
    throw new UnsupportedOperationException(NOT_VALID);
  }

  @Override
  public Void parse(String value) {
    throw new UnsupportedOperationException(NOT_VALID);
  }

  @SuppressWarnings("exports")
  @Override
  public VoidItem newItem(Object value) {
    throw new UnsupportedOperationException(NOT_VALID);
  }

  @Override
  public List<IEnhancedQName> getNames() {
    throw new UnsupportedOperationException(NOT_VALID);
  }

  /**
   * A placeholder atomic item type that throws unsupported operation exceptions
   * for all operations.
   */
  protected static class VoidItem implements IAnyAtomicItem {

    private static VoidItem cast(@SuppressWarnings("unused") @NonNull IAnyAtomicItem item) {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public Void getValue() {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @NonNull
    @Override
    public IAnyAtomicItem toAtomicItem() {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @NonNull
    @Override
    public String asString() {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public IDataTypeAdapter<?> getJavaTypeAdapter() {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public IAnyAtomicItem castAsType(IAnyAtomicItem item) {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public IMapKey asMapKey() {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public IItemType getType() {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public String toSignature() {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public boolean deepEquals(ICollectionValue other, DynamicContext dynamicContext) {
      throw new UnsupportedOperationException(NOT_VALID);
    }

    @Override
    public boolean deepEquals(ICollectionValue other) {
      throw new UnsupportedOperationException(NOT_VALID);
    }
  }
}
