/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.databind.model.metaschema;

import dev.metaschema.core.metapath.item.node.IDocumentNodeItem;
import dev.metaschema.core.metapath.item.node.IModuleNodeItem;
import dev.metaschema.core.model.IMetaschemaModule;
import dev.metaschema.databind.model.metaschema.binding.METASCHEMA;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * Represents a Metaschema module loaded via data binding.
 * <p>
 * This interface provides access to the bound representation of a Metaschema
 * module, including its definitions and constraints.
 */
public interface IBindingMetaschemaModule
    extends IMetaschemaModule<IBindingMetaschemaModule> {

  /**
   * Get the underlying module data as a bound object.
   *
   * @return the bound class
   */
  @NonNull
  METASCHEMA getBinding();

  /**
   * Get the underling bound objects as a {@link IDocumentNodeItem}.
   *
   * @return the document node item
   */
  @NonNull
  IDocumentNodeItem getSourceNodeItem();

  /**
   * Get a node item that can be used to query the module's model.
   *
   * @return the module node item
   */
  @NonNull
  IModuleNodeItem getModuleNodeItem();
}
