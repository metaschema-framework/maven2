// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.DecimalAdapter;
import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Performance timing measurements collected during validation.
 */
@MetaschemaAssembly(
    formalName = "Timing Data",
    description = "Performance timing measurements collected during validation.",
    name = "timingData",
    moduleClass = SarifModule.class
)
public class TimingData implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Total accumulated time in milliseconds across all invocations.
   */
  @BoundField(
      formalName = "Total Duration (ms)",
      description = "Total accumulated time in milliseconds across all invocations.",
      useName = "totalMs",
      typeAdapter = DecimalAdapter.class
  )
  private BigDecimal _totalMs;

  /**
   * Number of times this item was evaluated.
   */
  @BoundField(
      formalName = "Invocation Count",
      description = "Number of times this item was evaluated.",
      useName = "count",
      typeAdapter = IntegerAdapter.class
  )
  private BigInteger _count;

  /**
   * Minimum single-invocation duration in milliseconds.
   */
  @BoundField(
      formalName = "Minimum Duration (ms)",
      description = "Minimum single-invocation duration in milliseconds.",
      useName = "minMs",
      typeAdapter = DecimalAdapter.class
  )
  private BigDecimal _minMs;

  /**
   * Maximum single-invocation duration in milliseconds.
   */
  @BoundField(
      formalName = "Maximum Duration (ms)",
      description = "Maximum single-invocation duration in milliseconds.",
      useName = "maxMs",
      typeAdapter = DecimalAdapter.class
  )
  private BigDecimal _maxMs;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.TimingData} instance with no metadata.
   */
  public TimingData() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.TimingData} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public TimingData(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Total Duration (ms)}".
   *
   * <p>
   * Total accumulated time in milliseconds across all invocations.
   *
   * @return the totalMs value, or {@code null} if not set
   */
  @Nullable
  public BigDecimal getTotalMs() {
    return _totalMs;
  }

  /**
   * Set the "{@literal Total Duration (ms)}".
   *
   * <p>
   * Total accumulated time in milliseconds across all invocations.
   *
   * @param value
   *           the totalMs value to set, or {@code null} to clear
   */
  public void setTotalMs(@Nullable BigDecimal value) {
    _totalMs = value;
  }

  /**
   * Get the "{@literal Invocation Count}".
   *
   * <p>
   * Number of times this item was evaluated.
   *
   * @return the count value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getCount() {
    return _count;
  }

  /**
   * Set the "{@literal Invocation Count}".
   *
   * <p>
   * Number of times this item was evaluated.
   *
   * @param value
   *           the count value to set, or {@code null} to clear
   */
  public void setCount(@Nullable BigInteger value) {
    _count = value;
  }

  /**
   * Get the "{@literal Minimum Duration (ms)}".
   *
   * <p>
   * Minimum single-invocation duration in milliseconds.
   *
   * @return the minMs value, or {@code null} if not set
   */
  @Nullable
  public BigDecimal getMinMs() {
    return _minMs;
  }

  /**
   * Set the "{@literal Minimum Duration (ms)}".
   *
   * <p>
   * Minimum single-invocation duration in milliseconds.
   *
   * @param value
   *           the minMs value to set, or {@code null} to clear
   */
  public void setMinMs(@Nullable BigDecimal value) {
    _minMs = value;
  }

  /**
   * Get the "{@literal Maximum Duration (ms)}".
   *
   * <p>
   * Maximum single-invocation duration in milliseconds.
   *
   * @return the maxMs value, or {@code null} if not set
   */
  @Nullable
  public BigDecimal getMaxMs() {
    return _maxMs;
  }

  /**
   * Set the "{@literal Maximum Duration (ms)}".
   *
   * <p>
   * Maximum single-invocation duration in milliseconds.
   *
   * @param value
   *           the maxMs value to set, or {@code null} to clear
   */
  public void setMaxMs(@Nullable BigDecimal value) {
    _maxMs = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
