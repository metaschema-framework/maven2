// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * The analysis tool used.
 */
@MetaschemaAssembly(
    formalName = "Tool",
    description = "The analysis tool used.",
    name = "tool",
    moduleClass = SarifModule.class
)
public class Tool implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A component, such as a plug-in or the driver, of the analysis tool that was run.
   */
  @BoundAssembly(
      formalName = "Tool Component",
      description = "A component, such as a plug-in or the driver, of the analysis tool that was run.",
      useName = "driver"
  )
  private ToolComponent _driver;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Tool} instance with no metadata.
   */
  public Tool() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Tool} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Tool(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Tool Component}".
   *
   * <p>
   * A component, such as a plug-in or the driver, of the analysis tool that was run.
   *
   * @return the driver value, or {@code null} if not set
   */
  @Nullable
  public ToolComponent getDriver() {
    return _driver;
  }

  /**
   * Set the "{@literal Tool Component}".
   *
   * <p>
   * A component, such as a plug-in or the driver, of the analysis tool that was run.
   *
   * @param value
   *           the driver value to set, or {@code null} to clear
   */
  public void setDriver(@Nullable ToolComponent value) {
    _driver = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
