// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import java.net.URI;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Specifies the location of an artifact.
 */
@MetaschemaAssembly(
    formalName = "Artifact Location",
    description = "Specifies the location of an artifact.",
    name = "artifactLocation",
    moduleClass = SarifModule.class
)
public class ArtifactLocation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A valid relative or absolute URI.
   */
  @BoundField(
      formalName = "URI",
      description = "A valid relative or absolute URI.",
      useName = "uri",
      typeAdapter = UriReferenceAdapter.class
  )
  private URI _uri;

  /**
   * The index within the run artifacts array of the artifact object associated with the artifact location.
   */
  @BoundField(
      formalName = "Index",
      description = "The index within the run artifacts array of the artifact object associated with the artifact location.",
      useName = "index",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class,
      valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@id >= -1", message = "The index '{ . }' is not greater than or equal to '-1'."))
  )
  private BigInteger _index;

  /**
   * A short description of the artifact location.
   */
  @BoundAssembly(
      formalName = "Description",
      description = "A short description of the artifact location.",
      useName = "description"
  )
  private Message _description;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ArtifactLocation} instance with no metadata.
   */
  public ArtifactLocation() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ArtifactLocation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ArtifactLocation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal URI}".
   *
   * <p>
   * A valid relative or absolute URI.
   *
   * @return the uri value, or {@code null} if not set
   */
  @Nullable
  public URI getUri() {
    return _uri;
  }

  /**
   * Set the "{@literal URI}".
   *
   * <p>
   * A valid relative or absolute URI.
   *
   * @param value
   *           the uri value to set, or {@code null} to clear
   */
  public void setUri(@Nullable URI value) {
    _uri = value;
  }

  /**
   * Get the "{@literal Index}".
   *
   * <p>
   * The index within the run artifacts array of the artifact object associated with the artifact location.
   *
   * @return the index value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getIndex() {
    return _index;
  }

  /**
   * Set the "{@literal Index}".
   *
   * <p>
   * The index within the run artifacts array of the artifact object associated with the artifact location.
   *
   * @param value
   *           the index value to set, or {@code null} to clear
   */
  public void setIndex(@Nullable BigInteger value) {
    _index = value;
  }

  /**
   * Get the "{@literal Description}".
   *
   * <p>
   * A short description of the artifact location.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public Message getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Description}".
   *
   * <p>
   * A short description of the artifact location.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable Message value) {
    _description = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
