// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A component, such as a plug-in or the driver, of the analysis tool that was run.
 */
@MetaschemaAssembly(
    formalName = "Tool Component",
    description = "A component, such as a plug-in or the driver, of the analysis tool that was run.",
    name = "toolComponent",
    moduleClass = SarifModule.class
)
public class ToolComponent implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A stable, unique identifier for the tool component.
   */
  @BoundFlag(
      formalName = "Tool Component Unique Identifier",
      description = "A stable, unique identifier for the tool component.",
      name = "guid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _guid;

  /**
   * The name of the tool component.
   */
  @BoundField(
      formalName = "Tool Component Name",
      description = "The name of the tool component.",
      useName = "name",
      typeAdapter = StringAdapter.class
  )
  private String _name;

  /**
   * The organization or company that produced the tool component.
   */
  @BoundField(
      formalName = "Tool Component Organization",
      description = "The organization or company that produced the tool component.",
      useName = "organization",
      typeAdapter = StringAdapter.class
  )
  private String _organization;

  /**
   * A product suite to which the tool component belongs.
   */
  @BoundField(
      formalName = "Tool Component Product",
      description = "A product suite to which the tool component belongs.",
      useName = "product",
      typeAdapter = StringAdapter.class
  )
  private String _product;

  /**
   * The tool component version, in whatever format the component natively provides.
   */
  @BoundField(
      formalName = "Tool Component Version",
      description = "The tool component version, in whatever format the component natively provides.",
      useName = "version",
      typeAdapter = StringAdapter.class
  )
  private String _version;

  /**
   * The tool component version in the format specified by Semantic Versioning 2.0.
   */
  @BoundField(
      formalName = "Tool Component Semantic Version",
      description = "The tool component version in the format specified by Semantic Versioning 2.0.",
      useName = "semanticVersion",
      typeAdapter = StringAdapter.class
  )
  private String _semanticVersion;

  /**
   * The absolute URI at which information about this version of the tool component can be found.
   */
  @BoundField(
      formalName = "Tool Component Information URI",
      description = "The absolute URI at which information about this version of the tool component can be found.",
      useName = "informationUri",
      typeAdapter = UriAdapter.class
  )
  private URI _informationUri;

  /**
   * An array of reportingDescriptor objects relevant to the analysis performed by the tool component.
   */
  @BoundAssembly(
      formalName = "Rule",
      description = "An array of reportingDescriptor objects relevant to the analysis performed by the tool component.",
      useName = "rule",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "rules", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ReportingDescriptor> _rules;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ToolComponent} instance with no metadata.
   */
  public ToolComponent() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ToolComponent} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ToolComponent(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Tool Component Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the tool component.
   *
   * @return the guid value, or {@code null} if not set
   */
  @Nullable
  public UUID getGuid() {
    return _guid;
  }

  /**
   * Set the "{@literal Tool Component Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the tool component.
   *
   * @param value
   *           the guid value to set, or {@code null} to clear
   */
  public void setGuid(@Nullable UUID value) {
    _guid = value;
  }

  /**
   * Get the "{@literal Tool Component Name}".
   *
   * <p>
   * The name of the tool component.
   *
   * @return the name value, or {@code null} if not set
   */
  @Nullable
  public String getName() {
    return _name;
  }

  /**
   * Set the "{@literal Tool Component Name}".
   *
   * <p>
   * The name of the tool component.
   *
   * @param value
   *           the name value to set, or {@code null} to clear
   */
  public void setName(@Nullable String value) {
    _name = value;
  }

  /**
   * Get the "{@literal Tool Component Organization}".
   *
   * <p>
   * The organization or company that produced the tool component.
   *
   * @return the organization value, or {@code null} if not set
   */
  @Nullable
  public String getOrganization() {
    return _organization;
  }

  /**
   * Set the "{@literal Tool Component Organization}".
   *
   * <p>
   * The organization or company that produced the tool component.
   *
   * @param value
   *           the organization value to set, or {@code null} to clear
   */
  public void setOrganization(@Nullable String value) {
    _organization = value;
  }

  /**
   * Get the "{@literal Tool Component Product}".
   *
   * <p>
   * A product suite to which the tool component belongs.
   *
   * @return the product value, or {@code null} if not set
   */
  @Nullable
  public String getProduct() {
    return _product;
  }

  /**
   * Set the "{@literal Tool Component Product}".
   *
   * <p>
   * A product suite to which the tool component belongs.
   *
   * @param value
   *           the product value to set, or {@code null} to clear
   */
  public void setProduct(@Nullable String value) {
    _product = value;
  }

  /**
   * Get the "{@literal Tool Component Version}".
   *
   * <p>
   * The tool component version, in whatever format the component natively provides.
   *
   * @return the version value, or {@code null} if not set
   */
  @Nullable
  public String getVersion() {
    return _version;
  }

  /**
   * Set the "{@literal Tool Component Version}".
   *
   * <p>
   * The tool component version, in whatever format the component natively provides.
   *
   * @param value
   *           the version value to set, or {@code null} to clear
   */
  public void setVersion(@Nullable String value) {
    _version = value;
  }

  /**
   * Get the "{@literal Tool Component Semantic Version}".
   *
   * <p>
   * The tool component version in the format specified by Semantic Versioning 2.0.
   *
   * @return the semanticVersion value, or {@code null} if not set
   */
  @Nullable
  public String getSemanticVersion() {
    return _semanticVersion;
  }

  /**
   * Set the "{@literal Tool Component Semantic Version}".
   *
   * <p>
   * The tool component version in the format specified by Semantic Versioning 2.0.
   *
   * @param value
   *           the semanticVersion value to set, or {@code null} to clear
   */
  public void setSemanticVersion(@Nullable String value) {
    _semanticVersion = value;
  }

  /**
   * Get the "{@literal Tool Component Information URI}".
   *
   * <p>
   * The absolute URI at which information about this version of the tool component can be found.
   *
   * @return the informationUri value, or {@code null} if not set
   */
  @Nullable
  public URI getInformationUri() {
    return _informationUri;
  }

  /**
   * Set the "{@literal Tool Component Information URI}".
   *
   * <p>
   * The absolute URI at which information about this version of the tool component can be found.
   *
   * @param value
   *           the informationUri value to set, or {@code null} to clear
   */
  public void setInformationUri(@Nullable URI value) {
    _informationUri = value;
  }

  /**
   * Get the "{@literal Rule}".
   *
   * <p>
   * An array of reportingDescriptor objects relevant to the analysis performed by the tool component.
   *
   * @return the rule value
   */
  @NonNull
  public List<ReportingDescriptor> getRules() {
    if (_rules == null) {
      _rules = new LinkedList<>();
    }
    return ObjectUtils.notNull(_rules);
  }

  /**
   * Set the "{@literal Rule}".
   *
   * <p>
   * An array of reportingDescriptor objects relevant to the analysis performed by the tool component.
   *
   * @param value
   *           the rule value to set
   */
  public void setRules(@NonNull List<ReportingDescriptor> value) {
    _rules = value;
  }

  /**
   * Add a new {@link ReportingDescriptor} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRule(ReportingDescriptor item) {
    ReportingDescriptor value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_rules == null) {
      _rules = new LinkedList<>();
    }
    return _rules.add(value);
  }

  /**
   * Remove the first matching {@link ReportingDescriptor} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRule(ReportingDescriptor item) {
    ReportingDescriptor value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _rules != null && _rules.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
