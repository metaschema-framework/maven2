// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Contains information about how and when a result was detected.
 */
@MetaschemaAssembly(
    formalName = "Result Provanance",
    description = "Contains information about how and when a result was detected.",
    name = "resultProvenance",
    moduleClass = SarifModule.class
)
public class ResultProvenance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The Coordinated Universal Time (UTC) date and time at which the result was first detected. See \&quot;Date/time properties\&quot; in the SARIF spec for the required format.
   */
  @BoundField(
      formalName = "First Detection Time",
      description = "The Coordinated Universal Time (UTC) date and time at which the result was first detected. See \\\\\"Date/time properties\\\\\" in the SARIF spec for the required format.",
      useName = "firstDetectionTimeUtc",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _firstDetectionTimeUtc;

  /**
   * The Coordinated Universal Time (UTC) date and time at which the result was most recently detected. See \&quot;Date/time properties\&quot; in the SARIF spec for the required format.
   */
  @BoundField(
      formalName = "Last Detection Time",
      description = "The Coordinated Universal Time (UTC) date and time at which the result was most recently detected. See \\\\\"Date/time properties\\\\\" in the SARIF spec for the required format.",
      useName = "lastDetectionTimeUtc",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _lastDetectionTimeUtc;

  /**
   * An sequence of physicalLocation objects which specify the portions of an analysis tool's output that a converter transformed into the result.
   */
  @BoundAssembly(
      formalName = "Conversion Source",
      description = "An sequence of physicalLocation objects which specify the portions of an analysis tool's output that a converter transformed into the result.",
      useName = "conversionSource",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "conversionSources", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<PhysicalLocation> _conversionSources;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ResultProvenance} instance with no metadata.
   */
  public ResultProvenance() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ResultProvenance} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ResultProvenance(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal First Detection Time}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the result was first detected. See \&quot;Date/time properties\&quot; in the SARIF spec for the required format.
   *
   * @return the firstDetectionTimeUtc value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getFirstDetectionTimeUtc() {
    return _firstDetectionTimeUtc;
  }

  /**
   * Set the "{@literal First Detection Time}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the result was first detected. See \&quot;Date/time properties\&quot; in the SARIF spec for the required format.
   *
   * @param value
   *           the firstDetectionTimeUtc value to set, or {@code null} to clear
   */
  public void setFirstDetectionTimeUtc(@Nullable ZonedDateTime value) {
    _firstDetectionTimeUtc = value;
  }

  /**
   * Get the "{@literal Last Detection Time}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the result was most recently detected. See \&quot;Date/time properties\&quot; in the SARIF spec for the required format.
   *
   * @return the lastDetectionTimeUtc value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getLastDetectionTimeUtc() {
    return _lastDetectionTimeUtc;
  }

  /**
   * Set the "{@literal Last Detection Time}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the result was most recently detected. See \&quot;Date/time properties\&quot; in the SARIF spec for the required format.
   *
   * @param value
   *           the lastDetectionTimeUtc value to set, or {@code null} to clear
   */
  public void setLastDetectionTimeUtc(@Nullable ZonedDateTime value) {
    _lastDetectionTimeUtc = value;
  }

  /**
   * Get the "{@literal Conversion Source}".
   *
   * <p>
   * An sequence of physicalLocation objects which specify the portions of an analysis tool's output that a converter transformed into the result.
   *
   * @return the conversionSource value
   */
  @NonNull
  public List<PhysicalLocation> getConversionSources() {
    if (_conversionSources == null) {
      _conversionSources = new LinkedList<>();
    }
    return ObjectUtils.notNull(_conversionSources);
  }

  /**
   * Set the "{@literal Conversion Source}".
   *
   * <p>
   * An sequence of physicalLocation objects which specify the portions of an analysis tool's output that a converter transformed into the result.
   *
   * @param value
   *           the conversionSource value to set
   */
  public void setConversionSources(@NonNull List<PhysicalLocation> value) {
    _conversionSources = value;
  }

  /**
   * Add a new {@link PhysicalLocation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addConversionSource(PhysicalLocation item) {
    PhysicalLocation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_conversionSources == null) {
      _conversionSources = new LinkedList<>();
    }
    return _conversionSources.add(value);
  }

  /**
   * Remove the first matching {@link PhysicalLocation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeConversionSource(PhysicalLocation item) {
    PhysicalLocation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _conversionSources != null && _conversionSources.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
