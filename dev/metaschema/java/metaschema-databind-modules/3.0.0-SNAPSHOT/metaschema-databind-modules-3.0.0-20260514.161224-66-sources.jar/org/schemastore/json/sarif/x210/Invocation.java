// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.BooleanAdapter;
import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * The runtime environment of the analysis tool run.
 */
@MetaschemaAssembly(
    formalName = "Invocation",
    description = "The runtime environment of the analysis tool run.",
    name = "invocation",
    moduleClass = SarifModule.class
)
public class Invocation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The Coordinated Universal Time (UTC) date and time at which the invocation started.
   */
  @BoundField(
      formalName = "Start Time UTC",
      description = "The Coordinated Universal Time (UTC) date and time at which the invocation started.",
      useName = "startTimeUtc",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _startTimeUtc;

  /**
   * The Coordinated Universal Time (UTC) date and time at which the invocation ended.
   */
  @BoundField(
      formalName = "End Time UTC",
      description = "The Coordinated Universal Time (UTC) date and time at which the invocation ended.",
      useName = "endTimeUtc",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _endTimeUtc;

  /**
   * Specifies whether the tool's execution completed successfully.
   */
  @BoundField(
      formalName = "Execution Successful",
      description = "Specifies whether the tool's execution completed successfully.",
      useName = "executionSuccessful",
      minOccurs = 1,
      typeAdapter = BooleanAdapter.class
  )
  private Boolean _executionSuccessful;

  /**
   * A list of runtime conditions detected by the tool during the analysis.
   */
  @BoundAssembly(
      formalName = "Tool Execution Notification",
      description = "A list of runtime conditions detected by the tool during the analysis.",
      useName = "toolExecutionNotification",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "toolExecutionNotifications", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Notification> _toolExecutionNotifications;

  /**
   * Key/value pairs that provide additional information about the invocation.
   */
  @BoundAssembly(
      formalName = "Properties",
      description = "Key/value pairs that provide additional information about the invocation.",
      useName = "properties"
  )
  private PropertyBag _properties;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Invocation} instance with no metadata.
   */
  public Invocation() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Invocation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Invocation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Start Time UTC}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the invocation started.
   *
   * @return the startTimeUtc value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getStartTimeUtc() {
    return _startTimeUtc;
  }

  /**
   * Set the "{@literal Start Time UTC}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the invocation started.
   *
   * @param value
   *           the startTimeUtc value to set, or {@code null} to clear
   */
  public void setStartTimeUtc(@Nullable ZonedDateTime value) {
    _startTimeUtc = value;
  }

  /**
   * Get the "{@literal End Time UTC}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the invocation ended.
   *
   * @return the endTimeUtc value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getEndTimeUtc() {
    return _endTimeUtc;
  }

  /**
   * Set the "{@literal End Time UTC}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the invocation ended.
   *
   * @param value
   *           the endTimeUtc value to set, or {@code null} to clear
   */
  public void setEndTimeUtc(@Nullable ZonedDateTime value) {
    _endTimeUtc = value;
  }

  /**
   * Get the "{@literal Execution Successful}".
   *
   * <p>
   * Specifies whether the tool's execution completed successfully.
   *
   * @return the executionSuccessful value
   */
  @NonNull
  public Boolean getExecutionSuccessful() {
    return _executionSuccessful;
  }

  /**
   * Set the "{@literal Execution Successful}".
   *
   * <p>
   * Specifies whether the tool's execution completed successfully.
   *
   * @param value
   *           the executionSuccessful value to set
   */
  public void setExecutionSuccessful(@NonNull Boolean value) {
    _executionSuccessful = value;
  }

  /**
   * Get the "{@literal Tool Execution Notification}".
   *
   * <p>
   * A list of runtime conditions detected by the tool during the analysis.
   *
   * @return the toolExecutionNotification value
   */
  @NonNull
  public List<Notification> getToolExecutionNotifications() {
    if (_toolExecutionNotifications == null) {
      _toolExecutionNotifications = new LinkedList<>();
    }
    return ObjectUtils.notNull(_toolExecutionNotifications);
  }

  /**
   * Set the "{@literal Tool Execution Notification}".
   *
   * <p>
   * A list of runtime conditions detected by the tool during the analysis.
   *
   * @param value
   *           the toolExecutionNotification value to set
   */
  public void setToolExecutionNotifications(@NonNull List<Notification> value) {
    _toolExecutionNotifications = value;
  }

  /**
   * Add a new {@link Notification} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addToolExecutionNotification(Notification item) {
    Notification value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_toolExecutionNotifications == null) {
      _toolExecutionNotifications = new LinkedList<>();
    }
    return _toolExecutionNotifications.add(value);
  }

  /**
   * Remove the first matching {@link Notification} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeToolExecutionNotification(Notification item) {
    Notification value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _toolExecutionNotifications != null && _toolExecutionNotifications.remove(value);
  }

  /**
   * Get the "{@literal Properties}".
   *
   * <p>
   * Key/value pairs that provide additional information about the invocation.
   *
   * @return the properties value, or {@code null} if not set
   */
  @Nullable
  public PropertyBag getProperties() {
    return _properties;
  }

  /**
   * Set the "{@literal Properties}".
   *
   * <p>
   * Key/value pairs that provide additional information about the invocation.
   *
   * @param value
   *           the properties value to set, or {@code null} to clear
   */
  public void setProperties(@Nullable PropertyBag value) {
    _properties = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
