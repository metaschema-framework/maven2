// Generated from: ../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.databind.IBindingContext;
import dev.metaschema.databind.model.AbstractBoundModule;
import dev.metaschema.databind.model.IBoundModule;
import dev.metaschema.databind.model.annotations.MetaschemaModule;
import java.net.URI;
import java.util.List;

/**
 * SARIF Metaschema Module
 */
@MetaschemaModule(
    assemblies = {
        PropertyBag.class,
        TimingData.class,
        LetTimingEntry.class,
        ToolComponent.class,
        ReportingDescriptor.class,
        MultiformatMessageString.class,
        Tool.class,
        Artifact.class,
        Result.class,
        ReportingDescriptorReference.class,
        Message.class,
        ArtifactLocation.class,
        Location.class,
        PhysicalLocation.class,
        LogicalLocation.class,
        Region.class,
        ResultProvenance.class,
        Notification.class,
        Invocation.class,
        Run.class,
        Sarif.class
    }
)
public final class SarifModule extends AbstractBoundModule {
  private static final MarkupLine NAME = MarkupLine.fromMarkdown("SARIF Metaschema Module");

  private static final String SHORT_NAME = "sarif";

  private static final String VERSION = "0.1.0";

  private static final URI XML_NAMESPACE = URI.create("https://json.schemastore.org/sarif/2.1.0");

  private static final URI JSON_BASE_URI = URI.create("https://json.schemastore.org/sarif-2.1.0.json");

  /**
   * Construct a new module instance.
   *
   * @param importedModules
   *           modules imported by this module
   * @param bindingContext
   *           the binding context to associate with this module
   */
  public SarifModule(List<? extends IBoundModule> importedModules, IBindingContext bindingContext) {
    super(importedModules, bindingContext);
  }

  @Override
  public MarkupLine getName() {
    return NAME;
  }

  @Override
  public String getShortName() {
    return SHORT_NAME;
  }

  @Override
  public String getVersion() {
    return VERSION;
  }

  @Override
  public URI getXmlNamespace() {
    return XML_NAMESPACE;
  }

  @Override
  public URI getJsonBaseUri() {
    return JSON_BASE_URI;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return null;
  }
}
