// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A standard format for the output of static analysis tools.
 */
@MetaschemaAssembly(
    formalName = "Static Analysis Results Interchange Format",
    description = "A standard format for the output of static analysis tools.",
    name = "sarif",
    moduleClass = SarifModule.class,
    rootName = "sarif",
    remarks = "Note, Metaschema does not support an anonymous top-level assembly without a key name in JSON and YAML, which is required for SARIF."
)
public class Sarif implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The version of the SARIF Model used for conforming instances.
   */
  @BoundField(
      formalName = "SARIF Model Version",
      description = "The version of the SARIF Model used for conforming instances.",
      useName = "version",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = @AllowedValue(value = "2.1.0", description = "")))
  )
  private String _version;

  /**
   * Describes a single run of an analysis tool, and contains the reported output of that run.
   */
  @BoundAssembly(
      formalName = "Run",
      description = "Describes a single run of an analysis tool, and contains the reported output of that run.",
      useName = "run",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "runs", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Run> _runs;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Sarif} instance with no metadata.
   */
  public Sarif() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Sarif} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Sarif(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal SARIF Model Version}".
   *
   * <p>
   * The version of the SARIF Model used for conforming instances.
   *
   * @return the version value, or {@code null} if not set
   */
  @Nullable
  public String getVersion() {
    return _version;
  }

  /**
   * Set the "{@literal SARIF Model Version}".
   *
   * <p>
   * The version of the SARIF Model used for conforming instances.
   *
   * @param value
   *           the version value to set, or {@code null} to clear
   */
  public void setVersion(@Nullable String value) {
    _version = value;
  }

  /**
   * Get the "{@literal Run}".
   *
   * <p>
   * Describes a single run of an analysis tool, and contains the reported output of that run.
   *
   * @return the run value
   */
  @NonNull
  public List<Run> getRuns() {
    if (_runs == null) {
      _runs = new LinkedList<>();
    }
    return ObjectUtils.notNull(_runs);
  }

  /**
   * Set the "{@literal Run}".
   *
   * <p>
   * Describes a single run of an analysis tool, and contains the reported output of that run.
   *
   * @param value
   *           the run value to set
   */
  public void setRuns(@NonNull List<Run> value) {
    _runs = value;
  }

  /**
   * Add a new {@link Run} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRun(Run item) {
    Run value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_runs == null) {
      _runs = new LinkedList<>();
    }
    return _runs.add(value);
  }

  /**
   * Remove the first matching {@link Run} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRun(Run item) {
    Run value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _runs != null && _runs.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
