// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.time.ZonedDateTime;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes a condition relevant to the tool itself, as opposed to being relevant to a target being analyzed by the tool.
 */
@MetaschemaAssembly(
    formalName = "Notification",
    description = "Describes a condition relevant to the tool itself, as opposed to being relevant to a target being analyzed by the tool.",
    name = "notification",
    moduleClass = SarifModule.class
)
public class Notification implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A message that describes the condition that was encountered.
   */
  @BoundAssembly(
      formalName = "Notification Message",
      description = "A message that describes the condition that was encountered.",
      useName = "message",
      minOccurs = 1
  )
  private Message _message;

  /**
   * The Coordinated Universal Time (UTC) date and time at which the analysis tool generated the notification.
   */
  @BoundField(
      formalName = "Time UTC",
      description = "The Coordinated Universal Time (UTC) date and time at which the analysis tool generated the notification.",
      useName = "timeUtc",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _timeUtc;

  /**
   * A reference used to locate the descriptor relevant to this notification.
   */
  @BoundAssembly(
      formalName = "Associated Rule",
      description = "A reference used to locate the descriptor relevant to this notification.",
      useName = "associatedRule"
  )
  private ReportingDescriptorReference _associatedRule;

  /**
   * Key/value pairs that provide additional information about the notification.
   */
  @BoundAssembly(
      formalName = "Properties",
      description = "Key/value pairs that provide additional information about the notification.",
      useName = "properties"
  )
  private PropertyBag _properties;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Notification} instance with no metadata.
   */
  public Notification() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Notification} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Notification(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Notification Message}".
   *
   * <p>
   * A message that describes the condition that was encountered.
   *
   * @return the message value
   */
  @NonNull
  public Message getMessage() {
    return _message;
  }

  /**
   * Set the "{@literal Notification Message}".
   *
   * <p>
   * A message that describes the condition that was encountered.
   *
   * @param value
   *           the message value to set
   */
  public void setMessage(@NonNull Message value) {
    _message = value;
  }

  /**
   * Get the "{@literal Time UTC}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the analysis tool generated the notification.
   *
   * @return the timeUtc value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getTimeUtc() {
    return _timeUtc;
  }

  /**
   * Set the "{@literal Time UTC}".
   *
   * <p>
   * The Coordinated Universal Time (UTC) date and time at which the analysis tool generated the notification.
   *
   * @param value
   *           the timeUtc value to set, or {@code null} to clear
   */
  public void setTimeUtc(@Nullable ZonedDateTime value) {
    _timeUtc = value;
  }

  /**
   * Get the "{@literal Associated Rule}".
   *
   * <p>
   * A reference used to locate the descriptor relevant to this notification.
   *
   * @return the associatedRule value, or {@code null} if not set
   */
  @Nullable
  public ReportingDescriptorReference getAssociatedRule() {
    return _associatedRule;
  }

  /**
   * Set the "{@literal Associated Rule}".
   *
   * <p>
   * A reference used to locate the descriptor relevant to this notification.
   *
   * @param value
   *           the associatedRule value to set, or {@code null} to clear
   */
  public void setAssociatedRule(@Nullable ReportingDescriptorReference value) {
    _associatedRule = value;
  }

  /**
   * Get the "{@literal Properties}".
   *
   * <p>
   * Key/value pairs that provide additional information about the notification.
   *
   * @return the properties value, or {@code null} if not set
   */
  @Nullable
  public PropertyBag getProperties() {
    return _properties;
  }

  /**
   * Set the "{@literal Properties}".
   *
   * <p>
   * Key/value pairs that provide additional information about the notification.
   *
   * @param value
   *           the properties value to set, or {@code null} to clear
   */
  public void setProperties(@Nullable PropertyBag value) {
    _properties = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
