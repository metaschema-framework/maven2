// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A location within a programming artifact.
 */
@MetaschemaAssembly(
    formalName = "Location",
    description = "A location within a programming artifact.",
    name = "location",
    moduleClass = SarifModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@id >= -1", message = "The id '{ . }' is not greater than or equal to '-1'."))
)
public class Location implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A value that distinguishes this location from all other locations within a single result object.
   */
  @BoundFlag(
      formalName = "Location Identifier",
      description = "A value that distinguishes this location from all other locations within a single result object.",
      name = "id",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class
  )
  private BigInteger _id;

  /**
   * A physical location relevant to a result. Specifies a reference to a programming artifact together with a range of bytes or characters within that artifact.
   */
  @BoundAssembly(
      formalName = "Physical Location",
      description = "A physical location relevant to a result. Specifies a reference to a programming artifact together with a range of bytes or characters within that artifact.",
      useName = "physicalLocation"
  )
  private PhysicalLocation _physicalLocation;

  /**
   * The logical locations associated with the result.
   */
  @BoundAssembly(
      formalName = "Logical Location",
      description = "The logical locations associated with the result.",
      useName = "logicalLocation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "logicalLocations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<LogicalLocation> _logicalLocations;

  /**
   * A message relevant to the location.
   */
  @BoundAssembly(
      formalName = "Location Message",
      description = "A message relevant to the location.",
      useName = "message"
  )
  private Message _message;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Location} instance with no metadata.
   */
  public Location() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Location} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Location(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Location Identifier}".
   *
   * <p>
   * A value that distinguishes this location from all other locations within a single result object.
   *
   * @return the id value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getId() {
    return _id;
  }

  /**
   * Set the "{@literal Location Identifier}".
   *
   * <p>
   * A value that distinguishes this location from all other locations within a single result object.
   *
   * @param value
   *           the id value to set, or {@code null} to clear
   */
  public void setId(@Nullable BigInteger value) {
    _id = value;
  }

  /**
   * Get the "{@literal Physical Location}".
   *
   * <p>
   * A physical location relevant to a result. Specifies a reference to a programming artifact together with a range of bytes or characters within that artifact.
   *
   * @return the physicalLocation value, or {@code null} if not set
   */
  @Nullable
  public PhysicalLocation getPhysicalLocation() {
    return _physicalLocation;
  }

  /**
   * Set the "{@literal Physical Location}".
   *
   * <p>
   * A physical location relevant to a result. Specifies a reference to a programming artifact together with a range of bytes or characters within that artifact.
   *
   * @param value
   *           the physicalLocation value to set, or {@code null} to clear
   */
  public void setPhysicalLocation(@Nullable PhysicalLocation value) {
    _physicalLocation = value;
  }

  /**
   * Get the "{@literal Logical Location}".
   *
   * <p>
   * The logical locations associated with the result.
   *
   * @return the logicalLocation value
   */
  @NonNull
  public List<LogicalLocation> getLogicalLocations() {
    if (_logicalLocations == null) {
      _logicalLocations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_logicalLocations);
  }

  /**
   * Set the "{@literal Logical Location}".
   *
   * <p>
   * The logical locations associated with the result.
   *
   * @param value
   *           the logicalLocation value to set
   */
  public void setLogicalLocations(@NonNull List<LogicalLocation> value) {
    _logicalLocations = value;
  }

  /**
   * Add a new {@link LogicalLocation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLogicalLocation(LogicalLocation item) {
    LogicalLocation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_logicalLocations == null) {
      _logicalLocations = new LinkedList<>();
    }
    return _logicalLocations.add(value);
  }

  /**
   * Remove the first matching {@link LogicalLocation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLogicalLocation(LogicalLocation item) {
    LogicalLocation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _logicalLocations != null && _logicalLocations.remove(value);
  }

  /**
   * Get the "{@literal Location Message}".
   *
   * <p>
   * A message relevant to the location.
   *
   * @return the message value, or {@code null} if not set
   */
  @Nullable
  public Message getMessage() {
    return _message;
  }

  /**
   * Set the "{@literal Location Message}".
   *
   * <p>
   * A message relevant to the location.
   *
   * @param value
   *           the message value to set, or {@code null} to clear
   */
  public void setMessage(@Nullable Message value) {
    _message = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
