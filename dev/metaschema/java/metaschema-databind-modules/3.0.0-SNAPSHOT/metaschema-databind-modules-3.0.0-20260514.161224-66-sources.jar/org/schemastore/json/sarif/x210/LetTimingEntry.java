// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Timing data for a single let-statement evaluation.
 */
@MetaschemaAssembly(
    formalName = "Let Statement Timing Entry",
    description = "Timing data for a single let-statement evaluation.",
    name = "letTimingEntry",
    moduleClass = SarifModule.class
)
public class LetTimingEntry implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The name of the let-statement variable.
   */
  @BoundFlag(
      formalName = "Let Statement Name",
      description = "The name of the let-statement variable.",
      name = "name",
      required = true,
      typeAdapter = StringAdapter.class
  )
  private String _name;

  /**
   * Performance timing measurements for this let-statement.
   */
  @BoundAssembly(
      formalName = "Timing Data",
      description = "Performance timing measurements for this let-statement.",
      useName = "timing"
  )
  private TimingData _timing;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.LetTimingEntry} instance with no metadata.
   */
  public LetTimingEntry() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.LetTimingEntry} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public LetTimingEntry(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Let Statement Name}".
   *
   * <p>
   * The name of the let-statement variable.
   *
   * @return the name value
   */
  @NonNull
  public String getName() {
    return _name;
  }

  /**
   * Set the "{@literal Let Statement Name}".
   *
   * <p>
   * The name of the let-statement variable.
   *
   * @param value
   *           the name value to set
   */
  public void setName(@NonNull String value) {
    _name = value;
  }

  /**
   * Get the "{@literal Timing Data}".
   *
   * <p>
   * Performance timing measurements for this let-statement.
   *
   * @return the timing value, or {@code null} if not set
   */
  @Nullable
  public TimingData getTiming() {
    return _timing;
  }

  /**
   * Set the "{@literal Timing Data}".
   *
   * <p>
   * Performance timing measurements for this let-statement.
   *
   * @param value
   *           the timing value to set, or {@code null} to clear
   */
  public void setTiming(@Nullable TimingData value) {
    _timing = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
