// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A logical location of a construct that produced a result.
 */
@MetaschemaAssembly(
    formalName = "Logical Location",
    description = "A logical location of a construct that produced a result.",
    name = "logicalLocation",
    moduleClass = SarifModule.class
)
public class LogicalLocation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Identifies the construct in which the result occurred. For example, this property might contain the name of a class or a method.
   */
  @BoundField(
      formalName = "Logical Location Name",
      description = "Identifies the construct in which the result occurred. For example, this property might contain the name of a class or a method.",
      useName = "name",
      typeAdapter = StringAdapter.class
  )
  private String _name;

  /**
   * The index within the logical locations array.
   */
  @BoundField(
      formalName = "Index",
      description = "The index within the logical locations array.",
      useName = "index",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class,
      valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@id >= -1", message = "The index '{ . }' is not greater than or equal to '-1'."))
  )
  private BigInteger _index;

  /**
   * The human-readable fully qualified name of the logical location.
   */
  @BoundField(
      formalName = "Fully Qualified Name",
      description = "The human-readable fully qualified name of the logical location.",
      useName = "fullyQualifiedName",
      typeAdapter = StringAdapter.class
  )
  private String _fullyQualifiedName;

  /**
   * The machine-readable name for the logical location, such as a mangled function name provided by a C++ compiler that encodes calling convention, return type and other details along with the function name.
   */
  @BoundField(
      formalName = "Decorated Name",
      description = "The machine-readable name for the logical location, such as a mangled function name provided by a C++ compiler that encodes calling convention, return type and other details along with the function name.",
      useName = "decoratedName",
      typeAdapter = StringAdapter.class
  )
  private String _decoratedName;

  /**
   * Identifies the index of the immediate parent of the construct in which the result was detected. For example, this property might point to a logical location that represents the namespace that holds a type.
   */
  @BoundField(
      formalName = "Parent Index",
      description = "Identifies the index of the immediate parent of the construct in which the result was detected. For example, this property might point to a logical location that represents the namespace that holds a type.",
      useName = "parentIndex",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class,
      valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@id >= -1", message = "The index '{ . }' is not greater than or equal to '-1'."))
  )
  private BigInteger _parentIndex;

  /**
   * The type of construct this logical location component refers to. Should be one of &lsquo;function&rsquo;, &lsquo;member&rsquo;, &lsquo;module&rsquo;, &lsquo;namespace&rsquo;, &lsquo;parameter&rsquo;, &lsquo;resource&rsquo;, &lsquo;returnType&rsquo;, &lsquo;type&rsquo;, &lsquo;variable&rsquo;, &lsquo;object&rsquo;, &lsquo;array&rsquo;, &lsquo;property&rsquo;, &lsquo;value&rsquo;, &lsquo;element&rsquo;, &lsquo;text&rsquo;, &lsquo;attribute&rsquo;, &lsquo;comment&rsquo;, &lsquo;declaration&rsquo;, &lsquo;dtd&rsquo; or &lsquo;processingInstruction&rsquo;, if any of those accurately describe the construct.
   */
  @BoundField(
      formalName = "Kind",
      description = "The type of construct this logical location component refers to. Should be one of 'function', 'member', 'module', 'namespace', 'parameter', 'resource', 'returnType', 'type', 'variable', 'object', 'array', 'property', 'value', 'element', 'text', 'attribute', 'comment', 'declaration', 'dtd' or 'processingInstruction', if any of those accurately describe the construct.",
      useName = "kind",
      typeAdapter = StringAdapter.class
  )
  private String _kind;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.LogicalLocation} instance with no metadata.
   */
  public LogicalLocation() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.LogicalLocation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public LogicalLocation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Logical Location Name}".
   *
   * <p>
   * Identifies the construct in which the result occurred. For example, this property might contain the name of a class or a method.
   *
   * @return the name value, or {@code null} if not set
   */
  @Nullable
  public String getName() {
    return _name;
  }

  /**
   * Set the "{@literal Logical Location Name}".
   *
   * <p>
   * Identifies the construct in which the result occurred. For example, this property might contain the name of a class or a method.
   *
   * @param value
   *           the name value to set, or {@code null} to clear
   */
  public void setName(@Nullable String value) {
    _name = value;
  }

  /**
   * Get the "{@literal Index}".
   *
   * <p>
   * The index within the logical locations array.
   *
   * @return the index value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getIndex() {
    return _index;
  }

  /**
   * Set the "{@literal Index}".
   *
   * <p>
   * The index within the logical locations array.
   *
   * @param value
   *           the index value to set, or {@code null} to clear
   */
  public void setIndex(@Nullable BigInteger value) {
    _index = value;
  }

  /**
   * Get the "{@literal Fully Qualified Name}".
   *
   * <p>
   * The human-readable fully qualified name of the logical location.
   *
   * @return the fullyQualifiedName value, or {@code null} if not set
   */
  @Nullable
  public String getFullyQualifiedName() {
    return _fullyQualifiedName;
  }

  /**
   * Set the "{@literal Fully Qualified Name}".
   *
   * <p>
   * The human-readable fully qualified name of the logical location.
   *
   * @param value
   *           the fullyQualifiedName value to set, or {@code null} to clear
   */
  public void setFullyQualifiedName(@Nullable String value) {
    _fullyQualifiedName = value;
  }

  /**
   * Get the "{@literal Decorated Name}".
   *
   * <p>
   * The machine-readable name for the logical location, such as a mangled function name provided by a C++ compiler that encodes calling convention, return type and other details along with the function name.
   *
   * @return the decoratedName value, or {@code null} if not set
   */
  @Nullable
  public String getDecoratedName() {
    return _decoratedName;
  }

  /**
   * Set the "{@literal Decorated Name}".
   *
   * <p>
   * The machine-readable name for the logical location, such as a mangled function name provided by a C++ compiler that encodes calling convention, return type and other details along with the function name.
   *
   * @param value
   *           the decoratedName value to set, or {@code null} to clear
   */
  public void setDecoratedName(@Nullable String value) {
    _decoratedName = value;
  }

  /**
   * Get the "{@literal Parent Index}".
   *
   * <p>
   * Identifies the index of the immediate parent of the construct in which the result was detected. For example, this property might point to a logical location that represents the namespace that holds a type.
   *
   * @return the parentIndex value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getParentIndex() {
    return _parentIndex;
  }

  /**
   * Set the "{@literal Parent Index}".
   *
   * <p>
   * Identifies the index of the immediate parent of the construct in which the result was detected. For example, this property might point to a logical location that represents the namespace that holds a type.
   *
   * @param value
   *           the parentIndex value to set, or {@code null} to clear
   */
  public void setParentIndex(@Nullable BigInteger value) {
    _parentIndex = value;
  }

  /**
   * Get the "{@literal Kind}".
   *
   * <p>
   * The type of construct this logical location component refers to. Should be one of &lsquo;function&rsquo;, &lsquo;member&rsquo;, &lsquo;module&rsquo;, &lsquo;namespace&rsquo;, &lsquo;parameter&rsquo;, &lsquo;resource&rsquo;, &lsquo;returnType&rsquo;, &lsquo;type&rsquo;, &lsquo;variable&rsquo;, &lsquo;object&rsquo;, &lsquo;array&rsquo;, &lsquo;property&rsquo;, &lsquo;value&rsquo;, &lsquo;element&rsquo;, &lsquo;text&rsquo;, &lsquo;attribute&rsquo;, &lsquo;comment&rsquo;, &lsquo;declaration&rsquo;, &lsquo;dtd&rsquo; or &lsquo;processingInstruction&rsquo;, if any of those accurately describe the construct.
   *
   * @return the kind value, or {@code null} if not set
   */
  @Nullable
  public String getKind() {
    return _kind;
  }

  /**
   * Set the "{@literal Kind}".
   *
   * <p>
   * The type of construct this logical location component refers to. Should be one of &lsquo;function&rsquo;, &lsquo;member&rsquo;, &lsquo;module&rsquo;, &lsquo;namespace&rsquo;, &lsquo;parameter&rsquo;, &lsquo;resource&rsquo;, &lsquo;returnType&rsquo;, &lsquo;type&rsquo;, &lsquo;variable&rsquo;, &lsquo;object&rsquo;, &lsquo;array&rsquo;, &lsquo;property&rsquo;, &lsquo;value&rsquo;, &lsquo;element&rsquo;, &lsquo;text&rsquo;, &lsquo;attribute&rsquo;, &lsquo;comment&rsquo;, &lsquo;declaration&rsquo;, &lsquo;dtd&rsquo; or &lsquo;processingInstruction&rsquo;, if any of those accurately describe the construct.
   *
   * @param value
   *           the kind value to set, or {@code null} to clear
   */
  public void setKind(@Nullable String value) {
    _kind = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
