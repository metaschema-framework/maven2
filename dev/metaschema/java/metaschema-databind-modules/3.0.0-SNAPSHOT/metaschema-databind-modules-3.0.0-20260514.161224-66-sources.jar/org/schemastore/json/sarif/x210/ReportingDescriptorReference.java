// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Information about how to locate a relevant reporting descriptor.
 */
@MetaschemaAssembly(
    formalName = "Reporting Descriptor Reference",
    description = "Information about how to locate a relevant reporting descriptor.",
    name = "reportingDescriptorReference",
    moduleClass = SarifModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@id|@guid|index", message = "At least one id, guid, or index must be provided."))
)
public class ReportingDescriptorReference implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The id of the descriptor.
   */
  @BoundFlag(
      formalName = "Reporting Descriptor Identifier",
      description = "The id of the descriptor.",
      name = "id",
      required = true,
      typeAdapter = StringAdapter.class
  )
  private String _id;

  /**
   * A stable, unique identifier for the reporting descriptor.
   */
  @BoundFlag(
      formalName = "Reporting Descriptor Unique Identifier",
      description = "A stable, unique identifier for the reporting descriptor.",
      name = "guid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _guid;

  /**
   * The index into an array of descriptors in toolComponent.ruleDescriptors, toolComponent.notificationDescriptors, or toolComponent.taxonomyDescriptors, depending on context.
   */
  @BoundField(
      formalName = "Index",
      description = "The index into an array of descriptors in toolComponent.ruleDescriptors, toolComponent.notificationDescriptors, or toolComponent.taxonomyDescriptors, depending on context.",
      useName = "index",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class
  )
  private BigInteger _index;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ReportingDescriptorReference} instance with no metadata.
   */
  public ReportingDescriptorReference() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ReportingDescriptorReference} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ReportingDescriptorReference(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Reporting Descriptor Identifier}".
   *
   * <p>
   * The id of the descriptor.
   *
   * @return the id value
   */
  @NonNull
  public String getId() {
    return _id;
  }

  /**
   * Set the "{@literal Reporting Descriptor Identifier}".
   *
   * <p>
   * The id of the descriptor.
   *
   * @param value
   *           the id value to set
   */
  public void setId(@NonNull String value) {
    _id = value;
  }

  /**
   * Get the "{@literal Reporting Descriptor Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the reporting descriptor.
   *
   * @return the guid value, or {@code null} if not set
   */
  @Nullable
  public UUID getGuid() {
    return _guid;
  }

  /**
   * Set the "{@literal Reporting Descriptor Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the reporting descriptor.
   *
   * @param value
   *           the guid value to set, or {@code null} to clear
   */
  public void setGuid(@Nullable UUID value) {
    _guid = value;
  }

  /**
   * Get the "{@literal Index}".
   *
   * <p>
   * The index into an array of descriptors in toolComponent.ruleDescriptors, toolComponent.notificationDescriptors, or toolComponent.taxonomyDescriptors, depending on context.
   *
   * @return the index value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getIndex() {
    return _index;
  }

  /**
   * Set the "{@literal Index}".
   *
   * <p>
   * The index into an array of descriptors in toolComponent.ruleDescriptors, toolComponent.notificationDescriptors, or toolComponent.taxonomyDescriptors, depending on context.
   *
   * @param value
   *           the index value to set, or {@code null} to clear
   */
  public void setIndex(@Nullable BigInteger value) {
    _index = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
