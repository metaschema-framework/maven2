// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A physical location relevant to a result. Specifies a reference to a programming artifact together with a range of bytes or characters within that artifact.
 */
@MetaschemaAssembly(
    formalName = "Physical Location",
    description = "A physical location relevant to a result. Specifies a reference to a programming artifact together with a range of bytes or characters within that artifact.",
    name = "physicalLocation",
    moduleClass = SarifModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "exists(address|artifactLocation)", message = "At least one address or artifactLocation must be provided."))
)
public class PhysicalLocation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A physical or virtual address, or a range of addresses, in an &lsquo;addressable region&rsquo; (memory or a binary file).
   */
  @BoundAssembly(
      formalName = "Address",
      description = "A physical or virtual address, or a range of addresses, in an 'addressable region' (memory or a binary file).",
      useName = "address"
  )
  private Address _address;

  /**
   * The location of the artifact.
   */
  @BoundAssembly(
      formalName = "Artifact Location",
      description = "The location of the artifact.",
      useName = "artifactLocation"
  )
  private ArtifactLocation _artifactLocation;

  /**
   * Specifies a portion of the artifact.
   */
  @BoundAssembly(
      formalName = "Region",
      description = "Specifies a portion of the artifact.",
      useName = "region"
  )
  private Region _region;

  /**
   * Specifies a portion of the artifact that encloses the region. Allows a viewer to display additional context around the region.
   */
  @BoundAssembly(
      formalName = "Context Region",
      description = "Specifies a portion of the artifact that encloses the region. Allows a viewer to display additional context around the region.",
      useName = "contextRegion"
  )
  private Region _contextRegion;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.PhysicalLocation} instance with no metadata.
   */
  public PhysicalLocation() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.PhysicalLocation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public PhysicalLocation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Address}".
   *
   * <p>
   * A physical or virtual address, or a range of addresses, in an &lsquo;addressable region&rsquo; (memory or a binary file).
   *
   * @return the address value, or {@code null} if not set
   */
  @Nullable
  public Address getAddress() {
    return _address;
  }

  /**
   * Set the "{@literal Address}".
   *
   * <p>
   * A physical or virtual address, or a range of addresses, in an &lsquo;addressable region&rsquo; (memory or a binary file).
   *
   * @param value
   *           the address value to set, or {@code null} to clear
   */
  public void setAddress(@Nullable Address value) {
    _address = value;
  }

  /**
   * Get the "{@literal Artifact Location}".
   *
   * <p>
   * The location of the artifact.
   *
   * @return the artifactLocation value, or {@code null} if not set
   */
  @Nullable
  public ArtifactLocation getArtifactLocation() {
    return _artifactLocation;
  }

  /**
   * Set the "{@literal Artifact Location}".
   *
   * <p>
   * The location of the artifact.
   *
   * @param value
   *           the artifactLocation value to set, or {@code null} to clear
   */
  public void setArtifactLocation(@Nullable ArtifactLocation value) {
    _artifactLocation = value;
  }

  /**
   * Get the "{@literal Region}".
   *
   * <p>
   * Specifies a portion of the artifact.
   *
   * @return the region value, or {@code null} if not set
   */
  @Nullable
  public Region getRegion() {
    return _region;
  }

  /**
   * Set the "{@literal Region}".
   *
   * <p>
   * Specifies a portion of the artifact.
   *
   * @param value
   *           the region value to set, or {@code null} to clear
   */
  public void setRegion(@Nullable Region value) {
    _region = value;
  }

  /**
   * Get the "{@literal Context Region}".
   *
   * <p>
   * Specifies a portion of the artifact that encloses the region. Allows a viewer to display additional context around the region.
   *
   * @return the contextRegion value, or {@code null} if not set
   */
  @Nullable
  public Region getContextRegion() {
    return _contextRegion;
  }

  /**
   * Set the "{@literal Context Region}".
   *
   * <p>
   * Specifies a portion of the artifact that encloses the region. Allows a viewer to display additional context around the region.
   *
   * @param value
   *           the contextRegion value to set, or {@code null} to clear
   */
  public void setContextRegion(@Nullable Region value) {
    _contextRegion = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * A physical or virtual address, or a range of addresses, in an &lsquo;addressable region&rsquo; (memory or a binary file).
   */
  @MetaschemaAssembly(
      formalName = "Address",
      description = "A physical or virtual address, or a range of addresses, in an 'addressable region' (memory or a binary file).",
      name = "address",
      moduleClass = SarifModule.class
  )
  public static class Address implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * Constructs a new {@code org.schemastore.json.sarif.x210.PhysicalLocation.Address} instance with no metadata.
     */
    public Address() {
      this(null);
    }

    /**
     * Constructs a new {@code org.schemastore.json.sarif.x210.PhysicalLocation.Address} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Address(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
