// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Encapsulates a message intended to be read by the end user.
 */
@MetaschemaAssembly(
    formalName = "Message",
    description = "Encapsulates a message intended to be read by the end user.",
    name = "message",
    moduleClass = SarifModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "exists(@id|text)", message = "At least one id or text must be provided."))
)
public class Message implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The id of the message.
   */
  @BoundFlag(
      formalName = "Message Identifier",
      description = "The id of the message.",
      name = "id",
      required = true,
      typeAdapter = StringAdapter.class
  )
  private String _id;

  /**
   * A plain text message string.
   */
  @BoundField(
      formalName = "Text",
      description = "A plain text message string.",
      useName = "text",
      typeAdapter = StringAdapter.class
  )
  private String _text;

  /**
   * A Markdown message string.
   */
  @BoundField(
      formalName = "Markdown",
      description = "A Markdown message string.",
      useName = "markdown",
      typeAdapter = StringAdapter.class
  )
  private String _markdown;

  /**
   * A sequence of strings to substitute into the message string.
   */
  @BoundField(
      formalName = "Argument",
      description = "A sequence of strings to substitute into the message string.",
      useName = "argument",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "arguments", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = StringAdapter.class
  )
  private List<String> _arguments;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Message} instance with no metadata.
   */
  public Message() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Message} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Message(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Message Identifier}".
   *
   * <p>
   * The id of the message.
   *
   * @return the id value
   */
  @NonNull
  public String getId() {
    return _id;
  }

  /**
   * Set the "{@literal Message Identifier}".
   *
   * <p>
   * The id of the message.
   *
   * @param value
   *           the id value to set
   */
  public void setId(@NonNull String value) {
    _id = value;
  }

  /**
   * Get the "{@literal Text}".
   *
   * <p>
   * A plain text message string.
   *
   * @return the text value, or {@code null} if not set
   */
  @Nullable
  public String getText() {
    return _text;
  }

  /**
   * Set the "{@literal Text}".
   *
   * <p>
   * A plain text message string.
   *
   * @param value
   *           the text value to set, or {@code null} to clear
   */
  public void setText(@Nullable String value) {
    _text = value;
  }

  /**
   * Get the "{@literal Markdown}".
   *
   * <p>
   * A Markdown message string.
   *
   * @return the markdown value, or {@code null} if not set
   */
  @Nullable
  public String getMarkdown() {
    return _markdown;
  }

  /**
   * Set the "{@literal Markdown}".
   *
   * <p>
   * A Markdown message string.
   *
   * @param value
   *           the markdown value to set, or {@code null} to clear
   */
  public void setMarkdown(@Nullable String value) {
    _markdown = value;
  }

  /**
   * Get the "{@literal Argument}".
   *
   * <p>
   * A sequence of strings to substitute into the message string.
   *
   * @return the argument value
   */
  @NonNull
  public List<String> getArguments() {
    if (_arguments == null) {
      _arguments = new LinkedList<>();
    }
    return ObjectUtils.notNull(_arguments);
  }

  /**
   * Set the "{@literal Argument}".
   *
   * <p>
   * A sequence of strings to substitute into the message string.
   *
   * @param value
   *           the argument value to set
   */
  public void setArguments(@NonNull List<String> value) {
    _arguments = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addArgument(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_arguments == null) {
      _arguments = new LinkedList<>();
    }
    return _arguments.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeArgument(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _arguments != null && _arguments.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
