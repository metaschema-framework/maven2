// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.datatype.adapter.NonNegativeIntegerAdapter;
import dev.metaschema.core.datatype.adapter.PositiveIntegerAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A region within an artifact where a result was detected.
 */
@MetaschemaAssembly(
    formalName = "Region",
    description = "A region within an artifact where a result was detected.",
    name = "region",
    moduleClass = SarifModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "exists(startLine|charOffset|byteOffset)", message = "At least a startLine, charOffset, or byteOffset must be provided."))
)
public class Region implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The line number of the first character in the region.
   */
  @BoundField(
      formalName = "Start Line",
      description = "The line number of the first character in the region.",
      useName = "startLine",
      typeAdapter = PositiveIntegerAdapter.class
  )
  private BigInteger _startLine;

  /**
   * The column number of the first character in the region.
   */
  @BoundField(
      formalName = "Start Column",
      description = "The column number of the first character in the region.",
      useName = "startColumn",
      typeAdapter = PositiveIntegerAdapter.class
  )
  private BigInteger _startColumn;

  /**
   * The line number of the last character in the region.
   */
  @BoundField(
      formalName = "End Line",
      description = "The line number of the last character in the region.",
      useName = "endLine",
      typeAdapter = PositiveIntegerAdapter.class
  )
  private BigInteger _endLine;

  /**
   * The column number of the character following the end of the region.
   */
  @BoundField(
      formalName = "End Column",
      description = "The column number of the character following the end of the region.",
      useName = "endColumn",
      typeAdapter = PositiveIntegerAdapter.class
  )
  private BigInteger _endColumn;

  /**
   * The zero-based offset from the beginning of the artifact of the first character in the region.
   */
  @BoundField(
      formalName = "Character Offset",
      description = "The zero-based offset from the beginning of the artifact of the first character in the region.",
      useName = "charOffset",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class,
      valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@id >= -1", message = "The offset '{ . }' is not greater than or equal to '-1'."))
  )
  private BigInteger _charOffset;

  /**
   * The length of the region in characters.
   */
  @BoundField(
      formalName = "Character Length",
      description = "The length of the region in characters.",
      useName = "charLength",
      typeAdapter = NonNegativeIntegerAdapter.class
  )
  private BigInteger _charLength;

  /**
   * The zero-based offset from the beginning of the artifact of the first byte in the region
   */
  @BoundField(
      formalName = "Byte Offset",
      description = "The zero-based offset from the beginning of the artifact of the first byte in the region",
      useName = "byteOffset",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class,
      valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@id >= -1", message = "The offset '{ . }' is not greater than or equal to '-1'."))
  )
  private BigInteger _byteOffset;

  /**
   * The length of the region in bytes.
   */
  @BoundField(
      formalName = "Byte Length",
      description = "The length of the region in bytes.",
      useName = "byteLength",
      typeAdapter = NonNegativeIntegerAdapter.class
  )
  private BigInteger _byteLength;

  /**
   * A message relevant to the region.
   */
  @BoundAssembly(
      formalName = "Region Message",
      description = "A message relevant to the region.",
      useName = "message"
  )
  private Message _message;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Region} instance with no metadata.
   */
  public Region() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Region} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Region(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Start Line}".
   *
   * <p>
   * The line number of the first character in the region.
   *
   * @return the startLine value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getStartLine() {
    return _startLine;
  }

  /**
   * Set the "{@literal Start Line}".
   *
   * <p>
   * The line number of the first character in the region.
   *
   * @param value
   *           the startLine value to set, or {@code null} to clear
   */
  public void setStartLine(@Nullable BigInteger value) {
    _startLine = value;
  }

  /**
   * Get the "{@literal Start Column}".
   *
   * <p>
   * The column number of the first character in the region.
   *
   * @return the startColumn value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getStartColumn() {
    return _startColumn;
  }

  /**
   * Set the "{@literal Start Column}".
   *
   * <p>
   * The column number of the first character in the region.
   *
   * @param value
   *           the startColumn value to set, or {@code null} to clear
   */
  public void setStartColumn(@Nullable BigInteger value) {
    _startColumn = value;
  }

  /**
   * Get the "{@literal End Line}".
   *
   * <p>
   * The line number of the last character in the region.
   *
   * @return the endLine value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getEndLine() {
    return _endLine;
  }

  /**
   * Set the "{@literal End Line}".
   *
   * <p>
   * The line number of the last character in the region.
   *
   * @param value
   *           the endLine value to set, or {@code null} to clear
   */
  public void setEndLine(@Nullable BigInteger value) {
    _endLine = value;
  }

  /**
   * Get the "{@literal End Column}".
   *
   * <p>
   * The column number of the character following the end of the region.
   *
   * @return the endColumn value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getEndColumn() {
    return _endColumn;
  }

  /**
   * Set the "{@literal End Column}".
   *
   * <p>
   * The column number of the character following the end of the region.
   *
   * @param value
   *           the endColumn value to set, or {@code null} to clear
   */
  public void setEndColumn(@Nullable BigInteger value) {
    _endColumn = value;
  }

  /**
   * Get the "{@literal Character Offset}".
   *
   * <p>
   * The zero-based offset from the beginning of the artifact of the first character in the region.
   *
   * @return the charOffset value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getCharOffset() {
    return _charOffset;
  }

  /**
   * Set the "{@literal Character Offset}".
   *
   * <p>
   * The zero-based offset from the beginning of the artifact of the first character in the region.
   *
   * @param value
   *           the charOffset value to set, or {@code null} to clear
   */
  public void setCharOffset(@Nullable BigInteger value) {
    _charOffset = value;
  }

  /**
   * Get the "{@literal Character Length}".
   *
   * <p>
   * The length of the region in characters.
   *
   * @return the charLength value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getCharLength() {
    return _charLength;
  }

  /**
   * Set the "{@literal Character Length}".
   *
   * <p>
   * The length of the region in characters.
   *
   * @param value
   *           the charLength value to set, or {@code null} to clear
   */
  public void setCharLength(@Nullable BigInteger value) {
    _charLength = value;
  }

  /**
   * Get the "{@literal Byte Offset}".
   *
   * <p>
   * The zero-based offset from the beginning of the artifact of the first byte in the region
   *
   * @return the byteOffset value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getByteOffset() {
    return _byteOffset;
  }

  /**
   * Set the "{@literal Byte Offset}".
   *
   * <p>
   * The zero-based offset from the beginning of the artifact of the first byte in the region
   *
   * @param value
   *           the byteOffset value to set, or {@code null} to clear
   */
  public void setByteOffset(@Nullable BigInteger value) {
    _byteOffset = value;
  }

  /**
   * Get the "{@literal Byte Length}".
   *
   * <p>
   * The length of the region in bytes.
   *
   * @return the byteLength value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getByteLength() {
    return _byteLength;
  }

  /**
   * Set the "{@literal Byte Length}".
   *
   * <p>
   * The length of the region in bytes.
   *
   * @param value
   *           the byteLength value to set, or {@code null} to clear
   */
  public void setByteLength(@Nullable BigInteger value) {
    _byteLength = value;
  }

  /**
   * Get the "{@literal Region Message}".
   *
   * <p>
   * A message relevant to the region.
   *
   * @return the message value, or {@code null} if not set
   */
  @Nullable
  public Message getMessage() {
    return _message;
  }

  /**
   * Set the "{@literal Region Message}".
   *
   * <p>
   * A message relevant to the region.
   *
   * @param value
   *           the message value to set, or {@code null} to clear
   */
  public void setMessage(@Nullable Message value) {
    _message = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
