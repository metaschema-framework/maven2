// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IAnyContent;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAny;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Key/value pairs that provide additional information about the object.
 */
@MetaschemaAssembly(
    formalName = "Property Bag",
    description = "Key/value pairs that provide additional information about the object.",
    name = "propertyBag",
    moduleClass = SarifModule.class
)
public class PropertyBag implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A set of distinct strings that provide additional information.
   */
  @BoundField(
      formalName = "Tag",
      description = "A set of distinct strings that provide additional information.",
      useName = "tag",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "tags", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = StringAdapter.class
  )
  private List<String> _tags;

  /**
   * Performance timing measurements for the associated item.
   */
  @BoundAssembly(
      formalName = "Timing Data",
      description = "Performance timing measurements for the associated item.",
      useName = "timing"
  )
  private TimingData _timing;

  /**
   * Per-let-statement timing data for the associated constraint evaluation.
   */
  @BoundAssembly(
      formalName = "Let Statement Timings",
      description = "Per-let-statement timing data for the associated constraint evaluation.",
      useName = "letTimingEntry",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "letTimings", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<LetTimingEntry> _letTimings;

  /**
   * Captures unmodeled content not defined by the Metaschema model.
   */
  @BoundAny
  private IAnyContent _any;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.PropertyBag} instance with no metadata.
   */
  public PropertyBag() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.PropertyBag} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public PropertyBag(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Tag}".
   *
   * <p>
   * A set of distinct strings that provide additional information.
   *
   * @return the tag value
   */
  @NonNull
  public List<String> getTags() {
    if (_tags == null) {
      _tags = new LinkedList<>();
    }
    return ObjectUtils.notNull(_tags);
  }

  /**
   * Set the "{@literal Tag}".
   *
   * <p>
   * A set of distinct strings that provide additional information.
   *
   * @param value
   *           the tag value to set
   */
  public void setTags(@NonNull List<String> value) {
    _tags = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addTag(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_tags == null) {
      _tags = new LinkedList<>();
    }
    return _tags.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeTag(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _tags != null && _tags.remove(value);
  }

  /**
   * Get the "{@literal Timing Data}".
   *
   * <p>
   * Performance timing measurements for the associated item.
   *
   * @return the timing value, or {@code null} if not set
   */
  @Nullable
  public TimingData getTiming() {
    return _timing;
  }

  /**
   * Set the "{@literal Timing Data}".
   *
   * <p>
   * Performance timing measurements for the associated item.
   *
   * @param value
   *           the timing value to set, or {@code null} to clear
   */
  public void setTiming(@Nullable TimingData value) {
    _timing = value;
  }

  /**
   * Get the "{@literal Let Statement Timings}".
   *
   * <p>
   * Per-let-statement timing data for the associated constraint evaluation.
   *
   * @return the letTimingEntry value
   */
  @NonNull
  public List<LetTimingEntry> getLetTimings() {
    if (_letTimings == null) {
      _letTimings = new LinkedList<>();
    }
    return ObjectUtils.notNull(_letTimings);
  }

  /**
   * Set the "{@literal Let Statement Timings}".
   *
   * <p>
   * Per-let-statement timing data for the associated constraint evaluation.
   *
   * @param value
   *           the letTimingEntry value to set
   */
  public void setLetTimings(@NonNull List<LetTimingEntry> value) {
    _letTimings = value;
  }

  /**
   * Add a new {@link LetTimingEntry} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLetTimingEntry(LetTimingEntry item) {
    LetTimingEntry value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_letTimings == null) {
      _letTimings = new LinkedList<>();
    }
    return _letTimings.add(value);
  }

  /**
   * Remove the first matching {@link LetTimingEntry} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLetTimingEntry(LetTimingEntry item) {
    LetTimingEntry value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _letTimings != null && _letTimings.remove(value);
  }

  /**
   * Get the unmodeled content.
   *
   * @return the unmodeled content, or {@code null} if not set
   */
  @Nullable
  public IAnyContent getAny() {
    return _any;
  }

  /**
   * Set the unmodeled content.
   *
   * @param value
   *           the unmodeled content to set
   */
  public void setAny(@Nullable IAnyContent value) {
    _any = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
