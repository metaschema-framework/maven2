// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A message string or message format string rendered in multiple formats.
 */
@MetaschemaAssembly(
    formalName = "Multi-format Message String",
    description = "A message string or message format string rendered in multiple formats.",
    name = "multiformatMessageString",
    moduleClass = SarifModule.class
)
public class MultiformatMessageString implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A plain text message string or format string.
   */
  @BoundField(
      formalName = "Text",
      description = "A plain text message string or format string.",
      useName = "text",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _text;

  /**
   * A Markdown message string or format string.
   */
  @BoundField(
      formalName = "Markdown",
      description = "A Markdown message string or format string.",
      useName = "markdown",
      typeAdapter = StringAdapter.class
  )
  private String _markdown;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.MultiformatMessageString} instance with no metadata.
   */
  public MultiformatMessageString() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.MultiformatMessageString} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public MultiformatMessageString(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Text}".
   *
   * <p>
   * A plain text message string or format string.
   *
   * @return the text value
   */
  @NonNull
  public String getText() {
    return _text;
  }

  /**
   * Set the "{@literal Text}".
   *
   * <p>
   * A plain text message string or format string.
   *
   * @param value
   *           the text value to set
   */
  public void setText(@NonNull String value) {
    _text = value;
  }

  /**
   * Get the "{@literal Markdown}".
   *
   * <p>
   * A Markdown message string or format string.
   *
   * @return the markdown value, or {@code null} if not set
   */
  @Nullable
  public String getMarkdown() {
    return _markdown;
  }

  /**
   * Set the "{@literal Markdown}".
   *
   * <p>
   * A Markdown message string or format string.
   *
   * @param value
   *           the markdown value to set, or {@code null} to clear
   */
  public void setMarkdown(@Nullable String value) {
    _markdown = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
