// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
/**
 * Provides generated Metaschema binding classes for module(s): SARIF Metaschema Module.
 * <p>
 * version 0.1.0
 */
@dev.metaschema.databind.model.annotations.MetaschemaPackage(moduleClass = {
  org.schemastore.json.sarif.x210.SarifModule.class})
@dev.metaschema.databind.model.annotations.XmlSchema(namespace = "https://json.schemastore.org/sarif/2.1.0", xmlns = {@dev.metaschema.databind.model.annotations.XmlNs(prefix = "", namespace = "https://json.schemastore.org/sarif/2.1.0")}, xmlElementFormDefault = dev.metaschema.databind.model.annotations.XmlNsForm.QUALIFIED)
package org.schemastore.json.sarif.x210;
