// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Artifacts analyzed by the tool to yield results.
 */
@MetaschemaAssembly(
    formalName = "Artifacts",
    description = "Artifacts analyzed by the tool to yield results.",
    name = "artifact",
    moduleClass = SarifModule.class
)
public class Artifact implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The location of the artifact.
   */
  @BoundAssembly(
      formalName = "Artifact Location",
      description = "The location of the artifact.",
      useName = "location"
  )
  private ArtifactLocation _location;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Artifact} instance with no metadata.
   */
  public Artifact() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Artifact} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Artifact(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Artifact Location}".
   *
   * <p>
   * The location of the artifact.
   *
   * @return the location value, or {@code null} if not set
   */
  @Nullable
  public ArtifactLocation getLocation() {
    return _location;
  }

  /**
   * Set the "{@literal Artifact Location}".
   *
   * <p>
   * The location of the artifact.
   *
   * @param value
   *           the location value to set, or {@code null} to clear
   */
  public void setLocation(@Nullable ArtifactLocation value) {
    _location = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
