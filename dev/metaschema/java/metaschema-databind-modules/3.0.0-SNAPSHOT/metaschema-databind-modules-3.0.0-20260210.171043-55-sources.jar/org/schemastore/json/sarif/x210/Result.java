// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.datatype.adapter.PositiveIntegerAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Results from the run of a tool.
 */
@MetaschemaAssembly(
    formalName = "Results",
    description = "Results from the run of a tool.",
    name = "result",
    moduleClass = SarifModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(level = IConstraint.Level.ERROR, test = "@ruleIndex >= -1", message = "The value '{ . }' is not greater than or equal to '-1'."))
)
public class Result implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The stable, unique identifier of the rule, if any, to which this result is relevant.
   */
  @BoundFlag(
      formalName = "Rule Identifier",
      description = "The stable, unique identifier of the rule, if any, to which this result is relevant.",
      name = "ruleId",
      typeAdapter = StringAdapter.class
  )
  private String _ruleId;

  /**
   * The stable, unique identifier of the rule, if any, to which this result is relevant.
   */
  @BoundFlag(
      formalName = "Rule Identifier",
      description = "The stable, unique identifier of the rule, if any, to which this result is relevant.",
      name = "ruleIndex",
      defaultValue = "-1",
      typeAdapter = IntegerAdapter.class
  )
  private BigInteger _ruleIndex;

  /**
   * A stable, unique identifier for the result.
   */
  @BoundFlag(
      formalName = "Result Unique Identifier",
      description = "A stable, unique identifier for the result.",
      name = "guid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _guid;

  /**
   * A reference used to locate the rule descriptor relevant to this result.
   */
  @BoundAssembly(
      formalName = "Reporting Descriptor Reference",
      description = "A reference used to locate the rule descriptor relevant to this result.",
      useName = "rule"
  )
  private ReportingDescriptorReference _rule;

  /**
   * A value that categorizes results by evaluation state.
   */
  @BoundField(
      formalName = "Result Kind",
      description = "A value that categorizes results by evaluation state.",
      useName = "kind",
      defaultValue = "fail",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "notApplicable", description = ""), @AllowedValue(value = "pass", description = ""), @AllowedValue(value = "fail", description = ""), @AllowedValue(value = "review", description = ""), @AllowedValue(value = "open", description = ""), @AllowedValue(value = "informational", description = "")}))
  )
  private String _kind;

  /**
   * A value specifying the severity level of the result.
   */
  @BoundField(
      formalName = "Severity Level",
      description = "A value specifying the severity level of the result.",
      useName = "level",
      defaultValue = "warning",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "none", description = ""), @AllowedValue(value = "note", description = ""), @AllowedValue(value = "warning", description = ""), @AllowedValue(value = "error", description = "")}))
  )
  private String _level;

  /**
   * A message that describes the result. The first sentence of the message only will be displayed when visible space is limited.
   */
  @BoundAssembly(
      formalName = "Result Message",
      description = "A message that describes the result. The first sentence of the message only will be displayed when visible space is limited.",
      useName = "message"
  )
  private Message _message;

  /**
   * Identifies the artifact that the analysis tool was instructed to scan. This need not be the same as the artifact where the result actually occurred.
   */
  @BoundAssembly(
      formalName = "Scanned Artifact",
      description = "Identifies the artifact that the analysis tool was instructed to scan. This need not be the same as the artifact where the result actually occurred.",
      useName = "analysisTarget"
  )
  private ArtifactLocation _analysisTarget;

  /**
   * The set of locations where the result was detected. Specify only one location unless the problem indicated by the result can only be corrected by making a change at every specified location.
   */
  @BoundAssembly(
      formalName = "Result Location",
      description = "The set of locations where the result was detected. Specify only one location unless the problem indicated by the result can only be corrected by making a change at every specified location.",
      useName = "location",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "locations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Location> _locations;

  /**
   * A positive integer specifying the number of times this logically unique result was observed in this run.
   */
  @BoundField(
      formalName = "Occurrence Count",
      description = "A positive integer specifying the number of times this logically unique result was observed in this run.",
      useName = "occurenceCount",
      typeAdapter = PositiveIntegerAdapter.class
  )
  private BigInteger _occurenceCount;

  /**
   * A set of locations relevant to this result.
   */
  @BoundAssembly(
      formalName = "Result Related Location",
      description = "A set of locations relevant to this result.",
      useName = "relatedLocation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "relatedLocations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Location> _relatedLocations;

  /**
   * Information about how and when the result was detected.
   */
  @BoundAssembly(
      formalName = "Result Provenance",
      description = "Information about how and when the result was detected.",
      useName = "provenance"
  )
  private ResultProvenance _provenance;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Result} instance with no metadata.
   */
  public Result() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Result} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Result(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Rule Identifier}".
   *
   * <p>
   * The stable, unique identifier of the rule, if any, to which this result is relevant.
   *
   * @return the ruleId value, or {@code null} if not set
   */
  @Nullable
  public String getRuleId() {
    return _ruleId;
  }

  /**
   * Set the "{@literal Rule Identifier}".
   *
   * <p>
   * The stable, unique identifier of the rule, if any, to which this result is relevant.
   *
   * @param value
   *           the ruleId value to set, or {@code null} to clear
   */
  public void setRuleId(@Nullable String value) {
    _ruleId = value;
  }

  /**
   * Get the "{@literal Rule Identifier}".
   *
   * <p>
   * The stable, unique identifier of the rule, if any, to which this result is relevant.
   *
   * @return the ruleIndex value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getRuleIndex() {
    return _ruleIndex;
  }

  /**
   * Set the "{@literal Rule Identifier}".
   *
   * <p>
   * The stable, unique identifier of the rule, if any, to which this result is relevant.
   *
   * @param value
   *           the ruleIndex value to set, or {@code null} to clear
   */
  public void setRuleIndex(@Nullable BigInteger value) {
    _ruleIndex = value;
  }

  /**
   * Get the "{@literal Result Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the result.
   *
   * @return the guid value, or {@code null} if not set
   */
  @Nullable
  public UUID getGuid() {
    return _guid;
  }

  /**
   * Set the "{@literal Result Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the result.
   *
   * @param value
   *           the guid value to set, or {@code null} to clear
   */
  public void setGuid(@Nullable UUID value) {
    _guid = value;
  }

  /**
   * Get the "{@literal Reporting Descriptor Reference}".
   *
   * <p>
   * A reference used to locate the rule descriptor relevant to this result.
   *
   * @return the rule value, or {@code null} if not set
   */
  @Nullable
  public ReportingDescriptorReference getRule() {
    return _rule;
  }

  /**
   * Set the "{@literal Reporting Descriptor Reference}".
   *
   * <p>
   * A reference used to locate the rule descriptor relevant to this result.
   *
   * @param value
   *           the rule value to set, or {@code null} to clear
   */
  public void setRule(@Nullable ReportingDescriptorReference value) {
    _rule = value;
  }

  /**
   * Get the "{@literal Result Kind}".
   *
   * <p>
   * A value that categorizes results by evaluation state.
   *
   * @return the kind value, or {@code null} if not set
   */
  @Nullable
  public String getKind() {
    return _kind;
  }

  /**
   * Set the "{@literal Result Kind}".
   *
   * <p>
   * A value that categorizes results by evaluation state.
   *
   * @param value
   *           the kind value to set, or {@code null} to clear
   */
  public void setKind(@Nullable String value) {
    _kind = value;
  }

  /**
   * Get the "{@literal Severity Level}".
   *
   * <p>
   * A value specifying the severity level of the result.
   *
   * @return the level value, or {@code null} if not set
   */
  @Nullable
  public String getLevel() {
    return _level;
  }

  /**
   * Set the "{@literal Severity Level}".
   *
   * <p>
   * A value specifying the severity level of the result.
   *
   * @param value
   *           the level value to set, or {@code null} to clear
   */
  public void setLevel(@Nullable String value) {
    _level = value;
  }

  /**
   * Get the "{@literal Result Message}".
   *
   * <p>
   * A message that describes the result. The first sentence of the message only will be displayed when visible space is limited.
   *
   * @return the message value, or {@code null} if not set
   */
  @Nullable
  public Message getMessage() {
    return _message;
  }

  /**
   * Set the "{@literal Result Message}".
   *
   * <p>
   * A message that describes the result. The first sentence of the message only will be displayed when visible space is limited.
   *
   * @param value
   *           the message value to set, or {@code null} to clear
   */
  public void setMessage(@Nullable Message value) {
    _message = value;
  }

  /**
   * Get the "{@literal Scanned Artifact}".
   *
   * <p>
   * Identifies the artifact that the analysis tool was instructed to scan. This need not be the same as the artifact where the result actually occurred.
   *
   * @return the analysisTarget value, or {@code null} if not set
   */
  @Nullable
  public ArtifactLocation getAnalysisTarget() {
    return _analysisTarget;
  }

  /**
   * Set the "{@literal Scanned Artifact}".
   *
   * <p>
   * Identifies the artifact that the analysis tool was instructed to scan. This need not be the same as the artifact where the result actually occurred.
   *
   * @param value
   *           the analysisTarget value to set, or {@code null} to clear
   */
  public void setAnalysisTarget(@Nullable ArtifactLocation value) {
    _analysisTarget = value;
  }

  /**
   * Get the "{@literal Result Location}".
   *
   * <p>
   * The set of locations where the result was detected. Specify only one location unless the problem indicated by the result can only be corrected by making a change at every specified location.
   *
   * @return the location value
   */
  @NonNull
  public List<Location> getLocations() {
    if (_locations == null) {
      _locations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_locations);
  }

  /**
   * Set the "{@literal Result Location}".
   *
   * <p>
   * The set of locations where the result was detected. Specify only one location unless the problem indicated by the result can only be corrected by making a change at every specified location.
   *
   * @param value
   *           the location value to set
   */
  public void setLocations(@NonNull List<Location> value) {
    _locations = value;
  }

  /**
   * Add a new {@link Location} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLocation(Location item) {
    Location value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_locations == null) {
      _locations = new LinkedList<>();
    }
    return _locations.add(value);
  }

  /**
   * Remove the first matching {@link Location} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLocation(Location item) {
    Location value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _locations != null && _locations.remove(value);
  }

  /**
   * Get the "{@literal Occurrence Count}".
   *
   * <p>
   * A positive integer specifying the number of times this logically unique result was observed in this run.
   *
   * @return the occurenceCount value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getOccurenceCount() {
    return _occurenceCount;
  }

  /**
   * Set the "{@literal Occurrence Count}".
   *
   * <p>
   * A positive integer specifying the number of times this logically unique result was observed in this run.
   *
   * @param value
   *           the occurenceCount value to set, or {@code null} to clear
   */
  public void setOccurenceCount(@Nullable BigInteger value) {
    _occurenceCount = value;
  }

  /**
   * Get the "{@literal Result Related Location}".
   *
   * <p>
   * A set of locations relevant to this result.
   *
   * @return the relatedLocation value
   */
  @NonNull
  public List<Location> getRelatedLocations() {
    if (_relatedLocations == null) {
      _relatedLocations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedLocations);
  }

  /**
   * Set the "{@literal Result Related Location}".
   *
   * <p>
   * A set of locations relevant to this result.
   *
   * @param value
   *           the relatedLocation value to set
   */
  public void setRelatedLocations(@NonNull List<Location> value) {
    _relatedLocations = value;
  }

  /**
   * Add a new {@link Location} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRelatedLocation(Location item) {
    Location value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedLocations == null) {
      _relatedLocations = new LinkedList<>();
    }
    return _relatedLocations.add(value);
  }

  /**
   * Remove the first matching {@link Location} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRelatedLocation(Location item) {
    Location value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedLocations != null && _relatedLocations.remove(value);
  }

  /**
   * Get the "{@literal Result Provenance}".
   *
   * <p>
   * Information about how and when the result was detected.
   *
   * @return the provenance value, or {@code null} if not set
   */
  @Nullable
  public ResultProvenance getProvenance() {
    return _provenance;
  }

  /**
   * Set the "{@literal Result Provenance}".
   *
   * <p>
   * Information about how and when the result was detected.
   *
   * @param value
   *           the provenance value to set, or {@code null} to clear
   */
  public void setProvenance(@Nullable ResultProvenance value) {
    _provenance = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
