// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes a single run of an analysis tool, and contains the reported output of that run.
 */
@MetaschemaAssembly(
    formalName = "Run",
    description = "Describes a single run of an analysis tool, and contains the reported output of that run.",
    name = "run",
    moduleClass = SarifModule.class
)
public class Run implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Information about the tool or tool pipeline that generated the results in this run. A run can only contain results produced by a single tool or tool pipeline. A run can aggregate results from multiple log files, as long as context around the tool run (tool command-line arguments and the like) is identical for all aggregated files.
   */
  @BoundAssembly(
      formalName = "Tool",
      description = "Information about the tool or tool pipeline that generated the results in this run. A run can only contain results produced by a single tool or tool pipeline. A run can aggregate results from multiple log files, as long as context around the tool run (tool command-line arguments and the like) is identical for all aggregated files.",
      useName = "tool"
  )
  private Tool _tool;

  /**
   * A sequence of artifacts relevant to the run.
   */
  @BoundAssembly(
      formalName = "Artifact",
      description = "A sequence of artifacts relevant to the run.",
      useName = "artifact",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "artifacts", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Artifact> _artifacts;

  /**
   * The set of results contained in an SARIF log. The results array can be omitted when a run is solely exporting rules metadata. It must be present (but may be empty) if a log file represents an actual scan.
   */
  @BoundAssembly(
      formalName = "Result",
      description = "The set of results contained in an SARIF log. The results array can be omitted when a run is solely exporting rules metadata. It must be present (but may be empty) if a log file represents an actual scan.",
      useName = "result",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "results", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Result> _results;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Run} instance with no metadata.
   */
  public Run() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.Run} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Run(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Tool}".
   *
   * <p>
   * Information about the tool or tool pipeline that generated the results in this run. A run can only contain results produced by a single tool or tool pipeline. A run can aggregate results from multiple log files, as long as context around the tool run (tool command-line arguments and the like) is identical for all aggregated files.
   *
   * @return the tool value, or {@code null} if not set
   */
  @Nullable
  public Tool getTool() {
    return _tool;
  }

  /**
   * Set the "{@literal Tool}".
   *
   * <p>
   * Information about the tool or tool pipeline that generated the results in this run. A run can only contain results produced by a single tool or tool pipeline. A run can aggregate results from multiple log files, as long as context around the tool run (tool command-line arguments and the like) is identical for all aggregated files.
   *
   * @param value
   *           the tool value to set, or {@code null} to clear
   */
  public void setTool(@Nullable Tool value) {
    _tool = value;
  }

  /**
   * Get the "{@literal Artifact}".
   *
   * <p>
   * A sequence of artifacts relevant to the run.
   *
   * @return the artifact value
   */
  @NonNull
  public List<Artifact> getArtifacts() {
    if (_artifacts == null) {
      _artifacts = new LinkedList<>();
    }
    return ObjectUtils.notNull(_artifacts);
  }

  /**
   * Set the "{@literal Artifact}".
   *
   * <p>
   * A sequence of artifacts relevant to the run.
   *
   * @param value
   *           the artifact value to set
   */
  public void setArtifacts(@NonNull List<Artifact> value) {
    _artifacts = value;
  }

  /**
   * Add a new {@link Artifact} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addArtifact(Artifact item) {
    Artifact value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_artifacts == null) {
      _artifacts = new LinkedList<>();
    }
    return _artifacts.add(value);
  }

  /**
   * Remove the first matching {@link Artifact} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeArtifact(Artifact item) {
    Artifact value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _artifacts != null && _artifacts.remove(value);
  }

  /**
   * Get the "{@literal Result}".
   *
   * <p>
   * The set of results contained in an SARIF log. The results array can be omitted when a run is solely exporting rules metadata. It must be present (but may be empty) if a log file represents an actual scan.
   *
   * @return the result value
   */
  @NonNull
  public List<Result> getResults() {
    if (_results == null) {
      _results = new LinkedList<>();
    }
    return ObjectUtils.notNull(_results);
  }

  /**
   * Set the "{@literal Result}".
   *
   * <p>
   * The set of results contained in an SARIF log. The results array can be omitted when a run is solely exporting rules metadata. It must be present (but may be empty) if a log file represents an actual scan.
   *
   * @param value
   *           the result value to set
   */
  public void setResults(@NonNull List<Result> value) {
    _results = value;
  }

  /**
   * Add a new {@link Result} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResult(Result item) {
    Result value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_results == null) {
      _results = new LinkedList<>();
    }
    return _results.add(value);
  }

  /**
   * Remove the first matching {@link Result} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResult(Result item) {
    Result value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _results != null && _results.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
