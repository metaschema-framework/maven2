// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Metadata that describes a specific report produced by the tool, as part of the analysis it provides or its runtime reporting.
 */
@MetaschemaAssembly(
    formalName = "Reporting Descriptor",
    description = "Metadata that describes a specific report produced by the tool, as part of the analysis it provides or its runtime reporting.",
    name = "reportingDescriptor",
    moduleClass = SarifModule.class
)
public class ReportingDescriptor implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A stable, opaque identifier for the report.
   */
  @BoundFlag(
      formalName = "Reporting Descriptor Identifier",
      description = "A stable, opaque identifier for the report.",
      name = "id",
      required = true,
      typeAdapter = StringAdapter.class
  )
  private String _id;

  /**
   * A stable, unique identifier for the reporting descriptor.
   */
  @BoundFlag(
      formalName = "Reporting Descriptor Unique Identifier",
      description = "A stable, unique identifier for the reporting descriptor.",
      name = "guid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _guid;

  /**
   * A report identifier that is understandable to an end user.
   */
  @BoundField(
      formalName = "Reporting Descriptor Name",
      description = "A report identifier that is understandable to an end user.",
      useName = "name",
      typeAdapter = StringAdapter.class
  )
  private String _name;

  /**
   * A concise description of the report. Should be a single sentence that is understandable when visible space is limited to a single line of text.
   */
  @BoundAssembly(
      formalName = "Short Description",
      description = "A concise description of the report. Should be a single sentence that is understandable when visible space is limited to a single line of text.",
      useName = "shortDescription"
  )
  private MultiformatMessageString _shortDescription;

  /**
   * A description of the report. Should, as far as possible, provide details sufficient to enable resolution of any problem indicated by the result.
   */
  @BoundAssembly(
      formalName = "Full Description",
      description = "A description of the report. Should, as far as possible, provide details sufficient to enable resolution of any problem indicated by the result.",
      useName = "fullDescription"
  )
  private MultiformatMessageString _fullDescription;

  /**
   * A URI where the primary documentation for the report can be found.
   */
  @BoundField(
      formalName = "Help URI",
      description = "A URI where the primary documentation for the report can be found.",
      useName = "helpUri",
      typeAdapter = UriAdapter.class
  )
  private URI _helpUri;

  /**
   * Provides the primary documentation for the report, useful when there is no online documentation.
   */
  @BoundAssembly(
      formalName = "Help Description",
      description = "Provides the primary documentation for the report, useful when there is no online documentation.",
      useName = "help"
  )
  private MultiformatMessageString _help;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ReportingDescriptor} instance with no metadata.
   */
  public ReportingDescriptor() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.ReportingDescriptor} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ReportingDescriptor(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Reporting Descriptor Identifier}".
   *
   * <p>
   * A stable, opaque identifier for the report.
   *
   * @return the id value
   */
  @NonNull
  public String getId() {
    return _id;
  }

  /**
   * Set the "{@literal Reporting Descriptor Identifier}".
   *
   * <p>
   * A stable, opaque identifier for the report.
   *
   * @param value
   *           the id value to set
   */
  public void setId(@NonNull String value) {
    _id = value;
  }

  /**
   * Get the "{@literal Reporting Descriptor Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the reporting descriptor.
   *
   * @return the guid value, or {@code null} if not set
   */
  @Nullable
  public UUID getGuid() {
    return _guid;
  }

  /**
   * Set the "{@literal Reporting Descriptor Unique Identifier}".
   *
   * <p>
   * A stable, unique identifier for the reporting descriptor.
   *
   * @param value
   *           the guid value to set, or {@code null} to clear
   */
  public void setGuid(@Nullable UUID value) {
    _guid = value;
  }

  /**
   * Get the "{@literal Reporting Descriptor Name}".
   *
   * <p>
   * A report identifier that is understandable to an end user.
   *
   * @return the name value, or {@code null} if not set
   */
  @Nullable
  public String getName() {
    return _name;
  }

  /**
   * Set the "{@literal Reporting Descriptor Name}".
   *
   * <p>
   * A report identifier that is understandable to an end user.
   *
   * @param value
   *           the name value to set, or {@code null} to clear
   */
  public void setName(@Nullable String value) {
    _name = value;
  }

  /**
   * Get the "{@literal Short Description}".
   *
   * <p>
   * A concise description of the report. Should be a single sentence that is understandable when visible space is limited to a single line of text.
   *
   * @return the shortDescription value, or {@code null} if not set
   */
  @Nullable
  public MultiformatMessageString getShortDescription() {
    return _shortDescription;
  }

  /**
   * Set the "{@literal Short Description}".
   *
   * <p>
   * A concise description of the report. Should be a single sentence that is understandable when visible space is limited to a single line of text.
   *
   * @param value
   *           the shortDescription value to set, or {@code null} to clear
   */
  public void setShortDescription(@Nullable MultiformatMessageString value) {
    _shortDescription = value;
  }

  /**
   * Get the "{@literal Full Description}".
   *
   * <p>
   * A description of the report. Should, as far as possible, provide details sufficient to enable resolution of any problem indicated by the result.
   *
   * @return the fullDescription value, or {@code null} if not set
   */
  @Nullable
  public MultiformatMessageString getFullDescription() {
    return _fullDescription;
  }

  /**
   * Set the "{@literal Full Description}".
   *
   * <p>
   * A description of the report. Should, as far as possible, provide details sufficient to enable resolution of any problem indicated by the result.
   *
   * @param value
   *           the fullDescription value to set, or {@code null} to clear
   */
  public void setFullDescription(@Nullable MultiformatMessageString value) {
    _fullDescription = value;
  }

  /**
   * Get the "{@literal Help URI}".
   *
   * <p>
   * A URI where the primary documentation for the report can be found.
   *
   * @return the helpUri value, or {@code null} if not set
   */
  @Nullable
  public URI getHelpUri() {
    return _helpUri;
  }

  /**
   * Set the "{@literal Help URI}".
   *
   * <p>
   * A URI where the primary documentation for the report can be found.
   *
   * @param value
   *           the helpUri value to set, or {@code null} to clear
   */
  public void setHelpUri(@Nullable URI value) {
    _helpUri = value;
  }

  /**
   * Get the "{@literal Help Description}".
   *
   * <p>
   * Provides the primary documentation for the report, useful when there is no online documentation.
   *
   * @return the help value, or {@code null} if not set
   */
  @Nullable
  public MultiformatMessageString getHelp() {
    return _help;
  }

  /**
   * Set the "{@literal Help Description}".
   *
   * <p>
   * Provides the primary documentation for the report, useful when there is no online documentation.
   *
   * @param value
   *           the help value to set, or {@code null} to clear
   */
  public void setHelp(@Nullable MultiformatMessageString value) {
    _help = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
