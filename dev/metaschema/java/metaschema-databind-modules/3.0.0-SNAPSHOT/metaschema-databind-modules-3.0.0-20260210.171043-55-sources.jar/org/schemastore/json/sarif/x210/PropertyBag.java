// Generated from: ../../../../../../../../modules/sarif/sarif-module.xml
// Do not edit - changes will be lost when regenerated.
package org.schemastore.json.sarif.x210;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Key/value pairs that provide additional information about the object.
 */
@MetaschemaAssembly(
    formalName = "Property Bag",
    description = "Key/value pairs that provide additional information about the object.",
    name = "propertyBag",
    moduleClass = SarifModule.class
)
public class PropertyBag implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A set of distinct strings that provide additional information.
   */
  @BoundField(
      formalName = "Tag",
      description = "A set of distinct strings that provide additional information.",
      useName = "tag",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "tags", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = StringAdapter.class
  )
  private List<String> _tags;

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.PropertyBag} instance with no metadata.
   */
  public PropertyBag() {
    this(null);
  }

  /**
   * Constructs a new {@code org.schemastore.json.sarif.x210.PropertyBag} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public PropertyBag(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Tag}".
   *
   * <p>
   * A set of distinct strings that provide additional information.
   *
   * @return the tag value
   */
  @NonNull
  public List<String> getTags() {
    if (_tags == null) {
      _tags = new LinkedList<>();
    }
    return ObjectUtils.notNull(_tags);
  }

  /**
   * Set the "{@literal Tag}".
   *
   * <p>
   * A set of distinct strings that provide additional information.
   *
   * @param value
   *           the tag value to set
   */
  public void setTags(@NonNull List<String> value) {
    _tags = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addTag(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_tags == null) {
      _tags = new LinkedList<>();
    }
    return _tags.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeTag(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _tags != null && _tags.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
