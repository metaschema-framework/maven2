/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.model.constraint.impl;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import dev.metaschema.core.metapath.StaticContext;
import dev.metaschema.core.model.IModule;
import dev.metaschema.core.model.ISource;
import dev.metaschema.core.util.ObjectUtils;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * Implements a {@link dev.metaschema.core.model.ISource.SourceLocation#MODEL}
 * source with no associated resource.
 */
public final class InternalModelSource implements ISource {
  @NonNull
  private static final Map<IModule, InternalModelSource> sources = new HashMap<>(); // NOPMD - intentional
  @NonNull
  private static final Lock SOURCE_LOCK = new ReentrantLock();
  @NonNull
  private final IModule module;

  /**
   * Get a new instance of an external source associated with a resource
   * {@code location}.
   *
   * @param module
   *          the Metaschema module containing a constraint
   * @return the source
   */
  @NonNull
  public static ISource instance(@NonNull IModule module) {
    SOURCE_LOCK.lock();
    try {
      return ObjectUtils.notNull(sources.computeIfAbsent(
          module,
          uri -> new InternalModelSource(module)));
    } finally {
      SOURCE_LOCK.unlock();
    }
  }

  private InternalModelSource(@NonNull IModule module) {
    this.module = module;
  }

  @Override
  public SourceLocation getSourceType() {
    return SourceLocation.MODEL;
  }

  @Override
  public URI getSource() {
    return module.getLocation();
  }

  @Override
  public String getLocationHint() {
    return module.getLocationHint();
  }

  @Override
  public String toString() {
    return "internal:" + getSource();
  }

  @Override
  public StaticContext getStaticContext() {
    return module.getModuleStaticContext();
  }
}
