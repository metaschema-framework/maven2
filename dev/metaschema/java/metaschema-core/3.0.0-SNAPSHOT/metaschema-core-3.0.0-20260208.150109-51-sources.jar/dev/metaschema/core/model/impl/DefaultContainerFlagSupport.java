/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.model.impl;

import java.util.Map;

import dev.metaschema.core.model.IContainerFlagSupport;
import dev.metaschema.core.model.IFlagInstance;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;

/**
 * A flag container.
 *
 * @param <FI>
 *          the Java type of the flags supported by the container
 */
public class DefaultContainerFlagSupport<FI extends IFlagInstance> implements IContainerFlagSupport<FI> {
  @NonNull
  private final Map<Integer, FI> instances;
  @Nullable
  private final FI jsonKey;

  /**
   * Construct a new flag container using the provided flag instances.
   *
   * @param instances
   *          a collection of flag instances
   * @param jsonKey
   *          the JSON key flag instance or {@code null} if no JSON key is
   *          configured
   */
  public DefaultContainerFlagSupport(
      @NonNull Map<Integer, FI> instances,
      @Nullable FI jsonKey) {
    this.instances = instances;
    this.jsonKey = jsonKey;
  }

  @Override
  public Map<Integer, FI> getFlagInstanceMap() {
    return instances;
  }

  /**
   * Retrieves the flag instance to use as the property name for the containing
   * object in JSON whose value will be the object containing the flag.
   *
   * @return the flag instance if a JSON key is configured, or {@code null}
   *         otherwise
   */
  @Override
  public FI getJsonKeyFlagInstance() {
    return jsonKey;
  }
}
