/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.model.constraint.impl;

import java.util.regex.Pattern;

import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.metapath.IMetapathExpression;
import dev.metaschema.core.model.constraint.IIndexConstraint;
import dev.metaschema.core.model.constraint.IIndexHasKeyConstraint;
import dev.metaschema.core.model.constraint.IKeyField;
import dev.metaschema.core.model.constraint.IUniqueConstraint;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;

/**
 * The default implementation of an index that can support the
 * {@link IIndexConstraint}, {@link IIndexHasKeyConstraint}, and
 * {@link IUniqueConstraint}.
 */
public class DefaultKeyField implements IKeyField {

  @Nullable
  private final Pattern pattern;
  @NonNull
  private final IMetapathExpression target;
  @Nullable
  private final MarkupMultiline remarks;

  /**
   * Construct a new key field based on the provided target. An optional pattern
   * can be used to extract a portion of the resulting key value.
   *
   * @param target
   *          a Metapath expression identifying the target of the key field
   * @param pattern
   *          an optional used to extract a portion of the resulting key value
   * @param remarks
   *          optional remarks describing the intent of the constraint
   */
  public DefaultKeyField(
      @NonNull IMetapathExpression target,
      @Nullable Pattern pattern,
      @Nullable MarkupMultiline remarks) {
    this.pattern = pattern;
    this.target = target;
    this.remarks = remarks;
  }

  @Override
  public Pattern getPattern() {
    return pattern;
  }

  @Override
  public IMetapathExpression getTarget() {
    return target;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return remarks;
  }
}
