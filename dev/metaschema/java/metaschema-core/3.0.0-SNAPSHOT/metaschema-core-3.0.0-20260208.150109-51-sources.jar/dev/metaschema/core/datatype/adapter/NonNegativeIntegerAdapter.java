/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.datatype.adapter;

import java.math.BigInteger;
import java.util.List;

import dev.metaschema.core.metapath.MetapathConstants;
import dev.metaschema.core.metapath.item.atomic.INonNegativeIntegerItem;
import dev.metaschema.core.qname.EQNameFactory;
import dev.metaschema.core.qname.IEnhancedQName;
import dev.metaschema.core.util.ObjectUtils;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * Support for the Metaschema <a href=
 * "https://pages.nist.gov/metaschema/specification/datatypes/#non-negative-integer">non-negative-integer</a>
 * data type.
 */
public class NonNegativeIntegerAdapter
    extends AbstractIntegerAdapter<INonNegativeIntegerItem> {
  @NonNull
  private static final List<IEnhancedQName> NAMES = ObjectUtils.notNull(
      List.of(
          EQNameFactory.instance().newQName(MetapathConstants.NS_METAPATH, "non-negative-integer"),
          // for backwards compatibility with original type name
          EQNameFactory.instance().newQName(MetapathConstants.NS_METAPATH, "nonNegativeInteger")));

  NonNegativeIntegerAdapter() {
    super(INonNegativeIntegerItem.class, INonNegativeIntegerItem::cast);
    // avoid general construction
  }

  @Override
  public List<IEnhancedQName> getNames() {
    return NAMES;
  }

  @Override
  public INonNegativeIntegerItem newItem(Object value) {
    BigInteger item = toValue(value);
    return INonNegativeIntegerItem.valueOf(item);
  }
}
