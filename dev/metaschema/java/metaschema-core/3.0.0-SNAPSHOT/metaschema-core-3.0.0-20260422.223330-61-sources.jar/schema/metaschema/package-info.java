/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

/**
 * Provides schema resources for XML schema and Metaschema data types.
 */

package schema.metaschema;
