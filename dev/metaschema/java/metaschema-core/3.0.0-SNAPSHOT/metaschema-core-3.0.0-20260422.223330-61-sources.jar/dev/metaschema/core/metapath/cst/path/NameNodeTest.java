/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.cst.path;

import java.util.stream.Stream;

import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.cst.AbstractExpression;
import dev.metaschema.core.metapath.cst.IExpressionVisitor;
import dev.metaschema.core.metapath.item.ISequence;
import dev.metaschema.core.metapath.item.ItemUtils;
import dev.metaschema.core.metapath.item.node.IDefinitionNodeItem;
import dev.metaschema.core.metapath.item.node.INodeItem;
import dev.metaschema.core.qname.IEnhancedQName;
import dev.metaschema.core.util.ObjectUtils;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * The CST node for a Metapath
 * <a href="https://www.w3.org/TR/xpath-31/#dt-expanded-qname">expanded QName
 * name test</a>.
 */
@SuppressWarnings("PMD.TestClassWithoutTestCases") // not a test
public class NameNodeTest
    extends AbstractExpression
    implements INodeTestExpression {

  @NonNull
  private final IEnhancedQName name;

  /**
   * Construct a new expanded QName-based literal expression.
   *
   * @param text
   *          the parsed text of the expression
   * @param name
   *          the literal value
   */
  public NameNodeTest(@NonNull String text, @NonNull IEnhancedQName name) {
    super(text);
    this.name = name;
  }

  /**
   * Get the string value of the name.
   *
   * @return the string value of the name
   */
  @NonNull
  public IEnhancedQName getName() {
    return name;
  }

  @Override
  public <RESULT, CONTEXT> RESULT accept(IExpressionVisitor<RESULT, CONTEXT> visitor, CONTEXT context) {
    return visitor.visitNameNodeTest(this, context);
  }

  @Override
  protected ISequence<? extends INodeItem> evaluate(DynamicContext dynamicContext, ISequence<?> focus) {
    Stream<INodeItem> nodes = ObjectUtils.notNull(focus.stream()
        .map(item -> ItemUtils.checkItemIsNodeItem(dynamicContext, item)));
    return ISequence.of(filterStream(nodes));
  }

  @Override
  public boolean match(INodeItem item) {
    return item instanceof IDefinitionNodeItem
        && getName().equals(((IDefinitionNodeItem<?, ?>) item).getQName());
  }

  @SuppressWarnings("null")
  @Override
  public String toCSTString() {
    return String.format("%s[name=%s]", getClass().getName(), getName());
  }
}
