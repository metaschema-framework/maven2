/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.function.library;

import java.time.Duration;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.MetapathConstants;
import dev.metaschema.core.metapath.function.IFunction;
import dev.metaschema.core.metapath.item.IItem;
import dev.metaschema.core.metapath.item.ISequence;
import dev.metaschema.core.metapath.item.atomic.IDayTimeDurationItem;
import dev.metaschema.core.util.ObjectUtils;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * Implements <a href=
 * "https://www.w3.org/TR/xpath-functions-31/#func-implicit-timezone">fn:implicit-timezone</a>.
 */
public final class FnImplicitTimezone {
  private static final String NAME = "implicit-timezone";
  @NonNull
  static final IFunction SIGNATURE = IFunction.builder()
      .name(NAME)
      .namespace(MetapathConstants.NS_METAPATH_FUNCTIONS)
      .deterministic()
      .contextDependent()
      .focusIndependent()
      .returnType(IDayTimeDurationItem.type())
      .returnOne()
      .functionHandler(FnImplicitTimezone::execute)
      .build();

  private FnImplicitTimezone() {
    // disable construction
  }

  @SuppressWarnings("unused")
  @NonNull
  private static ISequence<IDayTimeDurationItem> execute(@NonNull IFunction function,
      @NonNull List<ISequence<?>> arguments,
      @NonNull DynamicContext dynamicContext,
      IItem focus) {
    return ISequence.of(fnImplicitTimezone(dynamicContext));
  }

  /**
   * Implements <a href=
   * "https://www.w3.org/TR/xpath-functions-31/#func-implicit-timezone">fn:implicit-timezone</a>.
   *
   * @param dynamicContext
   *          the dynamic evaluation context
   * @return the current date
   */
  @NonNull
  public static IDayTimeDurationItem fnImplicitTimezone(@NonNull DynamicContext dynamicContext) {
    // FIXME: support implicit timezone
    ZoneId timezone = dynamicContext.getImplicitTimeZone();
    ZonedDateTime now = dynamicContext.getCurrentDateTime().withZoneSameInstant(timezone);
    return IDayTimeDurationItem.valueOf(ObjectUtils.notNull(
        Duration.between(
            now,
            now.withZoneSameLocal(ZoneOffset.UTC))));
  }
}
