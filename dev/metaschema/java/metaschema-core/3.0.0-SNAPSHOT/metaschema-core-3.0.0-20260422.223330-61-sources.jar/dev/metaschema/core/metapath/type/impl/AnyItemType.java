/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.type.impl;

import dev.metaschema.core.metapath.item.IItem;
import dev.metaschema.core.metapath.type.IItemType;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

/**
 * An item type that applies to all items.
 */
@SuppressFBWarnings(value = "SING_SINGLETON_GETTER_NOT_SYNCHRONIZED", justification = "false positive")
public final class AnyItemType
    implements IItemType {
  @NonNull
  private static final AnyItemType INSTANCE = new AnyItemType();

  /**
   * Get the singleton instance.
   *
   * @return the singleton instance
   */
  @NonNull
  public static AnyItemType instance() {
    return INSTANCE;
  }

  @Override
  public boolean isInstance(IItem item) {
    // any item type always matches
    return true;
  }

  @Override
  public Class<? extends IItem> getItemClass() {
    return IItem.class;
  }

  @Override
  public String toSignature() {
    return "item()";
  }

  @Override
  public String toString() {
    return toSignature();
  }

  private AnyItemType() {
    // disable construction
  }
}
