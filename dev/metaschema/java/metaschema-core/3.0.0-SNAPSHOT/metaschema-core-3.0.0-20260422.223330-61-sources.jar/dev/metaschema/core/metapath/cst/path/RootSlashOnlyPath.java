/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.cst.path;

import java.util.List;

import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.IExpression;
import dev.metaschema.core.metapath.cst.IExpressionVisitor;
import dev.metaschema.core.metapath.item.ISequence;
import dev.metaschema.core.metapath.item.ItemUtils;
import dev.metaschema.core.metapath.item.node.INodeItem;
import dev.metaschema.core.util.CollectionUtil;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * An expression that gets the document root.
 * <p>
 * Based on the XPath 3.1
 * <a href= "https://www.w3.org/TR/xpath-31/#id-path-operator">path
 * operator</a>.
 * <p>
 * This class handles the root path expression "/", which selects the document
 * root node when evaluated. The evaluation follows the XPath specification for
 * absolute paths.
 */
public class RootSlashOnlyPath
    extends AbstractPathExpression<INodeItem> {

  /**
   * Construct a new path expression.
   *
   * @param text
   *          the parsed text of the expression
   */
  public RootSlashOnlyPath(@NonNull String text) {
    super(text);
  }

  @Override
  public List<? extends IExpression> getChildren() {
    return CollectionUtil.emptyList();
  }

  @Override
  public Class<INodeItem> getBaseResultType() {
    return INodeItem.class;
  }

  @Override
  public <RESULT, CONTEXT> RESULT accept(IExpressionVisitor<RESULT, CONTEXT> visitor, CONTEXT context) {
    return visitor.visitRootSlashOnlyPath(this, context);
  }

  @Override
  protected ISequence<? extends INodeItem> evaluate(DynamicContext dynamicContext, ISequence<?> focus) {
    return ItemUtils.getDocumentNodeItems(dynamicContext, focus);
  }
}
