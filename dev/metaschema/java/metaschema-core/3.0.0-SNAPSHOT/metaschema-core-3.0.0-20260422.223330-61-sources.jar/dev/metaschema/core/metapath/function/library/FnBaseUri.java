/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.function.library;

import java.net.URI;
import java.util.List;

import dev.metaschema.core.metapath.ContextAbsentDynamicMetapathException;
import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.MetapathConstants;
import dev.metaschema.core.metapath.function.FunctionUtils;
import dev.metaschema.core.metapath.function.IArgument;
import dev.metaschema.core.metapath.function.IFunction;
import dev.metaschema.core.metapath.item.IItem;
import dev.metaschema.core.metapath.item.ISequence;
import dev.metaschema.core.metapath.item.atomic.IAnyUriItem;
import dev.metaschema.core.metapath.item.node.INodeItem;
import dev.metaschema.core.metapath.type.InvalidTypeMetapathException;
import dev.metaschema.core.util.ObjectUtils;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;

/**
 * Implements the XPath 3.1 <a href=
 * "https://www.w3.org/TR/xpath-functions-31/#func-base-uri">fn:base-uri</a>
 * functions.
 * <p>
 * Since a node doesn't have a base URI in Metaschema, this is an alias for the
 * document-uri function, since the node's base URI is the same as the
 * document's URI.
 */
public final class FnBaseUri {
  private static final String NAME = "base-uri";
  @NonNull
  static final IFunction SIGNATURE_NO_ARG = IFunction.builder()
      .name(NAME)
      .namespace(MetapathConstants.NS_METAPATH_FUNCTIONS)
      .deterministic()
      .contextDependent()
      .focusDependent()
      .returnType(IAnyUriItem.type())
      .returnOne()
      .functionHandler(FnBaseUri::executeNoArg)
      .build();

  @NonNull
  static final IFunction SIGNATURE_ONE_ARG = IFunction.builder()
      .name(NAME)
      .namespace(MetapathConstants.NS_METAPATH_FUNCTIONS)
      .deterministic()
      .contextIndependent()
      .focusIndependent()
      .argument(IArgument.builder()
          .name("arg1")
          .type(INodeItem.type())
          .zeroOrOne()
          .build())
      .returnType(IAnyUriItem.type())
      .returnOne()
      .functionHandler(FnBaseUri::executeOneArg)
      .build();

  private FnBaseUri() {
    // disable construction
  }

  @SuppressWarnings("unused")
  @NonNull
  private static ISequence<IAnyUriItem> executeNoArg(@NonNull IFunction function,
      @NonNull List<ISequence<?>> arguments,
      @NonNull DynamicContext dynamicContext,
      IItem focus) {
    INodeItem nodeItem;
    if (focus == null) {
      // Per XPath 3.1: If the context item is absent, dynamic error [err:XPDY0002]
      throw new ContextAbsentDynamicMetapathException(
          "The context item is absent for fn:base-uri()");
    } else if (focus instanceof INodeItem) {
      nodeItem = (INodeItem) focus;
    } else {
      // Per XPath 3.1: If the context item is not a node, type error [err:XPTY0004]
      throw new InvalidTypeMetapathException(
          focus,
          String.format("Expected type '%s', but the context item was type '%s'.",
              INodeItem.class.getName(),
              focus.getClass().getName()));
    }
    return ISequence.of(fnBaseUri(nodeItem));
  }

  @SuppressWarnings("unused")
  @NonNull
  private static ISequence<IAnyUriItem> executeOneArg(@NonNull IFunction function,
      @NonNull List<ISequence<?>> arguments,
      @NonNull DynamicContext dynamicContext,
      IItem focus) {

    ISequence<? extends INodeItem> arg = FunctionUtils.asType(ObjectUtils.requireNonNull(arguments.get(0)));

    INodeItem item = arg.getFirstItem(true);

    return ISequence.of(fnBaseUri(item));
  }

  /**
   * Get the base URI for the provided {@code nodeItem}.
   * <p>
   * Based on the XPath 3.1 <a href=
   * "https://www.w3.org/TR/xpath-functions-31/#func-base-uri">fn:base-uri</a>
   * function.
   *
   * @param nodeItem
   *          the node to get the base URI from
   * @return the base URI, or {@code null} if the node is either null or doesn't
   *         have a base URI
   */
  @SuppressWarnings("PMD.NullAssignment") // for readability
  @Nullable
  public static IAnyUriItem fnBaseUri(INodeItem nodeItem) {
    IAnyUriItem retval;
    if (nodeItem == null) {
      retval = null;
    } else {
      URI baseUri = nodeItem.getBaseUri();
      retval = baseUri == null ? null : IAnyUriItem.valueOf(baseUri);
    }
    return retval;
  }
}
