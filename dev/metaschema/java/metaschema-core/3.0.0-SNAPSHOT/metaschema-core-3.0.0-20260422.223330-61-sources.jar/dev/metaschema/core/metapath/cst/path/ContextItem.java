/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.cst.path;

import java.util.Collections;
import java.util.List;

import dev.metaschema.core.metapath.ContextAbsentDynamicMetapathException;
import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.IExpression;
import dev.metaschema.core.metapath.cst.IExpressionVisitor;
import dev.metaschema.core.metapath.item.ISequence;
import dev.metaschema.core.metapath.item.node.INodeItem;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * An implementation of the
 * <a href="https://www.w3.org/TR/xpath-31/#id-context-item-expression">Context
 * Item Expression</a> based on the current focus of the Metapath
 * {@link DynamicContext}.
 */
public final class ContextItem
    extends AbstractPathExpression<INodeItem> {
  @NonNull
  private static final ContextItem SINGLETON = new ContextItem();

  /**
   * Get the singleton context item CST node.
   *
   * @return the singleton instance
   */
  @SuppressWarnings("PMD.AvoidSynchronizedAtMethodLevel")
  @NonNull
  public static synchronized ContextItem instance() {
    return SINGLETON;
  }

  private ContextItem() {
    // disable construction
    super(".");
  }

  @Override
  public Class<INodeItem> getBaseResultType() {
    return INodeItem.class;
  }

  @Override
  public Class<? extends INodeItem> getStaticResultType() {
    return getBaseResultType();
  }

  @SuppressWarnings("null")
  @Override
  public List<? extends IExpression> getChildren() {
    return Collections.emptyList();
  }

  @Override
  public <RESULT, CONTEXT> RESULT accept(IExpressionVisitor<RESULT, CONTEXT> visitor, CONTEXT context) {
    return visitor.visitContextItem(this, context);
  }

  @Override
  protected ISequence<?> evaluate(DynamicContext dynamicContext, ISequence<?> focus) {
    if (focus.isEmpty()) {
      throw new ContextAbsentDynamicMetapathException("The context item is empty")
          .registerEvaluationContext(dynamicContext);
    }
    return focus;
  }
}
