/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.cst.items;

import java.math.BigInteger;

import dev.metaschema.core.metapath.cst.IExpressionVisitor;
import dev.metaschema.core.metapath.item.atomic.IIntegerItem;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * An implementation of the
 * <a href="https://www.w3.org/TR/xpath-31/#id-literals">Integer Literal
 * Expression</a> supporting the creation of a Metapath constant literal
 * {@link IIntegerItem}.
 */
public class IntegerLiteral
    extends AbstractLiteralExpression<IIntegerItem> {

  /**
   * Construct a new expression that always returns the same integer value.
   *
   * @param text
   *          the parsed text of the expression
   * @param value
   *          the literal value
   */
  public IntegerLiteral(@NonNull String text, @NonNull BigInteger value) {
    super(text, IIntegerItem.valueOf(value));
  }

  @Override
  public Class<IIntegerItem> getBaseResultType() {
    return IIntegerItem.class;
  }

  @Override
  public <RESULT, CONTEXT> RESULT accept(IExpressionVisitor<RESULT, CONTEXT> visitor, CONTEXT context) {
    return visitor.visitIntegerLiteral(this, context);
  }
}
