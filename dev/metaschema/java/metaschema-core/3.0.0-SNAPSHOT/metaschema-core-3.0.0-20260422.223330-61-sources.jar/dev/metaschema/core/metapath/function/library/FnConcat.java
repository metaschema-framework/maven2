/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.function.library;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.MetapathConstants;
import dev.metaschema.core.metapath.function.IArgument;
import dev.metaschema.core.metapath.function.IFunction;
import dev.metaschema.core.metapath.item.IItem;
import dev.metaschema.core.metapath.item.ISequence;
import dev.metaschema.core.metapath.item.atomic.IAnyAtomicItem;
import dev.metaschema.core.metapath.item.atomic.IStringItem;
import dev.metaschema.core.util.ObjectUtils;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * Implements the XPath 3.1 <a href=
 * "https://www.w3.org/TR/xpath-functions-31/#func-concat">fn:concat</a>
 * function.
 */
public final class FnConcat {
  private static final String NAME = "concat";
  @NonNull
  static final IFunction SIGNATURE = IFunction.builder()
      .name(NAME)
      .namespace(MetapathConstants.NS_METAPATH_FUNCTIONS)
      .deterministic()
      .contextIndependent()
      .focusIndependent()
      .argument(IArgument.builder()
          .name("arg1")
          .type(IAnyAtomicItem.type())
          .zeroOrOne()
          .build())
      .argument(IArgument.builder()
          .name("arg2")
          .type(IAnyAtomicItem.type())
          .zeroOrOne()
          .build())
      .allowUnboundedArity(true)
      .returnType(IStringItem.type())
      .returnOne()
      .functionHandler(FnConcat::execute)
      .build();

  private FnConcat() {
    // disable construction
  }

  @SuppressWarnings("unused")
  @NonNull
  private static ISequence<IStringItem> execute(
      @NonNull IFunction function,
      @NonNull List<ISequence<?>> arguments,
      @NonNull DynamicContext dynamicContext,
      IItem focus) {

    return ISequence.of(concat(ObjectUtils.notNull(arguments.stream()
        .map(arg -> {
          assert arg != null;
          return (IAnyAtomicItem) arg.getFirstItem(true);
        }))));
  }

  /**
   * An implementation of XPath 3.1 <a href=
   * "https://www.w3.org/TR/xpath-functions-31/#func-concat">fn:concat</a>.
   *
   * @param items
   *          the items to concatenate
   * @return the atomized result
   */
  @NonNull
  public static IStringItem concat(IAnyAtomicItem... items) {
    return concat(ObjectUtils.notNull(Arrays.asList(items)));
  }

  /**
   * An implementation of XPath 3.1 <a href=
   * "https://www.w3.org/TR/xpath-functions-31/#func-concat">fn:concat</a>.
   *
   * @param items
   *          the items to concatenate
   * @return the atomized result
   */
  @NonNull
  public static IStringItem concat(@NonNull List<? extends IAnyAtomicItem> items) {
    return concat(ObjectUtils.notNull(items.stream()));
  }

  /**
   * An implementation of XPath 3.1 <a href=
   * "https://www.w3.org/TR/xpath-functions-31/#func-concat">fn:concat</a>.
   *
   * @param items
   *          the items to concatenate
   * @return the atomized result
   */
  @NonNull
  public static IStringItem concat(@NonNull Stream<? extends IAnyAtomicItem> items) {
    return IStringItem.valueOf(ObjectUtils.notNull(items
        .map(item -> item == null ? "" : IStringItem.cast(item).asString())
        .collect(Collectors.joining())));
  }
}
