/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.core.metapath.cst.items;

import java.util.List;

import dev.metaschema.core.metapath.DynamicContext;
import dev.metaschema.core.metapath.IExpression;
import dev.metaschema.core.metapath.cst.AbstractNAryExpression;
import dev.metaschema.core.metapath.cst.IExpressionVisitor;
import dev.metaschema.core.metapath.function.library.FnConcat;
import dev.metaschema.core.metapath.item.ISequence;
import dev.metaschema.core.metapath.item.atomic.IStringItem;
import dev.metaschema.core.util.ObjectUtils;
import edu.umd.cs.findbugs.annotations.NonNull;

/**
 * An XPath 3.1
 * <a href="https://www.w3.org/TR/xpath-31/#id-string-concat-expr">string
 * concatenation expression</a>.
 *
 * <p>
 * Concatenates the string values of its operands in left to right order. Each
 * operand is atomized and converted to a string value before concatenation.
 *
 * <p>
 * Example Metapath usage:
 * <p>
 * {@code "abc" || "def"} -> {@code "abcdef"}
 * <p>
 * {@code 123 || "456"} -> {@code "123456"}
 * <p>
 * {@code () || "xyz" || "abc"} -> {@code "xyzabc"}
 */
public class StringConcat
    extends AbstractNAryExpression {

  /**
   * Create a new expression that concatenates the results of evaluating the
   * provided {@code expressions} as strings.
   *
   * @param text
   *          the parsed text of the expression
   * @param expressions
   *          the expressions to evaluate
   */
  public StringConcat(@NonNull String text, @NonNull List<IExpression> expressions) {
    super(text, expressions);
  }

  @Override
  public Class<IStringItem> getBaseResultType() {
    return IStringItem.class;
  }

  @Override
  public Class<IStringItem> getStaticResultType() {
    return getBaseResultType();
  }

  @Override
  public <RESULT, CONTEXT> RESULT accept(IExpressionVisitor<RESULT, CONTEXT> visitor, CONTEXT context) {
    return visitor.visitStringConcat(this, context);
  }

  @Override
  protected ISequence<?> evaluate(DynamicContext dynamicContext, ISequence<?> focus) {
    return ISequence.of(FnConcat.concat(ObjectUtils.notNull(getChildren().stream()
        .map(child -> child.accept(dynamicContext, focus))
        .flatMap(result -> ObjectUtils.notNull(result).atomize()))));
  }
}
