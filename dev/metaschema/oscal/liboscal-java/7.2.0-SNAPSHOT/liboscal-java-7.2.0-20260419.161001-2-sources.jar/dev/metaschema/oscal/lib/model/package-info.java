// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_complete_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-plan_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_poam_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_catalog_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_control-common_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-results_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping_metaschema.xml
// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
/**
 * Provides generated Metaschema binding classes for module(s): OSCAL System Security Plan (SSP) Model, OSCAL Unified Model of Models, OSCAL Assessment Plan Model, OSCAL Plan of Action and Milestones (POA&amp;M) Model, OSCAL Component Definition Model, OSCAL Document Metadata Description, OSCAL Control Catalog Model, OSCAL Mapping Model -- Common Models, OSCAL Control Catalog Format -- Common Models, OSCAL Assessment Layer Format -- Common Modules, OSCAL Profile Model, OSCAL Assessment Results Model, OSCAL Control Mapping Model, OSCAL Implementation Common Information.
 * <p>
 * version 1.2.0
 * <p>The OSCAL Control SSP format can be used to describe the information typically specified in a system security plan, such as those defined in NIST SP 800-18.</p>
<p>The root of the OSCAL System Security Plan (SSP) format is <code>system-security-plan</code>.</p>
 * <p>
 * version 1.2.0
 * <p>This format represents a combination of all of the OSCAL models.</p>
 * <p>
 * version 1.2.0
 * <p>The OSCAL assessment plan format is used to describe the information typically provided by an assessor during the preparation for an assessment.</p>
<p>The root of the OSCAL assessment plan format is <code>assessment-plan</code>.</p>
 * <p>
 * version 1.2.0
 * <p>The OSCAL Plan of Action and Milestones (POA&amp;M) format is used to describe the information typically provided by an assessor during the preparation for an assessment.</p>
<p>The root of the OSCAL Plan of Action and Milestones (POA&amp;M) format is <code>plan-action-milestones</code>.</p>
 * <p>
 * version 1.1.3
 * <p>The OSCAL Component Definition Model can be used to describe the implementation of controls in a <code>component</code> or a set of components grouped as a <code>capability</code>. A component can be either a <em>technical component</em> , or a <em>documentary component</em>.</p>
<p>A technical component is a component that is implemented in hardware (physical or virtual) or software. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their hardware and software.</p>
<p>A documentary component is a component implemented for a documented process, procedure, or policy. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their process, procedure, or policy.</p>
<p>The information provided by a technical or documentary component can be used by component consumers to provide starting narratives for documenting control implementations in an OSCAL SSP.</p>
<p>The root of the OSCAL Implementation Layer Component Definition model is <code>component-definition</code>.</p>
 * <p>
 * version 1.2.0
 * <p>
 * version 1.2.0
 * <p>The OSCAL Control Catalog format can be used to describe a collection of security controls and related control enhancements, along with contextualizing documentation and metadata. The root of the Control Catalog format is <code>catalog</code>.</p>
 * <p>
 * version 1.2.0
 * <p>
 * version 1.2.0
 * <p>
 * version 1.2.0
 * <p>This contains all modules common to the assessment plan, assessment results, and POAM models.</p>
<p>The root of the OSCAL Assessment Plan format is <code>assessment-plan</code>.</p>
<p>The root of the OSCAL Assessment Results format is <code>assessment-results</code>.</p>
<p>The root of the OSCAL Plan of Action and Milestones (POA&amp;M) format is <code>plan-of-action-and-milestones</code>.</p>
 * <p>
 * version 1.2.0
 * <p>In OSCAL a profile represents a set of selected <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">controls</a> from one or more control catalogs. Such a set of controls can be referenced by an OSCAL <a href="https://pages.nist.gov/OSCAL/concepts/layer/implementation/ssp/">system security plan</a> (SSP) to establish a control <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#baseline">baseline</a>. This effective set of controls is produced from an OSCAL profile using a deterministic, predictable process called <a href="https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/">profile resolution</a>.</p>
<p>A profile references one or more OSCAL catalogs or profiles to import controls for control selection and tailoring. A profile can also describe how a resulting catalog is structured. When the profile is resolved, these selections and modifications are processed to produce a resulting OSCAL catalog.</p>
<p>OSCAL profiles have uses beyond establishing control baselines, such as documentation generation or as reference tables for validations.</p>
 * <p>
 * version 1.2.0
 * <p>The OSCAL assessment results format is used to describe the information typically provided by an assessor following an assessment.</p>
<p>The root of the OSCAL assessment results format is <code>assessment-results</code>.</p>
 * <p>
 * version 1.2.0
 * <p>The OSCAL Control mapping format can be used to describe how a collection of security controls and related control enhancements relate to another collection of controls. The root of the Control Catalog format is <code>mapping-collection</code>.</p>
 * <p>
 * version 1.2.0
 */
@dev.metaschema.databind.model.annotations.MetaschemaPackage(moduleClass = {
  dev.metaschema.oscal.lib.model.OscalSspModule.class,
  dev.metaschema.oscal.lib.model.OscalCompleteModule.class,
  dev.metaschema.oscal.lib.model.OscalApModule.class,
  dev.metaschema.oscal.lib.model.OscalPoamModule.class,
  dev.metaschema.oscal.lib.model.OscalComponentDefinitionModule.class,
  dev.metaschema.oscal.lib.model.OscalMetadataModule.class,
  dev.metaschema.oscal.lib.model.OscalCatalogModule.class,
  dev.metaschema.oscal.lib.model.OscalMappingCommonModule.class,
  dev.metaschema.oscal.lib.model.OscalControlCommonModule.class,
  dev.metaschema.oscal.lib.model.OscalAssessmentCommonModule.class,
  dev.metaschema.oscal.lib.model.OscalProfileModule.class,
  dev.metaschema.oscal.lib.model.OscalArModule.class,
  dev.metaschema.oscal.lib.model.OscalMappingModule.class,
  dev.metaschema.oscal.lib.model.OscalImplementationCommonModule.class})
@dev.metaschema.databind.model.annotations.XmlSchema(namespace = "http://csrc.nist.gov/ns/oscal/1.0", xmlns = {@dev.metaschema.databind.model.annotations.XmlNs(prefix = "", namespace = "http://csrc.nist.gov/ns/oscal/1.0")}, xmlElementFormDefault = dev.metaschema.databind.model.annotations.XmlNsForm.QUALIFIED)
package dev.metaschema.oscal.lib.model;
