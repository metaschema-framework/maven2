// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.datatype.object.AmbiguousDate;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Provides information as to how the system is implemented.
 */
@MetaschemaAssembly(
    formalName = "System Implementation",
    description = "Provides information as to how the system is implemented.",
    name = "system-implementation",
    moduleClass = OscalSspModule.class,
    valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-component-inventory-item-allows-authenticated-scan-values", level = IConstraint.Level.ERROR, target = "(component | inventory-item)/prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='allows-authenticated-scan']/@value", values = {@AllowedValue(value = "yes", description = "The component allows an authenticated scan."), @AllowedValue(value = "no", description = "The component does not allow an authenticated scan.")}), indexHasKey = {@IndexHasKey(id = "oscal-system-implementation-component-prop-leveraged-authorization-uuid-index", level = IConstraint.Level.ERROR, target = "component/prop[@name='leveraged-authorization-uuid']", indexName = "index-system-implementation-leveraged-authorization-uuid", keyFields = @KeyField(target = "@value")), @IndexHasKey(id = "oscal-system-implementation-component-depends-on-link-index", level = IConstraint.Level.ERROR, target = "component/link[@rel='depends-on']", indexName = "index-system-implementation-component-uuid", keyFields = @KeyField(target = "@href")), @IndexHasKey(id = "oscal-system-implementation-validated-by-index", level = IConstraint.Level.ERROR, target = "component/link[@rel='validated-by']", indexName = "index-system-implementation-component-uuid-validation", keyFields = @KeyField(target = "@href")), @IndexHasKey(id = "oscal-system-implementation-proof-of-compliance-index", level = IConstraint.Level.ERROR, target = "component/link[@rel='proof-of-compliance']", indexName = "index-system-implementation-component-uuid-validation", keyFields = @KeyField(target = "@href")), @IndexHasKey(id = "oscal-index-system-implementation-component-uuid-service", level = IConstraint.Level.ERROR, target = "component/link[@rel='uses-service']", indexName = "index-system-implementation-component-uuid-service", keyFields = @KeyField(target = "@href"))}),
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-system-implementation-component-leveraged-authorization-uuid-index", level = IConstraint.Level.ERROR, target = "leveraged-authorization", name = "index-system-implementation-leveraged-authorization-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-system-implementation-component-uuid-index", level = IConstraint.Level.ERROR, target = "component", name = "index-system-implementation-component-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-system-implementation-component-validation-uuid-index", level = IConstraint.Level.ERROR, target = "component[@type='validation']", name = "index-system-implementation-component-uuid-validation", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-index-system-implementation-component-uuid-service", level = IConstraint.Level.ERROR, target = "component[@type='service']", name = "index-system-implementation-component-uuid-service", keyFields = @KeyField(target = "@uuid"))}, unique = @IsUnique(id = "oscal-unique-ssp-system-implementation-user", level = IConstraint.Level.ERROR, target = "user", keyFields = @KeyField(target = "@uuid"), remarks = "A given `uuid` must be assigned only once to a user."))
)
public class SystemImplementation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * A description of another authorized system from which this system inherits capabilities that satisfy security requirements. Another term for this concept is a <em>common control provider</em>.
   */
  @BoundAssembly(
      formalName = "Leveraged Authorization",
      description = "A description of another authorized system from which this system inherits capabilities that satisfy security requirements. Another term for this concept is a *common control provider*.",
      useName = "leveraged-authorization",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "leveraged-authorizations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<LeveragedAuthorization> _leveragedAuthorizations;

  /**
   * A type of user that interacts with the system based on an associated role.
   */
  @BoundAssembly(
      formalName = "System User",
      description = "A type of user that interacts with the system based on an associated role.",
      useName = "user",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "users", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SystemUser> _users;

  /**
   * A defined component that can be part of an implemented system.
   */
  @BoundAssembly(
      formalName = "Component",
      description = "A defined component that can be part of an implemented system.",
      useName = "component",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "components", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SystemComponent> _components;

  /**
   * A single managed inventory item within the system.
   */
  @BoundAssembly(
      formalName = "Inventory Item",
      description = "A single managed inventory item within the system.",
      useName = "inventory-item",
      remarks = "A set of `inventory-item` entries that represent the managed inventory instances of the system.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "inventory-items", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<InventoryItem> _inventoryItems;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemImplementation} instance with no metadata.
   */
  public SystemImplementation() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemImplementation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SystemImplementation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Leveraged Authorization}".
   *
   * <p>
   * A description of another authorized system from which this system inherits capabilities that satisfy security requirements. Another term for this concept is a <em>common control provider</em>.
   *
   * @return the leveraged-authorization value
   */
  @NonNull
  public List<LeveragedAuthorization> getLeveragedAuthorizations() {
    if (_leveragedAuthorizations == null) {
      _leveragedAuthorizations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_leveragedAuthorizations);
  }

  /**
   * Set the "{@literal Leveraged Authorization}".
   *
   * <p>
   * A description of another authorized system from which this system inherits capabilities that satisfy security requirements. Another term for this concept is a <em>common control provider</em>.
   *
   * @param value
   *           the leveraged-authorization value to set
   */
  public void setLeveragedAuthorizations(@NonNull List<LeveragedAuthorization> value) {
    _leveragedAuthorizations = value;
  }

  /**
   * Add a new {@link LeveragedAuthorization} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLeveragedAuthorization(LeveragedAuthorization item) {
    LeveragedAuthorization value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_leveragedAuthorizations == null) {
      _leveragedAuthorizations = new LinkedList<>();
    }
    return _leveragedAuthorizations.add(value);
  }

  /**
   * Remove the first matching {@link LeveragedAuthorization} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLeveragedAuthorization(LeveragedAuthorization item) {
    LeveragedAuthorization value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _leveragedAuthorizations != null && _leveragedAuthorizations.remove(value);
  }

  /**
   * Get the "{@literal System User}".
   *
   * <p>
   * A type of user that interacts with the system based on an associated role.
   *
   * @return the user value
   */
  @NonNull
  public List<SystemUser> getUsers() {
    if (_users == null) {
      _users = new LinkedList<>();
    }
    return ObjectUtils.notNull(_users);
  }

  /**
   * Set the "{@literal System User}".
   *
   * <p>
   * A type of user that interacts with the system based on an associated role.
   *
   * @param value
   *           the user value to set
   */
  public void setUsers(@NonNull List<SystemUser> value) {
    _users = value;
  }

  /**
   * Add a new {@link SystemUser} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addUser(SystemUser item) {
    SystemUser value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_users == null) {
      _users = new LinkedList<>();
    }
    return _users.add(value);
  }

  /**
   * Remove the first matching {@link SystemUser} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeUser(SystemUser item) {
    SystemUser value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _users != null && _users.remove(value);
  }

  /**
   * Get the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @return the component value
   */
  @NonNull
  public List<SystemComponent> getComponents() {
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return ObjectUtils.notNull(_components);
  }

  /**
   * Set the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @param value
   *           the component value to set
   */
  public void setComponents(@NonNull List<SystemComponent> value) {
    _components = value;
  }

  /**
   * Add a new {@link SystemComponent} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addComponent(SystemComponent item) {
    SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return _components.add(value);
  }

  /**
   * Remove the first matching {@link SystemComponent} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeComponent(SystemComponent item) {
    SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _components != null && _components.remove(value);
  }

  /**
   * Get the "{@literal Inventory Item}".
   *
   * <p>
   * A single managed inventory item within the system.
   *
   * @return the inventory-item value
   */
  @NonNull
  public List<InventoryItem> getInventoryItems() {
    if (_inventoryItems == null) {
      _inventoryItems = new LinkedList<>();
    }
    return ObjectUtils.notNull(_inventoryItems);
  }

  /**
   * Set the "{@literal Inventory Item}".
   *
   * <p>
   * A single managed inventory item within the system.
   *
   * @param value
   *           the inventory-item value to set
   */
  public void setInventoryItems(@NonNull List<InventoryItem> value) {
    _inventoryItems = value;
  }

  /**
   * Add a new {@link InventoryItem} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addInventoryItem(InventoryItem item) {
    InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_inventoryItems == null) {
      _inventoryItems = new LinkedList<>();
    }
    return _inventoryItems.add(value);
  }

  /**
   * Remove the first matching {@link InventoryItem} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeInventoryItem(InventoryItem item) {
    InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _inventoryItems != null && _inventoryItems.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * A description of another authorized system from which this system inherits capabilities that satisfy security requirements. Another term for this concept is a <em>common control provider</em>.
   */
  @MetaschemaAssembly(
      formalName = "Leveraged Authorization",
      description = "A description of another authorized system from which this system inherits capabilities that satisfy security requirements. Another term for this concept is a *common control provider*.",
      name = "leveraged-authorization",
      moduleClass = OscalSspModule.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-leveraged-authorization-link-rel-values", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = @AllowedValue(value = "system-security-plan", description = "A reference to the system security plan for the leveraged authorization.")), indexHasKey = @IndexHasKey(id = "oscal-leveraged-authorization-index-back-matter-resource-ssp", level = IConstraint.Level.ERROR, target = "link[@rel='system-security-plan' and starts-with(@href,'#')]", indexName = "index-back-matter-resource", keyFields = @KeyField(target = "@href", pattern = "#(.*)")), matches = {@Matches(id = "oscal-leveraged-authorization-link-rel-ssp-datatype-uri-reference", level = IConstraint.Level.ERROR, target = "link[@rel='system-security-plan']/@href[starts-with(.,'#')]", typeAdapter = UriReferenceAdapter.class), @Matches(id = "oscal-leveraged-authorization-link-rel-ssp-datatype-uri", level = IConstraint.Level.ERROR, target = "link[@rel='system-security-plan']/@href[not(starts-with(.,'#'))]", typeAdapter = UriAdapter.class)})
  )
  public static class LeveragedAuthorization implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope and can be used to reference this leveraged authorization elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>leveraged authorization</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Leveraged Authorization Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope and can be used to reference this leveraged authorization elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `leveraged authorization` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A human readable name for the leveraged authorization in the context of the system.
     */
    @BoundField(
        formalName = "title field",
        description = "A human readable name for the leveraged authorization in the context of the system.",
        useName = "title",
        minOccurs = 1,
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the <code>party</code> that manages the leveraged system.
     */
    @BoundField(
        formalName = "party-uuid field",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to the `party` that manages the leveraged system.",
        useName = "party-uuid",
        minOccurs = 1,
        typeAdapter = UuidAdapter.class
    )
    private UUID _partyUuid;

    /**
     * The date the system received its authorization.
     */
    @BoundField(
        formalName = "System Authorization Date",
        description = "The date the system received its authorization.",
        useName = "date-authorized",
        minOccurs = 1,
        typeAdapter = DateAdapter.class
    )
    private AmbiguousDate _dateAuthorized;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemImplementation.LeveragedAuthorization} instance with no metadata.
     */
    public LeveragedAuthorization() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemImplementation.LeveragedAuthorization} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public LeveragedAuthorization(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Leveraged Authorization Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope and can be used to reference this leveraged authorization elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>leveraged authorization</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Leveraged Authorization Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope and can be used to reference this leveraged authorization elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>leveraged authorization</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal title field}".
     *
     * <p>
     * A human readable name for the leveraged authorization in the context of the system.
     *
     * @return the title value
     */
    @NonNull
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal title field}".
     *
     * <p>
     * A human readable name for the leveraged authorization in the context of the system.
     *
     * @param value
     *           the title value to set
     */
    public void setTitle(@NonNull MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal party-uuid field}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the <code>party</code> that manages the leveraged system.
     *
     * @return the party-uuid value
     */
    @NonNull
    public UUID getPartyUuid() {
      return _partyUuid;
    }

    /**
     * Set the "{@literal party-uuid field}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the <code>party</code> that manages the leveraged system.
     *
     * @param value
     *           the party-uuid value to set
     */
    public void setPartyUuid(@NonNull UUID value) {
      _partyUuid = value;
    }

    /**
     * Get the "{@literal System Authorization Date}".
     *
     * <p>
     * The date the system received its authorization.
     *
     * @return the date-authorized value
     */
    @NonNull
    public AmbiguousDate getDateAuthorized() {
      return _dateAuthorized;
    }

    /**
     * Set the "{@literal System Authorization Date}".
     *
     * <p>
     * The date the system received its authorization.
     *
     * @param value
     *           the date-authorized value to set
     */
    public void setDateAuthorized(@NonNull AmbiguousDate value) {
      _dateAuthorized = value;
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
