// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.databind.IBindingContext;
import dev.metaschema.databind.model.AbstractBoundModule;
import dev.metaschema.databind.model.IBoundModule;
import dev.metaschema.databind.model.annotations.MetaschemaModule;
import java.net.URI;
import java.util.List;

/**
 * OSCAL Profile Model
 * <p>In OSCAL a profile represents a set of selected <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">controls</a> from one or more control catalogs. Such a set of controls can be referenced by an OSCAL <a href="https://pages.nist.gov/OSCAL/concepts/layer/implementation/ssp/">system security plan</a> (SSP) to establish a control <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#baseline">baseline</a>. This effective set of controls is produced from an OSCAL profile using a deterministic, predictable process called <a href="https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/">profile resolution</a>.</p>
 * <p>A profile references one or more OSCAL catalogs or profiles to import controls for control selection and tailoring. A profile can also describe how a resulting catalog is structured. When the profile is resolved, these selections and modifications are processed to produce a resulting OSCAL catalog.</p>
 * <p>OSCAL profiles have uses beyond establishing control baselines, such as documentation generation or as reference tables for validations.</p>
 */
@MetaschemaModule(
    assemblies = {
        Profile.class,
        ProfileImport.class,
        Merge.class,
        ProfileGroup.class,
        Modify.class,
        InsertControls.class,
        ProfileSelectControlById.class,
        ProfileMatching.class
    },
    imports = {
        OscalMetadataModule.class,
        OscalControlCommonModule.class
    },
    remarks = "In OSCAL a profile represents a set of selected [controls](https://pages.nist.gov/OSCAL/concepts/terminology/#control) from one or more control catalogs. Such a set of controls can be referenced by an OSCAL [system security plan](https://pages.nist.gov/OSCAL/concepts/layer/implementation/ssp/) (SSP) to establish a control [baseline](https://pages.nist.gov/OSCAL/concepts/terminology/#baseline). This effective set of controls is produced from an OSCAL profile using a deterministic, predictable process called [profile resolution](https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/).\n"
            + "\n"
            + "A profile references one or more OSCAL catalogs or profiles to import controls for control selection and tailoring. A profile can also describe how a resulting catalog is structured. When the profile is resolved, these selections and modifications are processed to produce a resulting OSCAL catalog.\n"
            + "\n"
            + "OSCAL profiles have uses beyond establishing control baselines, such as documentation generation or as reference tables for validations."
)
public final class OscalProfileModule extends AbstractBoundModule {
  private static final MarkupLine NAME = MarkupLine.fromMarkdown("OSCAL Profile Model");

  private static final String SHORT_NAME = "oscal-profile";

  private static final String VERSION = "1.2.0";

  private static final URI XML_NAMESPACE = URI.create("http://csrc.nist.gov/ns/oscal/1.0");

  private static final URI JSON_BASE_URI = URI.create("http://csrc.nist.gov/ns/oscal");

  private static final MarkupMultiline REMARKS = MarkupMultiline.fromMarkdown("In OSCAL a profile represents a set of selected [controls](https://pages.nist.gov/OSCAL/concepts/terminology/#control) from one or more control catalogs. Such a set of controls can be referenced by an OSCAL [system security plan](https://pages.nist.gov/OSCAL/concepts/layer/implementation/ssp/) (SSP) to establish a control [baseline](https://pages.nist.gov/OSCAL/concepts/terminology/#baseline). This effective set of controls is produced from an OSCAL profile using a deterministic, predictable process called [profile resolution](https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/).\n"
      + "\n"
      + "A profile references one or more OSCAL catalogs or profiles to import controls for control selection and tailoring. A profile can also describe how a resulting catalog is structured. When the profile is resolved, these selections and modifications are processed to produce a resulting OSCAL catalog.\n"
      + "\n"
      + "OSCAL profiles have uses beyond establishing control baselines, such as documentation generation or as reference tables for validations.");

  /**
   * Construct a new module instance.
   *
   * @param importedModules
   *           modules imported by this module
   * @param bindingContext
   *           the binding context to associate with this module
   */
  public OscalProfileModule(List<? extends IBoundModule> importedModules,
      IBindingContext bindingContext) {
    super(importedModules, bindingContext);
  }

  @Override
  public MarkupLine getName() {
    return NAME;
  }

  @Override
  public String getShortName() {
    return SHORT_NAME;
  }

  @Override
  public String getVersion() {
    return VERSION;
  }

  @Override
  public URI getXmlNamespace() {
    return XML_NAMESPACE;
  }

  @Override
  public URI getJsonBaseUri() {
    return JSON_BASE_URI;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return REMARKS;
  }
}
