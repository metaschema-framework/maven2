// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DecimalAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
 */
@MetaschemaField(
    formalName = "Confidence Score",
    description = "This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.",
    name = "confidence-score",
    moduleClass = OscalMappingCommonModule.class
)
public class ConfidenceScore implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  @BoundFlag(
      name = "category",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "unspecified", description = "No category is specified for the confidence score."), @AllowedValue(value = "high", description = "High confidence in the mapping."), @AllowedValue(value = "medium", description = "Medium confidence in the mapping."), @AllowedValue(value = "low", description = "Low confidence in the mapping.")}))
  )
  private String _category;

  @BoundFlag(
      name = "percentage",
      typeAdapter = DecimalAdapter.class
  )
  private BigDecimal _percentage;

  /**
   * The field value.
   */
  @BoundFieldValue(
      valueKeyName = "STRVALUE"
  )
  private String _value;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ConfidenceScore} instance with no metadata.
   */
  public ConfidenceScore() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ConfidenceScore} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ConfidenceScore(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the {@code category} property.
   *
   * @return the category value, or {@code null} if not set
   */
  @Nullable
  public String getCategory() {
    return _category;
  }

  /**
   * Set the {@code category} property.
   *
   * @param value
   *           the category value to set, or {@code null} to clear
   */
  public void setCategory(@Nullable String value) {
    _category = value;
  }

  /**
   * Get the {@code percentage} property.
   *
   * @return the percentage value, or {@code null} if not set
   */
  @Nullable
  public BigDecimal getPercentage() {
    return _percentage;
  }

  /**
   * Set the {@code percentage} property.
   *
   * @param value
   *           the percentage value to set, or {@code null} to clear
   */
  public void setPercentage(@Nullable BigDecimal value) {
    _percentage = value;
  }

  /**
   * Get the field value.
   *
   * @return the value
   */
  @Nullable
  public String getValue() {
    return _value;
  }

  /**
   * Set the field value.
   *
   * @param value
   *           the value to set
   */
  public void setValue(@Nullable String value) {
    _value = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
