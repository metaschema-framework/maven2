// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.
 */
@MetaschemaAssembly(
    formalName = "Mapping Provenance",
    description = "Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.",
    name = "mapping-provenance",
    moduleClass = OscalMappingCommonModule.class
)
public class MappingProvenance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The method used to complete the overall mapping.
   */
  @BoundFlag(
      formalName = "Method",
      description = "The method used to complete the overall mapping.",
      name = "method",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "human", description = "Human"), @AllowedValue(value = "automation", description = "Automation"), @AllowedValue(value = "hybrid", description = "Hybrid")}))
  )
  private String _method;

  /**
   * The method used for relating controls within the mapping. The supported methods are aligned with the <a href="https://doi.org/10.6028/NIST.IR.8477">NIST Interagency Report (IR) 8477</a>, Section 4.3 Set Theory Relationship Mapping.
   */
  @BoundFlag(
      formalName = "Matching",
      description = "The method used for relating controls within the mapping. The supported methods are aligned with the [NIST Interagency Report (IR) 8477](https://doi.org/10.6028/NIST.IR.8477), Section 4.3 Set Theory Relationship Mapping.",
      name = "matching-rationale",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "syntactic", description = "Syntactic: How similar is the *wording* that expresses the two concepts. This is a word-for-word analysis of the relationship, not an interpretation of the language."), @AllowedValue(value = "semantic", description = "Semantic: How similar are the *meanings* of the two concepts? This involves some interpretation of each concept’s language."), @AllowedValue(value = "functional", description = "Functional: How similar are the *results* of executing the two concepts? This involves understanding what will happen if the two concepts are implemented, performed, or otherwise executed.")}))
  )
  private String _matchingRationale;

  /**
   * The current status of this mapping document.
   */
  @BoundFlag(
      formalName = "Status",
      description = "The current status of this mapping document.",
      name = "status",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "complete", description = "Complete"), @AllowedValue(value = "not-complete", description = "Not Complete"), @AllowedValue(value = "draft", description = "Draft"), @AllowedValue(value = "deprecated", description = "Deprecated"), @AllowedValue(value = "superseded", description = "Superseded")}))
  )
  private String _status;

  /**
   * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
   */
  @BoundField(
      formalName = "Confidence Score",
      description = "This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.",
      useName = "confidence-score"
  )
  private ConfidenceScore _confidenceScore;

  /**
   * A decimal value from 0-1, representing the percentage coverage of the targets by the sources.
   */
  @BoundField(
      formalName = "Coverage",
      description = "A decimal value from 0-1, representing the percentage coverage of the targets by the sources.",
      useName = "coverage"
  )
  private Coverage _coverage;

  /**
   * Description of the context and intended use of the mapping set.
   */
  @BoundField(
      formalName = "Mapping Description",
      description = "Description of the context and intended use of the mapping set.",
      useName = "mapping-description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _mappingDescription;

  /**
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   */
  @BoundAssembly(
      formalName = "Responsible Party",
      description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
      useName = "responsible-party",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleParty> _responsibleParties;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappingProvenance} instance with no metadata.
   */
  public MappingProvenance() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappingProvenance} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public MappingProvenance(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Method}".
   *
   * <p>
   * The method used to complete the overall mapping.
   *
   * @return the method value
   */
  @NonNull
  public String getMethod() {
    return _method;
  }

  /**
   * Set the "{@literal Method}".
   *
   * <p>
   * The method used to complete the overall mapping.
   *
   * @param value
   *           the method value to set
   */
  public void setMethod(@NonNull String value) {
    _method = value;
  }

  /**
   * Get the "{@literal Matching}".
   *
   * <p>
   * The method used for relating controls within the mapping. The supported methods are aligned with the <a href="https://doi.org/10.6028/NIST.IR.8477">NIST Interagency Report (IR) 8477</a>, Section 4.3 Set Theory Relationship Mapping.
   *
   * @return the matching-rationale value
   */
  @NonNull
  public String getMatchingRationale() {
    return _matchingRationale;
  }

  /**
   * Set the "{@literal Matching}".
   *
   * <p>
   * The method used for relating controls within the mapping. The supported methods are aligned with the <a href="https://doi.org/10.6028/NIST.IR.8477">NIST Interagency Report (IR) 8477</a>, Section 4.3 Set Theory Relationship Mapping.
   *
   * @param value
   *           the matching-rationale value to set
   */
  public void setMatchingRationale(@NonNull String value) {
    _matchingRationale = value;
  }

  /**
   * Get the "{@literal Status}".
   *
   * <p>
   * The current status of this mapping document.
   *
   * @return the status value
   */
  @NonNull
  public String getStatus() {
    return _status;
  }

  /**
   * Set the "{@literal Status}".
   *
   * <p>
   * The current status of this mapping document.
   *
   * @param value
   *           the status value to set
   */
  public void setStatus(@NonNull String value) {
    _status = value;
  }

  /**
   * Get the "{@literal Confidence Score}".
   *
   * <p>
   * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
   *
   * @return the confidence-score value, or {@code null} if not set
   */
  @Nullable
  public ConfidenceScore getConfidenceScore() {
    return _confidenceScore;
  }

  /**
   * Set the "{@literal Confidence Score}".
   *
   * <p>
   * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
   *
   * @param value
   *           the confidence-score value to set, or {@code null} to clear
   */
  public void setConfidenceScore(@Nullable ConfidenceScore value) {
    _confidenceScore = value;
  }

  /**
   * Get the "{@literal Coverage}".
   *
   * <p>
   * A decimal value from 0-1, representing the percentage coverage of the targets by the sources.
   *
   * @return the coverage value, or {@code null} if not set
   */
  @Nullable
  public Coverage getCoverage() {
    return _coverage;
  }

  /**
   * Set the "{@literal Coverage}".
   *
   * <p>
   * A decimal value from 0-1, representing the percentage coverage of the targets by the sources.
   *
   * @param value
   *           the coverage value to set, or {@code null} to clear
   */
  public void setCoverage(@Nullable Coverage value) {
    _coverage = value;
  }

  /**
   * Get the "{@literal Mapping Description}".
   *
   * <p>
   * Description of the context and intended use of the mapping set.
   *
   * @return the mapping-description value
   */
  @NonNull
  public MarkupMultiline getMappingDescription() {
    return _mappingDescription;
  }

  /**
   * Set the "{@literal Mapping Description}".
   *
   * <p>
   * Description of the context and intended use of the mapping set.
   *
   * @param value
   *           the mapping-description value to set
   */
  public void setMappingDescription(@NonNull MarkupMultiline value) {
    _mappingDescription = value;
  }

  /**
   * Get the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @return the responsible-party value
   */
  @NonNull
  public List<ResponsibleParty> getResponsibleParties() {
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleParties);
  }

  /**
   * Set the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @param value
   *           the responsible-party value to set
   */
  public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
    _responsibleParties = value;
  }

  /**
   * Add a new {@link ResponsibleParty} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return _responsibleParties.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleParties != null && _responsibleParties.remove(value);
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
