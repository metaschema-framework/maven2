// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies the controls being assessed and their control objectives.
 */
@MetaschemaAssembly(
    formalName = "Reviewed Controls and Control Objectives",
    description = "Identifies the controls being assessed and their control objectives.",
    name = "reviewed-controls",
    moduleClass = OscalAssessmentCommonModule.class,
    remarks = "In the context of an assessment plan, this construct is used to identify the controls and control objectives that are to be assessed. In the context of an assessment result, this construct is used to identify the actual controls and objectives that were assessed, reflecting any changes from the plan.\n"
            + "\n"
            + "When resolving the selection of controls and control objectives, the following processing will occur:\n"
            + "\n"
            + "1. Controls will be resolved by creating a set of controls based on the control-selections by first handling the includes, and then removing any excluded controls.\n"
            + "\n"
            + "2. The set of control objectives will be resolved from the set of controls that was generated in the previous step. The set of control objectives is based on the control-objective-selection by first handling the includes, and then removing any excluded control objectives."
)
public class ReviewedControls implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A human-readable description of control objectives.
   */
  @BoundField(
      formalName = "Control Objective Description",
      description = "A human-readable description of control objectives.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the controls being assessed. In the assessment plan, these are the planned controls. In the assessment results, these are the actual controls, and reflects any changes from the plan.
   */
  @BoundAssembly(
      formalName = "Assessed Controls",
      description = "Identifies the controls being assessed. In the assessment plan, these are the planned controls. In the assessment results, these are the actual controls, and reflects any changes from the plan.",
      useName = "control-selection",
      remarks = "The `include-all`, specifies all control identified in the **baseline** are included in the scope if this assessment, as specified by the `include-profile` statement within the linked SSP.\n"
              + "\n"
              + "Any control specified within `exclude-controls` must first be within a range of explicitly included controls, via `include-controls` or `include-all`.",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "control-selections", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlSelection> _controlSelections;

  /**
   * Identifies the control objectives of the assessment. In the assessment plan, these are the planned objectives. In the assessment results, these are the assessed objectives, and reflects any changes from the plan.
   */
  @BoundAssembly(
      formalName = "Referenced Control Objectives",
      description = "Identifies the control objectives of the assessment. In the assessment plan, these are the planned objectives. In the assessment results, these are the assessed objectives, and reflects any changes from the plan.",
      useName = "control-objective-selection",
      remarks = "The `include-all` field, specifies all control objectives for any in-scope control. In-scope controls are defined in the `control-selection`.\n"
              + "\n"
              + "Any control objective specified within `exclude-controls` must first be within a range of explicitly included control objectives, via `include-objectives` or `include-all`.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "control-objective-selections", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlObjectiveSelection> _controlObjectiveSelections;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ReviewedControls} instance with no metadata.
   */
  public ReviewedControls() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ReviewedControls} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ReviewedControls(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Control Objective Description}".
   *
   * <p>
   * A human-readable description of control objectives.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Control Objective Description}".
   *
   * <p>
   * A human-readable description of control objectives.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Assessed Controls}".
   *
   * <p>
   * Identifies the controls being assessed. In the assessment plan, these are the planned controls. In the assessment results, these are the actual controls, and reflects any changes from the plan.
   *
   * @return the control-selection value
   */
  @NonNull
  public List<ControlSelection> getControlSelections() {
    if (_controlSelections == null) {
      _controlSelections = new LinkedList<>();
    }
    return ObjectUtils.notNull(_controlSelections);
  }

  /**
   * Set the "{@literal Assessed Controls}".
   *
   * <p>
   * Identifies the controls being assessed. In the assessment plan, these are the planned controls. In the assessment results, these are the actual controls, and reflects any changes from the plan.
   *
   * @param value
   *           the control-selection value to set
   */
  public void setControlSelections(@NonNull List<ControlSelection> value) {
    _controlSelections = value;
  }

  /**
   * Add a new {@link ControlSelection} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addControlSelection(ControlSelection item) {
    ControlSelection value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_controlSelections == null) {
      _controlSelections = new LinkedList<>();
    }
    return _controlSelections.add(value);
  }

  /**
   * Remove the first matching {@link ControlSelection} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeControlSelection(ControlSelection item) {
    ControlSelection value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _controlSelections != null && _controlSelections.remove(value);
  }

  /**
   * Get the "{@literal Referenced Control Objectives}".
   *
   * <p>
   * Identifies the control objectives of the assessment. In the assessment plan, these are the planned objectives. In the assessment results, these are the assessed objectives, and reflects any changes from the plan.
   *
   * @return the control-objective-selection value
   */
  @NonNull
  public List<ControlObjectiveSelection> getControlObjectiveSelections() {
    if (_controlObjectiveSelections == null) {
      _controlObjectiveSelections = new LinkedList<>();
    }
    return ObjectUtils.notNull(_controlObjectiveSelections);
  }

  /**
   * Set the "{@literal Referenced Control Objectives}".
   *
   * <p>
   * Identifies the control objectives of the assessment. In the assessment plan, these are the planned objectives. In the assessment results, these are the assessed objectives, and reflects any changes from the plan.
   *
   * @param value
   *           the control-objective-selection value to set
   */
  public void setControlObjectiveSelections(@NonNull List<ControlObjectiveSelection> value) {
    _controlObjectiveSelections = value;
  }

  /**
   * Add a new {@link ControlObjectiveSelection} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addControlObjectiveSelection(ControlObjectiveSelection item) {
    ControlObjectiveSelection value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_controlObjectiveSelections == null) {
      _controlObjectiveSelections = new LinkedList<>();
    }
    return _controlObjectiveSelections.add(value);
  }

  /**
   * Remove the first matching {@link ControlObjectiveSelection} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeControlObjectiveSelection(ControlObjectiveSelection item) {
    ControlObjectiveSelection value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _controlObjectiveSelections != null && _controlObjectiveSelections.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Identifies the controls being assessed. In the assessment plan, these are the planned controls. In the assessment results, these are the actual controls, and reflects any changes from the plan.
   */
  @MetaschemaAssembly(
      formalName = "Assessed Controls",
      description = "Identifies the controls being assessed. In the assessment plan, these are the planned controls. In the assessment results, these are the actual controls, and reflects any changes from the plan.",
      name = "control-selection",
      moduleClass = OscalAssessmentCommonModule.class,
      remarks = "The `include-all`, specifies all control identified in the **baseline** are included in the scope if this assessment, as specified by the `include-profile` statement within the linked SSP.\n"
              + "\n"
              + "Any control specified within `exclude-controls` must first be within a range of explicitly included controls, via `include-controls` or `include-all`."
  )
  public static class ControlSelection implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A human-readable description of in-scope controls specified for assessment.
     */
    @BoundField(
        formalName = "Assessed Controls Description",
        description = "A human-readable description of in-scope controls specified for assessment.",
        useName = "description",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Include all controls from the imported catalog or profile resources.
     */
    @BoundAssembly(
        formalName = "Include All",
        description = "Include all controls from the imported catalog or profile resources.",
        useName = "include-all",
        minOccurs = 1
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private IncludeAll _includeAll;

    /**
     * Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.
     */
    @BoundAssembly(
        formalName = "Select Control",
        description = "Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.",
        useName = "include-control",
        remarks = "Used to select a control for inclusion by the control's identifier. Specific control statements can be selected by their statement identifier.",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "include-controls", inJson = JsonGroupAsBehavior.LIST)
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private List<SelectControlByIdOscalAssessmentCommon> _includeControls;

    /**
     * Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.
     */
    @BoundAssembly(
        formalName = "Select Control",
        description = "Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.",
        useName = "exclude-control",
        remarks = "Used to select a control for exclusion by the control's identifier. Specific control statements can be excluded by their statement identifier.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "exclude-controls", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SelectControlByIdOscalAssessmentCommon> _excludeControls;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ReviewedControls.ControlSelection} instance with no metadata.
     */
    public ControlSelection() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ReviewedControls.ControlSelection} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public ControlSelection(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Assessed Controls Description}".
     *
     * <p>
     * A human-readable description of in-scope controls specified for assessment.
     *
     * @return the description value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Assessed Controls Description}".
     *
     * <p>
     * A human-readable description of in-scope controls specified for assessment.
     *
     * @param value
     *           the description value to set, or {@code null} to clear
     */
    public void setDescription(@Nullable MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Include All}".
     *
     * <p>
     * Include all controls from the imported catalog or profile resources.
     *
     * @return the include-all value, or {@code null} if not set
     */
    @Nullable
    public IncludeAll getIncludeAll() {
      return _includeAll;
    }

    /**
     * Set the "{@literal Include All}".
     *
     * <p>
     * Include all controls from the imported catalog or profile resources.
     *
     * @param value
     *           the include-all value to set, or {@code null} to clear
     */
    public void setIncludeAll(@Nullable IncludeAll value) {
      _includeAll = value;
    }

    /**
     * Get the "{@literal Select Control}".
     *
     * <p>
     * Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.
     *
     * @return the include-control value
     */
    @NonNull
    public List<SelectControlByIdOscalAssessmentCommon> getIncludeControls() {
      if (_includeControls == null) {
        _includeControls = new LinkedList<>();
      }
      return ObjectUtils.notNull(_includeControls);
    }

    /**
     * Set the "{@literal Select Control}".
     *
     * <p>
     * Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.
     *
     * @param value
     *           the include-control value to set
     */
    public void setIncludeControls(@NonNull List<SelectControlByIdOscalAssessmentCommon> value) {
      _includeControls = value;
    }

    /**
     * Add a new {@link SelectControlByIdOscalAssessmentCommon} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addIncludeControl(SelectControlByIdOscalAssessmentCommon item) {
      SelectControlByIdOscalAssessmentCommon value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_includeControls == null) {
        _includeControls = new LinkedList<>();
      }
      return _includeControls.add(value);
    }

    /**
     * Remove the first matching {@link SelectControlByIdOscalAssessmentCommon} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeIncludeControl(SelectControlByIdOscalAssessmentCommon item) {
      SelectControlByIdOscalAssessmentCommon value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _includeControls != null && _includeControls.remove(value);
    }

    /**
     * Get the "{@literal Select Control}".
     *
     * <p>
     * Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.
     *
     * @return the exclude-control value
     */
    @NonNull
    public List<SelectControlByIdOscalAssessmentCommon> getExcludeControls() {
      if (_excludeControls == null) {
        _excludeControls = new LinkedList<>();
      }
      return ObjectUtils.notNull(_excludeControls);
    }

    /**
     * Set the "{@literal Select Control}".
     *
     * <p>
     * Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.
     *
     * @param value
     *           the exclude-control value to set
     */
    public void setExcludeControls(@NonNull List<SelectControlByIdOscalAssessmentCommon> value) {
      _excludeControls = value;
    }

    /**
     * Add a new {@link SelectControlByIdOscalAssessmentCommon} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addExcludeControl(SelectControlByIdOscalAssessmentCommon item) {
      SelectControlByIdOscalAssessmentCommon value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_excludeControls == null) {
        _excludeControls = new LinkedList<>();
      }
      return _excludeControls.add(value);
    }

    /**
     * Remove the first matching {@link SelectControlByIdOscalAssessmentCommon} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeExcludeControl(SelectControlByIdOscalAssessmentCommon item) {
      SelectControlByIdOscalAssessmentCommon value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _excludeControls != null && _excludeControls.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Identifies the control objectives of the assessment. In the assessment plan, these are the planned objectives. In the assessment results, these are the assessed objectives, and reflects any changes from the plan.
   */
  @MetaschemaAssembly(
      formalName = "Referenced Control Objectives",
      description = "Identifies the control objectives of the assessment. In the assessment plan, these are the planned objectives. In the assessment results, these are the assessed objectives, and reflects any changes from the plan.",
      name = "control-objective-selection",
      moduleClass = OscalAssessmentCommonModule.class,
      remarks = "The `include-all` field, specifies all control objectives for any in-scope control. In-scope controls are defined in the `control-selection`.\n"
              + "\n"
              + "Any control objective specified within `exclude-controls` must first be within a range of explicitly included control objectives, via `include-objectives` or `include-all`."
  )
  public static class ControlObjectiveSelection implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A human-readable description of this collection of control objectives.
     */
    @BoundField(
        formalName = "Control Objectives Description",
        description = "A human-readable description of this collection of control objectives.",
        useName = "description",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Include all controls from the imported catalog or profile resources.
     */
    @BoundAssembly(
        formalName = "Include All",
        description = "Include all controls from the imported catalog or profile resources.",
        useName = "include-all",
        minOccurs = 1
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private IncludeAll _includeAll;

    /**
     * Used to select a control objective for inclusion/exclusion based on the control objective's identifier.
     */
    @BoundAssembly(
        formalName = "Select Objective",
        description = "Used to select a control objective for inclusion/exclusion based on the control objective's identifier.",
        useName = "include-objective",
        remarks = "Used to select a control objective for inclusion by the control objective's identifier.",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "include-objectives", inJson = JsonGroupAsBehavior.LIST)
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private List<SelectObjectiveById> _includeObjectives;

    /**
     * Used to select a control objective for inclusion/exclusion based on the control objective's identifier.
     */
    @BoundAssembly(
        formalName = "Select Objective",
        description = "Used to select a control objective for inclusion/exclusion based on the control objective's identifier.",
        useName = "exclude-objective",
        remarks = "Used to select a control objective for exclusion by the control objective's identifier.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "exclude-objectives", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SelectObjectiveById> _excludeObjectives;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ReviewedControls.ControlObjectiveSelection} instance with no metadata.
     */
    public ControlObjectiveSelection() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ReviewedControls.ControlObjectiveSelection} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public ControlObjectiveSelection(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Control Objectives Description}".
     *
     * <p>
     * A human-readable description of this collection of control objectives.
     *
     * @return the description value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Control Objectives Description}".
     *
     * <p>
     * A human-readable description of this collection of control objectives.
     *
     * @param value
     *           the description value to set, or {@code null} to clear
     */
    public void setDescription(@Nullable MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Include All}".
     *
     * <p>
     * Include all controls from the imported catalog or profile resources.
     *
     * @return the include-all value, or {@code null} if not set
     */
    @Nullable
    public IncludeAll getIncludeAll() {
      return _includeAll;
    }

    /**
     * Set the "{@literal Include All}".
     *
     * <p>
     * Include all controls from the imported catalog or profile resources.
     *
     * @param value
     *           the include-all value to set, or {@code null} to clear
     */
    public void setIncludeAll(@Nullable IncludeAll value) {
      _includeAll = value;
    }

    /**
     * Get the "{@literal Select Objective}".
     *
     * <p>
     * Used to select a control objective for inclusion/exclusion based on the control objective's identifier.
     *
     * @return the include-objective value
     */
    @NonNull
    public List<SelectObjectiveById> getIncludeObjectives() {
      if (_includeObjectives == null) {
        _includeObjectives = new LinkedList<>();
      }
      return ObjectUtils.notNull(_includeObjectives);
    }

    /**
     * Set the "{@literal Select Objective}".
     *
     * <p>
     * Used to select a control objective for inclusion/exclusion based on the control objective's identifier.
     *
     * @param value
     *           the include-objective value to set
     */
    public void setIncludeObjectives(@NonNull List<SelectObjectiveById> value) {
      _includeObjectives = value;
    }

    /**
     * Add a new {@link SelectObjectiveById} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addIncludeObjective(SelectObjectiveById item) {
      SelectObjectiveById value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_includeObjectives == null) {
        _includeObjectives = new LinkedList<>();
      }
      return _includeObjectives.add(value);
    }

    /**
     * Remove the first matching {@link SelectObjectiveById} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeIncludeObjective(SelectObjectiveById item) {
      SelectObjectiveById value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _includeObjectives != null && _includeObjectives.remove(value);
    }

    /**
     * Get the "{@literal Select Objective}".
     *
     * <p>
     * Used to select a control objective for inclusion/exclusion based on the control objective's identifier.
     *
     * @return the exclude-objective value
     */
    @NonNull
    public List<SelectObjectiveById> getExcludeObjectives() {
      if (_excludeObjectives == null) {
        _excludeObjectives = new LinkedList<>();
      }
      return ObjectUtils.notNull(_excludeObjectives);
    }

    /**
     * Set the "{@literal Select Objective}".
     *
     * <p>
     * Used to select a control objective for inclusion/exclusion based on the control objective's identifier.
     *
     * @param value
     *           the exclude-objective value to set
     */
    public void setExcludeObjectives(@NonNull List<SelectObjectiveById> value) {
      _excludeObjectives = value;
    }

    /**
     * Add a new {@link SelectObjectiveById} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addExcludeObjective(SelectObjectiveById item) {
      SelectObjectiveById value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_excludeObjectives == null) {
        _excludeObjectives = new LinkedList<>();
      }
      return _excludeObjectives.add(value);
    }

    /**
     * Remove the first matching {@link SelectObjectiveById} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeExcludeObjective(SelectObjectiveById item) {
      SelectObjectiveById value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _excludeObjectives != null && _excludeObjectives.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
