// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Select a control or controls from an imported control set.
 */
@MetaschemaAssembly(
    formalName = "Select Control",
    description = "Select a control or controls from an imported control set.",
    name = "select-control-by-id",
    moduleClass = OscalMappingCommonModule.class,
    remarks = "If `with-child-controls` is \"yes\" on the call to a control, no sibling `call`elements need to be used to call any controls appearing within it. Since generally, this is how control enhancements are represented (as controls within controls), this provides a way to include controls with all their dependent controls (enhancements) without having to call them individually."
)
public class SelectControlById implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * When a control is included, whether its child (dependent) controls are also included.
   */
  @BoundFlag(
      formalName = "Include Contained Controls with Control",
      description = "When a control is included, whether its child (dependent) controls are also included.",
      name = "with-child-controls",
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "yes", description = "Include child controls with an included control."), @AllowedValue(value = "no", description = "When importing a control, only include child controls that are also explicitly called.")}))
  )
  private String _withChildControls;

  /**
   * Selecting a control by its ID given as a literal.
   */
  @BoundField(
      formalName = "Match Controls by Identifier",
      description = "Selecting a control by its ID given as a literal.",
      useName = "with-id",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "with-ids", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = TokenAdapter.class
  )
  private List<String> _withIds;

  /**
   * Selecting a set of controls by matching their IDs with a wildcard pattern.
   */
  @BoundAssembly(
      formalName = "Match Controls by Pattern",
      description = "Selecting a set of controls by matching their IDs with a wildcard pattern.",
      useName = "matching",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "matching", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<MappedControlMatching> _matching;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SelectControlById} instance with no metadata.
   */
  public SelectControlById() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SelectControlById} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SelectControlById(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Include Contained Controls with Control}".
   *
   * <p>
   * When a control is included, whether its child (dependent) controls are also included.
   *
   * @return the with-child-controls value, or {@code null} if not set
   */
  @Nullable
  public String getWithChildControls() {
    return _withChildControls;
  }

  /**
   * Set the "{@literal Include Contained Controls with Control}".
   *
   * <p>
   * When a control is included, whether its child (dependent) controls are also included.
   *
   * @param value
   *           the with-child-controls value to set, or {@code null} to clear
   */
  public void setWithChildControls(@Nullable String value) {
    _withChildControls = value;
  }

  /**
   * Get the "{@literal Match Controls by Identifier}".
   *
   * <p>
   * Selecting a control by its ID given as a literal.
   *
   * @return the with-id value
   */
  @NonNull
  public List<String> getWithIds() {
    if (_withIds == null) {
      _withIds = new LinkedList<>();
    }
    return ObjectUtils.notNull(_withIds);
  }

  /**
   * Set the "{@literal Match Controls by Identifier}".
   *
   * <p>
   * Selecting a control by its ID given as a literal.
   *
   * @param value
   *           the with-id value to set
   */
  public void setWithIds(@NonNull List<String> value) {
    _withIds = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addWithId(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_withIds == null) {
      _withIds = new LinkedList<>();
    }
    return _withIds.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeWithId(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _withIds != null && _withIds.remove(value);
  }

  /**
   * Get the "{@literal Match Controls by Pattern}".
   *
   * <p>
   * Selecting a set of controls by matching their IDs with a wildcard pattern.
   *
   * @return the matching value
   */
  @NonNull
  public List<MappedControlMatching> getMatching() {
    if (_matching == null) {
      _matching = new LinkedList<>();
    }
    return ObjectUtils.notNull(_matching);
  }

  /**
   * Set the "{@literal Match Controls by Pattern}".
   *
   * <p>
   * Selecting a set of controls by matching their IDs with a wildcard pattern.
   *
   * @param value
   *           the matching value to set
   */
  public void setMatching(@NonNull List<MappedControlMatching> value) {
    _matching = value;
  }

  /**
   * Add a new {@link MappedControlMatching} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addMatching(MappedControlMatching item) {
    MappedControlMatching value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_matching == null) {
      _matching = new LinkedList<>();
    }
    return _matching.add(value);
  }

  /**
   * Remove the first matching {@link MappedControlMatching} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeMatching(MappedControlMatching item) {
    MappedControlMatching value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _matching != null && _matching.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
