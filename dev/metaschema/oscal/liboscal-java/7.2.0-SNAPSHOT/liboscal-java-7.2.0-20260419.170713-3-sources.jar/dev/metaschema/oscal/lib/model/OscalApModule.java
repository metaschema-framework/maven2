// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-plan_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.databind.IBindingContext;
import dev.metaschema.databind.model.AbstractBoundModule;
import dev.metaschema.databind.model.IBoundModule;
import dev.metaschema.databind.model.annotations.MetaschemaModule;
import java.net.URI;
import java.util.List;

/**
 * OSCAL Assessment Plan Model
 * <p>The OSCAL assessment plan format is used to describe the information typically provided by an assessor during the preparation for an assessment.</p>
 * <p>The root of the OSCAL assessment plan format is <code>assessment-plan</code>.</p>
 */
@MetaschemaModule(
    assemblies = AssessmentPlan.class,
    imports = {
        OscalMetadataModule.class,
        OscalAssessmentCommonModule.class
    },
    remarks = "The OSCAL assessment plan format is used to describe the information typically provided by an assessor during the preparation for an assessment.\n"
            + "\n"
            + "The root of the OSCAL assessment plan format is `assessment-plan`."
)
public final class OscalApModule extends AbstractBoundModule {
  private static final MarkupLine NAME = MarkupLine.fromMarkdown("OSCAL Assessment Plan Model");

  private static final String SHORT_NAME = "oscal-ap";

  private static final String VERSION = "1.2.0";

  private static final URI XML_NAMESPACE = URI.create("http://csrc.nist.gov/ns/oscal/1.0");

  private static final URI JSON_BASE_URI = URI.create("http://csrc.nist.gov/ns/oscal");

  private static final MarkupMultiline REMARKS = MarkupMultiline.fromMarkdown("The OSCAL assessment plan format is used to describe the information typically provided by an assessor during the preparation for an assessment.\n"
      + "\n"
      + "The root of the OSCAL assessment plan format is `assessment-plan`.");

  /**
   * Construct a new module instance.
   *
   * @param importedModules
   *           modules imported by this module
   * @param bindingContext
   *           the binding context to associate with this module
   */
  public OscalApModule(List<? extends IBoundModule> importedModules,
      IBindingContext bindingContext) {
    super(importedModules, bindingContext);
  }

  @Override
  public MarkupLine getName() {
    return NAME;
  }

  @Override
  public String getShortName() {
    return SHORT_NAME;
  }

  @Override
  public String getVersion() {
    return VERSION;
  }

  @Override
  public URI getXmlNamespace() {
    return XML_NAMESPACE;
  }

  @Override
  public URI getJsonBaseUri() {
    return JSON_BASE_URI;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return REMARKS;
  }
}
