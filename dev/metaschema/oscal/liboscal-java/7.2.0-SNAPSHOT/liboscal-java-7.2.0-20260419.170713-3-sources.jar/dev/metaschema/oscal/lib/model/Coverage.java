// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DecimalAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A decimal value from 0-1, representing the percentage coverage of the targets by the sources.
 */
@MetaschemaField(
    formalName = "Coverage",
    description = "A decimal value from 0-1, representing the percentage coverage of the targets by the sources.",
    name = "coverage",
    moduleClass = OscalMappingCommonModule.class
)
public class Coverage implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  @BoundFlag(
      name = "generation-method",
      defaultValue = "arbitrary",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, allowOthers = true, values = @AllowedValue(value = "arbitrary", description = "The coverage value is a qualitative estimate of coverage with no strict formula.")))
  )
  private String _generationMethod;

  /**
   * The field value.
   */
  @BoundFieldValue(
      valueKeyName = "STRVALUE",
      typeAdapter = DecimalAdapter.class
  )
  private BigDecimal _value;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Coverage} instance with no metadata.
   */
  public Coverage() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Coverage} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Coverage(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the {@code generation-method} property.
   *
   * @return the generation-method value, or {@code null} if not set
   */
  @Nullable
  public String getGenerationMethod() {
    return _generationMethod;
  }

  /**
   * Set the {@code generation-method} property.
   *
   * @param value
   *           the generation-method value to set, or {@code null} to clear
   */
  public void setGenerationMethod(@Nullable String value) {
    _generationMethod = value;
  }

  /**
   * Get the field value.
   *
   * @return the value
   */
  @Nullable
  public BigDecimal getValue() {
    return _value;
  }

  /**
   * Set the field value.
   *
   * @param value
   *           the value to set
   */
  public void setValue(@Nullable BigDecimal value) {
    _value = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
