// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.
 */
@MetaschemaAssembly(
    formalName = "Select Control",
    description = "Used to select a control for inclusion/exclusion based on one or more control identifiers. A set of statement identifiers can be used to target the inclusion/exclusion to only specific control statements providing more granularity over the specific statements that are within the assessment scope.",
    name = "select-control-by-id",
    moduleClass = OscalAssessmentCommonModule.class
)
public class SelectControlByIdOscalAssessmentCommon implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   */
  @BoundFlag(
      formalName = "Control Identifier Reference",
      description = "A reference to a control with a corresponding `id` value. When referencing an externally defined `control`, the `Control Identifier Reference` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).",
      name = "control-id",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _controlId;

  /**
   * Used to constrain the selection to only specificity identified statements.
   */
  @BoundField(
      formalName = "Include Specific Statements",
      description = "Used to constrain the selection to only specificity identified statements.",
      useName = "statement-id",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "statement-ids", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = TokenAdapter.class
  )
  private List<String> _statementIds;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SelectControlByIdOscalAssessmentCommon} instance with no metadata.
   */
  public SelectControlByIdOscalAssessmentCommon() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SelectControlByIdOscalAssessmentCommon} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SelectControlByIdOscalAssessmentCommon(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @return the control-id value
   */
  @NonNull
  public String getControlId() {
    return _controlId;
  }

  /**
   * Set the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @param value
   *           the control-id value to set
   */
  public void setControlId(@NonNull String value) {
    _controlId = value;
  }

  /**
   * Get the "{@literal Include Specific Statements}".
   *
   * <p>
   * Used to constrain the selection to only specificity identified statements.
   *
   * @return the statement-id value
   */
  @NonNull
  public List<String> getStatementIds() {
    if (_statementIds == null) {
      _statementIds = new LinkedList<>();
    }
    return ObjectUtils.notNull(_statementIds);
  }

  /**
   * Set the "{@literal Include Specific Statements}".
   *
   * <p>
   * Used to constrain the selection to only specificity identified statements.
   *
   * @param value
   *           the statement-id value to set
   */
  public void setStatementIds(@NonNull List<String> value) {
    _statementIds = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addStatementId(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_statementIds == null) {
      _statementIds = new LinkedList<>();
    }
    return _statementIds.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeStatementId(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _statementIds != null && _statementIds.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
