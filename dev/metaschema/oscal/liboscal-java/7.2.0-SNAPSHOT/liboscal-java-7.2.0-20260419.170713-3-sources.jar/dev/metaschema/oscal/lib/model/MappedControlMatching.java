// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Selecting a set of controls by matching their IDs with a wildcard pattern.
 */
@MetaschemaAssembly(
    formalName = "Match Controls by Pattern",
    description = "Selecting a set of controls by matching their IDs with a wildcard pattern.",
    name = "matching",
    moduleClass = OscalMappingCommonModule.class
)
public class MappedControlMatching implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://en.wikipedia.org/wiki/Glob_(programming)">glob expression</a> matching the IDs of one or more controls to be selected.
   */
  @BoundFlag(
      formalName = "Pattern",
      description = "A [glob expression](https://en.wikipedia.org/wiki/Glob_(programming)) matching the IDs of one or more controls to be selected.",
      name = "pattern",
      typeAdapter = StringAdapter.class
  )
  private String _pattern;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappedControlMatching} instance with no metadata.
   */
  public MappedControlMatching() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappedControlMatching} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public MappedControlMatching(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Pattern}".
   *
   * <p>
   * A <a href="https://en.wikipedia.org/wiki/Glob_(programming)">glob expression</a> matching the IDs of one or more controls to be selected.
   *
   * @return the pattern value, or {@code null} if not set
   */
  @Nullable
  public String getPattern() {
    return _pattern;
  }

  /**
   * Set the "{@literal Pattern}".
   *
   * <p>
   * A <a href="https://en.wikipedia.org/wiki/Glob_(programming)">glob expression</a> matching the IDs of one or more controls to be selected.
   *
   * @param value
   *           the pattern value to set, or {@code null} to clear
   */
  public void setPattern(@Nullable String value) {
    _pattern = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
