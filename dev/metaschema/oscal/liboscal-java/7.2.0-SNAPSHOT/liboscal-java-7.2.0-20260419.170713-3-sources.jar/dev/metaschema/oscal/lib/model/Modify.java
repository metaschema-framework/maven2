// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Set parameters or amend controls in resolution.
 */
@MetaschemaAssembly(
    formalName = "Modify Controls",
    description = "Set parameters or amend controls in resolution.",
    name = "modify",
    moduleClass = OscalProfileModule.class,
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-profile-modify-set-parameter", level = IConstraint.Level.ERROR, target = "set-parameter", keyFields = @KeyField(target = "@param-id"), remarks = "Since multiple `set-parameter` entries can be provided, each parameter must be set only once."))
)
public class Modify implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A parameter setting, to be propagated to points of insertion.
   */
  @BoundAssembly(
      formalName = "Parameter Setting",
      description = "A parameter setting, to be propagated to points of insertion.",
      useName = "set-parameter",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "set-parameters", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ProfileSetParameter> _setParameters;

  /**
   * Specifies changes to be made to an included control when a profile is resolved.
   */
  @BoundAssembly(
      formalName = "Alteration",
      description = "Specifies changes to be made to an included control when a profile is resolved.",
      useName = "alter",
      remarks = "Use `@control-id` to indicate the scope of alteration.\n"
              + "\n"
              + "It is an error for two `alter` elements to apply to the same control. In practice, multiple alterations can be applied (together), but it creates confusion.\n"
              + "\n"
              + "At present, no provision is made for altering many controls at once (for example, to systematically remove properties or add global properties); extending this element to match multiple control IDs could provide for this.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "alters", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Alter> _alters;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify} instance with no metadata.
   */
  public Modify() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Modify(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Parameter Setting}".
   *
   * <p>
   * A parameter setting, to be propagated to points of insertion.
   *
   * @return the set-parameter value
   */
  @NonNull
  public List<ProfileSetParameter> getSetParameters() {
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return ObjectUtils.notNull(_setParameters);
  }

  /**
   * Set the "{@literal Parameter Setting}".
   *
   * <p>
   * A parameter setting, to be propagated to points of insertion.
   *
   * @param value
   *           the set-parameter value to set
   */
  public void setSetParameters(@NonNull List<ProfileSetParameter> value) {
    _setParameters = value;
  }

  /**
   * Add a new {@link ProfileSetParameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSetParameter(ProfileSetParameter item) {
    ProfileSetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return _setParameters.add(value);
  }

  /**
   * Remove the first matching {@link ProfileSetParameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSetParameter(ProfileSetParameter item) {
    ProfileSetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _setParameters != null && _setParameters.remove(value);
  }

  /**
   * Get the "{@literal Alteration}".
   *
   * <p>
   * Specifies changes to be made to an included control when a profile is resolved.
   *
   * @return the alter value
   */
  @NonNull
  public List<Alter> getAlters() {
    if (_alters == null) {
      _alters = new LinkedList<>();
    }
    return ObjectUtils.notNull(_alters);
  }

  /**
   * Set the "{@literal Alteration}".
   *
   * <p>
   * Specifies changes to be made to an included control when a profile is resolved.
   *
   * @param value
   *           the alter value to set
   */
  public void setAlters(@NonNull List<Alter> value) {
    _alters = value;
  }

  /**
   * Add a new {@link Alter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAlter(Alter item) {
    Alter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_alters == null) {
      _alters = new LinkedList<>();
    }
    return _alters.add(value);
  }

  /**
   * Remove the first matching {@link Alter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAlter(Alter item) {
    Alter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _alters != null && _alters.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * A parameter setting, to be propagated to points of insertion.
   */
  @MetaschemaAssembly(
      formalName = "Parameter Setting",
      description = "A parameter setting, to be propagated to points of insertion.",
      name = "set-parameter",
      moduleClass = OscalProfileModule.class
  )
  public static class ProfileSetParameter implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * An identifier for the parameter.
     */
    @BoundFlag(
        formalName = "Parameter ID",
        description = "An identifier for the parameter.",
        name = "param-id",
        required = true,
        typeAdapter = TokenAdapter.class
    )
    private String _paramId;

    /**
     * A textual label that provides a characterization of the parameter.
     */
    @BoundFlag(
        formalName = "Parameter Class",
        description = "A textual label that provides a characterization of the parameter.",
        name = "class",
        typeAdapter = TokenAdapter.class,
        remarks = "A `class` can be used in validation rules to express extra constraints over named items of a specific `class` value."
    )
    private String _clazz;

    /**
     * **(deprecated)** Another parameter invoking this one. This construct has been deprecated and should not be used.
     */
    @BoundFlag(
        formalName = "Depends On",
        description = "\\*\\*(deprecated)\\*\\* Another parameter invoking this one. This construct has been deprecated and should not be used.",
        name = "depends-on",
        typeAdapter = TokenAdapter.class
    )
    private String _dependsOn;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * A short, placeholder name for the parameter, which can be used as a substitute for a <code>value</code> if no value is assigned.
     */
    @BoundField(
        formalName = "Parameter Label",
        description = "A short, placeholder name for the parameter, which can be used as a substitute for a `value` if no value is assigned.",
        useName = "label",
        remarks = "The label value should be suitable for inline display in a rendered catalog.",
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _label;

    /**
     * Describes the purpose and use of a parameter.
     */
    @BoundField(
        formalName = "Parameter Usage Description",
        description = "Describes the purpose and use of a parameter.",
        useName = "usage",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _usage;

    /**
     * A formal or informal expression of a constraint or test.
     */
    @BoundAssembly(
        formalName = "Constraint",
        description = "A formal or informal expression of a constraint or test.",
        useName = "constraint",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "constraints", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ParameterConstraint> _constraints;

    /**
     * A prose statement that provides a recommendation for the use of a parameter.
     */
    @BoundAssembly(
        formalName = "Guideline",
        description = "A prose statement that provides a recommendation for the use of a parameter.",
        useName = "guideline",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "guidelines", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ParameterGuideline> _guidelines;

    /**
     * A parameter value or set of values.
     */
    @BoundField(
        formalName = "Parameter Value",
        description = "A parameter value or set of values.",
        useName = "value",
        remarks = "Used to (re)define a parameter value.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "values", inJson = JsonGroupAsBehavior.LIST),
        typeAdapter = StringAdapter.class
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private List<String> _values;

    /**
     * Presenting a choice among alternatives.
     */
    @BoundAssembly(
        formalName = "Selection",
        description = "Presenting a choice among alternatives.",
        useName = "select"
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private ParameterSelection _select;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.ProfileSetParameter} instance with no metadata.
     */
    public ProfileSetParameter() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.ProfileSetParameter} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public ProfileSetParameter(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Parameter ID}".
     *
     * <p>
     * An identifier for the parameter.
     *
     * @return the param-id value
     */
    @NonNull
    public String getParamId() {
      return _paramId;
    }

    /**
     * Set the "{@literal Parameter ID}".
     *
     * <p>
     * An identifier for the parameter.
     *
     * @param value
     *           the param-id value to set
     */
    public void setParamId(@NonNull String value) {
      _paramId = value;
    }

    /**
     * Get the "{@literal Parameter Class}".
     *
     * <p>
     * A textual label that provides a characterization of the parameter.
     *
     * @return the class value, or {@code null} if not set
     */
    @Nullable
    public String getClazz() {
      return _clazz;
    }

    /**
     * Set the "{@literal Parameter Class}".
     *
     * <p>
     * A textual label that provides a characterization of the parameter.
     *
     * @param value
     *           the class value to set, or {@code null} to clear
     */
    public void setClazz(@Nullable String value) {
      _clazz = value;
    }

    /**
     * Get the "{@literal Depends On}".
     *
     * <p>
     * **(deprecated)** Another parameter invoking this one. This construct has been deprecated and should not be used.
     *
     * @return the depends-on value, or {@code null} if not set
     */
    @Nullable
    public String getDependsOn() {
      return _dependsOn;
    }

    /**
     * Set the "{@literal Depends On}".
     *
     * <p>
     * **(deprecated)** Another parameter invoking this one. This construct has been deprecated and should not be used.
     *
     * @param value
     *           the depends-on value to set, or {@code null} to clear
     */
    public void setDependsOn(@Nullable String value) {
      _dependsOn = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Parameter Label}".
     *
     * <p>
     * A short, placeholder name for the parameter, which can be used as a substitute for a <code>value</code> if no value is assigned.
     *
     * @return the label value, or {@code null} if not set
     */
    @Nullable
    public MarkupLine getLabel() {
      return _label;
    }

    /**
     * Set the "{@literal Parameter Label}".
     *
     * <p>
     * A short, placeholder name for the parameter, which can be used as a substitute for a <code>value</code> if no value is assigned.
     *
     * @param value
     *           the label value to set, or {@code null} to clear
     */
    public void setLabel(@Nullable MarkupLine value) {
      _label = value;
    }

    /**
     * Get the "{@literal Parameter Usage Description}".
     *
     * <p>
     * Describes the purpose and use of a parameter.
     *
     * @return the usage value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getUsage() {
      return _usage;
    }

    /**
     * Set the "{@literal Parameter Usage Description}".
     *
     * <p>
     * Describes the purpose and use of a parameter.
     *
     * @param value
     *           the usage value to set, or {@code null} to clear
     */
    public void setUsage(@Nullable MarkupMultiline value) {
      _usage = value;
    }

    /**
     * Get the "{@literal Constraint}".
     *
     * <p>
     * A formal or informal expression of a constraint or test.
     *
     * @return the constraint value
     */
    @NonNull
    public List<ParameterConstraint> getConstraints() {
      if (_constraints == null) {
        _constraints = new LinkedList<>();
      }
      return ObjectUtils.notNull(_constraints);
    }

    /**
     * Set the "{@literal Constraint}".
     *
     * <p>
     * A formal or informal expression of a constraint or test.
     *
     * @param value
     *           the constraint value to set
     */
    public void setConstraints(@NonNull List<ParameterConstraint> value) {
      _constraints = value;
    }

    /**
     * Add a new {@link ParameterConstraint} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addConstraint(ParameterConstraint item) {
      ParameterConstraint value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_constraints == null) {
        _constraints = new LinkedList<>();
      }
      return _constraints.add(value);
    }

    /**
     * Remove the first matching {@link ParameterConstraint} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeConstraint(ParameterConstraint item) {
      ParameterConstraint value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _constraints != null && _constraints.remove(value);
    }

    /**
     * Get the "{@literal Guideline}".
     *
     * <p>
     * A prose statement that provides a recommendation for the use of a parameter.
     *
     * @return the guideline value
     */
    @NonNull
    public List<ParameterGuideline> getGuidelines() {
      if (_guidelines == null) {
        _guidelines = new LinkedList<>();
      }
      return ObjectUtils.notNull(_guidelines);
    }

    /**
     * Set the "{@literal Guideline}".
     *
     * <p>
     * A prose statement that provides a recommendation for the use of a parameter.
     *
     * @param value
     *           the guideline value to set
     */
    public void setGuidelines(@NonNull List<ParameterGuideline> value) {
      _guidelines = value;
    }

    /**
     * Add a new {@link ParameterGuideline} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addGuideline(ParameterGuideline item) {
      ParameterGuideline value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_guidelines == null) {
        _guidelines = new LinkedList<>();
      }
      return _guidelines.add(value);
    }

    /**
     * Remove the first matching {@link ParameterGuideline} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeGuideline(ParameterGuideline item) {
      ParameterGuideline value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _guidelines != null && _guidelines.remove(value);
    }

    /**
     * Get the "{@literal Parameter Value}".
     *
     * <p>
     * A parameter value or set of values.
     *
     * @return the value value
     */
    @NonNull
    public List<String> getValues() {
      if (_values == null) {
        _values = new LinkedList<>();
      }
      return ObjectUtils.notNull(_values);
    }

    /**
     * Set the "{@literal Parameter Value}".
     *
     * <p>
     * A parameter value or set of values.
     *
     * @param value
     *           the value value to set
     */
    public void setValues(@NonNull List<String> value) {
      _values = value;
    }

    /**
     * Add a new {@link String} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addValue(String item) {
      String value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_values == null) {
        _values = new LinkedList<>();
      }
      return _values.add(value);
    }

    /**
     * Remove the first matching {@link String} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeValue(String item) {
      String value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _values != null && _values.remove(value);
    }

    /**
     * Get the "{@literal Selection}".
     *
     * <p>
     * Presenting a choice among alternatives.
     *
     * @return the select value, or {@code null} if not set
     */
    @Nullable
    public ParameterSelection getSelect() {
      return _select;
    }

    /**
     * Set the "{@literal Selection}".
     *
     * <p>
     * Presenting a choice among alternatives.
     *
     * @param value
     *           the select value to set, or {@code null} to clear
     */
    public void setSelect(@Nullable ParameterSelection value) {
      _select = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Specifies changes to be made to an included control when a profile is resolved.
   */
  @MetaschemaAssembly(
      formalName = "Alteration",
      description = "Specifies changes to be made to an included control when a profile is resolved.",
      name = "alter",
      moduleClass = OscalProfileModule.class,
      remarks = "Use `@control-id` to indicate the scope of alteration.\n"
              + "\n"
              + "It is an error for two `alter` elements to apply to the same control. In practice, multiple alterations can be applied (together), but it creates confusion.\n"
              + "\n"
              + "At present, no provision is made for altering many controls at once (for example, to systematically remove properties or add global properties); extending this element to match multiple control IDs could provide for this."
  )
  public static class Alter implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
     */
    @BoundFlag(
        formalName = "Control Identifier Reference",
        description = "A reference to a control with a corresponding `id` value. When referencing an externally defined `control`, the `Control Identifier Reference` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).",
        name = "control-id",
        required = true,
        typeAdapter = TokenAdapter.class
    )
    private String _controlId;

    /**
     * Specifies objects to be removed from a control based on specific aspects of the object that must all match.
     */
    @BoundAssembly(
        formalName = "Removal",
        description = "Specifies objects to be removed from a control based on specific aspects of the object that must all match.",
        useName = "remove",
        remarks = "Use `by-name`, `by-class`, `by-id` or `by-item-name` to indicate class tokens or ID reference, or the formal name, of the component to be removed or erased from a control, when a catalog is resolved. The control affected is indicated by the pointer on the removal's parent (containing) `alter` element.\n"
                + "\n"
                + "To change an element, use `remove` to remove the element, then `add` to add it back again with changes.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "removes", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Remove> _removes;

    /**
     * Specifies contents to be added into controls, in resolution.
     */
    @BoundAssembly(
        formalName = "Addition",
        description = "Specifies contents to be added into controls, in resolution.",
        useName = "add",
        remarks = "When no `by-id` is given, the addition is inserted into the control targeted by the alteration at the start or end as indicated by `position`. Only `position` values of \"starting\" or \"ending\" are permitted when there is no `by-id`.\n"
                + "\n"
                + "`by-id`, when given, should indicate, by its ID, an element inside the control to serve as the anchor point for the addition. In this case, `position` value may be any of the permitted values.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "adds", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Add> _adds;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.Alter} instance with no metadata.
     */
    public Alter() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.Alter} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Alter(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Control Identifier Reference}".
     *
     * <p>
     * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
     *
     * @return the control-id value
     */
    @NonNull
    public String getControlId() {
      return _controlId;
    }

    /**
     * Set the "{@literal Control Identifier Reference}".
     *
     * <p>
     * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
     *
     * @param value
     *           the control-id value to set
     */
    public void setControlId(@NonNull String value) {
      _controlId = value;
    }

    /**
     * Get the "{@literal Removal}".
     *
     * <p>
     * Specifies objects to be removed from a control based on specific aspects of the object that must all match.
     *
     * @return the remove value
     */
    @NonNull
    public List<Remove> getRemoves() {
      if (_removes == null) {
        _removes = new LinkedList<>();
      }
      return ObjectUtils.notNull(_removes);
    }

    /**
     * Set the "{@literal Removal}".
     *
     * <p>
     * Specifies objects to be removed from a control based on specific aspects of the object that must all match.
     *
     * @param value
     *           the remove value to set
     */
    public void setRemoves(@NonNull List<Remove> value) {
      _removes = value;
    }

    /**
     * Add a new {@link Remove} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addRemove(Remove item) {
      Remove value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_removes == null) {
        _removes = new LinkedList<>();
      }
      return _removes.add(value);
    }

    /**
     * Remove the first matching {@link Remove} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeRemove(Remove item) {
      Remove value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _removes != null && _removes.remove(value);
    }

    /**
     * Get the "{@literal Addition}".
     *
     * <p>
     * Specifies contents to be added into controls, in resolution.
     *
     * @return the add value
     */
    @NonNull
    public List<Add> getAdds() {
      if (_adds == null) {
        _adds = new LinkedList<>();
      }
      return ObjectUtils.notNull(_adds);
    }

    /**
     * Set the "{@literal Addition}".
     *
     * <p>
     * Specifies contents to be added into controls, in resolution.
     *
     * @param value
     *           the add value to set
     */
    public void setAdds(@NonNull List<Add> value) {
      _adds = value;
    }

    /**
     * Add a new {@link Add} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addAdd(Add item) {
      Add value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_adds == null) {
        _adds = new LinkedList<>();
      }
      return _adds.add(value);
    }

    /**
     * Remove the first matching {@link Add} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeAdd(Add item) {
      Add value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _adds != null && _adds.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * Specifies objects to be removed from a control based on specific aspects of the object that must all match.
     */
    @MetaschemaAssembly(
        formalName = "Removal",
        description = "Specifies objects to be removed from a control based on specific aspects of the object that must all match.",
        name = "remove",
        moduleClass = OscalProfileModule.class,
        remarks = "Use `by-name`, `by-class`, `by-id` or `by-item-name` to indicate class tokens or ID reference, or the formal name, of the component to be removed or erased from a control, when a catalog is resolved. The control affected is indicated by the pointer on the removal's parent (containing) `alter` element.\n"
                + "\n"
                + "To change an element, use `remove` to remove the element, then `add` to add it back again with changes."
    )
    public static class Remove implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * Identify items remove by matching their assigned name.
       */
      @BoundFlag(
          formalName = "Reference by (assigned) name",
          description = "Identify items remove by matching their assigned name.",
          name = "by-name",
          typeAdapter = TokenAdapter.class
      )
      private String _byName;

      /**
       * Identify items to remove by matching their <code>class</code>.
       */
      @BoundFlag(
          formalName = "Reference by class",
          description = "Identify items to remove by matching their `class`.",
          name = "by-class",
          typeAdapter = TokenAdapter.class
      )
      private String _byClass;

      /**
       * Identify items to remove indicated by their <code>id</code>.
       */
      @BoundFlag(
          formalName = "Reference by ID",
          description = "Identify items to remove indicated by their `id`.",
          name = "by-id",
          typeAdapter = TokenAdapter.class
      )
      private String _byId;

      /**
       * Identify items to remove by the name of the item's information object name, e.g. <code>title</code> or <code>prop</code>.
       */
      @BoundFlag(
          formalName = "Item Name Reference",
          description = "Identify items to remove by the name of the item's information object name, e.g. `title` or `prop`.",
          name = "by-item-name",
          typeAdapter = TokenAdapter.class,
          valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-profile-alter-by-item-name-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "param", description = "A descendant parameter and all of its descendants."), @AllowedValue(value = "prop", description = "A descendant property and all of its descendants."), @AllowedValue(value = "link", description = "A descendant link and all of its descendants."), @AllowedValue(value = "part", description = "A descendant parameter and all of its descendants."), @AllowedValue(value = "mapping", description = "A descendant mapping and all of its descendants."), @AllowedValue(value = "map", description = "A descendant mapping entry (map) and all of its descendants.")}))
      )
      private String _byItemName;

      /**
       * Identify items to remove by the item's <code>ns</code>, which is the namespace associated with a <code>part</code>, or <code>prop</code>.
       */
      @BoundFlag(
          formalName = "Item Namespace Reference",
          description = "Identify items to remove by the item's `ns`, which is the namespace associated with a `part`, or `prop`.",
          name = "by-ns",
          typeAdapter = UriAdapter.class
      )
      private URI _byNs;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.Alter.Remove} instance with no metadata.
       */
      public Remove() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.Alter.Remove} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Remove(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Reference by (assigned) name}".
       *
       * <p>
       * Identify items remove by matching their assigned name.
       *
       * @return the by-name value, or {@code null} if not set
       */
      @Nullable
      public String getByName() {
        return _byName;
      }

      /**
       * Set the "{@literal Reference by (assigned) name}".
       *
       * <p>
       * Identify items remove by matching their assigned name.
       *
       * @param value
       *           the by-name value to set, or {@code null} to clear
       */
      public void setByName(@Nullable String value) {
        _byName = value;
      }

      /**
       * Get the "{@literal Reference by class}".
       *
       * <p>
       * Identify items to remove by matching their <code>class</code>.
       *
       * @return the by-class value, or {@code null} if not set
       */
      @Nullable
      public String getByClass() {
        return _byClass;
      }

      /**
       * Set the "{@literal Reference by class}".
       *
       * <p>
       * Identify items to remove by matching their <code>class</code>.
       *
       * @param value
       *           the by-class value to set, or {@code null} to clear
       */
      public void setByClass(@Nullable String value) {
        _byClass = value;
      }

      /**
       * Get the "{@literal Reference by ID}".
       *
       * <p>
       * Identify items to remove indicated by their <code>id</code>.
       *
       * @return the by-id value, or {@code null} if not set
       */
      @Nullable
      public String getById() {
        return _byId;
      }

      /**
       * Set the "{@literal Reference by ID}".
       *
       * <p>
       * Identify items to remove indicated by their <code>id</code>.
       *
       * @param value
       *           the by-id value to set, or {@code null} to clear
       */
      public void setById(@Nullable String value) {
        _byId = value;
      }

      /**
       * Get the "{@literal Item Name Reference}".
       *
       * <p>
       * Identify items to remove by the name of the item's information object name, e.g. <code>title</code> or <code>prop</code>.
       *
       * @return the by-item-name value, or {@code null} if not set
       */
      @Nullable
      public String getByItemName() {
        return _byItemName;
      }

      /**
       * Set the "{@literal Item Name Reference}".
       *
       * <p>
       * Identify items to remove by the name of the item's information object name, e.g. <code>title</code> or <code>prop</code>.
       *
       * @param value
       *           the by-item-name value to set, or {@code null} to clear
       */
      public void setByItemName(@Nullable String value) {
        _byItemName = value;
      }

      /**
       * Get the "{@literal Item Namespace Reference}".
       *
       * <p>
       * Identify items to remove by the item's <code>ns</code>, which is the namespace associated with a <code>part</code>, or <code>prop</code>.
       *
       * @return the by-ns value, or {@code null} if not set
       */
      @Nullable
      public URI getByNs() {
        return _byNs;
      }

      /**
       * Set the "{@literal Item Namespace Reference}".
       *
       * <p>
       * Identify items to remove by the item's <code>ns</code>, which is the namespace associated with a <code>part</code>, or <code>prop</code>.
       *
       * @param value
       *           the by-ns value to set, or {@code null} to clear
       */
      public void setByNs(@Nullable URI value) {
        _byNs = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }

    /**
     * Specifies contents to be added into controls, in resolution.
     */
    @MetaschemaAssembly(
        formalName = "Addition",
        description = "Specifies contents to be added into controls, in resolution.",
        name = "add",
        moduleClass = OscalProfileModule.class,
        remarks = "When no `by-id` is given, the addition is inserted into the control targeted by the alteration at the start or end as indicated by `position`. Only `position` values of \"starting\" or \"ending\" are permitted when there is no `by-id`.\n"
                + "\n"
                + "`by-id`, when given, should indicate, by its ID, an element inside the control to serve as the anchor point for the addition. In this case, `position` value may be any of the permitted values.",
        valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-profile-modify-alter-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "label", description = "A human-readable label for the parent context, which may be rendered in place of the actual identifier for some use cases."), @AllowedValue(value = "sort-id", description = "An alternative identifier, whose value is easily sortable among other such values in the document."), @AllowedValue(value = "alt-identifier", description = "An alternate or aliased identifier for the parent context.")}))
    )
    public static class Add implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * Where to add the new content with respect to the targeted element (beside it or inside it).
       */
      @BoundFlag(
          formalName = "Position",
          description = "Where to add the new content with respect to the targeted element (beside it or inside it).",
          name = "position",
          defaultValue = "ending",
          typeAdapter = TokenAdapter.class,
          valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-alter-position-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "before", description = "Preceding the by-id target"), @AllowedValue(value = "after", description = "Following the by-id target"), @AllowedValue(value = "starting", description = "Inside the control or by-id target, at the start"), @AllowedValue(value = "ending", description = "Inside the control or by-id target, at the end")}))
      )
      private String _position;

      /**
       * Target location of the addition.
       */
      @BoundFlag(
          formalName = "Reference by ID",
          description = "Target location of the addition.",
          name = "by-id",
          typeAdapter = TokenAdapter.class
      )
      private String _byId;

      /**
       * A name given to the control, which may be used by a tool for display and navigation.
       */
      @BoundField(
          formalName = "Title Change",
          description = "A name given to the control, which may be used by a tool for display and navigation.",
          useName = "title",
          typeAdapter = MarkupLineAdapter.class
      )
      private MarkupLine _title;

      /**
       * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
       */
      @BoundAssembly(
          formalName = "Parameter",
          description = "Parameters provide a mechanism for the dynamic assignment of value(s) in a control.",
          useName = "param",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "params", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Parameter> _params;

      /**
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       */
      @BoundAssembly(
          formalName = "Property",
          description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
          useName = "prop",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Property> _props;

      /**
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       */
      @BoundAssembly(
          formalName = "Link",
          description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
          useName = "link",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Link> _links;

      /**
       * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
       */
      @BoundAssembly(
          formalName = "Part",
          description = "An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.",
          useName = "part",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "parts", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<ControlPart> _parts;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.Alter.Add} instance with no metadata.
       */
      public Add() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Modify.Alter.Add} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Add(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Position}".
       *
       * <p>
       * Where to add the new content with respect to the targeted element (beside it or inside it).
       *
       * @return the position value, or {@code null} if not set
       */
      @Nullable
      public String getPosition() {
        return _position;
      }

      /**
       * Set the "{@literal Position}".
       *
       * <p>
       * Where to add the new content with respect to the targeted element (beside it or inside it).
       *
       * @param value
       *           the position value to set, or {@code null} to clear
       */
      public void setPosition(@Nullable String value) {
        _position = value;
      }

      /**
       * Get the "{@literal Reference by ID}".
       *
       * <p>
       * Target location of the addition.
       *
       * @return the by-id value, or {@code null} if not set
       */
      @Nullable
      public String getById() {
        return _byId;
      }

      /**
       * Set the "{@literal Reference by ID}".
       *
       * <p>
       * Target location of the addition.
       *
       * @param value
       *           the by-id value to set, or {@code null} to clear
       */
      public void setById(@Nullable String value) {
        _byId = value;
      }

      /**
       * Get the "{@literal Title Change}".
       *
       * <p>
       * A name given to the control, which may be used by a tool for display and navigation.
       *
       * @return the title value, or {@code null} if not set
       */
      @Nullable
      public MarkupLine getTitle() {
        return _title;
      }

      /**
       * Set the "{@literal Title Change}".
       *
       * <p>
       * A name given to the control, which may be used by a tool for display and navigation.
       *
       * @param value
       *           the title value to set, or {@code null} to clear
       */
      public void setTitle(@Nullable MarkupLine value) {
        _title = value;
      }

      /**
       * Get the "{@literal Parameter}".
       *
       * <p>
       * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
       *
       * @return the param value
       */
      @NonNull
      public List<Parameter> getParams() {
        if (_params == null) {
          _params = new LinkedList<>();
        }
        return ObjectUtils.notNull(_params);
      }

      /**
       * Set the "{@literal Parameter}".
       *
       * <p>
       * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
       *
       * @param value
       *           the param value to set
       */
      public void setParams(@NonNull List<Parameter> value) {
        _params = value;
      }

      /**
       * Add a new {@link Parameter} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addParam(Parameter item) {
        Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_params == null) {
          _params = new LinkedList<>();
        }
        return _params.add(value);
      }

      /**
       * Remove the first matching {@link Parameter} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeParam(Parameter item) {
        Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _params != null && _params.remove(value);
      }

      /**
       * Get the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @return the prop value
       */
      @NonNull
      public List<Property> getProps() {
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return ObjectUtils.notNull(_props);
      }

      /**
       * Set the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @param value
       *           the prop value to set
       */
      public void setProps(@NonNull List<Property> value) {
        _props = value;
      }

      /**
       * Add a new {@link Property} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return _props.add(value);
      }

      /**
       * Remove the first matching {@link Property} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _props != null && _props.remove(value);
      }

      /**
       * Get the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @return the link value
       */
      @NonNull
      public List<Link> getLinks() {
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return ObjectUtils.notNull(_links);
      }

      /**
       * Set the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @param value
       *           the link value to set
       */
      public void setLinks(@NonNull List<Link> value) {
        _links = value;
      }

      /**
       * Add a new {@link Link} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return _links.add(value);
      }

      /**
       * Remove the first matching {@link Link} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _links != null && _links.remove(value);
      }

      /**
       * Get the "{@literal Part}".
       *
       * <p>
       * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
       *
       * @return the part value
       */
      @NonNull
      public List<ControlPart> getParts() {
        if (_parts == null) {
          _parts = new LinkedList<>();
        }
        return ObjectUtils.notNull(_parts);
      }

      /**
       * Set the "{@literal Part}".
       *
       * <p>
       * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
       *
       * @param value
       *           the part value to set
       */
      public void setParts(@NonNull List<ControlPart> value) {
        _parts = value;
      }

      /**
       * Add a new {@link ControlPart} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addPart(ControlPart item) {
        ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_parts == null) {
          _parts = new LinkedList<>();
        }
        return _parts.add(value);
      }

      /**
       * Remove the first matching {@link ControlPart} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removePart(ControlPart item) {
        ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _parts != null && _parts.remove(value);
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }
}
