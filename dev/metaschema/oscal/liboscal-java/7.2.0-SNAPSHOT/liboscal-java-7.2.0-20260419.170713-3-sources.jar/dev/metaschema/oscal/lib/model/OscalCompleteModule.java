// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_complete_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.databind.IBindingContext;
import dev.metaschema.databind.model.AbstractBoundModule;
import dev.metaschema.databind.model.IBoundModule;
import dev.metaschema.databind.model.annotations.MetaschemaModule;
import java.net.URI;
import java.util.List;

/**
 * OSCAL Unified Model of Models
 * <p>This format represents a combination of all of the OSCAL models.</p>
 */
@MetaschemaModule(
    imports = {
        OscalCatalogModule.class,
        OscalMappingModule.class,
        OscalProfileModule.class,
        OscalComponentDefinitionModule.class,
        OscalSspModule.class,
        OscalApModule.class,
        OscalArModule.class,
        OscalPoamModule.class
    },
    remarks = "This format represents a combination of all of the OSCAL models."
)
public final class OscalCompleteModule extends AbstractBoundModule {
  private static final MarkupLine NAME = MarkupLine.fromMarkdown("OSCAL Unified Model of Models");

  private static final String SHORT_NAME = "oscal-complete";

  private static final String VERSION = "1.2.0";

  private static final URI XML_NAMESPACE = URI.create("http://csrc.nist.gov/ns/oscal/1.0");

  private static final URI JSON_BASE_URI = URI.create("http://csrc.nist.gov/ns/oscal/1.0");

  private static final MarkupMultiline REMARKS = MarkupMultiline.fromMarkdown("This format represents a combination of all of the OSCAL models.");

  /**
   * Construct a new module instance.
   *
   * @param importedModules
   *           modules imported by this module
   * @param bindingContext
   *           the binding context to associate with this module
   */
  public OscalCompleteModule(List<? extends IBoundModule> importedModules,
      IBindingContext bindingContext) {
    super(importedModules, bindingContext);
  }

  @Override
  public MarkupLine getName() {
    return NAME;
  }

  @Override
  public String getShortName() {
    return SHORT_NAME;
  }

  @Override
  public String getVersion() {
    return VERSION;
  }

  @Override
  public URI getXmlNamespace() {
    return XML_NAMESPACE;
  }

  @Override
  public URI getJsonBaseUri() {
    return JSON_BASE_URI;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return REMARKS;
  }
}
