// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_poam_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes an individual POA&amp;M item.
 */
@MetaschemaAssembly(
    formalName = "POA&M Item",
    description = "Describes an individual POA\\&M item.",
    name = "poam-item",
    moduleClass = OscalPoamModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(id = "oscal-poam-item-uuid", level = IConstraint.Level.WARNING, test = "@uuid", message = "It is a best practice to provide a UUID."))
)
public class PoamItem implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance">instance</a> scope that can be used to reference this POA&amp;M item entry in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers">this OSCAL instance</a>. This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "POA&M Item Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance) scope that can be used to reference this POA\\&M item entry in [this OSCAL instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The title or name for this POA&amp;M item .
   */
  @BoundField(
      formalName = "POA&M Item Title",
      description = "The title or name for this POA\\&M item .",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of POA&amp;M item.
   */
  @BoundField(
      formalName = "POA&M Item Description",
      description = "A human-readable description of POA\\&M item.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the source of the finding, such as a tool or person.
   */
  @BoundAssembly(
      formalName = "Origin",
      description = "Identifies the source of the finding, such as a tool or person.",
      useName = "origin",
      remarks = "Used to identify the individual and/or tool generated this poam-item.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "origins", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Origin> _origins;

  /**
   * Relates the poam-item to referenced finding(s).
   */
  @BoundAssembly(
      formalName = "Related Finding",
      description = "Relates the poam-item to referenced finding(s).",
      useName = "related-finding",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "related-findings", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<RelatedFinding> _relatedFindings;

  /**
   * Relates the poam-item to a set of referenced observations that were used to determine the finding.
   */
  @BoundAssembly(
      formalName = "Related Observation",
      description = "Relates the poam-item to a set of referenced observations that were used to determine the finding.",
      useName = "related-observation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "related-observations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<RelatedObservation> _relatedObservations;

  /**
   * Relates the finding to a set of referenced risks that were used to determine the finding.
   */
  @BoundAssembly(
      formalName = "Associated Risk",
      description = "Relates the finding to a set of referenced risks that were used to determine the finding.",
      useName = "associated-risk",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "related-risks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AssociatedRisk> _relatedRisks;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem} instance with no metadata.
   */
  public PoamItem() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public PoamItem(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal POA&M Item Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance">instance</a> scope that can be used to reference this POA&amp;M item entry in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers">this OSCAL instance</a>. This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value, or {@code null} if not set
   */
  @Nullable
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal POA&M Item Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance">instance</a> scope that can be used to reference this POA&amp;M item entry in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers">this OSCAL instance</a>. This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set, or {@code null} to clear
   */
  public void setUuid(@Nullable UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal POA&M Item Title}".
   *
   * <p>
   * The title or name for this POA&amp;M item .
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal POA&M Item Title}".
   *
   * <p>
   * The title or name for this POA&amp;M item .
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal POA&M Item Description}".
   *
   * <p>
   * A human-readable description of POA&amp;M item.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal POA&M Item Description}".
   *
   * <p>
   * A human-readable description of POA&amp;M item.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool or person.
   *
   * @return the origin value
   */
  @NonNull
  public List<Origin> getOrigins() {
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return ObjectUtils.notNull(_origins);
  }

  /**
   * Set the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool or person.
   *
   * @param value
   *           the origin value to set
   */
  public void setOrigins(@NonNull List<Origin> value) {
    _origins = value;
  }

  /**
   * Add a new {@link Origin} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return _origins.add(value);
  }

  /**
   * Remove the first matching {@link Origin} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _origins != null && _origins.remove(value);
  }

  /**
   * Get the "{@literal Related Finding}".
   *
   * <p>
   * Relates the poam-item to referenced finding(s).
   *
   * @return the related-finding value
   */
  @NonNull
  public List<RelatedFinding> getRelatedFindings() {
    if (_relatedFindings == null) {
      _relatedFindings = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedFindings);
  }

  /**
   * Set the "{@literal Related Finding}".
   *
   * <p>
   * Relates the poam-item to referenced finding(s).
   *
   * @param value
   *           the related-finding value to set
   */
  public void setRelatedFindings(@NonNull List<RelatedFinding> value) {
    _relatedFindings = value;
  }

  /**
   * Add a new {@link RelatedFinding} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRelatedFinding(RelatedFinding item) {
    RelatedFinding value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedFindings == null) {
      _relatedFindings = new LinkedList<>();
    }
    return _relatedFindings.add(value);
  }

  /**
   * Remove the first matching {@link RelatedFinding} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRelatedFinding(RelatedFinding item) {
    RelatedFinding value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedFindings != null && _relatedFindings.remove(value);
  }

  /**
   * Get the "{@literal Related Observation}".
   *
   * <p>
   * Relates the poam-item to a set of referenced observations that were used to determine the finding.
   *
   * @return the related-observation value
   */
  @NonNull
  public List<RelatedObservation> getRelatedObservations() {
    if (_relatedObservations == null) {
      _relatedObservations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedObservations);
  }

  /**
   * Set the "{@literal Related Observation}".
   *
   * <p>
   * Relates the poam-item to a set of referenced observations that were used to determine the finding.
   *
   * @param value
   *           the related-observation value to set
   */
  public void setRelatedObservations(@NonNull List<RelatedObservation> value) {
    _relatedObservations = value;
  }

  /**
   * Add a new {@link RelatedObservation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRelatedObservation(RelatedObservation item) {
    RelatedObservation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedObservations == null) {
      _relatedObservations = new LinkedList<>();
    }
    return _relatedObservations.add(value);
  }

  /**
   * Remove the first matching {@link RelatedObservation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRelatedObservation(RelatedObservation item) {
    RelatedObservation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedObservations != null && _relatedObservations.remove(value);
  }

  /**
   * Get the "{@literal Associated Risk}".
   *
   * <p>
   * Relates the finding to a set of referenced risks that were used to determine the finding.
   *
   * @return the associated-risk value
   */
  @NonNull
  public List<AssociatedRisk> getRelatedRisks() {
    if (_relatedRisks == null) {
      _relatedRisks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedRisks);
  }

  /**
   * Set the "{@literal Associated Risk}".
   *
   * <p>
   * Relates the finding to a set of referenced risks that were used to determine the finding.
   *
   * @param value
   *           the associated-risk value to set
   */
  public void setRelatedRisks(@NonNull List<AssociatedRisk> value) {
    _relatedRisks = value;
  }

  /**
   * Add a new {@link AssociatedRisk} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAssociatedRisk(AssociatedRisk item) {
    AssociatedRisk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedRisks == null) {
      _relatedRisks = new LinkedList<>();
    }
    return _relatedRisks.add(value);
  }

  /**
   * Remove the first matching {@link AssociatedRisk} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAssociatedRisk(AssociatedRisk item) {
    AssociatedRisk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedRisks != null && _relatedRisks.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Identifies the source of the finding, such as a tool or person.
   */
  @MetaschemaAssembly(
      formalName = "Origin",
      description = "Identifies the source of the finding, such as a tool or person.",
      name = "origin",
      moduleClass = OscalPoamModule.class,
      remarks = "Used to identify the individual and/or tool generated this poam-item."
  )
  public static class Origin implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.
     */
    @BoundAssembly(
        formalName = "Originating Actor",
        description = "The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.",
        useName = "actor",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "actors", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<OriginActor> _actors;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.Origin} instance with no metadata.
     */
    public Origin() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.Origin} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Origin(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Originating Actor}".
     *
     * <p>
     * The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.
     *
     * @return the actor value
     */
    @NonNull
    public List<OriginActor> getActors() {
      if (_actors == null) {
        _actors = new LinkedList<>();
      }
      return ObjectUtils.notNull(_actors);
    }

    /**
     * Set the "{@literal Originating Actor}".
     *
     * <p>
     * The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.
     *
     * @param value
     *           the actor value to set
     */
    public void setActors(@NonNull List<OriginActor> value) {
      _actors = value;
    }

    /**
     * Add a new {@link OriginActor} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addActor(OriginActor item) {
      OriginActor value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_actors == null) {
        _actors = new LinkedList<>();
      }
      return _actors.add(value);
    }

    /**
     * Remove the first matching {@link OriginActor} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeActor(OriginActor item) {
      OriginActor value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _actors != null && _actors.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Relates the poam-item to referenced finding(s).
   */
  @MetaschemaAssembly(
      formalName = "Related Finding",
      description = "Relates the poam-item to referenced finding(s).",
      name = "related-finding",
      moduleClass = OscalPoamModule.class
  )
  public static class RelatedFinding implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a finding defined in the list of findings.
     */
    @BoundFlag(
        formalName = "Finding Universally Unique Identifier Reference",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a finding defined in the list of findings.",
        name = "finding-uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _findingUuid;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.RelatedFinding} instance with no metadata.
     */
    public RelatedFinding() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.RelatedFinding} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public RelatedFinding(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Finding Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a finding defined in the list of findings.
     *
     * @return the finding-uuid value
     */
    @NonNull
    public UUID getFindingUuid() {
      return _findingUuid;
    }

    /**
     * Set the "{@literal Finding Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a finding defined in the list of findings.
     *
     * @param value
     *           the finding-uuid value to set
     */
    public void setFindingUuid(@NonNull UUID value) {
      _findingUuid = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Relates the poam-item to a set of referenced observations that were used to determine the finding.
   */
  @MetaschemaAssembly(
      formalName = "Related Observation",
      description = "Relates the poam-item to a set of referenced observations that were used to determine the finding.",
      name = "related-observation",
      moduleClass = OscalPoamModule.class
  )
  public static class RelatedObservation implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an observation defined in the list of observations.
     */
    @BoundFlag(
        formalName = "Observation Universally Unique Identifier Reference",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to an observation defined in the list of observations.",
        name = "observation-uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _observationUuid;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.RelatedObservation} instance with no metadata.
     */
    public RelatedObservation() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.RelatedObservation} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public RelatedObservation(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Observation Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an observation defined in the list of observations.
     *
     * @return the observation-uuid value
     */
    @NonNull
    public UUID getObservationUuid() {
      return _observationUuid;
    }

    /**
     * Set the "{@literal Observation Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an observation defined in the list of observations.
     *
     * @param value
     *           the observation-uuid value to set
     */
    public void setObservationUuid(@NonNull UUID value) {
      _observationUuid = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Relates the finding to a set of referenced risks that were used to determine the finding.
   */
  @MetaschemaAssembly(
      formalName = "Associated Risk",
      description = "Relates the finding to a set of referenced risks that were used to determine the finding.",
      name = "associated-risk",
      moduleClass = OscalPoamModule.class
  )
  public static class AssociatedRisk implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a risk defined in the list of risks.
     */
    @BoundFlag(
        formalName = "Risk Universally Unique Identifier Reference",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a risk defined in the list of risks.",
        name = "risk-uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _riskUuid;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.AssociatedRisk} instance with no metadata.
     */
    public AssociatedRisk() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.PoamItem.AssociatedRisk} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public AssociatedRisk(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Risk Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a risk defined in the list of risks.
     *
     * @return the risk-uuid value
     */
    @NonNull
    public UUID getRiskUuid() {
      return _riskUuid;
    }

    /**
     * Set the "{@literal Risk Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a risk defined in the list of risks.
     *
     * @param value
     *           the risk-uuid value to set
     */
    public void setRiskUuid(@NonNull UUID value) {
      _riskUuid = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
