// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Used to select a control objective for inclusion/exclusion based on the control objective's identifier.
 */
@MetaschemaAssembly(
    formalName = "Select Objective",
    description = "Used to select a control objective for inclusion/exclusion based on the control objective's identifier.",
    name = "select-objective-by-id",
    moduleClass = OscalAssessmentCommonModule.class
)
public class SelectObjectiveById implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Points to an assessment objective.
   */
  @BoundFlag(
      formalName = "Objective ID",
      description = "Points to an assessment objective.",
      name = "objective-id",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _objectiveId;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SelectObjectiveById} instance with no metadata.
   */
  public SelectObjectiveById() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SelectObjectiveById} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SelectObjectiveById(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Objective ID}".
   *
   * <p>
   * Points to an assessment objective.
   *
   * @return the objective-id value
   */
  @NonNull
  public String getObjectiveId() {
    return _objectiveId;
  }

  /**
   * Set the "{@literal Objective ID}".
   *
   * <p>
   * Points to an assessment objective.
   *
   * @param value
   *           the objective-id value to set
   */
  public void setObjectiveId(@NonNull String value) {
    _objectiveId = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
