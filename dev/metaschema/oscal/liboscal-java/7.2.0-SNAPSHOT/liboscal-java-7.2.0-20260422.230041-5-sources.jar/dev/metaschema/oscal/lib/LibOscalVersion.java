/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.oscal.lib;

import dev.metaschema.core.util.IVersionInfo;

/**
 * Provides version information for this library.
 */
public final class LibOscalVersion implements IVersionInfo {
  private static final String NAME = "liboscal-java";
  private static final String BUILD_VERSION = "7.2.0-SNAPSHOT";
  private static final String BUILD_TIMESTAMP = "2026-04-22 23:00";
  private static final String COMMIT = "ea0ea0c";
  private static final String BRANCH = "develop";
  private static final String CLOSEST_TAG = "";
  private static final String ORIGIN = "https://github.com/metaschema-framework/liboscal-java";

  @Override
  public String getName() {
    return NAME;
  }

  @Override
  public String getVersion() {
    return BUILD_VERSION;
  }

  @Override
  public String getBuildTimestamp() {
    return BUILD_TIMESTAMP;
  }

  @Override
  public String getGitOriginUrl() {
    return ORIGIN;
  }

  @Override
  public String getGitCommit() {
    return COMMIT;
  }

  @Override
  public String getGitBranch() {
    return BRANCH;
  }

  @Override
  public String getGitClosestTag() {
    return CLOSEST_TAG;
  }
}
