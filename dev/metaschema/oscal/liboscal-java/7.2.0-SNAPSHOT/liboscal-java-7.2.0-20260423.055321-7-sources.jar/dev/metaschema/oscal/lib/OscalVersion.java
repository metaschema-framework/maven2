/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.oscal.lib;

import dev.metaschema.core.util.IVersionInfo;

/**
 * Provides version information for the underlying OSCAL implementation used by this library.
 */
public final class OscalVersion implements IVersionInfo {
  private static final String NAME = "oscal";
  private static final String BUILD_TIMESTAMP = "2026-04-23 05:53";
  private static final String COMMIT = "26df050";
  private static final String BRANCH = "develop";
  private static final String CLOSEST_TAG = "";
  private static final String ORIGIN = "https://github.com/usnistgov/OSCAL.git";

  @Override
  public String getName() {
    return NAME;
  }

  @Override
  public String getVersion() {
    return CLOSEST_TAG;
  }

  @Override
  public String getBuildTimestamp() {
    return BUILD_TIMESTAMP;
  }

  @Override
  public String getGitOriginUrl() {
    return ORIGIN;
  }

  @Override
  public String getGitCommit() {
    return COMMIT;
  }

  @Override
  public String getGitBranch() {
    return BRANCH;
  }

  @Override
  public String getGitClosestTag() {
    return CLOSEST_TAG;
  }
}
