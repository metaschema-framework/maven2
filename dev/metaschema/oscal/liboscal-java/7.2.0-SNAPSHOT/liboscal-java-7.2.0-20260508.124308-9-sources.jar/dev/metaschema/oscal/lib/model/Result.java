// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-results_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Used by the assessment results and POA&amp;M. In the assessment results, this identifies all of the assessment observations and findings, initial and residual risks, deviations, and disposition. In the POA&amp;M, this identifies initial and residual risks, deviations, and disposition.
 */
@MetaschemaAssembly(
    formalName = "Assessment Result",
    description = "Used by the assessment results and POA\\&M. In the assessment results, this identifies all of the assessment observations and findings, initial and residual risks, deviations, and disposition. In the POA\\&M, this identifies initial and residual risks, deviations, and disposition.",
    name = "result",
    moduleClass = OscalArModule.class
)
public class Result implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this set of results in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment result</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Results Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this set of results in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers). The locally defined *UUID* of the `assessment result` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The title for this set of results.
   */
  @BoundField(
      formalName = "Results Title",
      description = "The title for this set of results.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of this set of test results.
   */
  @BoundField(
      formalName = "Results Description",
      description = "A human-readable description of this set of test results.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * Date/time stamp identifying the start of the evidence collection reflected in these results.
   */
  @BoundField(
      formalName = "start field",
      description = "Date/time stamp identifying the start of the evidence collection reflected in these results.",
      useName = "start",
      minOccurs = 1,
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _start;

  /**
   * Date/time stamp identifying the end of the evidence collection reflected in these results. In a continuous motoring scenario, this may contain the same value as start if appropriate.
   */
  @BoundField(
      formalName = "end field",
      description = "Date/time stamp identifying the end of the evidence collection reflected in these results. In a continuous motoring scenario, this may contain the same value as start if appropriate.",
      useName = "end",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _end;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   */
  @BoundAssembly(
      formalName = "Local Definitions",
      description = "Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.",
      useName = "local-definitions"
  )
  private LocalDefinitions _localDefinitions;

  /**
   * Identifies the controls being assessed and their control objectives.
   */
  @BoundAssembly(
      formalName = "Reviewed Controls and Control Objectives",
      description = "Identifies the controls being assessed and their control objectives.",
      useName = "reviewed-controls",
      remarks = "The Assessment Results `control-selection` ignores any control selection in the Assessment Plan and re-selects controls from the baseline identified by the SSP.\n"
              + "\n"
              + "The Assessment Results `control-objective-selection` ignores any control objective selection in the Assessment Plan and re-selects control objectives from the baseline identified by the SSP.\n"
              + "\n"
              + "Any additional control objectives defined in the Assessment Plan `local-definitions` do not need to be re-defined in the Assessment Results `local-definitions`; however, if they were explicitly referenced with an Assessment Plan `control-objective-selection`, they need to be selected again in the Assessment Results `control-objective-selection`.",
      minOccurs = 1
  )
  private ReviewedControls _reviewedControls;

  /**
   * A set of textual statements, typically written by the assessor.
   */
  @BoundAssembly(
      formalName = "Attestation Statements",
      description = "A set of textual statements, typically written by the assessor.",
      useName = "attestation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "attestations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Attestation> _attestations;

  /**
   * A log of all assessment-related actions taken.
   */
  @BoundAssembly(
      formalName = "Assessment Log",
      description = "A log of all assessment-related actions taken.",
      useName = "assessment-log"
  )
  private AssessmentLog _assessmentLog;

  /**
   * Describes an individual observation.
   */
  @BoundAssembly(
      formalName = "Observation",
      description = "Describes an individual observation.",
      useName = "observation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "observations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Observation> _observations;

  /**
   * An identified risk.
   */
  @BoundAssembly(
      formalName = "Identified Risk",
      description = "An identified risk.",
      useName = "risk",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "risks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Risk> _risks;

  /**
   * Describes an individual finding.
   */
  @BoundAssembly(
      formalName = "Finding",
      description = "Describes an individual finding.",
      useName = "finding",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "findings", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Finding> _findings;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Result} instance with no metadata.
   */
  public Result() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Result} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Result(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Results Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this set of results in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment result</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Results Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this set of results in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment result</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Results Title}".
   *
   * <p>
   * The title for this set of results.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Results Title}".
   *
   * <p>
   * The title for this set of results.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Results Description}".
   *
   * <p>
   * A human-readable description of this set of test results.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Results Description}".
   *
   * <p>
   * A human-readable description of this set of test results.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal start field}".
   *
   * <p>
   * Date/time stamp identifying the start of the evidence collection reflected in these results.
   *
   * @return the start value
   */
  @NonNull
  public ZonedDateTime getStart() {
    return _start;
  }

  /**
   * Set the "{@literal start field}".
   *
   * <p>
   * Date/time stamp identifying the start of the evidence collection reflected in these results.
   *
   * @param value
   *           the start value to set
   */
  public void setStart(@NonNull ZonedDateTime value) {
    _start = value;
  }

  /**
   * Get the "{@literal end field}".
   *
   * <p>
   * Date/time stamp identifying the end of the evidence collection reflected in these results. In a continuous motoring scenario, this may contain the same value as start if appropriate.
   *
   * @return the end value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getEnd() {
    return _end;
  }

  /**
   * Set the "{@literal end field}".
   *
   * <p>
   * Date/time stamp identifying the end of the evidence collection reflected in these results. In a continuous motoring scenario, this may contain the same value as start if appropriate.
   *
   * @param value
   *           the end value to set, or {@code null} to clear
   */
  public void setEnd(@Nullable ZonedDateTime value) {
    _end = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Local Definitions}".
   *
   * <p>
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   *
   * @return the local-definitions value, or {@code null} if not set
   */
  @Nullable
  public LocalDefinitions getLocalDefinitions() {
    return _localDefinitions;
  }

  /**
   * Set the "{@literal Local Definitions}".
   *
   * <p>
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   *
   * @param value
   *           the local-definitions value to set, or {@code null} to clear
   */
  public void setLocalDefinitions(@Nullable LocalDefinitions value) {
    _localDefinitions = value;
  }

  /**
   * Get the "{@literal Reviewed Controls and Control Objectives}".
   *
   * <p>
   * Identifies the controls being assessed and their control objectives.
   *
   * @return the reviewed-controls value
   */
  @NonNull
  public ReviewedControls getReviewedControls() {
    return _reviewedControls;
  }

  /**
   * Set the "{@literal Reviewed Controls and Control Objectives}".
   *
   * <p>
   * Identifies the controls being assessed and their control objectives.
   *
   * @param value
   *           the reviewed-controls value to set
   */
  public void setReviewedControls(@NonNull ReviewedControls value) {
    _reviewedControls = value;
  }

  /**
   * Get the "{@literal Attestation Statements}".
   *
   * <p>
   * A set of textual statements, typically written by the assessor.
   *
   * @return the attestation value
   */
  @NonNull
  public List<Attestation> getAttestations() {
    if (_attestations == null) {
      _attestations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_attestations);
  }

  /**
   * Set the "{@literal Attestation Statements}".
   *
   * <p>
   * A set of textual statements, typically written by the assessor.
   *
   * @param value
   *           the attestation value to set
   */
  public void setAttestations(@NonNull List<Attestation> value) {
    _attestations = value;
  }

  /**
   * Add a new {@link Attestation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAttestation(Attestation item) {
    Attestation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_attestations == null) {
      _attestations = new LinkedList<>();
    }
    return _attestations.add(value);
  }

  /**
   * Remove the first matching {@link Attestation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAttestation(Attestation item) {
    Attestation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _attestations != null && _attestations.remove(value);
  }

  /**
   * Get the "{@literal Assessment Log}".
   *
   * <p>
   * A log of all assessment-related actions taken.
   *
   * @return the assessment-log value, or {@code null} if not set
   */
  @Nullable
  public AssessmentLog getAssessmentLog() {
    return _assessmentLog;
  }

  /**
   * Set the "{@literal Assessment Log}".
   *
   * <p>
   * A log of all assessment-related actions taken.
   *
   * @param value
   *           the assessment-log value to set, or {@code null} to clear
   */
  public void setAssessmentLog(@Nullable AssessmentLog value) {
    _assessmentLog = value;
  }

  /**
   * Get the "{@literal Observation}".
   *
   * <p>
   * Describes an individual observation.
   *
   * @return the observation value
   */
  @NonNull
  public List<Observation> getObservations() {
    if (_observations == null) {
      _observations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_observations);
  }

  /**
   * Set the "{@literal Observation}".
   *
   * <p>
   * Describes an individual observation.
   *
   * @param value
   *           the observation value to set
   */
  public void setObservations(@NonNull List<Observation> value) {
    _observations = value;
  }

  /**
   * Add a new {@link Observation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addObservation(Observation item) {
    Observation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_observations == null) {
      _observations = new LinkedList<>();
    }
    return _observations.add(value);
  }

  /**
   * Remove the first matching {@link Observation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeObservation(Observation item) {
    Observation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _observations != null && _observations.remove(value);
  }

  /**
   * Get the "{@literal Identified Risk}".
   *
   * <p>
   * An identified risk.
   *
   * @return the risk value
   */
  @NonNull
  public List<Risk> getRisks() {
    if (_risks == null) {
      _risks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_risks);
  }

  /**
   * Set the "{@literal Identified Risk}".
   *
   * <p>
   * An identified risk.
   *
   * @param value
   *           the risk value to set
   */
  public void setRisks(@NonNull List<Risk> value) {
    _risks = value;
  }

  /**
   * Add a new {@link Risk} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRisk(Risk item) {
    Risk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_risks == null) {
      _risks = new LinkedList<>();
    }
    return _risks.add(value);
  }

  /**
   * Remove the first matching {@link Risk} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRisk(Risk item) {
    Risk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _risks != null && _risks.remove(value);
  }

  /**
   * Get the "{@literal Finding}".
   *
   * <p>
   * Describes an individual finding.
   *
   * @return the finding value
   */
  @NonNull
  public List<Finding> getFindings() {
    if (_findings == null) {
      _findings = new LinkedList<>();
    }
    return ObjectUtils.notNull(_findings);
  }

  /**
   * Set the "{@literal Finding}".
   *
   * <p>
   * Describes an individual finding.
   *
   * @param value
   *           the finding value to set
   */
  public void setFindings(@NonNull List<Finding> value) {
    _findings = value;
  }

  /**
   * Add a new {@link Finding} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addFinding(Finding item) {
    Finding value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_findings == null) {
      _findings = new LinkedList<>();
    }
    return _findings.add(value);
  }

  /**
   * Remove the first matching {@link Finding} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeFinding(Finding item) {
    Finding value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _findings != null && _findings.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   */
  @MetaschemaAssembly(
      formalName = "Local Definitions",
      description = "Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.",
      name = "local-definitions",
      moduleClass = OscalArModule.class,
      modelConstraints = @AssemblyConstraints(unique = {@IsUnique(id = "oscal-unique-ar-local-definitions-component", level = IConstraint.Level.ERROR, target = "component", keyFields = @KeyField(target = "@uuid"), remarks = "Since multiple `component` entries can be provided, each component must have a unique `uuid`."), @IsUnique(id = "oscal-unique-ar-local-definitions-user", level = IConstraint.Level.ERROR, target = "user", keyFields = @KeyField(target = "@uuid"), remarks = "A given `uuid` must be assigned only once to a user.")})
  )
  public static class LocalDefinitions implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A defined component that can be part of an implemented system.
     */
    @BoundAssembly(
        formalName = "Component",
        description = "A defined component that can be part of an implemented system.",
        useName = "component",
        remarks = "Used to add any components, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "components", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SystemComponent> _components;

    /**
     * A single managed inventory item within the system.
     */
    @BoundAssembly(
        formalName = "Inventory Item",
        description = "A single managed inventory item within the system.",
        useName = "inventory-item",
        remarks = "Used to add any inventory-items, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "inventory-items", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<InventoryItem> _inventoryItems;

    /**
     * A type of user that interacts with the system based on an associated role.
     */
    @BoundAssembly(
        formalName = "System User",
        description = "A type of user that interacts with the system based on an associated role.",
        useName = "user",
        remarks = "Used to add any users, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "users", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SystemUser> _users;

    /**
     * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
     */
    @BoundAssembly(
        formalName = "Assessment Assets",
        description = "Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.",
        useName = "assessment-assets",
        remarks = "This needs to be defined in the results if an assessment platform used is different from the one described in the assessment plan. Else the platform(s) defined in the plan may be referenced within the results."
    )
    private AssessmentAssets _assessmentAssets;

    /**
     * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
     */
    @BoundAssembly(
        formalName = "Task",
        description = "Represents a scheduled event or milestone, which may be associated with a series of assessment actions.",
        useName = "assessment-task",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "tasks", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Task> _tasks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.LocalDefinitions} instance with no metadata.
     */
    public LocalDefinitions() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.LocalDefinitions} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public LocalDefinitions(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Component}".
     *
     * <p>
     * A defined component that can be part of an implemented system.
     *
     * @return the component value
     */
    @NonNull
    public List<SystemComponent> getComponents() {
      if (_components == null) {
        _components = new LinkedList<>();
      }
      return ObjectUtils.notNull(_components);
    }

    /**
     * Set the "{@literal Component}".
     *
     * <p>
     * A defined component that can be part of an implemented system.
     *
     * @param value
     *           the component value to set
     */
    public void setComponents(@NonNull List<SystemComponent> value) {
      _components = value;
    }

    /**
     * Add a new {@link SystemComponent} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addComponent(SystemComponent item) {
      SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_components == null) {
        _components = new LinkedList<>();
      }
      return _components.add(value);
    }

    /**
     * Remove the first matching {@link SystemComponent} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeComponent(SystemComponent item) {
      SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _components != null && _components.remove(value);
    }

    /**
     * Get the "{@literal Inventory Item}".
     *
     * <p>
     * A single managed inventory item within the system.
     *
     * @return the inventory-item value
     */
    @NonNull
    public List<InventoryItem> getInventoryItems() {
      if (_inventoryItems == null) {
        _inventoryItems = new LinkedList<>();
      }
      return ObjectUtils.notNull(_inventoryItems);
    }

    /**
     * Set the "{@literal Inventory Item}".
     *
     * <p>
     * A single managed inventory item within the system.
     *
     * @param value
     *           the inventory-item value to set
     */
    public void setInventoryItems(@NonNull List<InventoryItem> value) {
      _inventoryItems = value;
    }

    /**
     * Add a new {@link InventoryItem} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addInventoryItem(InventoryItem item) {
      InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_inventoryItems == null) {
        _inventoryItems = new LinkedList<>();
      }
      return _inventoryItems.add(value);
    }

    /**
     * Remove the first matching {@link InventoryItem} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeInventoryItem(InventoryItem item) {
      InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _inventoryItems != null && _inventoryItems.remove(value);
    }

    /**
     * Get the "{@literal System User}".
     *
     * <p>
     * A type of user that interacts with the system based on an associated role.
     *
     * @return the user value
     */
    @NonNull
    public List<SystemUser> getUsers() {
      if (_users == null) {
        _users = new LinkedList<>();
      }
      return ObjectUtils.notNull(_users);
    }

    /**
     * Set the "{@literal System User}".
     *
     * <p>
     * A type of user that interacts with the system based on an associated role.
     *
     * @param value
     *           the user value to set
     */
    public void setUsers(@NonNull List<SystemUser> value) {
      _users = value;
    }

    /**
     * Add a new {@link SystemUser} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addUser(SystemUser item) {
      SystemUser value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_users == null) {
        _users = new LinkedList<>();
      }
      return _users.add(value);
    }

    /**
     * Remove the first matching {@link SystemUser} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeUser(SystemUser item) {
      SystemUser value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _users != null && _users.remove(value);
    }

    /**
     * Get the "{@literal Assessment Assets}".
     *
     * <p>
     * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
     *
     * @return the assessment-assets value, or {@code null} if not set
     */
    @Nullable
    public AssessmentAssets getAssessmentAssets() {
      return _assessmentAssets;
    }

    /**
     * Set the "{@literal Assessment Assets}".
     *
     * <p>
     * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
     *
     * @param value
     *           the assessment-assets value to set, or {@code null} to clear
     */
    public void setAssessmentAssets(@Nullable AssessmentAssets value) {
      _assessmentAssets = value;
    }

    /**
     * Get the "{@literal Task}".
     *
     * <p>
     * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
     *
     * @return the assessment-task value
     */
    @NonNull
    public List<Task> getTasks() {
      if (_tasks == null) {
        _tasks = new LinkedList<>();
      }
      return ObjectUtils.notNull(_tasks);
    }

    /**
     * Set the "{@literal Task}".
     *
     * <p>
     * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
     *
     * @param value
     *           the assessment-task value to set
     */
    public void setTasks(@NonNull List<Task> value) {
      _tasks = value;
    }

    /**
     * Add a new {@link Task} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addAssessmentTask(Task item) {
      Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_tasks == null) {
        _tasks = new LinkedList<>();
      }
      return _tasks.add(value);
    }

    /**
     * Remove the first matching {@link Task} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeAssessmentTask(Task item) {
      Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _tasks != null && _tasks.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * A set of textual statements, typically written by the assessor.
   */
  @MetaschemaAssembly(
      formalName = "Attestation Statements",
      description = "A set of textual statements, typically written by the assessor.",
      name = "attestation",
      moduleClass = OscalArModule.class,
      modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-ar-attestation-responsible-party", level = IConstraint.Level.ERROR, target = "responsible-party", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-party` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
  )
  public static class Attestation implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
     */
    @BoundAssembly(
        formalName = "Responsible Party",
        description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
        useName = "responsible-party",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ResponsibleParty> _responsibleParties;

    /**
     * A partition of an assessment plan or results or a child of another part.
     */
    @BoundAssembly(
        formalName = "Assessment Part",
        description = "A partition of an assessment plan or results or a child of another part.",
        useName = "part",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "parts", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<AssessmentPart> _parts;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.Attestation} instance with no metadata.
     */
    public Attestation() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.Attestation} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Attestation(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Responsible Party}".
     *
     * <p>
     * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
     *
     * @return the responsible-party value
     */
    @NonNull
    public List<ResponsibleParty> getResponsibleParties() {
      if (_responsibleParties == null) {
        _responsibleParties = new LinkedList<>();
      }
      return ObjectUtils.notNull(_responsibleParties);
    }

    /**
     * Set the "{@literal Responsible Party}".
     *
     * <p>
     * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
     *
     * @param value
     *           the responsible-party value to set
     */
    public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
      _responsibleParties = value;
    }

    /**
     * Add a new {@link ResponsibleParty} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addResponsibleParty(ResponsibleParty item) {
      ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_responsibleParties == null) {
        _responsibleParties = new LinkedList<>();
      }
      return _responsibleParties.add(value);
    }

    /**
     * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeResponsibleParty(ResponsibleParty item) {
      ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _responsibleParties != null && _responsibleParties.remove(value);
    }

    /**
     * Get the "{@literal Assessment Part}".
     *
     * <p>
     * A partition of an assessment plan or results or a child of another part.
     *
     * @return the part value
     */
    @NonNull
    public List<AssessmentPart> getParts() {
      if (_parts == null) {
        _parts = new LinkedList<>();
      }
      return ObjectUtils.notNull(_parts);
    }

    /**
     * Set the "{@literal Assessment Part}".
     *
     * <p>
     * A partition of an assessment plan or results or a child of another part.
     *
     * @param value
     *           the part value to set
     */
    public void setParts(@NonNull List<AssessmentPart> value) {
      _parts = value;
    }

    /**
     * Add a new {@link AssessmentPart} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addPart(AssessmentPart item) {
      AssessmentPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_parts == null) {
        _parts = new LinkedList<>();
      }
      return _parts.add(value);
    }

    /**
     * Remove the first matching {@link AssessmentPart} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removePart(AssessmentPart item) {
      AssessmentPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _parts != null && _parts.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * A log of all assessment-related actions taken.
   */
  @MetaschemaAssembly(
      formalName = "Assessment Log",
      description = "A log of all assessment-related actions taken.",
      name = "assessment-log",
      moduleClass = OscalArModule.class
  )
  public static class AssessmentLog implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * Identifies the result of an action and/or task that occurred as part of executing an assessment plan or an assessment event that occurred in producing the assessment results.
     */
    @BoundAssembly(
        formalName = "Assessment Log Entry",
        description = "Identifies the result of an action and/or task that occurred as part of executing an assessment plan or an assessment event that occurred in producing the assessment results.",
        useName = "entry",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "entries", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Entry> _entries;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.AssessmentLog} instance with no metadata.
     */
    public AssessmentLog() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.AssessmentLog} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public AssessmentLog(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Assessment Log Entry}".
     *
     * <p>
     * Identifies the result of an action and/or task that occurred as part of executing an assessment plan or an assessment event that occurred in producing the assessment results.
     *
     * @return the entry value
     */
    @NonNull
    public List<Entry> getEntries() {
      if (_entries == null) {
        _entries = new LinkedList<>();
      }
      return ObjectUtils.notNull(_entries);
    }

    /**
     * Set the "{@literal Assessment Log Entry}".
     *
     * <p>
     * Identifies the result of an action and/or task that occurred as part of executing an assessment plan or an assessment event that occurred in producing the assessment results.
     *
     * @param value
     *           the entry value to set
     */
    public void setEntries(@NonNull List<Entry> value) {
      _entries = value;
    }

    /**
     * Add a new {@link Entry} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addEntry(Entry item) {
      Entry value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_entries == null) {
        _entries = new LinkedList<>();
      }
      return _entries.add(value);
    }

    /**
     * Remove the first matching {@link Entry} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeEntry(Entry item) {
      Entry value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _entries != null && _entries.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * Identifies the result of an action and/or task that occurred as part of executing an assessment plan or an assessment event that occurred in producing the assessment results.
     */
    @MetaschemaAssembly(
        formalName = "Assessment Log Entry",
        description = "Identifies the result of an action and/or task that occurred as part of executing an assessment plan or an assessment event that occurred in producing the assessment results.",
        name = "entry",
        moduleClass = OscalArModule.class
    )
    public static class Entry implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference an assessment event in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment log entry</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       */
      @BoundFlag(
          formalName = "Assessment Log Entry Universally Unique Identifier",
          description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference an assessment event in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers). The locally defined *UUID* of the `assessment log entry` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
          name = "uuid",
          required = true,
          typeAdapter = UuidAdapter.class
      )
      private UUID _uuid;

      /**
       * The title for this event.
       */
      @BoundField(
          formalName = "Action Title",
          description = "The title for this event.",
          useName = "title",
          typeAdapter = MarkupLineAdapter.class
      )
      private MarkupLine _title;

      /**
       * A human-readable description of this event.
       */
      @BoundField(
          formalName = "Action Description",
          description = "A human-readable description of this event.",
          useName = "description",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _description;

      /**
       * Identifies the start date and time of an event.
       */
      @BoundField(
          formalName = "Start",
          description = "Identifies the start date and time of an event.",
          useName = "start",
          minOccurs = 1,
          typeAdapter = DateTimeWithTZAdapter.class
      )
      private ZonedDateTime _start;

      /**
       * Identifies the end date and time of an event. If the event is a point in time, the start and end will be the same date and time.
       */
      @BoundField(
          formalName = "End",
          description = "Identifies the end date and time of an event. If the event is a point in time, the start and end will be the same date and time.",
          useName = "end",
          typeAdapter = DateTimeWithTZAdapter.class
      )
      private ZonedDateTime _end;

      /**
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       */
      @BoundAssembly(
          formalName = "Property",
          description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
          useName = "prop",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Property> _props;

      /**
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       */
      @BoundAssembly(
          formalName = "Link",
          description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
          useName = "link",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Link> _links;

      /**
       * Used to indicate who created a log entry in what role.
       */
      @BoundAssembly(
          formalName = "Logged By",
          description = "Used to indicate who created a log entry in what role.",
          useName = "logged-by",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "logged-by", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<LoggedBy> _loggedBy;

      /**
       * Identifies an individual task for which the containing object is a consequence of.
       */
      @BoundAssembly(
          formalName = "Task Reference",
          description = "Identifies an individual task for which the containing object is a consequence of.",
          useName = "related-task",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "related-tasks", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<RelatedTask> _relatedTasks;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.AssessmentLog.Entry} instance with no metadata.
       */
      public Entry() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Result.AssessmentLog.Entry} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Entry(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Assessment Log Entry Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference an assessment event in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment log entry</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @return the uuid value
       */
      @NonNull
      public UUID getUuid() {
        return _uuid;
      }

      /**
       * Set the "{@literal Assessment Log Entry Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference an assessment event in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment log entry</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @param value
       *           the uuid value to set
       */
      public void setUuid(@NonNull UUID value) {
        _uuid = value;
      }

      /**
       * Get the "{@literal Action Title}".
       *
       * <p>
       * The title for this event.
       *
       * @return the title value, or {@code null} if not set
       */
      @Nullable
      public MarkupLine getTitle() {
        return _title;
      }

      /**
       * Set the "{@literal Action Title}".
       *
       * <p>
       * The title for this event.
       *
       * @param value
       *           the title value to set, or {@code null} to clear
       */
      public void setTitle(@Nullable MarkupLine value) {
        _title = value;
      }

      /**
       * Get the "{@literal Action Description}".
       *
       * <p>
       * A human-readable description of this event.
       *
       * @return the description value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getDescription() {
        return _description;
      }

      /**
       * Set the "{@literal Action Description}".
       *
       * <p>
       * A human-readable description of this event.
       *
       * @param value
       *           the description value to set, or {@code null} to clear
       */
      public void setDescription(@Nullable MarkupMultiline value) {
        _description = value;
      }

      /**
       * Get the "{@literal Start}".
       *
       * <p>
       * Identifies the start date and time of an event.
       *
       * @return the start value
       */
      @NonNull
      public ZonedDateTime getStart() {
        return _start;
      }

      /**
       * Set the "{@literal Start}".
       *
       * <p>
       * Identifies the start date and time of an event.
       *
       * @param value
       *           the start value to set
       */
      public void setStart(@NonNull ZonedDateTime value) {
        _start = value;
      }

      /**
       * Get the "{@literal End}".
       *
       * <p>
       * Identifies the end date and time of an event. If the event is a point in time, the start and end will be the same date and time.
       *
       * @return the end value, or {@code null} if not set
       */
      @Nullable
      public ZonedDateTime getEnd() {
        return _end;
      }

      /**
       * Set the "{@literal End}".
       *
       * <p>
       * Identifies the end date and time of an event. If the event is a point in time, the start and end will be the same date and time.
       *
       * @param value
       *           the end value to set, or {@code null} to clear
       */
      public void setEnd(@Nullable ZonedDateTime value) {
        _end = value;
      }

      /**
       * Get the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @return the prop value
       */
      @NonNull
      public List<Property> getProps() {
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return ObjectUtils.notNull(_props);
      }

      /**
       * Set the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @param value
       *           the prop value to set
       */
      public void setProps(@NonNull List<Property> value) {
        _props = value;
      }

      /**
       * Add a new {@link Property} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return _props.add(value);
      }

      /**
       * Remove the first matching {@link Property} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _props != null && _props.remove(value);
      }

      /**
       * Get the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @return the link value
       */
      @NonNull
      public List<Link> getLinks() {
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return ObjectUtils.notNull(_links);
      }

      /**
       * Set the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @param value
       *           the link value to set
       */
      public void setLinks(@NonNull List<Link> value) {
        _links = value;
      }

      /**
       * Add a new {@link Link} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return _links.add(value);
      }

      /**
       * Remove the first matching {@link Link} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _links != null && _links.remove(value);
      }

      /**
       * Get the "{@literal Logged By}".
       *
       * <p>
       * Used to indicate who created a log entry in what role.
       *
       * @return the logged-by value
       */
      @NonNull
      public List<LoggedBy> getLoggedBy() {
        if (_loggedBy == null) {
          _loggedBy = new LinkedList<>();
        }
        return ObjectUtils.notNull(_loggedBy);
      }

      /**
       * Set the "{@literal Logged By}".
       *
       * <p>
       * Used to indicate who created a log entry in what role.
       *
       * @param value
       *           the logged-by value to set
       */
      public void setLoggedBy(@NonNull List<LoggedBy> value) {
        _loggedBy = value;
      }

      /**
       * Add a new {@link LoggedBy} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLoggedBy(LoggedBy item) {
        LoggedBy value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_loggedBy == null) {
          _loggedBy = new LinkedList<>();
        }
        return _loggedBy.add(value);
      }

      /**
       * Remove the first matching {@link LoggedBy} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLoggedBy(LoggedBy item) {
        LoggedBy value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _loggedBy != null && _loggedBy.remove(value);
      }

      /**
       * Get the "{@literal Task Reference}".
       *
       * <p>
       * Identifies an individual task for which the containing object is a consequence of.
       *
       * @return the related-task value
       */
      @NonNull
      public List<RelatedTask> getRelatedTasks() {
        if (_relatedTasks == null) {
          _relatedTasks = new LinkedList<>();
        }
        return ObjectUtils.notNull(_relatedTasks);
      }

      /**
       * Set the "{@literal Task Reference}".
       *
       * <p>
       * Identifies an individual task for which the containing object is a consequence of.
       *
       * @param value
       *           the related-task value to set
       */
      public void setRelatedTasks(@NonNull List<RelatedTask> value) {
        _relatedTasks = value;
      }

      /**
       * Add a new {@link RelatedTask} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addRelatedTask(RelatedTask item) {
        RelatedTask value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_relatedTasks == null) {
          _relatedTasks = new LinkedList<>();
        }
        return _relatedTasks.add(value);
      }

      /**
       * Remove the first matching {@link RelatedTask} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeRelatedTask(RelatedTask item) {
        RelatedTask value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _relatedTasks != null && _relatedTasks.remove(value);
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }
}
