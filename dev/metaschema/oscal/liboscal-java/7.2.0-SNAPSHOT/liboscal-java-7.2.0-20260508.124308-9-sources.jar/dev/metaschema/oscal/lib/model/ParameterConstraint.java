// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_control-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A formal or informal expression of a constraint or test.
 */
@MetaschemaAssembly(
    formalName = "Constraint",
    description = "A formal or informal expression of a constraint or test.",
    name = "parameter-constraint",
    moduleClass = OscalControlCommonModule.class
)
public class ParameterConstraint implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A textual summary of the constraint to be applied.
   */
  @BoundField(
      formalName = "Constraint Description",
      description = "A textual summary of the constraint to be applied.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * A test expression which is expected to be evaluated by a tool.
   */
  @BoundAssembly(
      formalName = "Constraint Test",
      description = "A test expression which is expected to be evaluated by a tool.",
      useName = "test",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "tests", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Test> _tests;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterConstraint} instance with no metadata.
   */
  public ParameterConstraint() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterConstraint} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ParameterConstraint(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Constraint Description}".
   *
   * <p>
   * A textual summary of the constraint to be applied.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Constraint Description}".
   *
   * <p>
   * A textual summary of the constraint to be applied.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Constraint Test}".
   *
   * <p>
   * A test expression which is expected to be evaluated by a tool.
   *
   * @return the test value
   */
  @NonNull
  public List<Test> getTests() {
    if (_tests == null) {
      _tests = new LinkedList<>();
    }
    return ObjectUtils.notNull(_tests);
  }

  /**
   * Set the "{@literal Constraint Test}".
   *
   * <p>
   * A test expression which is expected to be evaluated by a tool.
   *
   * @param value
   *           the test value to set
   */
  public void setTests(@NonNull List<Test> value) {
    _tests = value;
  }

  /**
   * Add a new {@link Test} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addTest(Test item) {
    Test value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_tests == null) {
      _tests = new LinkedList<>();
    }
    return _tests.add(value);
  }

  /**
   * Remove the first matching {@link Test} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeTest(Test item) {
    Test value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _tests != null && _tests.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * A test expression which is expected to be evaluated by a tool.
   */
  @MetaschemaAssembly(
      formalName = "Constraint Test",
      description = "A test expression which is expected to be evaluated by a tool.",
      name = "test",
      moduleClass = OscalControlCommonModule.class
  )
  public static class Test implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A formal (executable) expression of a constraint.
     */
    @BoundField(
        formalName = "Constraint test",
        description = "A formal (executable) expression of a constraint.",
        useName = "expression",
        minOccurs = 1,
        typeAdapter = StringAdapter.class
    )
    private String _expression;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterConstraint.Test} instance with no metadata.
     */
    public Test() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterConstraint.Test} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Test(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Constraint test}".
     *
     * <p>
     * A formal (executable) expression of a constraint.
     *
     * @return the expression value
     */
    @NonNull
    public String getExpression() {
      return _expression;
    }

    /**
     * Set the "{@literal Constraint test}".
     *
     * <p>
     * A formal (executable) expression of a constraint.
     *
     * @param value
     *           the expression value to set
     */
    public void setExpression(@NonNull String value) {
      _expression = value;
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
