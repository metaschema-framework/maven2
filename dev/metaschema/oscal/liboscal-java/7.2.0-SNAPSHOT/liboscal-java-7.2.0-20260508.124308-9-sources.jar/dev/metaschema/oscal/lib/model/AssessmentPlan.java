// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-plan_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Let;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * An assessment plan, such as those provided by a FedRAMP assessor.
 */
@MetaschemaAssembly(
    formalName = "Security Assessment Plan (SAP)",
    description = "An assessment plan, such as those provided by a FedRAMP assessor.",
    name = "assessment-plan",
    moduleClass = OscalApModule.class,
    rootName = "assessment-plan",
    valueConstraints = @ValueConstraints(lets = @Let(name = "all-imports", target = "recurse-depth('.[import-ssp]/doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-ssp/@href)))/system-security-plan|.[import-profile]/resolve-profile(doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-profile/@href))))/catalog')")),
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-ap-index-metadata-scoped-role-id", formalName = "In-Scope Role Identifiers", description = "An index of role identifiers that are in-scope for the assessment-plan model. Roles are collected from imported system-securtity-plans, which in turn includes referenced profiles and catalogs. For a given role @id, a locally declared role takes precedence over a role that is imported, the role that was last imported.", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/role ! map:entry(@id,.))?*", name = "index-imports-metadata-role-id", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-ap-index-metadata-scoped-location-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/location ! map:entry(@uuid,.))?*", name = "index-imports-metadata-location-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-ap-index-metadata-scoped-party-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-ap-index-metadata-scoped-party-organization-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party[@type='organization'] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-organization-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-ap-index-metadata-scoped-property-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports//prop[@uuid] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-property-uuid", keyFields = @KeyField(target = "@uuid"))}, unique = {@IsUnique(id = "oscal-unique-document-id", formalName = "Unique Document Identifier", description = "Ensure all document identifiers have a unique combination of @scheme and value.", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-property-in-context-location", formalName = "Unique Properties", description = "Ensure all properties are unique for a given location using a unique combination of @ns, @name, @class. @group. and @value.", level = IConstraint.Level.ERROR, target = ".//prop", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-link-in-context-location", formalName = "Unique Links", description = "Ensure all links are unique for a given location using a unique combination of @href, @rel, and @media-type.", level = IConstraint.Level.ERROR, target = ".//link", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type"), @KeyField(target = "@resource-fragment")}), @IsUnique(id = "oscal-unique-responsibility-in-context-location", formalName = "Unique Responsibilities", description = "Ensure all responsible-roles and responsible-parties are unique for a given location using a unique combination of @role-id and the combination of @party-uuid values.", level = IConstraint.Level.ERROR, target = ".//(responsible-party|responsible-role)", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@role-id"), @KeyField(target = "@party-uuid")}, remarks = "Since `responsible-party` and `responsible-role` associate multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.")})
)
public class AssessmentPlan extends AbstractOscalInstance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment plan in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ap-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment plan</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Assessment Plan Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this assessment plan in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ap-identifiers). The locally defined *UUID* of the `assessment plan` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Provides information about the containing document, and defines concepts that are shared across the document.
   */
  @BoundAssembly(
      formalName = "Document Metadata",
      description = "Provides information about the containing document, and defines concepts that are shared across the document.",
      useName = "metadata",
      minOccurs = 1
  )
  private Metadata _metadata;

  /**
   * Used by the assessment plan and POA&amp;M to import information about the system.
   */
  @BoundAssembly(
      formalName = "Import System Security Plan",
      description = "Used by the assessment plan and POA\\&M to import information about the system.",
      useName = "import-ssp",
      remarks = "Used by the SAP to import information about the system being assessed.",
      minOccurs = 1
  )
  private ImportSsp _importSsp;

  /**
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   */
  @BoundAssembly(
      formalName = "Local Definitions",
      description = "Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.",
      useName = "local-definitions"
  )
  private LocalDefinitions _localDefinitions;

  /**
   * Used to define various terms and conditions under which an assessment, described by the plan, can be performed. Each child part defines a different type of term or condition.
   */
  @BoundAssembly(
      formalName = "Assessment Plan Terms and Conditions",
      description = "Used to define various terms and conditions under which an assessment, described by the plan, can be performed. Each child part defines a different type of term or condition.",
      useName = "terms-and-conditions"
  )
  private TermsAndConditions _termsAndConditions;

  /**
   * Identifies the controls being assessed and their control objectives.
   */
  @BoundAssembly(
      formalName = "Reviewed Controls and Control Objectives",
      description = "Identifies the controls being assessed and their control objectives.",
      useName = "reviewed-controls",
      minOccurs = 1
  )
  private ReviewedControls _reviewedControls;

  /**
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   */
  @BoundAssembly(
      formalName = "Subject of Assessment",
      description = "Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.",
      useName = "assessment-subject",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "assessment-subjects", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AssessmentSubject> _assessmentSubjects;

  /**
   * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
   */
  @BoundAssembly(
      formalName = "Assessment Assets",
      description = "Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.",
      useName = "assessment-assets"
  )
  private AssessmentAssets _assessmentAssets;

  /**
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   */
  @BoundAssembly(
      formalName = "Task",
      description = "Represents a scheduled event or milestone, which may be associated with a series of assessment actions.",
      useName = "task",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "tasks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Task> _tasks;

  /**
   * A collection of resources that may be referenced from within the OSCAL document instance.
   */
  @BoundAssembly(
      formalName = "Back matter",
      description = "A collection of resources that may be referenced from within the OSCAL document instance.",
      useName = "back-matter"
  )
  private BackMatter _backMatter;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentPlan} instance with no metadata.
   */
  public AssessmentPlan() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentPlan} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public AssessmentPlan(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Assessment Plan Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment plan in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ap-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment plan</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Assessment Plan Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment plan in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ap-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment plan</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @return the metadata value
   */
  @NonNull
  public Metadata getMetadata() {
    return _metadata;
  }

  /**
   * Set the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @param value
   *           the metadata value to set
   */
  public void setMetadata(@NonNull Metadata value) {
    _metadata = value;
  }

  /**
   * Get the "{@literal Import System Security Plan}".
   *
   * <p>
   * Used by the assessment plan and POA&amp;M to import information about the system.
   *
   * @return the import-ssp value
   */
  @NonNull
  public ImportSsp getImportSsp() {
    return _importSsp;
  }

  /**
   * Set the "{@literal Import System Security Plan}".
   *
   * <p>
   * Used by the assessment plan and POA&amp;M to import information about the system.
   *
   * @param value
   *           the import-ssp value to set
   */
  public void setImportSsp(@NonNull ImportSsp value) {
    _importSsp = value;
  }

  /**
   * Get the "{@literal Local Definitions}".
   *
   * <p>
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   *
   * @return the local-definitions value, or {@code null} if not set
   */
  @Nullable
  public LocalDefinitions getLocalDefinitions() {
    return _localDefinitions;
  }

  /**
   * Set the "{@literal Local Definitions}".
   *
   * <p>
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   *
   * @param value
   *           the local-definitions value to set, or {@code null} to clear
   */
  public void setLocalDefinitions(@Nullable LocalDefinitions value) {
    _localDefinitions = value;
  }

  /**
   * Get the "{@literal Assessment Plan Terms and Conditions}".
   *
   * <p>
   * Used to define various terms and conditions under which an assessment, described by the plan, can be performed. Each child part defines a different type of term or condition.
   *
   * @return the terms-and-conditions value, or {@code null} if not set
   */
  @Nullable
  public TermsAndConditions getTermsAndConditions() {
    return _termsAndConditions;
  }

  /**
   * Set the "{@literal Assessment Plan Terms and Conditions}".
   *
   * <p>
   * Used to define various terms and conditions under which an assessment, described by the plan, can be performed. Each child part defines a different type of term or condition.
   *
   * @param value
   *           the terms-and-conditions value to set, or {@code null} to clear
   */
  public void setTermsAndConditions(@Nullable TermsAndConditions value) {
    _termsAndConditions = value;
  }

  /**
   * Get the "{@literal Reviewed Controls and Control Objectives}".
   *
   * <p>
   * Identifies the controls being assessed and their control objectives.
   *
   * @return the reviewed-controls value
   */
  @NonNull
  public ReviewedControls getReviewedControls() {
    return _reviewedControls;
  }

  /**
   * Set the "{@literal Reviewed Controls and Control Objectives}".
   *
   * <p>
   * Identifies the controls being assessed and their control objectives.
   *
   * @param value
   *           the reviewed-controls value to set
   */
  public void setReviewedControls(@NonNull ReviewedControls value) {
    _reviewedControls = value;
  }

  /**
   * Get the "{@literal Subject of Assessment}".
   *
   * <p>
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   *
   * @return the assessment-subject value
   */
  @NonNull
  public List<AssessmentSubject> getAssessmentSubjects() {
    if (_assessmentSubjects == null) {
      _assessmentSubjects = new LinkedList<>();
    }
    return ObjectUtils.notNull(_assessmentSubjects);
  }

  /**
   * Set the "{@literal Subject of Assessment}".
   *
   * <p>
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   *
   * @param value
   *           the assessment-subject value to set
   */
  public void setAssessmentSubjects(@NonNull List<AssessmentSubject> value) {
    _assessmentSubjects = value;
  }

  /**
   * Add a new {@link AssessmentSubject} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAssessmentSubject(AssessmentSubject item) {
    AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_assessmentSubjects == null) {
      _assessmentSubjects = new LinkedList<>();
    }
    return _assessmentSubjects.add(value);
  }

  /**
   * Remove the first matching {@link AssessmentSubject} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAssessmentSubject(AssessmentSubject item) {
    AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _assessmentSubjects != null && _assessmentSubjects.remove(value);
  }

  /**
   * Get the "{@literal Assessment Assets}".
   *
   * <p>
   * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
   *
   * @return the assessment-assets value, or {@code null} if not set
   */
  @Nullable
  public AssessmentAssets getAssessmentAssets() {
    return _assessmentAssets;
  }

  /**
   * Set the "{@literal Assessment Assets}".
   *
   * <p>
   * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
   *
   * @param value
   *           the assessment-assets value to set, or {@code null} to clear
   */
  public void setAssessmentAssets(@Nullable AssessmentAssets value) {
    _assessmentAssets = value;
  }

  /**
   * Get the "{@literal Task}".
   *
   * <p>
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   *
   * @return the task value
   */
  @NonNull
  public List<Task> getTasks() {
    if (_tasks == null) {
      _tasks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_tasks);
  }

  /**
   * Set the "{@literal Task}".
   *
   * <p>
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   *
   * @param value
   *           the task value to set
   */
  public void setTasks(@NonNull List<Task> value) {
    _tasks = value;
  }

  /**
   * Add a new {@link Task} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addTask(Task item) {
    Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_tasks == null) {
      _tasks = new LinkedList<>();
    }
    return _tasks.add(value);
  }

  /**
   * Remove the first matching {@link Task} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeTask(Task item) {
    Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _tasks != null && _tasks.remove(value);
  }

  /**
   * Get the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @return the back-matter value, or {@code null} if not set
   */
  @Nullable
  public BackMatter getBackMatter() {
    return _backMatter;
  }

  /**
   * Set the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @param value
   *           the back-matter value to set, or {@code null} to clear
   */
  public void setBackMatter(@Nullable BackMatter value) {
    _backMatter = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   */
  @MetaschemaAssembly(
      formalName = "Local Definitions",
      description = "Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.",
      name = "local-definitions",
      moduleClass = OscalApModule.class,
      modelConstraints = @AssemblyConstraints(unique = {@IsUnique(id = "oscal-unique-ap-local-definitions-component", level = IConstraint.Level.ERROR, target = "component", keyFields = @KeyField(target = "@uuid"), remarks = "Since multiple `component` entries can be provided, each component must have a unique `uuid`."), @IsUnique(id = "oscal-unique-ap-local-definitions-user", level = IConstraint.Level.ERROR, target = "user", keyFields = @KeyField(target = "@uuid"), remarks = "A given `uuid` must be assigned only once to a user.")})
  )
  public static class LocalDefinitions implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A defined component that can be part of an implemented system.
     */
    @BoundAssembly(
        formalName = "Component",
        description = "A defined component that can be part of an implemented system.",
        useName = "component",
        remarks = "Used to add any components, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "components", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SystemComponent> _components;

    /**
     * A single managed inventory item within the system.
     */
    @BoundAssembly(
        formalName = "Inventory Item",
        description = "A single managed inventory item within the system.",
        useName = "inventory-item",
        remarks = "Used to add any inventory-items, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "inventory-items", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<InventoryItem> _inventoryItems;

    /**
     * A type of user that interacts with the system based on an associated role.
     */
    @BoundAssembly(
        formalName = "System User",
        description = "A type of user that interacts with the system based on an associated role.",
        useName = "user",
        remarks = "Used to add any users, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "users", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SystemUser> _users;

    /**
     * A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.
     */
    @BoundAssembly(
        formalName = "Assessment-Specific Control Objective",
        description = "A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.",
        useName = "objectives-and-methods",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "objectives-and-methods", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<LocalObjective> _objectivesAndMethods;

    /**
     * Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.
     */
    @BoundAssembly(
        formalName = "Activity",
        description = "Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.",
        useName = "activity",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "activities", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Activity> _activities;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentPlan.LocalDefinitions} instance with no metadata.
     */
    public LocalDefinitions() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentPlan.LocalDefinitions} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public LocalDefinitions(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Component}".
     *
     * <p>
     * A defined component that can be part of an implemented system.
     *
     * @return the component value
     */
    @NonNull
    public List<SystemComponent> getComponents() {
      if (_components == null) {
        _components = new LinkedList<>();
      }
      return ObjectUtils.notNull(_components);
    }

    /**
     * Set the "{@literal Component}".
     *
     * <p>
     * A defined component that can be part of an implemented system.
     *
     * @param value
     *           the component value to set
     */
    public void setComponents(@NonNull List<SystemComponent> value) {
      _components = value;
    }

    /**
     * Add a new {@link SystemComponent} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addComponent(SystemComponent item) {
      SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_components == null) {
        _components = new LinkedList<>();
      }
      return _components.add(value);
    }

    /**
     * Remove the first matching {@link SystemComponent} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeComponent(SystemComponent item) {
      SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _components != null && _components.remove(value);
    }

    /**
     * Get the "{@literal Inventory Item}".
     *
     * <p>
     * A single managed inventory item within the system.
     *
     * @return the inventory-item value
     */
    @NonNull
    public List<InventoryItem> getInventoryItems() {
      if (_inventoryItems == null) {
        _inventoryItems = new LinkedList<>();
      }
      return ObjectUtils.notNull(_inventoryItems);
    }

    /**
     * Set the "{@literal Inventory Item}".
     *
     * <p>
     * A single managed inventory item within the system.
     *
     * @param value
     *           the inventory-item value to set
     */
    public void setInventoryItems(@NonNull List<InventoryItem> value) {
      _inventoryItems = value;
    }

    /**
     * Add a new {@link InventoryItem} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addInventoryItem(InventoryItem item) {
      InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_inventoryItems == null) {
        _inventoryItems = new LinkedList<>();
      }
      return _inventoryItems.add(value);
    }

    /**
     * Remove the first matching {@link InventoryItem} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeInventoryItem(InventoryItem item) {
      InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _inventoryItems != null && _inventoryItems.remove(value);
    }

    /**
     * Get the "{@literal System User}".
     *
     * <p>
     * A type of user that interacts with the system based on an associated role.
     *
     * @return the user value
     */
    @NonNull
    public List<SystemUser> getUsers() {
      if (_users == null) {
        _users = new LinkedList<>();
      }
      return ObjectUtils.notNull(_users);
    }

    /**
     * Set the "{@literal System User}".
     *
     * <p>
     * A type of user that interacts with the system based on an associated role.
     *
     * @param value
     *           the user value to set
     */
    public void setUsers(@NonNull List<SystemUser> value) {
      _users = value;
    }

    /**
     * Add a new {@link SystemUser} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addUser(SystemUser item) {
      SystemUser value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_users == null) {
        _users = new LinkedList<>();
      }
      return _users.add(value);
    }

    /**
     * Remove the first matching {@link SystemUser} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeUser(SystemUser item) {
      SystemUser value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _users != null && _users.remove(value);
    }

    /**
     * Get the "{@literal Assessment-Specific Control Objective}".
     *
     * <p>
     * A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.
     *
     * @return the objectives-and-methods value
     */
    @NonNull
    public List<LocalObjective> getObjectivesAndMethods() {
      if (_objectivesAndMethods == null) {
        _objectivesAndMethods = new LinkedList<>();
      }
      return ObjectUtils.notNull(_objectivesAndMethods);
    }

    /**
     * Set the "{@literal Assessment-Specific Control Objective}".
     *
     * <p>
     * A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.
     *
     * @param value
     *           the objectives-and-methods value to set
     */
    public void setObjectivesAndMethods(@NonNull List<LocalObjective> value) {
      _objectivesAndMethods = value;
    }

    /**
     * Add a new {@link LocalObjective} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addObjectivesAndMethods(LocalObjective item) {
      LocalObjective value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_objectivesAndMethods == null) {
        _objectivesAndMethods = new LinkedList<>();
      }
      return _objectivesAndMethods.add(value);
    }

    /**
     * Remove the first matching {@link LocalObjective} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeObjectivesAndMethods(LocalObjective item) {
      LocalObjective value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _objectivesAndMethods != null && _objectivesAndMethods.remove(value);
    }

    /**
     * Get the "{@literal Activity}".
     *
     * <p>
     * Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.
     *
     * @return the activity value
     */
    @NonNull
    public List<Activity> getActivities() {
      if (_activities == null) {
        _activities = new LinkedList<>();
      }
      return ObjectUtils.notNull(_activities);
    }

    /**
     * Set the "{@literal Activity}".
     *
     * <p>
     * Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.
     *
     * @param value
     *           the activity value to set
     */
    public void setActivities(@NonNull List<Activity> value) {
      _activities = value;
    }

    /**
     * Add a new {@link Activity} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addActivity(Activity item) {
      Activity value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_activities == null) {
        _activities = new LinkedList<>();
      }
      return _activities.add(value);
    }

    /**
     * Remove the first matching {@link Activity} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeActivity(Activity item) {
      Activity value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _activities != null && _activities.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Used to define various terms and conditions under which an assessment, described by the plan, can be performed. Each child part defines a different type of term or condition.
   */
  @MetaschemaAssembly(
      formalName = "Assessment Plan Terms and Conditions",
      description = "Used to define various terms and conditions under which an assessment, described by the plan, can be performed. Each child part defines a different type of term or condition.",
      name = "terms-and-conditions",
      moduleClass = OscalApModule.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-terms-and-conditions-part-name", level = IConstraint.Level.ERROR, target = "part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "rules-of-engagement", description = "Defines the circumstances, conditions, degree, and manner in which the use of cyber-attack techniques or actions may be applied to the assessment."), @AllowedValue(value = "disclosures", description = "Any information the assessor should make known to the system owner or authorizing official. Has child 'item' parts for each individual disclosure."), @AllowedValue(value = "assessment-inclusions", description = "Defines any assessment activities which the system owner or authorizing official wishes to ensure are performed as part of the assessment."), @AllowedValue(value = "assessment-exclusions", description = "Defines any assessment activities which the system owner or authorizing official explicitly prohibits from being performed as part of the assessment."), @AllowedValue(value = "results-delivery", description = "Defines conditions related to the delivery of the assessment results, such as when to deliver, how, and to whom."), @AllowedValue(value = "assumptions", description = "Defines any supposition made by the assessor. Has child 'item' parts for each assumption."), @AllowedValue(value = "methodology", description = "An explanation of practices, procedures, and rules used in the course of the assessment.")}))
  )
  public static class TermsAndConditions implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A partition of an assessment plan or results or a child of another part.
     */
    @BoundAssembly(
        formalName = "Assessment Part",
        description = "A partition of an assessment plan or results or a child of another part.",
        useName = "part",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "parts", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<AssessmentPart> _parts;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentPlan.TermsAndConditions} instance with no metadata.
     */
    public TermsAndConditions() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentPlan.TermsAndConditions} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public TermsAndConditions(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Assessment Part}".
     *
     * <p>
     * A partition of an assessment plan or results or a child of another part.
     *
     * @return the part value
     */
    @NonNull
    public List<AssessmentPart> getParts() {
      if (_parts == null) {
        _parts = new LinkedList<>();
      }
      return ObjectUtils.notNull(_parts);
    }

    /**
     * Set the "{@literal Assessment Part}".
     *
     * <p>
     * A partition of an assessment plan or results or a child of another part.
     *
     * @param value
     *           the part value to set
     */
    public void setParts(@NonNull List<AssessmentPart> value) {
      _parts = value;
    }

    /**
     * Add a new {@link AssessmentPart} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addPart(AssessmentPart item) {
      AssessmentPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_parts == null) {
        _parts = new LinkedList<>();
      }
      return _parts.add(value);
    }

    /**
     * Remove the first matching {@link AssessmentPart} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removePart(AssessmentPart item) {
      AssessmentPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _parts != null && _parts.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
