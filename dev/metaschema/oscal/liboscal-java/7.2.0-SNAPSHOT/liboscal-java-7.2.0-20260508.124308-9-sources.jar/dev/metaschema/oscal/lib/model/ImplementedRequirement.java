// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.HasCardinality;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes how the system satisfies the requirements of an individual control.
 */
@MetaschemaAssembly(
    formalName = "Control-based Requirement",
    description = "Describes how the system satisfies the requirements of an individual control.",
    name = "implemented-requirement",
    moduleClass = OscalSspModule.class,
    remarks = "Use of `set-parameter` in this context, sets the parameter for the referenced control. Any `set-parameter` defined in a child context will override this value. If not overridden by a child, this value applies in the child context.",
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-implemented-requirement-statement-by-component-prop-name-values", level = IConstraint.Level.ERROR, target = "(.|statement|.//by-component)/prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "control-origination", description = "Identifies the source of the implemented control. Any `control-origination` prop defined in a child context will override the parent value.")), @AllowedValues(id = "oscal-implemented-requirement-statement-by-component-prop-control-origination-values", level = IConstraint.Level.ERROR, target = "(.|statement|.//by-component)/prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='control-origination']/@value", values = {@AllowedValue(value = "organization", description = "The control is implemented by the organization owning the system, but is not specific to the system itself."), @AllowedValue(value = "system-specific", description = "The control is implemented specifically to this system."), @AllowedValue(value = "customer-configured", description = "The control is provided by the system, but must be configured by the customer."), @AllowedValue(value = "customer-provided", description = "The control must be implemented by the customer."), @AllowedValue(value = "inherited", description = "This control is inherited from an underlying system.")}), @AllowedValues(id = "oscal-implemented-requirement-responsible-role-id-values", level = IConstraint.Level.ERROR, target = "responsible-role/@role-id", allowOthers = true, values = {@AllowedValue(value = "asset-owner", description = "Accountable for ensuring the asset is managed in accordance with organizational policies and procedures."), @AllowedValue(value = "asset-administrator", description = "Responsible for administering a set of assets."), @AllowedValue(value = "security-operations", description = "Members of the security operations center (SOC)."), @AllowedValue(value = "network-operations", description = "Members of the network operations center (NOC)."), @AllowedValue(value = "incident-response", description = "Responsible for responding to an event that could lead to loss of, or disruption to, an organization's operations, services or functions."), @AllowedValue(value = "help-desk", description = "Responsible for providing information and support to users."), @AllowedValue(value = "configuration-management", description = "Responsible for the configuration management processes governing changes to the asset.")})}, indexHasKey = {@IndexHasKey(id = "oscal-implemented-requirement-index-metadata-role-id", level = IConstraint.Level.ERROR, target = "responsible-role|statement/responsible-role|.//by-component//responsible-role", indexName = "index-metadata-role-id", keyFields = @KeyField(target = "@role-id")), @IndexHasKey(id = "oscal-implemented-requirement-index-metadata-party-uuid", level = IConstraint.Level.ERROR, target = "responsible-role|statement/responsible-role|.//by-component//responsible-role", indexName = "index-metadata-party-uuid", keyFields = @KeyField(target = "party-uuid"))}),
    modelConstraints = @AssemblyConstraints(unique = {@IsUnique(id = "oscal-unique-ssp-implemented-requirement-set-parameter", level = IConstraint.Level.ERROR, target = "set-parameter", keyFields = @KeyField(target = "@param-id"), remarks = "Since multiple `set-parameter` entries can be provided, each parameter must be set only once."), @IsUnique(id = "oscal-unique-ssp-implemented-requirement-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."), @IsUnique(id = "oscal-unique-ssp-implemented-requirement-statement", level = IConstraint.Level.ERROR, target = "statement", keyFields = @KeyField(target = "@statement-id"), remarks = "Since `statement` entries can be referenced using the statement's statement-id, each statement must be referenced only once."), @IsUnique(id = "oscal-unique-ssp-implemented-requirement-by-component", level = IConstraint.Level.ERROR, target = "by-component", keyFields = @KeyField(target = "@component-uuid"), remarks = "Since `by-component` can reference `component` entries using the component's uuid, each component must be referenced only once. This ensures that all implementation statements are contained in the same `by-component` entry.")}, cardinality = @HasCardinality(id = "oscal-implemented-requirement-by-component-cardinality", level = IConstraint.Level.ERROR, target = ".//by-component", minOccurs = 1))
)
public class ImplementedRequirement implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this control requirement elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>control requirement</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Control Requirement Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this control requirement elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `control requirement` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   */
  @BoundFlag(
      formalName = "Control Identifier Reference",
      description = "A reference to a control with a corresponding `id` value. When referencing an externally defined `control`, the `Control Identifier Reference` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).",
      name = "control-id",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _controlId;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the parameter that will be set by the enclosed value.
   */
  @BoundAssembly(
      formalName = "Set Parameter Value",
      description = "Identifies the parameter that will be set by the enclosed value.",
      useName = "set-parameter",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "set-parameters", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SetParameter> _setParameters;

  /**
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   */
  @BoundAssembly(
      formalName = "Responsible Role",
      description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
      useName = "responsible-role",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleRole> _responsibleRoles;

  /**
   * Identifies which statements within a control are addressed.
   */
  @BoundAssembly(
      formalName = "Specific Control Statement",
      description = "Identifies which statements within a control are addressed.",
      useName = "statement",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "statements", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Statement> _statements;

  /**
   * Defines how the referenced component implements a set of controls.
   */
  @BoundAssembly(
      formalName = "Component Control Implementation",
      description = "Defines how the referenced component implements a set of controls.",
      useName = "by-component",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "by-components", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ByComponent> _byComponents;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImplementedRequirement} instance with no metadata.
   */
  public ImplementedRequirement() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImplementedRequirement} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ImplementedRequirement(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Control Requirement Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this control requirement elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>control requirement</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Control Requirement Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this control requirement elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>control requirement</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @return the control-id value
   */
  @NonNull
  public String getControlId() {
    return _controlId;
  }

  /**
   * Set the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @param value
   *           the control-id value to set
   */
  public void setControlId(@NonNull String value) {
    _controlId = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @return the set-parameter value
   */
  @NonNull
  public List<SetParameter> getSetParameters() {
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return ObjectUtils.notNull(_setParameters);
  }

  /**
   * Set the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @param value
   *           the set-parameter value to set
   */
  public void setSetParameters(@NonNull List<SetParameter> value) {
    _setParameters = value;
  }

  /**
   * Add a new {@link SetParameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return _setParameters.add(value);
  }

  /**
   * Remove the first matching {@link SetParameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _setParameters != null && _setParameters.remove(value);
  }

  /**
   * Get the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @return the responsible-role value
   */
  @NonNull
  public List<ResponsibleRole> getResponsibleRoles() {
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleRoles);
  }

  /**
   * Set the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @param value
   *           the responsible-role value to set
   */
  public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
    _responsibleRoles = value;
  }

  /**
   * Add a new {@link ResponsibleRole} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return _responsibleRoles.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleRoles != null && _responsibleRoles.remove(value);
  }

  /**
   * Get the "{@literal Specific Control Statement}".
   *
   * <p>
   * Identifies which statements within a control are addressed.
   *
   * @return the statement value
   */
  @NonNull
  public List<Statement> getStatements() {
    if (_statements == null) {
      _statements = new LinkedList<>();
    }
    return ObjectUtils.notNull(_statements);
  }

  /**
   * Set the "{@literal Specific Control Statement}".
   *
   * <p>
   * Identifies which statements within a control are addressed.
   *
   * @param value
   *           the statement value to set
   */
  public void setStatements(@NonNull List<Statement> value) {
    _statements = value;
  }

  /**
   * Add a new {@link Statement} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addStatement(Statement item) {
    Statement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_statements == null) {
      _statements = new LinkedList<>();
    }
    return _statements.add(value);
  }

  /**
   * Remove the first matching {@link Statement} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeStatement(Statement item) {
    Statement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _statements != null && _statements.remove(value);
  }

  /**
   * Get the "{@literal Component Control Implementation}".
   *
   * <p>
   * Defines how the referenced component implements a set of controls.
   *
   * @return the by-component value
   */
  @NonNull
  public List<ByComponent> getByComponents() {
    if (_byComponents == null) {
      _byComponents = new LinkedList<>();
    }
    return ObjectUtils.notNull(_byComponents);
  }

  /**
   * Set the "{@literal Component Control Implementation}".
   *
   * <p>
   * Defines how the referenced component implements a set of controls.
   *
   * @param value
   *           the by-component value to set
   */
  public void setByComponents(@NonNull List<ByComponent> value) {
    _byComponents = value;
  }

  /**
   * Add a new {@link ByComponent} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addByComponent(ByComponent item) {
    ByComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_byComponents == null) {
      _byComponents = new LinkedList<>();
    }
    return _byComponents.add(value);
  }

  /**
   * Remove the first matching {@link ByComponent} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeByComponent(ByComponent item) {
    ByComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _byComponents != null && _byComponents.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
