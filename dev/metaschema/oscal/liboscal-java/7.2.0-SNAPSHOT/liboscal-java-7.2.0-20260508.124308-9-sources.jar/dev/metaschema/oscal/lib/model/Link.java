// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import dev.metaschema.oscal.lib.model.metadata.AbstractLink;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A reference to a local or remote resource, that has a specific relation to the containing object.
 */
@MetaschemaAssembly(
    formalName = "Link",
    description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
    name = "link",
    moduleClass = OscalMetadataModule.class,
    remarks = "To provide a cryptographic hash for a remote target resource, a local reference to a back matter `resource` is needed. The resource allows one or more hash values to be provided using the `rlink/hash` object.\n"
            + "\n"
            + "The OSCAL `link` is a roughly based on the HTML [link element](https://www.w3.org/TR/html401/struct/links.html#edef-LINK).",
    valueConstraints = @ValueConstraints(indexHasKey = @IndexHasKey(id = "oscal-metadata-link-reference-index-back-matter-resource", level = IConstraint.Level.ERROR, target = ".[@rel=('reference') and starts-with(@href,'#')]", indexName = "index-back-matter-resource", keyFields = @KeyField(target = "@href", pattern = "#(.*)")), matches = {@Matches(id = "oscal-metadata-link-reference-href-datatype-uri-reference", level = IConstraint.Level.ERROR, target = ".[@rel=('reference') and starts-with(@href,'#')]/@href", typeAdapter = UriReferenceAdapter.class), @Matches(id = "oscal-metadata-link-reference-href-datatype-uri", level = IConstraint.Level.ERROR, target = ".[@rel=('reference') and not(starts-with(@href,'#'))]/@href", typeAdapter = UriAdapter.class), @Matches(id = "oscal-metadata-link-resource-fragment-datatype", level = IConstraint.Level.ERROR, target = "@resource-fragment", pattern = "(?:[0-9a-zA-Z-._~/?!$&'()*+,;=:@]|%[0-9A-F][0-9A-F])+", remarks = "This pattern is based on the fragment Augmented Backus-Naur form (ABNF) syntax provided in \\[RFC3986 section 3.5\\](https://www.rfc-editor.org/rfc/rfc3986#section-3.5). Uppercase alpha hex digits are required, which is the preferred normalized form defined in RFC3986.")}, expect = @Expect(id = "oscal-metadata-link-uri-reference-no-media-type", description = "A local reference SHOULD NOT have a media-type.", level = IConstraint.Level.ERROR, target = ".[starts-with(@href,'#')]", test = "not(exists(@media-type))", remarks = "Since both `link` and `back-matter/resource` both allow specification of a `media-type`, the `media-type` on `link` may conflict with the any `media-type` entries on a resource's `rlink` or `base64` objects. This constraint prevents this from occurring."))
)
public class Link extends AbstractLink implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A resolvable URL reference to a resource.
   */
  @BoundFlag(
      formalName = "Hypertext Reference",
      description = "A resolvable URL reference to a resource.",
      name = "href",
      required = true,
      typeAdapter = UriReferenceAdapter.class,
      remarks = "This value may be one of:\n"
              + "\n"
              + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
              + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
              + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to an OSCAL object by the objects identifier (e.g., id, uuid) in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object)). The specific object type will differ based on the link relationship type."
  )
  private URI _href;

  /**
   * Describes the type of relationship provided by the link's hypertext reference. This can be an indicator of the link's purpose.
   */
  @BoundFlag(
      formalName = "Link Relation Type",
      description = "Describes the type of relationship provided by the link's hypertext reference. This can be an indicator of the link's purpose.",
      name = "rel",
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-link-rel-values", level = IConstraint.Level.ERROR, allowOthers = true, values = @AllowedValue(value = "reference", description = "A generalized reference to a network resource (relative or absolute) or to a `back-matter` resource by UUID expressed as a bare URI fragment.")))
  )
  private String _rel;

  /**
   * A label that indicates the nature of a resource, as a data serialization or format.
   */
  @BoundFlag(
      formalName = "Link Media Type",
      description = "A label that indicates the nature of a resource, as a data serialization or format.",
      name = "media-type",
      typeAdapter = StringAdapter.class,
      remarks = "The `media-type` provides a hint about the content model of the referenced resource. A valid entry from the [IANA Media Types registry](https://www.iana.org/assignments/media-types/media-types.xhtml) SHOULD be used."
  )
  private String _mediaType;

  /**
   * In case where the <code>href</code> points to a <code>back-matter/resource</code>, this value will indicate the URI <a href="https://www.rfc-editor.org/rfc/rfc3986#section-3.5">fragment</a> to append to any <code>rlink</code> associated with the resource. This value MUST be <a href="https://www.rfc-editor.org/rfc/rfc3986#section-2.1">URI encoded</a>.
   */
  @BoundFlag(
      formalName = "Resource Fragment",
      description = "In case where the `href` points to a `back-matter/resource`, this value will indicate the URI [fragment](https://www.rfc-editor.org/rfc/rfc3986#section-3.5) to append to any `rlink` associated with the resource. This value MUST be [URI encoded](https://www.rfc-editor.org/rfc/rfc3986#section-2.1).",
      name = "resource-fragment",
      typeAdapter = StringAdapter.class
  )
  private String _resourceFragment;

  /**
   * A textual label to associate with the link, which may be used for presentation in a tool.
   */
  @BoundField(
      formalName = "Link Text",
      description = "A textual label to associate with the link, which may be used for presentation in a tool.",
      useName = "text",
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _text;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Link} instance with no metadata.
   */
  public Link() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Link} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Link(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Hypertext Reference}".
   *
   * <p>
   * A resolvable URL reference to a resource.
   *
   * @return the href value
   */
  @NonNull
  public URI getHref() {
    return _href;
  }

  /**
   * Set the "{@literal Hypertext Reference}".
   *
   * <p>
   * A resolvable URL reference to a resource.
   *
   * @param value
   *           the href value to set
   */
  public void setHref(@NonNull URI value) {
    _href = value;
  }

  /**
   * Get the "{@literal Link Relation Type}".
   *
   * <p>
   * Describes the type of relationship provided by the link's hypertext reference. This can be an indicator of the link's purpose.
   *
   * @return the rel value, or {@code null} if not set
   */
  @Nullable
  public String getRel() {
    return _rel;
  }

  /**
   * Set the "{@literal Link Relation Type}".
   *
   * <p>
   * Describes the type of relationship provided by the link's hypertext reference. This can be an indicator of the link's purpose.
   *
   * @param value
   *           the rel value to set, or {@code null} to clear
   */
  public void setRel(@Nullable String value) {
    _rel = value;
  }

  /**
   * Get the "{@literal Link Media Type}".
   *
   * <p>
   * A label that indicates the nature of a resource, as a data serialization or format.
   *
   * @return the media-type value, or {@code null} if not set
   */
  @Nullable
  public String getMediaType() {
    return _mediaType;
  }

  /**
   * Set the "{@literal Link Media Type}".
   *
   * <p>
   * A label that indicates the nature of a resource, as a data serialization or format.
   *
   * @param value
   *           the media-type value to set, or {@code null} to clear
   */
  public void setMediaType(@Nullable String value) {
    _mediaType = value;
  }

  /**
   * Get the "{@literal Resource Fragment}".
   *
   * <p>
   * In case where the <code>href</code> points to a <code>back-matter/resource</code>, this value will indicate the URI <a href="https://www.rfc-editor.org/rfc/rfc3986#section-3.5">fragment</a> to append to any <code>rlink</code> associated with the resource. This value MUST be <a href="https://www.rfc-editor.org/rfc/rfc3986#section-2.1">URI encoded</a>.
   *
   * @return the resource-fragment value, or {@code null} if not set
   */
  @Nullable
  public String getResourceFragment() {
    return _resourceFragment;
  }

  /**
   * Set the "{@literal Resource Fragment}".
   *
   * <p>
   * In case where the <code>href</code> points to a <code>back-matter/resource</code>, this value will indicate the URI <a href="https://www.rfc-editor.org/rfc/rfc3986#section-3.5">fragment</a> to append to any <code>rlink</code> associated with the resource. This value MUST be <a href="https://www.rfc-editor.org/rfc/rfc3986#section-2.1">URI encoded</a>.
   *
   * @param value
   *           the resource-fragment value to set, or {@code null} to clear
   */
  public void setResourceFragment(@Nullable String value) {
    _resourceFragment = value;
  }

  /**
   * Get the "{@literal Link Text}".
   *
   * <p>
   * A textual label to associate with the link, which may be used for presentation in a tool.
   *
   * @return the text value, or {@code null} if not set
   */
  @Nullable
  public MarkupLine getText() {
    return _text;
  }

  /**
   * Set the "{@literal Link Text}".
   *
   * <p>
   * A textual label to associate with the link, which may be used for presentation in a tool.
   *
   * @param value
   *           the text value to set, or {@code null} to clear
   */
  public void setText(@Nullable MarkupLine value) {
    _text = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
