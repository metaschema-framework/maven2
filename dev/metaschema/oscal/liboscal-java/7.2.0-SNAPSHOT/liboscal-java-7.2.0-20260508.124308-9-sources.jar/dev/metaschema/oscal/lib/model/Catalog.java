// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_catalog_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import dev.metaschema.oscal.lib.model.control.catalog.AbstractCatalog;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A structured, <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#catalog">organized collection</a> of control information.
 */
@MetaschemaAssembly(
    formalName = "Catalog",
    description = "A structured, [organized collection](https://pages.nist.gov/OSCAL/concepts/terminology/#catalog) of control information.",
    name = "catalog",
    moduleClass = OscalCatalogModule.class,
    rootName = "catalog",
    remarks = "Catalogs may use one or more `group` objects to subdivide the control contents of a catalog.",
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-catalog-metadata-prop-name", level = IConstraint.Level.ERROR, target = "metadata/prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "resolution-tool", description = "The tool used to produce a resolved profile."), @AllowedValue(value = "source-profile-uuid", description = "The document-level `uuid` of the source profile from which the catalog was produced by [profile resolution](https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/).")}), @AllowedValues(id = "oscal-catalog-metadata-link-rel-type", level = IConstraint.Level.ERROR, target = "metadata/link/@rel", allowOthers = true, values = {@AllowedValue(value = "source-profile", description = "The profile from which the catalog was produced by [profile resolution](https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/)."), @AllowedValue(value = "source-profile-uuid", description = "The document-level `uuid` of the profile from which the catalog was produced by [profile resolution](https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/).")})}),
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-catalog-parts", level = IConstraint.Level.ERROR, target = "//part", name = "catalog-parts", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-catalog-props", level = IConstraint.Level.ERROR, target = "//prop", name = "catalog-props", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-catalog-groups-controls-parts", level = IConstraint.Level.ERROR, target = "//(control|group|part)", name = "catalog-groups-controls-parts", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-catalog-controls", level = IConstraint.Level.ERROR, target = "//control", name = "catalog-controls", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-catalog-params", level = IConstraint.Level.ERROR, target = "//param", name = "catalog-params", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-catalog-groups", level = IConstraint.Level.ERROR, target = "//group", name = "catalog-groups", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-catalog-index-metadata-scoped-metadata-role-id", formalName = "In-Scope Role Identifiers", description = "An index of role identifiers that are in-scope for the catalog model.", level = IConstraint.Level.ERROR, target = "metadata/role", name = "index-imports-metadata-role-id", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-catalog-index-metadata-scoped-location-uuid", level = IConstraint.Level.ERROR, target = "metadata/location", name = "index-imports-metadata-location-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-catalog-index-metadata-scoped-party-uuid", level = IConstraint.Level.ERROR, target = "metadata/party", name = "index-imports-metadata-party-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-catalog-index-metadata-scoped-party-organization-uuid", level = IConstraint.Level.ERROR, target = "metadata/party[@type='organization']", name = "index-imports-metadata-party-organization-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-catalog-index-metadata-scoped-property-uuid", level = IConstraint.Level.ERROR, target = ".//prop[@uuid]", name = "index-imports-metadata-property-uuid", keyFields = @KeyField(target = "@uuid"))}, unique = {@IsUnique(id = "oscal-unique-document-id", formalName = "Unique Document Identifier", description = "Ensure all document identifiers have a unique combination of @scheme and value.", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-property-in-context-location", formalName = "Unique Properties", description = "Ensure all properties are unique for a given location using a unique combination of @ns, @name, @class. @group. and @value.", level = IConstraint.Level.ERROR, target = ".//prop", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-link-in-context-location", formalName = "Unique Links", description = "Ensure all links are unique for a given location using a unique combination of @href, @rel, and @media-type.", level = IConstraint.Level.ERROR, target = ".//link", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type"), @KeyField(target = "@resource-fragment")}), @IsUnique(id = "oscal-unique-responsibility-in-context-location", formalName = "Unique Responsibilities", description = "Ensure all responsible-roles and responsible-parties are unique for a given location using a unique combination of @role-id and the combination of @party-uuid values.", level = IConstraint.Level.ERROR, target = ".//(responsible-party|responsible-role)", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@role-id"), @KeyField(target = "@party-uuid")}, remarks = "Since `responsible-party` and `responsible-role` associate multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.")})
)
public class Catalog extends AbstractCatalog implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Provides a globally unique means to identify a given catalog instance.
   */
  @BoundFlag(
      formalName = "Catalog Universally Unique Identifier",
      description = "Provides a globally unique means to identify a given catalog instance.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Provides information about the containing document, and defines concepts that are shared across the document.
   */
  @BoundAssembly(
      formalName = "Document Metadata",
      description = "Provides information about the containing document, and defines concepts that are shared across the document.",
      useName = "metadata",
      minOccurs = 1
  )
  private Metadata _metadata;

  /**
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   */
  @BoundAssembly(
      formalName = "Parameter",
      description = "Parameters provide a mechanism for the dynamic assignment of value(s) in a control.",
      useName = "param",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "params", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Parameter> _params;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">structured object</a> representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.
   */
  @BoundAssembly(
      formalName = "Control",
      description = "A [structured object](https://pages.nist.gov/OSCAL/concepts/terminology/#control) representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.",
      useName = "control",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "controls", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Control> _controls;

  /**
   * A group of controls, or of groups of controls.
   */
  @BoundAssembly(
      formalName = "Control Group",
      description = "A group of controls, or of groups of controls.",
      useName = "group",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "groups", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<CatalogGroup> _groups;

  /**
   * A collection of resources that may be referenced from within the OSCAL document instance.
   */
  @BoundAssembly(
      formalName = "Back matter",
      description = "A collection of resources that may be referenced from within the OSCAL document instance.",
      useName = "back-matter",
      remarks = "Back matter including references and resources."
  )
  private BackMatter _backMatter;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Catalog} instance with no metadata.
   */
  public Catalog() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Catalog} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Catalog(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Catalog Universally Unique Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given catalog instance.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Catalog Universally Unique Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given catalog instance.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @return the metadata value
   */
  @NonNull
  public Metadata getMetadata() {
    return _metadata;
  }

  /**
   * Set the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @param value
   *           the metadata value to set
   */
  public void setMetadata(@NonNull Metadata value) {
    _metadata = value;
  }

  /**
   * Get the "{@literal Parameter}".
   *
   * <p>
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   *
   * @return the param value
   */
  @NonNull
  public List<Parameter> getParams() {
    if (_params == null) {
      _params = new LinkedList<>();
    }
    return ObjectUtils.notNull(_params);
  }

  /**
   * Set the "{@literal Parameter}".
   *
   * <p>
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   *
   * @param value
   *           the param value to set
   */
  public void setParams(@NonNull List<Parameter> value) {
    _params = value;
  }

  /**
   * Add a new {@link Parameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addParam(Parameter item) {
    Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_params == null) {
      _params = new LinkedList<>();
    }
    return _params.add(value);
  }

  /**
   * Remove the first matching {@link Parameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeParam(Parameter item) {
    Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _params != null && _params.remove(value);
  }

  /**
   * Get the "{@literal Control}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">structured object</a> representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.
   *
   * @return the control value
   */
  @NonNull
  public List<Control> getControls() {
    if (_controls == null) {
      _controls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_controls);
  }

  /**
   * Set the "{@literal Control}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">structured object</a> representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.
   *
   * @param value
   *           the control value to set
   */
  public void setControls(@NonNull List<Control> value) {
    _controls = value;
  }

  /**
   * Add a new {@link Control} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addControl(Control item) {
    Control value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_controls == null) {
      _controls = new LinkedList<>();
    }
    return _controls.add(value);
  }

  /**
   * Remove the first matching {@link Control} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeControl(Control item) {
    Control value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _controls != null && _controls.remove(value);
  }

  /**
   * Get the "{@literal Control Group}".
   *
   * <p>
   * A group of controls, or of groups of controls.
   *
   * @return the group value
   */
  @NonNull
  public List<CatalogGroup> getGroups() {
    if (_groups == null) {
      _groups = new LinkedList<>();
    }
    return ObjectUtils.notNull(_groups);
  }

  /**
   * Set the "{@literal Control Group}".
   *
   * <p>
   * A group of controls, or of groups of controls.
   *
   * @param value
   *           the group value to set
   */
  public void setGroups(@NonNull List<CatalogGroup> value) {
    _groups = value;
  }

  /**
   * Add a new {@link CatalogGroup} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addGroup(CatalogGroup item) {
    CatalogGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_groups == null) {
      _groups = new LinkedList<>();
    }
    return _groups.add(value);
  }

  /**
   * Remove the first matching {@link CatalogGroup} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeGroup(CatalogGroup item) {
    CatalogGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _groups != null && _groups.remove(value);
  }

  /**
   * Get the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @return the back-matter value, or {@code null} if not set
   */
  @Nullable
  public BackMatter getBackMatter() {
    return _backMatter;
  }

  /**
   * Set the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @param value
   *           the back-matter value to set, or {@code null} to clear
   */
  public void setBackMatter(@Nullable BackMatter value) {
    _backMatter = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
