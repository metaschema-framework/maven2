// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.datatype.adapter.IntegerAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * An identified risk.
 */
@MetaschemaAssembly(
    formalName = "Identified Risk",
    description = "An identified risk.",
    name = "risk",
    moduleClass = OscalAssessmentCommonModule.class,
    valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-risk-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "false-positive", description = "The risk has been confirmed to be a false positive."), @AllowedValue(value = "accepted", description = "The risk has been accepted. No further action will be taken."), @AllowedValue(value = "risk-adjusted", description = "The risk has been adjusted."), @AllowedValue(value = "priority", description = "A numeric value indicating the sequence in which risks should be addressed. (Lower numbers are higher priority)")}), matches = @Matches(id = "oscal-risk-priority-datatype", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='priority']/@value", typeAdapter = IntegerAdapter.class))
)
public class Risk implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this risk elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Risk Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this risk elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `risk` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The title for this risk.
   */
  @BoundField(
      formalName = "Risk Title",
      description = "The title for this risk.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable summary of the identified risk, to include a statement of how the risk impacts the system.
   */
  @BoundField(
      formalName = "Risk Description",
      description = "A human-readable summary of the identified risk, to include a statement of how the risk impacts the system.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An summary of impact for how the risk affects the system.
   */
  @BoundField(
      formalName = "Risk Statement",
      description = "An summary of impact for how the risk affects the system.",
      useName = "statement",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _statement;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Describes the status of the associated risk.
   */
  @BoundField(
      formalName = "Risk Status",
      description = "Describes the status of the associated risk.",
      useName = "status",
      minOccurs = 1,
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-risk-status-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "open", description = "The risk has been identified."), @AllowedValue(value = "investigating", description = "The identified risk is being investigated. (Open risk)"), @AllowedValue(value = "remediating", description = "Remediation activities are underway, but are not yet complete. (Open risk)"), @AllowedValue(value = "deviation-requested", description = "A risk deviation, such as false positive, risk reduction, or operational requirement has been submitted for approval. (Open risk)"), @AllowedValue(value = "deviation-approved", description = "A risk deviation, such as false positive, risk reduction, or operational requirement has been approved. (Open risk)"), @AllowedValue(value = "closed", description = "The risk has been resolved.")}))
  )
  private String _status;

  /**
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   */
  @BoundAssembly(
      formalName = "Origin",
      description = "Identifies the source of the finding, such as a tool, interviewed person, or activity.",
      useName = "origin",
      remarks = "Used to identify the individual and/or tool that identified this risk.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "origins", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Origin> _origins;

  /**
   * A pointer, by ID, to an externally-defined threat.
   */
  @BoundField(
      formalName = "Threat ID",
      description = "A pointer, by ID, to an externally-defined threat.",
      useName = "threat-id",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "threat-ids", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ThreatId> _threatIds;

  /**
   * A collection of descriptive data about the containing object from a specific origin.
   */
  @BoundAssembly(
      formalName = "Characterization",
      description = "A collection of descriptive data about the containing object from a specific origin.",
      useName = "characterization",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "characterizations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Characterization> _characterizations;

  /**
   * Describes an existing mitigating factor that may affect the overall determination of the risk, with an optional link to an implementation statement in the SSP.
   */
  @BoundAssembly(
      formalName = "Mitigating Factor",
      description = "Describes an existing mitigating factor that may affect the overall determination of the risk, with an optional link to an implementation statement in the SSP.",
      useName = "mitigating-factor",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "mitigating-factors", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<MitigatingFactor> _mitigatingFactors;

  /**
   * The date/time by which the risk must be resolved.
   */
  @BoundField(
      formalName = "Risk Resolution Deadline",
      description = "The date/time by which the risk must be resolved.",
      useName = "deadline",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _deadline;

  /**
   * Describes either recommended or an actual plan for addressing the risk.
   */
  @BoundAssembly(
      formalName = "Risk Response",
      description = "Describes either recommended or an actual plan for addressing the risk.",
      useName = "response",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "remediations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Response> _remediations;

  /**
   * A log of all risk-related tasks taken.
   */
  @BoundAssembly(
      formalName = "Risk Log",
      description = "A log of all risk-related tasks taken.",
      useName = "risk-log"
  )
  private RiskLog _riskLog;

  /**
   * Relates the identified element to a set of referenced observations that were used to support its determination.
   */
  @BoundAssembly(
      formalName = "Related Observation",
      description = "Relates the identified element to a set of referenced observations that were used to support its determination.",
      useName = "related-observation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "related-observations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<RelatedObservation> _relatedObservations;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk} instance with no metadata.
   */
  public Risk() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Risk(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Risk Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this risk elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Risk Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this risk elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Risk Title}".
   *
   * <p>
   * The title for this risk.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Risk Title}".
   *
   * <p>
   * The title for this risk.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Risk Description}".
   *
   * <p>
   * A human-readable summary of the identified risk, to include a statement of how the risk impacts the system.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Risk Description}".
   *
   * <p>
   * A human-readable summary of the identified risk, to include a statement of how the risk impacts the system.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Risk Statement}".
   *
   * <p>
   * An summary of impact for how the risk affects the system.
   *
   * @return the statement value
   */
  @NonNull
  public MarkupMultiline getStatement() {
    return _statement;
  }

  /**
   * Set the "{@literal Risk Statement}".
   *
   * <p>
   * An summary of impact for how the risk affects the system.
   *
   * @param value
   *           the statement value to set
   */
  public void setStatement(@NonNull MarkupMultiline value) {
    _statement = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Risk Status}".
   *
   * <p>
   * Describes the status of the associated risk.
   *
   * @return the status value
   */
  @NonNull
  public String getStatus() {
    return _status;
  }

  /**
   * Set the "{@literal Risk Status}".
   *
   * <p>
   * Describes the status of the associated risk.
   *
   * @param value
   *           the status value to set
   */
  public void setStatus(@NonNull String value) {
    _status = value;
  }

  /**
   * Get the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @return the origin value
   */
  @NonNull
  public List<Origin> getOrigins() {
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return ObjectUtils.notNull(_origins);
  }

  /**
   * Set the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @param value
   *           the origin value to set
   */
  public void setOrigins(@NonNull List<Origin> value) {
    _origins = value;
  }

  /**
   * Add a new {@link Origin} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return _origins.add(value);
  }

  /**
   * Remove the first matching {@link Origin} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _origins != null && _origins.remove(value);
  }

  /**
   * Get the "{@literal Threat ID}".
   *
   * <p>
   * A pointer, by ID, to an externally-defined threat.
   *
   * @return the threat-id value
   */
  @NonNull
  public List<ThreatId> getThreatIds() {
    if (_threatIds == null) {
      _threatIds = new LinkedList<>();
    }
    return ObjectUtils.notNull(_threatIds);
  }

  /**
   * Set the "{@literal Threat ID}".
   *
   * <p>
   * A pointer, by ID, to an externally-defined threat.
   *
   * @param value
   *           the threat-id value to set
   */
  public void setThreatIds(@NonNull List<ThreatId> value) {
    _threatIds = value;
  }

  /**
   * Add a new {@link ThreatId} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addThreatId(ThreatId item) {
    ThreatId value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_threatIds == null) {
      _threatIds = new LinkedList<>();
    }
    return _threatIds.add(value);
  }

  /**
   * Remove the first matching {@link ThreatId} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeThreatId(ThreatId item) {
    ThreatId value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _threatIds != null && _threatIds.remove(value);
  }

  /**
   * Get the "{@literal Characterization}".
   *
   * <p>
   * A collection of descriptive data about the containing object from a specific origin.
   *
   * @return the characterization value
   */
  @NonNull
  public List<Characterization> getCharacterizations() {
    if (_characterizations == null) {
      _characterizations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_characterizations);
  }

  /**
   * Set the "{@literal Characterization}".
   *
   * <p>
   * A collection of descriptive data about the containing object from a specific origin.
   *
   * @param value
   *           the characterization value to set
   */
  public void setCharacterizations(@NonNull List<Characterization> value) {
    _characterizations = value;
  }

  /**
   * Add a new {@link Characterization} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addCharacterization(Characterization item) {
    Characterization value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_characterizations == null) {
      _characterizations = new LinkedList<>();
    }
    return _characterizations.add(value);
  }

  /**
   * Remove the first matching {@link Characterization} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeCharacterization(Characterization item) {
    Characterization value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _characterizations != null && _characterizations.remove(value);
  }

  /**
   * Get the "{@literal Mitigating Factor}".
   *
   * <p>
   * Describes an existing mitigating factor that may affect the overall determination of the risk, with an optional link to an implementation statement in the SSP.
   *
   * @return the mitigating-factor value
   */
  @NonNull
  public List<MitigatingFactor> getMitigatingFactors() {
    if (_mitigatingFactors == null) {
      _mitigatingFactors = new LinkedList<>();
    }
    return ObjectUtils.notNull(_mitigatingFactors);
  }

  /**
   * Set the "{@literal Mitigating Factor}".
   *
   * <p>
   * Describes an existing mitigating factor that may affect the overall determination of the risk, with an optional link to an implementation statement in the SSP.
   *
   * @param value
   *           the mitigating-factor value to set
   */
  public void setMitigatingFactors(@NonNull List<MitigatingFactor> value) {
    _mitigatingFactors = value;
  }

  /**
   * Add a new {@link MitigatingFactor} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addMitigatingFactor(MitigatingFactor item) {
    MitigatingFactor value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_mitigatingFactors == null) {
      _mitigatingFactors = new LinkedList<>();
    }
    return _mitigatingFactors.add(value);
  }

  /**
   * Remove the first matching {@link MitigatingFactor} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeMitigatingFactor(MitigatingFactor item) {
    MitigatingFactor value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _mitigatingFactors != null && _mitigatingFactors.remove(value);
  }

  /**
   * Get the "{@literal Risk Resolution Deadline}".
   *
   * <p>
   * The date/time by which the risk must be resolved.
   *
   * @return the deadline value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getDeadline() {
    return _deadline;
  }

  /**
   * Set the "{@literal Risk Resolution Deadline}".
   *
   * <p>
   * The date/time by which the risk must be resolved.
   *
   * @param value
   *           the deadline value to set, or {@code null} to clear
   */
  public void setDeadline(@Nullable ZonedDateTime value) {
    _deadline = value;
  }

  /**
   * Get the "{@literal Risk Response}".
   *
   * <p>
   * Describes either recommended or an actual plan for addressing the risk.
   *
   * @return the response value
   */
  @NonNull
  public List<Response> getRemediations() {
    if (_remediations == null) {
      _remediations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_remediations);
  }

  /**
   * Set the "{@literal Risk Response}".
   *
   * <p>
   * Describes either recommended or an actual plan for addressing the risk.
   *
   * @param value
   *           the response value to set
   */
  public void setRemediations(@NonNull List<Response> value) {
    _remediations = value;
  }

  /**
   * Add a new {@link Response} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponse(Response item) {
    Response value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_remediations == null) {
      _remediations = new LinkedList<>();
    }
    return _remediations.add(value);
  }

  /**
   * Remove the first matching {@link Response} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponse(Response item) {
    Response value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _remediations != null && _remediations.remove(value);
  }

  /**
   * Get the "{@literal Risk Log}".
   *
   * <p>
   * A log of all risk-related tasks taken.
   *
   * @return the risk-log value, or {@code null} if not set
   */
  @Nullable
  public RiskLog getRiskLog() {
    return _riskLog;
  }

  /**
   * Set the "{@literal Risk Log}".
   *
   * <p>
   * A log of all risk-related tasks taken.
   *
   * @param value
   *           the risk-log value to set, or {@code null} to clear
   */
  public void setRiskLog(@Nullable RiskLog value) {
    _riskLog = value;
  }

  /**
   * Get the "{@literal Related Observation}".
   *
   * <p>
   * Relates the identified element to a set of referenced observations that were used to support its determination.
   *
   * @return the related-observation value
   */
  @NonNull
  public List<RelatedObservation> getRelatedObservations() {
    if (_relatedObservations == null) {
      _relatedObservations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedObservations);
  }

  /**
   * Set the "{@literal Related Observation}".
   *
   * <p>
   * Relates the identified element to a set of referenced observations that were used to support its determination.
   *
   * @param value
   *           the related-observation value to set
   */
  public void setRelatedObservations(@NonNull List<RelatedObservation> value) {
    _relatedObservations = value;
  }

  /**
   * Add a new {@link RelatedObservation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRelatedObservation(RelatedObservation item) {
    RelatedObservation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedObservations == null) {
      _relatedObservations = new LinkedList<>();
    }
    return _relatedObservations.add(value);
  }

  /**
   * Remove the first matching {@link RelatedObservation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRelatedObservation(RelatedObservation item) {
    RelatedObservation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedObservations != null && _relatedObservations.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Describes an existing mitigating factor that may affect the overall determination of the risk, with an optional link to an implementation statement in the SSP.
   */
  @MetaschemaAssembly(
      formalName = "Mitigating Factor",
      description = "Describes an existing mitigating factor that may affect the overall determination of the risk, with an optional link to an implementation statement in the SSP.",
      name = "mitigating-factor",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class MitigatingFactor implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mitigating factor elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>mitigating factor</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Mitigating Factor Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this mitigating factor elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `mitigating factor` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this implementation statement elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>s. The locally defined <em>UUID</em> of the <code>implementation statement</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Implementation UUID",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this implementation statement elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope)s. The locally defined *UUID* of the `implementation statement` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "implementation-uuid",
        typeAdapter = UuidAdapter.class
    )
    private UUID _implementationUuid;

    /**
     * A human-readable description of this mitigating factor.
     */
    @BoundField(
        formalName = "Mitigating Factor Description",
        description = "A human-readable description of this mitigating factor.",
        useName = "description",
        minOccurs = 1,
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
     */
    @BoundAssembly(
        formalName = "Identifies the Subject",
        description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented) identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.",
        useName = "subject",
        remarks = "Links identifiable elements of the system to this mitigating factor, such as an inventory-item or component.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "subjects", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SubjectReference> _subjects;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.MitigatingFactor} instance with no metadata.
     */
    public MitigatingFactor() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.MitigatingFactor} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public MitigatingFactor(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Mitigating Factor Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mitigating factor elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>mitigating factor</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Mitigating Factor Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mitigating factor elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>mitigating factor</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Implementation UUID}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this implementation statement elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>s. The locally defined <em>UUID</em> of the <code>implementation statement</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the implementation-uuid value, or {@code null} if not set
     */
    @Nullable
    public UUID getImplementationUuid() {
      return _implementationUuid;
    }

    /**
     * Set the "{@literal Implementation UUID}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this implementation statement elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>s. The locally defined <em>UUID</em> of the <code>implementation statement</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the implementation-uuid value to set, or {@code null} to clear
     */
    public void setImplementationUuid(@Nullable UUID value) {
      _implementationUuid = value;
    }

    /**
     * Get the "{@literal Mitigating Factor Description}".
     *
     * <p>
     * A human-readable description of this mitigating factor.
     *
     * @return the description value
     */
    @NonNull
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Mitigating Factor Description}".
     *
     * <p>
     * A human-readable description of this mitigating factor.
     *
     * @param value
     *           the description value to set
     */
    public void setDescription(@NonNull MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Identifies the Subject}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
     *
     * @return the subject value
     */
    @NonNull
    public List<SubjectReference> getSubjects() {
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return ObjectUtils.notNull(_subjects);
    }

    /**
     * Set the "{@literal Identifies the Subject}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
     *
     * @param value
     *           the subject value to set
     */
    public void setSubjects(@NonNull List<SubjectReference> value) {
      _subjects = value;
    }

    /**
     * Add a new {@link SubjectReference} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addSubject(SubjectReference item) {
      SubjectReference value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return _subjects.add(value);
    }

    /**
     * Remove the first matching {@link SubjectReference} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeSubject(SubjectReference item) {
      SubjectReference value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _subjects != null && _subjects.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * A log of all risk-related tasks taken.
   */
  @MetaschemaAssembly(
      formalName = "Risk Log",
      description = "A log of all risk-related tasks taken.",
      name = "risk-log",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class RiskLog implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * Identifies an individual risk response that occurred as part of managing an identified risk.
     */
    @BoundAssembly(
        formalName = "Risk Log Entry",
        description = "Identifies an individual risk response that occurred as part of managing an identified risk.",
        useName = "entry",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "entries", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Entry> _entries;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.RiskLog} instance with no metadata.
     */
    public RiskLog() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.RiskLog} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public RiskLog(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Risk Log Entry}".
     *
     * <p>
     * Identifies an individual risk response that occurred as part of managing an identified risk.
     *
     * @return the entry value
     */
    @NonNull
    public List<Entry> getEntries() {
      if (_entries == null) {
        _entries = new LinkedList<>();
      }
      return ObjectUtils.notNull(_entries);
    }

    /**
     * Set the "{@literal Risk Log Entry}".
     *
     * <p>
     * Identifies an individual risk response that occurred as part of managing an identified risk.
     *
     * @param value
     *           the entry value to set
     */
    public void setEntries(@NonNull List<Entry> value) {
      _entries = value;
    }

    /**
     * Add a new {@link Entry} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addEntry(Entry item) {
      Entry value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_entries == null) {
        _entries = new LinkedList<>();
      }
      return _entries.add(value);
    }

    /**
     * Remove the first matching {@link Entry} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeEntry(Entry item) {
      Entry value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _entries != null && _entries.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * Identifies an individual risk response that occurred as part of managing an identified risk.
     */
    @MetaschemaAssembly(
        formalName = "Risk Log Entry",
        description = "Identifies an individual risk response that occurred as part of managing an identified risk.",
        name = "entry",
        moduleClass = OscalAssessmentCommonModule.class,
        valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-risk-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "type", description = "The type of remediation tracking entry. Can be multi-valued.")), @AllowedValues(id = "oscal-risk-prop-type-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='type']/@value", allowOthers = true, values = {@AllowedValue(value = "vendor-check-in", description = "Contacted vendor to determine the status of a pending fix to a known vulnerability."), @AllowedValue(value = "status-update", description = "Information related to the current state of response to this risk."), @AllowedValue(value = "milestone-complete", description = "A significant step in the response plan has been achieved."), @AllowedValue(value = "mitigation", description = "An activity was completed that reduces the likelihood or impact of this risk."), @AllowedValue(value = "remediated", description = "An activity was completed that eliminates the likelihood or impact of this risk."), @AllowedValue(value = "closed", description = "The risk is no longer applicable to the system."), @AllowedValue(value = "dr-submission", description = "A deviation request was made to the authorizing official."), @AllowedValue(value = "dr-updated", description = "A previously submitted deviation request has been modified."), @AllowedValue(value = "dr-approved", description = "The authorizing official approved the deviation."), @AllowedValue(value = "dr-rejected", description = "The authorizing official rejected the deviation.")})})
    )
    public static class Entry implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this risk log entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk log entry</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       */
      @BoundFlag(
          formalName = "Risk Log Entry Universally Unique Identifier",
          description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this risk log entry elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `risk log entry` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
          name = "uuid",
          required = true,
          typeAdapter = UuidAdapter.class
      )
      private UUID _uuid;

      /**
       * The title for this risk log entry.
       */
      @BoundField(
          formalName = "Title",
          description = "The title for this risk log entry.",
          useName = "title",
          typeAdapter = MarkupLineAdapter.class
      )
      private MarkupLine _title;

      /**
       * A human-readable description of what was done regarding the risk.
       */
      @BoundField(
          formalName = "Risk Task Description",
          description = "A human-readable description of what was done regarding the risk.",
          useName = "description",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _description;

      /**
       * Identifies the start date and time of the event.
       */
      @BoundField(
          formalName = "Start",
          description = "Identifies the start date and time of the event.",
          useName = "start",
          minOccurs = 1,
          typeAdapter = DateTimeWithTZAdapter.class
      )
      private ZonedDateTime _start;

      /**
       * Identifies the end date and time of the event. If the event is a point in time, the start and end will be the same date and time.
       */
      @BoundField(
          formalName = "End",
          description = "Identifies the end date and time of the event. If the event is a point in time, the start and end will be the same date and time.",
          useName = "end",
          typeAdapter = DateTimeWithTZAdapter.class
      )
      private ZonedDateTime _end;

      /**
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       */
      @BoundAssembly(
          formalName = "Property",
          description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
          useName = "prop",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Property> _props;

      /**
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       */
      @BoundAssembly(
          formalName = "Link",
          description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
          useName = "link",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Link> _links;

      /**
       * Used to indicate who created a log entry in what role.
       */
      @BoundAssembly(
          formalName = "Logged By",
          description = "Used to indicate who created a log entry in what role.",
          useName = "logged-by",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "logged-by", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<LoggedBy> _loggedBy;

      /**
       * Describes the status of the associated risk.
       */
      @BoundField(
          formalName = "Risk Status",
          description = "Describes the status of the associated risk.",
          useName = "status-change",
          remarks = "Identifies a change in risk status made resulting from the task described by this risk log entry. This allows the risk's status history to be captured as a sequence of risk log entries.",
          typeAdapter = TokenAdapter.class,
          valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-risk-status-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "open", description = "The risk has been identified."), @AllowedValue(value = "investigating", description = "The identified risk is being investigated. (Open risk)"), @AllowedValue(value = "remediating", description = "Remediation activities are underway, but are not yet complete. (Open risk)"), @AllowedValue(value = "deviation-requested", description = "A risk deviation, such as false positive, risk reduction, or operational requirement has been submitted for approval. (Open risk)"), @AllowedValue(value = "deviation-approved", description = "A risk deviation, such as false positive, risk reduction, or operational requirement has been approved. (Open risk)"), @AllowedValue(value = "closed", description = "The risk has been resolved.")}))
      )
      private String _statusChange;

      /**
       * Identifies an individual risk response that this log entry is for.
       */
      @BoundAssembly(
          formalName = "Risk Response Reference",
          description = "Identifies an individual risk response that this log entry is for.",
          useName = "related-response",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "related-responses", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<RelatedResponse> _relatedResponses;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.RiskLog.Entry} instance with no metadata.
       */
      public Entry() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.RiskLog.Entry} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Entry(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Risk Log Entry Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this risk log entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk log entry</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @return the uuid value
       */
      @NonNull
      public UUID getUuid() {
        return _uuid;
      }

      /**
       * Set the "{@literal Risk Log Entry Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this risk log entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk log entry</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @param value
       *           the uuid value to set
       */
      public void setUuid(@NonNull UUID value) {
        _uuid = value;
      }

      /**
       * Get the "{@literal Title}".
       *
       * <p>
       * The title for this risk log entry.
       *
       * @return the title value, or {@code null} if not set
       */
      @Nullable
      public MarkupLine getTitle() {
        return _title;
      }

      /**
       * Set the "{@literal Title}".
       *
       * <p>
       * The title for this risk log entry.
       *
       * @param value
       *           the title value to set, or {@code null} to clear
       */
      public void setTitle(@Nullable MarkupLine value) {
        _title = value;
      }

      /**
       * Get the "{@literal Risk Task Description}".
       *
       * <p>
       * A human-readable description of what was done regarding the risk.
       *
       * @return the description value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getDescription() {
        return _description;
      }

      /**
       * Set the "{@literal Risk Task Description}".
       *
       * <p>
       * A human-readable description of what was done regarding the risk.
       *
       * @param value
       *           the description value to set, or {@code null} to clear
       */
      public void setDescription(@Nullable MarkupMultiline value) {
        _description = value;
      }

      /**
       * Get the "{@literal Start}".
       *
       * <p>
       * Identifies the start date and time of the event.
       *
       * @return the start value
       */
      @NonNull
      public ZonedDateTime getStart() {
        return _start;
      }

      /**
       * Set the "{@literal Start}".
       *
       * <p>
       * Identifies the start date and time of the event.
       *
       * @param value
       *           the start value to set
       */
      public void setStart(@NonNull ZonedDateTime value) {
        _start = value;
      }

      /**
       * Get the "{@literal End}".
       *
       * <p>
       * Identifies the end date and time of the event. If the event is a point in time, the start and end will be the same date and time.
       *
       * @return the end value, or {@code null} if not set
       */
      @Nullable
      public ZonedDateTime getEnd() {
        return _end;
      }

      /**
       * Set the "{@literal End}".
       *
       * <p>
       * Identifies the end date and time of the event. If the event is a point in time, the start and end will be the same date and time.
       *
       * @param value
       *           the end value to set, or {@code null} to clear
       */
      public void setEnd(@Nullable ZonedDateTime value) {
        _end = value;
      }

      /**
       * Get the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @return the prop value
       */
      @NonNull
      public List<Property> getProps() {
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return ObjectUtils.notNull(_props);
      }

      /**
       * Set the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @param value
       *           the prop value to set
       */
      public void setProps(@NonNull List<Property> value) {
        _props = value;
      }

      /**
       * Add a new {@link Property} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return _props.add(value);
      }

      /**
       * Remove the first matching {@link Property} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _props != null && _props.remove(value);
      }

      /**
       * Get the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @return the link value
       */
      @NonNull
      public List<Link> getLinks() {
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return ObjectUtils.notNull(_links);
      }

      /**
       * Set the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @param value
       *           the link value to set
       */
      public void setLinks(@NonNull List<Link> value) {
        _links = value;
      }

      /**
       * Add a new {@link Link} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return _links.add(value);
      }

      /**
       * Remove the first matching {@link Link} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _links != null && _links.remove(value);
      }

      /**
       * Get the "{@literal Logged By}".
       *
       * <p>
       * Used to indicate who created a log entry in what role.
       *
       * @return the logged-by value
       */
      @NonNull
      public List<LoggedBy> getLoggedBy() {
        if (_loggedBy == null) {
          _loggedBy = new LinkedList<>();
        }
        return ObjectUtils.notNull(_loggedBy);
      }

      /**
       * Set the "{@literal Logged By}".
       *
       * <p>
       * Used to indicate who created a log entry in what role.
       *
       * @param value
       *           the logged-by value to set
       */
      public void setLoggedBy(@NonNull List<LoggedBy> value) {
        _loggedBy = value;
      }

      /**
       * Add a new {@link LoggedBy} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLoggedBy(LoggedBy item) {
        LoggedBy value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_loggedBy == null) {
          _loggedBy = new LinkedList<>();
        }
        return _loggedBy.add(value);
      }

      /**
       * Remove the first matching {@link LoggedBy} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLoggedBy(LoggedBy item) {
        LoggedBy value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _loggedBy != null && _loggedBy.remove(value);
      }

      /**
       * Get the "{@literal Risk Status}".
       *
       * <p>
       * Describes the status of the associated risk.
       *
       * @return the status-change value, or {@code null} if not set
       */
      @Nullable
      public String getStatusChange() {
        return _statusChange;
      }

      /**
       * Set the "{@literal Risk Status}".
       *
       * <p>
       * Describes the status of the associated risk.
       *
       * @param value
       *           the status-change value to set, or {@code null} to clear
       */
      public void setStatusChange(@Nullable String value) {
        _statusChange = value;
      }

      /**
       * Get the "{@literal Risk Response Reference}".
       *
       * <p>
       * Identifies an individual risk response that this log entry is for.
       *
       * @return the related-response value
       */
      @NonNull
      public List<RelatedResponse> getRelatedResponses() {
        if (_relatedResponses == null) {
          _relatedResponses = new LinkedList<>();
        }
        return ObjectUtils.notNull(_relatedResponses);
      }

      /**
       * Set the "{@literal Risk Response Reference}".
       *
       * <p>
       * Identifies an individual risk response that this log entry is for.
       *
       * @param value
       *           the related-response value to set
       */
      public void setRelatedResponses(@NonNull List<RelatedResponse> value) {
        _relatedResponses = value;
      }

      /**
       * Add a new {@link RelatedResponse} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addRelatedResponse(RelatedResponse item) {
        RelatedResponse value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_relatedResponses == null) {
          _relatedResponses = new LinkedList<>();
        }
        return _relatedResponses.add(value);
      }

      /**
       * Remove the first matching {@link RelatedResponse} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeRelatedResponse(RelatedResponse item) {
        RelatedResponse value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _relatedResponses != null && _relatedResponses.remove(value);
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }

      /**
       * Identifies an individual risk response that this log entry is for.
       */
      @MetaschemaAssembly(
          formalName = "Risk Response Reference",
          description = "Identifies an individual risk response that this log entry is for.",
          name = "related-response",
          moduleClass = OscalAssessmentCommonModule.class
      )
      public static class RelatedResponse implements IBoundObject {
        private final IMetaschemaData __metaschemaData;

        /**
         * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique risk response.
         */
        @BoundFlag(
            formalName = "Response Universally Unique Identifier Reference",
            description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a unique risk response.",
            name = "response-uuid",
            required = true,
            typeAdapter = UuidAdapter.class
        )
        private UUID _responseUuid;

        /**
         * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
         */
        @BoundAssembly(
            formalName = "Property",
            description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
            useName = "prop",
            maxOccurs = -1,
            groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
        )
        private List<Property> _props;

        /**
         * A reference to a local or remote resource, that has a specific relation to the containing object.
         */
        @BoundAssembly(
            formalName = "Link",
            description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
            useName = "link",
            maxOccurs = -1,
            groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
        )
        private List<Link> _links;

        /**
         * Identifies an individual task for which the containing object is a consequence of.
         */
        @BoundAssembly(
            formalName = "Task Reference",
            description = "Identifies an individual task for which the containing object is a consequence of.",
            useName = "related-task",
            remarks = "This is used to identify the task(s) that this log entry was generated for.",
            maxOccurs = -1,
            groupAs = @GroupAs(name = "related-tasks", inJson = JsonGroupAsBehavior.LIST)
        )
        private List<RelatedTask> _relatedTasks;

        /**
         * Additional commentary about the containing object.
         */
        @BoundField(
            formalName = "Remarks",
            description = "Additional commentary about the containing object.",
            useName = "remarks",
            typeAdapter = MarkupMultilineAdapter.class
        )
        private MarkupMultiline _remarks;

        /**
         * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.RiskLog.Entry.RelatedResponse} instance with no metadata.
         */
        public RelatedResponse() {
          this(null);
        }

        /**
         * Constructs a new {@code dev.metaschema.oscal.lib.model.Risk.RiskLog.Entry.RelatedResponse} instance with the specified metadata.
         *
         * @param data
         *           the metaschema data, or {@code null} if none
         */
        public RelatedResponse(IMetaschemaData data) {
          this.__metaschemaData = data;
        }

        @Override
        public IMetaschemaData getMetaschemaData() {
          return __metaschemaData;
        }

        /**
         * Get the "{@literal Response Universally Unique Identifier Reference}".
         *
         * <p>
         * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique risk response.
         *
         * @return the response-uuid value
         */
        @NonNull
        public UUID getResponseUuid() {
          return _responseUuid;
        }

        /**
         * Set the "{@literal Response Universally Unique Identifier Reference}".
         *
         * <p>
         * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique risk response.
         *
         * @param value
         *           the response-uuid value to set
         */
        public void setResponseUuid(@NonNull UUID value) {
          _responseUuid = value;
        }

        /**
         * Get the "{@literal Property}".
         *
         * <p>
         * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
         *
         * @return the prop value
         */
        @NonNull
        public List<Property> getProps() {
          if (_props == null) {
            _props = new LinkedList<>();
          }
          return ObjectUtils.notNull(_props);
        }

        /**
         * Set the "{@literal Property}".
         *
         * <p>
         * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
         *
         * @param value
         *           the prop value to set
         */
        public void setProps(@NonNull List<Property> value) {
          _props = value;
        }

        /**
         * Add a new {@link Property} item to the underlying collection.
         * @param item the item to add
         * @return {@code true}
         */
        public boolean addProp(Property item) {
          Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
          if (_props == null) {
            _props = new LinkedList<>();
          }
          return _props.add(value);
        }

        /**
         * Remove the first matching {@link Property} item from the underlying collection.
         * @param item the item to remove
         * @return {@code true} if the item was removed or {@code false} otherwise
         */
        public boolean removeProp(Property item) {
          Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
          return _props != null && _props.remove(value);
        }

        /**
         * Get the "{@literal Link}".
         *
         * <p>
         * A reference to a local or remote resource, that has a specific relation to the containing object.
         *
         * @return the link value
         */
        @NonNull
        public List<Link> getLinks() {
          if (_links == null) {
            _links = new LinkedList<>();
          }
          return ObjectUtils.notNull(_links);
        }

        /**
         * Set the "{@literal Link}".
         *
         * <p>
         * A reference to a local or remote resource, that has a specific relation to the containing object.
         *
         * @param value
         *           the link value to set
         */
        public void setLinks(@NonNull List<Link> value) {
          _links = value;
        }

        /**
         * Add a new {@link Link} item to the underlying collection.
         * @param item the item to add
         * @return {@code true}
         */
        public boolean addLink(Link item) {
          Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
          if (_links == null) {
            _links = new LinkedList<>();
          }
          return _links.add(value);
        }

        /**
         * Remove the first matching {@link Link} item from the underlying collection.
         * @param item the item to remove
         * @return {@code true} if the item was removed or {@code false} otherwise
         */
        public boolean removeLink(Link item) {
          Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
          return _links != null && _links.remove(value);
        }

        /**
         * Get the "{@literal Task Reference}".
         *
         * <p>
         * Identifies an individual task for which the containing object is a consequence of.
         *
         * @return the related-task value
         */
        @NonNull
        public List<RelatedTask> getRelatedTasks() {
          if (_relatedTasks == null) {
            _relatedTasks = new LinkedList<>();
          }
          return ObjectUtils.notNull(_relatedTasks);
        }

        /**
         * Set the "{@literal Task Reference}".
         *
         * <p>
         * Identifies an individual task for which the containing object is a consequence of.
         *
         * @param value
         *           the related-task value to set
         */
        public void setRelatedTasks(@NonNull List<RelatedTask> value) {
          _relatedTasks = value;
        }

        /**
         * Add a new {@link RelatedTask} item to the underlying collection.
         * @param item the item to add
         * @return {@code true}
         */
        public boolean addRelatedTask(RelatedTask item) {
          RelatedTask value = ObjectUtils.requireNonNull(item,"item cannot be null");
          if (_relatedTasks == null) {
            _relatedTasks = new LinkedList<>();
          }
          return _relatedTasks.add(value);
        }

        /**
         * Remove the first matching {@link RelatedTask} item from the underlying collection.
         * @param item the item to remove
         * @return {@code true} if the item was removed or {@code false} otherwise
         */
        public boolean removeRelatedTask(RelatedTask item) {
          RelatedTask value = ObjectUtils.requireNonNull(item,"item cannot be null");
          return _relatedTasks != null && _relatedTasks.remove(value);
        }

        /**
         * Get the "{@literal Remarks}".
         *
         * <p>
         * Additional commentary about the containing object.
         *
         * @return the remarks value, or {@code null} if not set
         */
        @Nullable
        public MarkupMultiline getRemarks() {
          return _remarks;
        }

        /**
         * Set the "{@literal Remarks}".
         *
         * <p>
         * Additional commentary about the containing object.
         *
         * @param value
         *           the remarks value to set, or {@code null} to clear
         */
        public void setRemarks(@Nullable MarkupMultiline value) {
          _remarks = value;
        }

        @Override
        public String toString() {
          return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
        }
      }
    }
  }
}
