// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.Base64Adapter;
import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.HasCardinality;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import dev.metaschema.oscal.lib.model.metadata.AbstractBackMatter;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A collection of resources that may be referenced from within the OSCAL document instance.
 */
@MetaschemaAssembly(
    formalName = "Back matter",
    description = "A collection of resources that may be referenced from within the OSCAL document instance.",
    name = "back-matter",
    moduleClass = OscalMetadataModule.class,
    remarks = "Provides a collection of identified `resource` objects that can be referenced by a `link` with a `rel` value of \"reference\" and an `href` value that is a fragment \"#\" followed by a reference to a reference's `uuid`. Other specialized link \"rel\" values also use this pattern when indicated in that context of use.",
    modelConstraints = @AssemblyConstraints(index = @Index(id = "oscal-back-matter-resource-uuid-index", level = IConstraint.Level.ERROR, target = "resource", name = "index-back-matter-resource", keyFields = @KeyField(target = "@uuid")))
)
public class BackMatter extends AbstractBackMatter implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A resource associated with content in the containing document instance. A resource may be directly included in the document using base64 encoding or may point to one or more equivalent internet resources.
   */
  @BoundAssembly(
      formalName = "Resource",
      description = "A resource associated with content in the containing document instance. A resource may be directly included in the document using base64 encoding or may point to one or more equivalent internet resources.",
      useName = "resource",
      remarks = "A resource can be used in two ways. 1) it may point to an specific retrievable network resource using a `rlink`, or 2) it may be included as an attachment using a `base64`. A resource may contain multiple `rlink` and `base64` entries that represent alternative download locations (rlink) and attachments (base64) for the same resource.\n"
              + "\n"
              + "Both rlink and base64 allow for a `media-type` to be specified, which is used to distinguish between different representations of the same resource (e.g., Microsoft Word, PDF). When multiple `rlink` and `base64` items are included for a given resource, all items must contain equivalent information. This allows the document consumer to choose a preferred item to process based on a the selected item's `media-type`. This is extremely important when the items represent OSCAL content that is represented in alternate formats (i.e., XML, JSON, YAML), allowing the same OSCAL data to be processed from any of the available formats indicated by the items.\n"
              + "\n"
              + "When a resource includes a citation, then the `title` and `citation` properties must both be included.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "resources", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Resource> _resources;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter} instance with no metadata.
   */
  public BackMatter() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public BackMatter(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Resource}".
   *
   * <p>
   * A resource associated with content in the containing document instance. A resource may be directly included in the document using base64 encoding or may point to one or more equivalent internet resources.
   *
   * @return the resource value
   */
  @NonNull
  public List<Resource> getResources() {
    if (_resources == null) {
      _resources = new LinkedList<>();
    }
    return ObjectUtils.notNull(_resources);
  }

  /**
   * Set the "{@literal Resource}".
   *
   * <p>
   * A resource associated with content in the containing document instance. A resource may be directly included in the document using base64 encoding or may point to one or more equivalent internet resources.
   *
   * @param value
   *           the resource value to set
   */
  public void setResources(@NonNull List<Resource> value) {
    _resources = value;
  }

  /**
   * Add a new {@link Resource} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResource(Resource item) {
    Resource value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_resources == null) {
      _resources = new LinkedList<>();
    }
    return _resources.add(value);
  }

  /**
   * Remove the first matching {@link Resource} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResource(Resource item) {
    Resource value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _resources != null && _resources.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * A resource associated with content in the containing document instance. A resource may be directly included in the document using base64 encoding or may point to one or more equivalent internet resources.
   */
  @MetaschemaAssembly(
      formalName = "Resource",
      description = "A resource associated with content in the containing document instance. A resource may be directly included in the document using base64 encoding or may point to one or more equivalent internet resources.",
      name = "resource",
      moduleClass = OscalMetadataModule.class,
      remarks = "A resource can be used in two ways. 1) it may point to an specific retrievable network resource using a `rlink`, or 2) it may be included as an attachment using a `base64`. A resource may contain multiple `rlink` and `base64` entries that represent alternative download locations (rlink) and attachments (base64) for the same resource.\n"
              + "\n"
              + "Both rlink and base64 allow for a `media-type` to be specified, which is used to distinguish between different representations of the same resource (e.g., Microsoft Word, PDF). When multiple `rlink` and `base64` items are included for a given resource, all items must contain equivalent information. This allows the document consumer to choose a preferred item to process based on a the selected item's `media-type`. This is extremely important when the items represent OSCAL content that is represented in alternate formats (i.e., XML, JSON, YAML), allowing the same OSCAL data to be processed from any of the available formats indicated by the items.\n"
              + "\n"
              + "When a resource includes a citation, then the `title` and `citation` properties must both be included.",
      valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-back-matter-resource-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "type", description = "Identifies the type of resource represented. The most specific appropriate type value SHOULD be used."), @AllowedValue(value = "version", description = "For resources representing a published document, this represents the version number of that document."), @AllowedValue(value = "published", description = "For resources representing a published document, this represents the publication date of that document.")}), @AllowedValues(id = "oscal-back-matter-resource-prop-type-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='type']/@value", values = {@AllowedValue(value = "logo", description = "Indicates the resource is an organization's logo."), @AllowedValue(value = "image", description = "Indicates the resource represents an image."), @AllowedValue(value = "screen-shot", description = "Indicates the resource represents an image of screen content."), @AllowedValue(value = "law", description = "Indicates the resource represents an applicable law."), @AllowedValue(value = "regulation", description = "Indicates the resource represents an applicable regulation."), @AllowedValue(value = "standard", description = "Indicates the resource represents an applicable standard."), @AllowedValue(value = "external-guidance", description = "Indicates the resource represents applicable guidance."), @AllowedValue(value = "acronyms", description = "Indicates the resource provides a list of relevant acronyms."), @AllowedValue(value = "citation", description = "Indicates the resource cites relevant information."), @AllowedValue(value = "policy", description = "Indicates the resource is a policy."), @AllowedValue(value = "procedure", description = "Indicates the resource is a procedure."), @AllowedValue(value = "system-guide", description = "Indicates the resource is guidance document related to the subject system of an SSP."), @AllowedValue(value = "users-guide", description = "Indicates the resource is guidance document a user's guide or administrator's guide."), @AllowedValue(value = "administrators-guide", description = "Indicates the resource is guidance document a administrator's guide."), @AllowedValue(value = "rules-of-behavior", description = "Indicates the resource represents rules of behavior content."), @AllowedValue(value = "plan", description = "Indicates the resource represents a plan."), @AllowedValue(value = "artifact", description = "Indicates the resource represents an artifact, such as may be reviewed by an assessor."), @AllowedValue(value = "evidence", description = "Indicates the resource represents evidence, such as to support an assessment finding."), @AllowedValue(value = "tool-output", description = "Indicates the resource represents output from a tool."), @AllowedValue(value = "raw-data", description = "Indicates the resource represents machine data, which may require a tool or analysis for interpretation or presentation."), @AllowedValue(value = "interview-notes", description = "Indicates the resource represents notes from an interview, such as may be collected during an assessment."), @AllowedValue(value = "questionnaire", description = "Indicates the resource is a set of questions, possibly with responses."), @AllowedValue(value = "report", description = "Indicates the resource is a report."), @AllowedValue(value = "agreement", description = "Indicates the resource is a formal agreement between two or more parties.")})}, matches = @Matches(id = "oscal-back-matter-resource-prop-published-datatype", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='published']/@value", typeAdapter = DateTimeWithTZAdapter.class), expect = @Expect(id = "oscal-back-matter-resource-citation-title", description = "A `title` is required when a `citation` is provided.", level = IConstraint.Level.ERROR, target = ".[citation]", test = "title")),
      modelConstraints = @AssemblyConstraints(unique = {@IsUnique(id = "oscal-unique-resource-rlink-href", description = "Ensure that each rlink item references a unique resource.", level = IConstraint.Level.ERROR, target = "rlink", keyFields = {@KeyField(target = "@href"), @KeyField(target = "@media-type")}), @IsUnique(id = "oscal-unique-resource-base64-filename", description = "Ensure that all base64 resources have a unique `filename`.", level = IConstraint.Level.ERROR, target = "base64", keyFields = @KeyField(target = "@filename"))}, cardinality = @HasCardinality(id = "oscal-back-matter-resource-base64-rlink-cardinality", description = "A resource should provide at least an `rlink` or `base64` object.", level = IConstraint.Level.WARNING, target = "rlink|base64", minOccurs = 1))
  )
  public static class Resource implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A unique identifier for a resource.
     */
    @BoundFlag(
        formalName = "Resource Universally Unique Identifier",
        description = "A unique identifier for a resource.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * An optional name given to the resource, which may be used by a tool for display and navigation.
     */
    @BoundField(
        formalName = "Resource Title",
        description = "An optional name given to the resource, which may be used by a tool for display and navigation.",
        useName = "title",
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * An optional short summary of the resource used to indicate the purpose of the resource.
     */
    @BoundField(
        formalName = "Resource Description",
        description = "An optional short summary of the resource used to indicate the purpose of the resource.",
        useName = "description",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A document identifier qualified by an identifier <code>scheme</code>.
     */
    @BoundField(
        formalName = "Document Identifier",
        description = "A document identifier qualified by an identifier `scheme`.",
        useName = "document-id",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "document-ids", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<DocumentId> _documentIds;

    /**
     * An optional citation consisting of end note text using structured markup.
     */
    @BoundAssembly(
        formalName = "Citation",
        description = "An optional citation consisting of end note text using structured markup.",
        useName = "citation"
    )
    private Citation _citation;

    /**
     * A URL-based pointer to an external resource with an optional hash for verification and change detection.
     */
    @BoundAssembly(
        formalName = "Resource link",
        description = "A URL-based pointer to an external resource with an optional hash for verification and change detection.",
        useName = "rlink",
        remarks = "Multiple `rlink` objects can be included for a resource. In such a case, all provided `rlink` items are intended to be equivalent in content, but may differ in structure or format.\n"
                + "\n"
                + "A `media-type` is used to identify the format of a given rlink, and can be used to differentiate items in a collection of rlinks. The `media-type` provides a hint to the OSCAL document consumer about the structure of the resource referenced by the `rlink`.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "rlinks", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Rlink> _rlinks;

    /**
     * A resource encoded using the Base64 alphabet defined by <a href="https://www.rfc-editor.org/rfc/rfc2045.html">RFC 2045</a>.
     */
    @BoundField(
        formalName = "Base64",
        description = "A resource encoded using the Base64 alphabet defined by [RFC 2045](https://www.rfc-editor.org/rfc/rfc2045.html).",
        useName = "base64"
    )
    private Base64 _base64;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource} instance with no metadata.
     */
    public Resource() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Resource(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Resource Universally Unique Identifier}".
     *
     * <p>
     * A unique identifier for a resource.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Resource Universally Unique Identifier}".
     *
     * <p>
     * A unique identifier for a resource.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Resource Title}".
     *
     * <p>
     * An optional name given to the resource, which may be used by a tool for display and navigation.
     *
     * @return the title value, or {@code null} if not set
     */
    @Nullable
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal Resource Title}".
     *
     * <p>
     * An optional name given to the resource, which may be used by a tool for display and navigation.
     *
     * @param value
     *           the title value to set, or {@code null} to clear
     */
    public void setTitle(@Nullable MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Resource Description}".
     *
     * <p>
     * An optional short summary of the resource used to indicate the purpose of the resource.
     *
     * @return the description value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Resource Description}".
     *
     * <p>
     * An optional short summary of the resource used to indicate the purpose of the resource.
     *
     * @param value
     *           the description value to set, or {@code null} to clear
     */
    public void setDescription(@Nullable MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Document Identifier}".
     *
     * <p>
     * A document identifier qualified by an identifier <code>scheme</code>.
     *
     * @return the document-id value
     */
    @NonNull
    public List<DocumentId> getDocumentIds() {
      if (_documentIds == null) {
        _documentIds = new LinkedList<>();
      }
      return ObjectUtils.notNull(_documentIds);
    }

    /**
     * Set the "{@literal Document Identifier}".
     *
     * <p>
     * A document identifier qualified by an identifier <code>scheme</code>.
     *
     * @param value
     *           the document-id value to set
     */
    public void setDocumentIds(@NonNull List<DocumentId> value) {
      _documentIds = value;
    }

    /**
     * Add a new {@link DocumentId} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addDocumentId(DocumentId item) {
      DocumentId value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_documentIds == null) {
        _documentIds = new LinkedList<>();
      }
      return _documentIds.add(value);
    }

    /**
     * Remove the first matching {@link DocumentId} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeDocumentId(DocumentId item) {
      DocumentId value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _documentIds != null && _documentIds.remove(value);
    }

    /**
     * Get the "{@literal Citation}".
     *
     * <p>
     * An optional citation consisting of end note text using structured markup.
     *
     * @return the citation value, or {@code null} if not set
     */
    @Nullable
    public Citation getCitation() {
      return _citation;
    }

    /**
     * Set the "{@literal Citation}".
     *
     * <p>
     * An optional citation consisting of end note text using structured markup.
     *
     * @param value
     *           the citation value to set, or {@code null} to clear
     */
    public void setCitation(@Nullable Citation value) {
      _citation = value;
    }

    /**
     * Get the "{@literal Resource link}".
     *
     * <p>
     * A URL-based pointer to an external resource with an optional hash for verification and change detection.
     *
     * @return the rlink value
     */
    @NonNull
    public List<Rlink> getRlinks() {
      if (_rlinks == null) {
        _rlinks = new LinkedList<>();
      }
      return ObjectUtils.notNull(_rlinks);
    }

    /**
     * Set the "{@literal Resource link}".
     *
     * <p>
     * A URL-based pointer to an external resource with an optional hash for verification and change detection.
     *
     * @param value
     *           the rlink value to set
     */
    public void setRlinks(@NonNull List<Rlink> value) {
      _rlinks = value;
    }

    /**
     * Add a new {@link Rlink} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addRlink(Rlink item) {
      Rlink value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_rlinks == null) {
        _rlinks = new LinkedList<>();
      }
      return _rlinks.add(value);
    }

    /**
     * Remove the first matching {@link Rlink} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeRlink(Rlink item) {
      Rlink value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _rlinks != null && _rlinks.remove(value);
    }

    /**
     * Get the "{@literal Base64}".
     *
     * <p>
     * A resource encoded using the Base64 alphabet defined by <a href="https://www.rfc-editor.org/rfc/rfc2045.html">RFC 2045</a>.
     *
     * @return the base64 value, or {@code null} if not set
     */
    @Nullable
    public Base64 getBase64() {
      return _base64;
    }

    /**
     * Set the "{@literal Base64}".
     *
     * <p>
     * A resource encoded using the Base64 alphabet defined by <a href="https://www.rfc-editor.org/rfc/rfc2045.html">RFC 2045</a>.
     *
     * @param value
     *           the base64 value to set, or {@code null} to clear
     */
    public void setBase64(@Nullable Base64 value) {
      _base64 = value;
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * An optional citation consisting of end note text using structured markup.
     */
    @MetaschemaAssembly(
        formalName = "Citation",
        description = "An optional citation consisting of end note text using structured markup.",
        name = "citation",
        moduleClass = OscalMetadataModule.class
    )
    public static class Citation implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * A line of citation text.
       */
      @BoundField(
          formalName = "Citation Text",
          description = "A line of citation text.",
          useName = "text",
          minOccurs = 1,
          typeAdapter = MarkupLineAdapter.class
      )
      private MarkupLine _text;

      /**
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       */
      @BoundAssembly(
          formalName = "Property",
          description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
          useName = "prop",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Property> _props;

      /**
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       */
      @BoundAssembly(
          formalName = "Link",
          description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
          useName = "link",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Link> _links;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource.Citation} instance with no metadata.
       */
      public Citation() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource.Citation} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Citation(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Citation Text}".
       *
       * <p>
       * A line of citation text.
       *
       * @return the text value
       */
      @NonNull
      public MarkupLine getText() {
        return _text;
      }

      /**
       * Set the "{@literal Citation Text}".
       *
       * <p>
       * A line of citation text.
       *
       * @param value
       *           the text value to set
       */
      public void setText(@NonNull MarkupLine value) {
        _text = value;
      }

      /**
       * Get the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @return the prop value
       */
      @NonNull
      public List<Property> getProps() {
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return ObjectUtils.notNull(_props);
      }

      /**
       * Set the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @param value
       *           the prop value to set
       */
      public void setProps(@NonNull List<Property> value) {
        _props = value;
      }

      /**
       * Add a new {@link Property} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return _props.add(value);
      }

      /**
       * Remove the first matching {@link Property} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _props != null && _props.remove(value);
      }

      /**
       * Get the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @return the link value
       */
      @NonNull
      public List<Link> getLinks() {
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return ObjectUtils.notNull(_links);
      }

      /**
       * Set the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @param value
       *           the link value to set
       */
      public void setLinks(@NonNull List<Link> value) {
        _links = value;
      }

      /**
       * Add a new {@link Link} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return _links.add(value);
      }

      /**
       * Remove the first matching {@link Link} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _links != null && _links.remove(value);
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }

    /**
     * A URL-based pointer to an external resource with an optional hash for verification and change detection.
     */
    @MetaschemaAssembly(
        formalName = "Resource link",
        description = "A URL-based pointer to an external resource with an optional hash for verification and change detection.",
        name = "rlink",
        moduleClass = OscalMetadataModule.class,
        remarks = "Multiple `rlink` objects can be included for a resource. In such a case, all provided `rlink` items are intended to be equivalent in content, but may differ in structure or format.\n"
                + "\n"
                + "A `media-type` is used to identify the format of a given rlink, and can be used to differentiate items in a collection of rlinks. The `media-type` provides a hint to the OSCAL document consumer about the structure of the resource referenced by the `rlink`."
    )
    public static class Rlink implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * A resolvable URL pointing to the referenced resource.
       */
      @BoundFlag(
          formalName = "Hypertext Reference",
          description = "A resolvable URL pointing to the referenced resource.",
          name = "href",
          required = true,
          typeAdapter = UriReferenceAdapter.class,
          remarks = "This value may be either:\n"
                  + "\n"
                  + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
                  + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or"
      )
      private URI _href;

      /**
       * A label that indicates the nature of a resource, as a data serialization or format.
       */
      @BoundFlag(
          formalName = "Media Type",
          description = "A label that indicates the nature of a resource, as a data serialization or format.",
          name = "media-type",
          typeAdapter = StringAdapter.class
      )
      private String _mediaType;

      /**
       * A hash of the resource identified by <code>href</code>, which can be used to verify the resource was not changed since it was hashed.
       */
      @BoundField(
          formalName = "Hash",
          description = "A hash of the resource identified by `href`, which can be used to verify the resource was not changed since it was hashed.",
          useName = "hash",
          remarks = "The `hash` value can be used to confirm that the resource referenced by the `href` is the same resources that was hashed by retrieving the resource, calculating a hash, and comparing the result to this value.",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "hashes", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Hash> _hashes;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource.Rlink} instance with no metadata.
       */
      public Rlink() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource.Rlink} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Rlink(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Hypertext Reference}".
       *
       * <p>
       * A resolvable URL pointing to the referenced resource.
       *
       * @return the href value
       */
      @NonNull
      public URI getHref() {
        return _href;
      }

      /**
       * Set the "{@literal Hypertext Reference}".
       *
       * <p>
       * A resolvable URL pointing to the referenced resource.
       *
       * @param value
       *           the href value to set
       */
      public void setHref(@NonNull URI value) {
        _href = value;
      }

      /**
       * Get the "{@literal Media Type}".
       *
       * <p>
       * A label that indicates the nature of a resource, as a data serialization or format.
       *
       * @return the media-type value, or {@code null} if not set
       */
      @Nullable
      public String getMediaType() {
        return _mediaType;
      }

      /**
       * Set the "{@literal Media Type}".
       *
       * <p>
       * A label that indicates the nature of a resource, as a data serialization or format.
       *
       * @param value
       *           the media-type value to set, or {@code null} to clear
       */
      public void setMediaType(@Nullable String value) {
        _mediaType = value;
      }

      /**
       * Get the "{@literal Hash}".
       *
       * <p>
       * A hash of the resource identified by <code>href</code>, which can be used to verify the resource was not changed since it was hashed.
       *
       * @return the hash value
       */
      @NonNull
      public List<Hash> getHashes() {
        if (_hashes == null) {
          _hashes = new LinkedList<>();
        }
        return ObjectUtils.notNull(_hashes);
      }

      /**
       * Set the "{@literal Hash}".
       *
       * <p>
       * A hash of the resource identified by <code>href</code>, which can be used to verify the resource was not changed since it was hashed.
       *
       * @param value
       *           the hash value to set
       */
      public void setHashes(@NonNull List<Hash> value) {
        _hashes = value;
      }

      /**
       * Add a new {@link Hash} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addHash(Hash item) {
        Hash value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_hashes == null) {
          _hashes = new LinkedList<>();
        }
        return _hashes.add(value);
      }

      /**
       * Remove the first matching {@link Hash} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeHash(Hash item) {
        Hash value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _hashes != null && _hashes.remove(value);
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }

    /**
     * A resource encoded using the Base64 alphabet defined by <a href="https://www.rfc-editor.org/rfc/rfc2045.html">RFC 2045</a>.
     */
    @MetaschemaField(
        formalName = "Base64",
        description = "A resource encoded using the Base64 alphabet defined by [RFC 2045](https://www.rfc-editor.org/rfc/rfc2045.html).",
        name = "base64",
        moduleClass = OscalMetadataModule.class
    )
    public static class Base64 implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * Name of the file before it was encoded as Base64 to be embedded in a <code>resource</code>. This is the name that will be assigned to the file when the file is decoded.
       */
      @BoundFlag(
          formalName = "File Name",
          description = "Name of the file before it was encoded as Base64 to be embedded in a `resource`. This is the name that will be assigned to the file when the file is decoded.",
          name = "filename",
          typeAdapter = TokenAdapter.class
      )
      private String _filename;

      /**
       * A label that indicates the nature of a resource, as a data serialization or format.
       */
      @BoundFlag(
          formalName = "Media Type",
          description = "A label that indicates the nature of a resource, as a data serialization or format.",
          name = "media-type",
          typeAdapter = StringAdapter.class
      )
      private String _mediaType;

      /**
       * The field value.
       */
      @BoundFieldValue(
          valueKeyName = "value",
          typeAdapter = Base64Adapter.class
      )
      private ByteBuffer _value;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource.Base64} instance with no metadata.
       */
      public Base64() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.BackMatter.Resource.Base64} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Base64(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal File Name}".
       *
       * <p>
       * Name of the file before it was encoded as Base64 to be embedded in a <code>resource</code>. This is the name that will be assigned to the file when the file is decoded.
       *
       * @return the filename value, or {@code null} if not set
       */
      @Nullable
      public String getFilename() {
        return _filename;
      }

      /**
       * Set the "{@literal File Name}".
       *
       * <p>
       * Name of the file before it was encoded as Base64 to be embedded in a <code>resource</code>. This is the name that will be assigned to the file when the file is decoded.
       *
       * @param value
       *           the filename value to set, or {@code null} to clear
       */
      public void setFilename(@Nullable String value) {
        _filename = value;
      }

      /**
       * Get the "{@literal Media Type}".
       *
       * <p>
       * A label that indicates the nature of a resource, as a data serialization or format.
       *
       * @return the media-type value, or {@code null} if not set
       */
      @Nullable
      public String getMediaType() {
        return _mediaType;
      }

      /**
       * Set the "{@literal Media Type}".
       *
       * <p>
       * A label that indicates the nature of a resource, as a data serialization or format.
       *
       * @param value
       *           the media-type value to set, or {@code null} to clear
       */
      public void setMediaType(@Nullable String value) {
        _mediaType = value;
      }

      /**
       * Get the field value.
       *
       * @return the value
       */
      @Nullable
      public ByteBuffer getValue() {
        return _value;
      }

      /**
       * Set the field value.
       *
       * @param value
       *           the value to set
       */
      public void setValue(@Nullable ByteBuffer value) {
        _value = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }
}
