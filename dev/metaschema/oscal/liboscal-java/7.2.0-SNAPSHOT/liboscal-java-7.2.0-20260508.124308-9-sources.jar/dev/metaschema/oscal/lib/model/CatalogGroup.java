// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_catalog_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import dev.metaschema.oscal.lib.model.control.catalog.AbstractCatalogGroup;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A group of controls, or of groups of controls.
 */
@MetaschemaAssembly(
    formalName = "Control Group",
    description = "A group of controls, or of groups of controls.",
    name = "group",
    moduleClass = OscalCatalogModule.class,
    remarks = "Catalogs can use the catalog `group` construct to organize related controls into a single grouping, such as a family of controls or other logical organizational structure.\n"
            + "\n"
            + "A `group` may have its own properties, statements, parameters, and references, which are inherited by all controls of that are a member of the group.",
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-group-prop-name", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "label", description = "A human-readable label for the parent context, which may be rendered in place of the actual identifier for some use cases."), @AllowedValue(value = "sort-id", description = "An alternative identifier, whose value is easily sortable among other such values in the document."), @AllowedValue(value = "alt-identifier", description = "An alternate or aliased identifier for the parent context.")}), @AllowedValues(id = "oscal-group-part-name", level = IConstraint.Level.ERROR, target = "part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "overview", description = "An introduction to a control or a group of controls."), @AllowedValue(value = "instruction", description = "Information providing directions for a control or a group of controls.")})})
)
public class CatalogGroup extends AbstractCatalogGroup implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Identifies the group for the purpose of cross-linking within the defining instance or from other instances that reference the catalog.
   */
  @BoundFlag(
      formalName = "Group Identifier",
      description = "Identifies the group for the purpose of cross-linking within the defining instance or from other instances that reference the catalog.",
      name = "id",
      typeAdapter = TokenAdapter.class
  )
  private String _id;

  /**
   * A textual label that provides a sub-type or characterization of the group.
   */
  @BoundFlag(
      formalName = "Group Class",
      description = "A textual label that provides a sub-type or characterization of the group.",
      name = "class",
      typeAdapter = TokenAdapter.class,
      remarks = "A `class` can be used in validation rules to express extra constraints over named items of a specific `class` value.\n"
              + "\n"
              + "A `class` can also be used in an OSCAL profile as a means to target an alteration to control content."
  )
  private String _clazz;

  /**
   * A name given to the group, which may be used by a tool for display and navigation.
   */
  @BoundField(
      formalName = "Group Title",
      description = "A name given to the group, which may be used by a tool for display and navigation.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   */
  @BoundAssembly(
      formalName = "Parameter",
      description = "Parameters provide a mechanism for the dynamic assignment of value(s) in a control.",
      useName = "param",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "params", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Parameter> _params;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   */
  @BoundAssembly(
      formalName = "Part",
      description = "An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.",
      useName = "part",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "parts", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlPart> _parts;

  /**
   * A group of controls, or of groups of controls.
   */
  @BoundAssembly(
      formalName = "Control Group",
      description = "A group of controls, or of groups of controls.",
      useName = "group",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "groups", inJson = JsonGroupAsBehavior.LIST)
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private List<CatalogGroup> _groups;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">structured object</a> representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.
   */
  @BoundAssembly(
      formalName = "Control",
      description = "A [structured object](https://pages.nist.gov/OSCAL/concepts/terminology/#control) representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.",
      useName = "control",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "controls", inJson = JsonGroupAsBehavior.LIST)
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private List<Control> _controls;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.CatalogGroup} instance with no metadata.
   */
  public CatalogGroup() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.CatalogGroup} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public CatalogGroup(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Group Identifier}".
   *
   * <p>
   * Identifies the group for the purpose of cross-linking within the defining instance or from other instances that reference the catalog.
   *
   * @return the id value, or {@code null} if not set
   */
  @Nullable
  public String getId() {
    return _id;
  }

  /**
   * Set the "{@literal Group Identifier}".
   *
   * <p>
   * Identifies the group for the purpose of cross-linking within the defining instance or from other instances that reference the catalog.
   *
   * @param value
   *           the id value to set, or {@code null} to clear
   */
  public void setId(@Nullable String value) {
    _id = value;
  }

  /**
   * Get the "{@literal Group Class}".
   *
   * <p>
   * A textual label that provides a sub-type or characterization of the group.
   *
   * @return the class value, or {@code null} if not set
   */
  @Nullable
  public String getClazz() {
    return _clazz;
  }

  /**
   * Set the "{@literal Group Class}".
   *
   * <p>
   * A textual label that provides a sub-type or characterization of the group.
   *
   * @param value
   *           the class value to set, or {@code null} to clear
   */
  public void setClazz(@Nullable String value) {
    _clazz = value;
  }

  /**
   * Get the "{@literal Group Title}".
   *
   * <p>
   * A name given to the group, which may be used by a tool for display and navigation.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Group Title}".
   *
   * <p>
   * A name given to the group, which may be used by a tool for display and navigation.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Parameter}".
   *
   * <p>
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   *
   * @return the param value
   */
  @NonNull
  public List<Parameter> getParams() {
    if (_params == null) {
      _params = new LinkedList<>();
    }
    return ObjectUtils.notNull(_params);
  }

  /**
   * Set the "{@literal Parameter}".
   *
   * <p>
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   *
   * @param value
   *           the param value to set
   */
  public void setParams(@NonNull List<Parameter> value) {
    _params = value;
  }

  /**
   * Add a new {@link Parameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addParam(Parameter item) {
    Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_params == null) {
      _params = new LinkedList<>();
    }
    return _params.add(value);
  }

  /**
   * Remove the first matching {@link Parameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeParam(Parameter item) {
    Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _params != null && _params.remove(value);
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Part}".
   *
   * <p>
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   *
   * @return the part value
   */
  @NonNull
  public List<ControlPart> getParts() {
    if (_parts == null) {
      _parts = new LinkedList<>();
    }
    return ObjectUtils.notNull(_parts);
  }

  /**
   * Set the "{@literal Part}".
   *
   * <p>
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   *
   * @param value
   *           the part value to set
   */
  public void setParts(@NonNull List<ControlPart> value) {
    _parts = value;
  }

  /**
   * Add a new {@link ControlPart} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addPart(ControlPart item) {
    ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_parts == null) {
      _parts = new LinkedList<>();
    }
    return _parts.add(value);
  }

  /**
   * Remove the first matching {@link ControlPart} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removePart(ControlPart item) {
    ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _parts != null && _parts.remove(value);
  }

  /**
   * Get the "{@literal Control Group}".
   *
   * <p>
   * A group of controls, or of groups of controls.
   *
   * @return the group value
   */
  @NonNull
  public List<CatalogGroup> getGroups() {
    if (_groups == null) {
      _groups = new LinkedList<>();
    }
    return ObjectUtils.notNull(_groups);
  }

  /**
   * Set the "{@literal Control Group}".
   *
   * <p>
   * A group of controls, or of groups of controls.
   *
   * @param value
   *           the group value to set
   */
  public void setGroups(@NonNull List<CatalogGroup> value) {
    _groups = value;
  }

  /**
   * Add a new {@link CatalogGroup} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addGroup(CatalogGroup item) {
    CatalogGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_groups == null) {
      _groups = new LinkedList<>();
    }
    return _groups.add(value);
  }

  /**
   * Remove the first matching {@link CatalogGroup} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeGroup(CatalogGroup item) {
    CatalogGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _groups != null && _groups.remove(value);
  }

  /**
   * Get the "{@literal Control}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">structured object</a> representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.
   *
   * @return the control value
   */
  @NonNull
  public List<Control> getControls() {
    if (_controls == null) {
      _controls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_controls);
  }

  /**
   * Set the "{@literal Control}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/terminology/#control">structured object</a> representing a requirement or guideline, which when implemented will reduce an aspect of risk related to an information system and its information.
   *
   * @param value
   *           the control value to set
   */
  public void setControls(@NonNull List<Control> value) {
    _controls = value;
  }

  /**
   * Add a new {@link Control} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addControl(Control item) {
    Control value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_controls == null) {
      _controls = new LinkedList<>();
    }
    return _controls.add(value);
  }

  /**
   * Remove the first matching {@link Control} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeControl(Control item) {
    Control value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _controls != null && _controls.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
