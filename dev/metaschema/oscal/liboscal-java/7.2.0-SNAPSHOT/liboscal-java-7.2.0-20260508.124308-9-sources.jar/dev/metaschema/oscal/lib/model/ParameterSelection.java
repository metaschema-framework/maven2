// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_control-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Presenting a choice among alternatives.
 */
@MetaschemaAssembly(
    formalName = "Selection",
    description = "Presenting a choice among alternatives.",
    name = "parameter-selection",
    moduleClass = OscalControlCommonModule.class,
    remarks = "A set of parameter value choices, that may be picked from to set the parameter value."
)
public class ParameterSelection implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Describes the number of selections that must occur. Without this setting, only one value should be assumed to be permitted.
   */
  @BoundFlag(
      formalName = "Parameter Cardinality",
      description = "Describes the number of selections that must occur. Without this setting, only one value should be assumed to be permitted.",
      name = "how-many",
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-parameter-how-many-type", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "one", description = "Only one value is permitted."), @AllowedValue(value = "one-or-more", description = "One or more values are permitted.")}))
  )
  private String _howMany;

  /**
   * A value selection among several such options.
   */
  @BoundField(
      formalName = "Choice",
      description = "A value selection among several such options.",
      useName = "choice",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "choice", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = MarkupLineAdapter.class
  )
  private List<MarkupLine> _choice;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterSelection} instance with no metadata.
   */
  public ParameterSelection() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterSelection} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ParameterSelection(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Parameter Cardinality}".
   *
   * <p>
   * Describes the number of selections that must occur. Without this setting, only one value should be assumed to be permitted.
   *
   * @return the how-many value, or {@code null} if not set
   */
  @Nullable
  public String getHowMany() {
    return _howMany;
  }

  /**
   * Set the "{@literal Parameter Cardinality}".
   *
   * <p>
   * Describes the number of selections that must occur. Without this setting, only one value should be assumed to be permitted.
   *
   * @param value
   *           the how-many value to set, or {@code null} to clear
   */
  public void setHowMany(@Nullable String value) {
    _howMany = value;
  }

  /**
   * Get the "{@literal Choice}".
   *
   * <p>
   * A value selection among several such options.
   *
   * @return the choice value
   */
  @NonNull
  public List<MarkupLine> getChoice() {
    if (_choice == null) {
      _choice = new LinkedList<>();
    }
    return ObjectUtils.notNull(_choice);
  }

  /**
   * Set the "{@literal Choice}".
   *
   * <p>
   * A value selection among several such options.
   *
   * @param value
   *           the choice value to set
   */
  public void setChoice(@NonNull List<MarkupLine> value) {
    _choice = value;
  }

  /**
   * Add a new {@link MarkupLine} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addChoice(MarkupLine item) {
    MarkupLine value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_choice == null) {
      _choice = new LinkedList<>();
    }
    return _choice.add(value);
  }

  /**
   * Remove the first matching {@link MarkupLine} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeChoice(MarkupLine item) {
    MarkupLine value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _choice != null && _choice.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
