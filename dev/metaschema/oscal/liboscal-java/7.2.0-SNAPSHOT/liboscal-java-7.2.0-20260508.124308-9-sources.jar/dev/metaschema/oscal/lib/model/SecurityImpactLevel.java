// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * The overall level of expected impact resulting from unauthorized disclosure, modification, or loss of access to information.
 */
@MetaschemaAssembly(
    formalName = "Security Impact Level",
    description = "The overall level of expected impact resulting from unauthorized disclosure, modification, or loss of access to information.",
    name = "security-impact-level",
    moduleClass = OscalSspModule.class
)
public class SecurityImpactLevel implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A target-level of confidentiality for the system, based on the sensitivity of information within the system.
   */
  @BoundField(
      formalName = "Security Objective: Confidentiality",
      description = "A target-level of confidentiality for the system, based on the sensitivity of information within the system.",
      useName = "security-objective-confidentiality",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _securityObjectiveConfidentiality;

  /**
   * A target-level of integrity for the system, based on the sensitivity of information within the system.
   */
  @BoundField(
      formalName = "Security Objective: Integrity",
      description = "A target-level of integrity for the system, based on the sensitivity of information within the system.",
      useName = "security-objective-integrity",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _securityObjectiveIntegrity;

  /**
   * A target-level of availability for the system, based on the sensitivity of information within the system.
   */
  @BoundField(
      formalName = "Security Objective: Availability",
      description = "A target-level of availability for the system, based on the sensitivity of information within the system.",
      useName = "security-objective-availability",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _securityObjectiveAvailability;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SecurityImpactLevel} instance with no metadata.
   */
  public SecurityImpactLevel() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SecurityImpactLevel} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SecurityImpactLevel(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Security Objective: Confidentiality}".
   *
   * <p>
   * A target-level of confidentiality for the system, based on the sensitivity of information within the system.
   *
   * @return the security-objective-confidentiality value
   */
  @NonNull
  public String getSecurityObjectiveConfidentiality() {
    return _securityObjectiveConfidentiality;
  }

  /**
   * Set the "{@literal Security Objective: Confidentiality}".
   *
   * <p>
   * A target-level of confidentiality for the system, based on the sensitivity of information within the system.
   *
   * @param value
   *           the security-objective-confidentiality value to set
   */
  public void setSecurityObjectiveConfidentiality(@NonNull String value) {
    _securityObjectiveConfidentiality = value;
  }

  /**
   * Get the "{@literal Security Objective: Integrity}".
   *
   * <p>
   * A target-level of integrity for the system, based on the sensitivity of information within the system.
   *
   * @return the security-objective-integrity value
   */
  @NonNull
  public String getSecurityObjectiveIntegrity() {
    return _securityObjectiveIntegrity;
  }

  /**
   * Set the "{@literal Security Objective: Integrity}".
   *
   * <p>
   * A target-level of integrity for the system, based on the sensitivity of information within the system.
   *
   * @param value
   *           the security-objective-integrity value to set
   */
  public void setSecurityObjectiveIntegrity(@NonNull String value) {
    _securityObjectiveIntegrity = value;
  }

  /**
   * Get the "{@literal Security Objective: Availability}".
   *
   * <p>
   * A target-level of availability for the system, based on the sensitivity of information within the system.
   *
   * @return the security-objective-availability value
   */
  @NonNull
  public String getSecurityObjectiveAvailability() {
    return _securityObjectiveAvailability;
  }

  /**
   * Set the "{@literal Security Objective: Availability}".
   *
   * <p>
   * A target-level of availability for the system, based on the sensitivity of information within the system.
   *
   * @param value
   *           the security-objective-availability value to set
   */
  public void setSecurityObjectiveAvailability(@NonNull String value) {
    _securityObjectiveAvailability = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
