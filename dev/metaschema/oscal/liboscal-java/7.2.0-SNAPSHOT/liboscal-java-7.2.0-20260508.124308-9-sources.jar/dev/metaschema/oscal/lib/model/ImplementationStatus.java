// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Indicates the degree to which the a given control is implemented.
 */
@MetaschemaAssembly(
    formalName = "Implementation Status",
    description = "Indicates the degree to which the a given control is implemented.",
    name = "implementation-status",
    moduleClass = OscalImplementationCommonModule.class
)
public class ImplementationStatus implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Identifies the implementation status of the control or control objective.
   */
  @BoundFlag(
      formalName = "Implementation State",
      description = "Identifies the implementation status of the control or control objective.",
      name = "state",
      required = true,
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-implementation-status-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "implemented", description = "The control is fully implemented."), @AllowedValue(value = "partial", description = "The control is partially implemented."), @AllowedValue(value = "planned", description = "There is a plan for implementing the control as explained in the remarks."), @AllowedValue(value = "alternative", description = "There is an alternative implementation for this control as explained in the remarks."), @AllowedValue(value = "not-applicable", description = "This control does not apply to this system as justified in the remarks.")}))
  )
  private String _state;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImplementationStatus} instance with no metadata.
   */
  public ImplementationStatus() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImplementationStatus} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ImplementationStatus(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Implementation State}".
   *
   * <p>
   * Identifies the implementation status of the control or control objective.
   *
   * @return the state value
   */
  @NonNull
  public String getState() {
    return _state;
  }

  /**
   * Set the "{@literal Implementation State}".
   *
   * <p>
   * Identifies the implementation status of the control or control objective.
   *
   * @param value
   *           the state value to set
   */
  public void setState(@NonNull String value) {
    _state = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
