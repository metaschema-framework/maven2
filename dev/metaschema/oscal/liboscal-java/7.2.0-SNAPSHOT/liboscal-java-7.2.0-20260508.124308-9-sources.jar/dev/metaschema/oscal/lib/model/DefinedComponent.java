// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A defined component that can be part of an implemented system.
 */
@MetaschemaAssembly(
    formalName = "Component",
    description = "A defined component that can be part of an implemented system.",
    name = "defined-component",
    moduleClass = OscalComponentDefinitionModule.class,
    remarks = "Components may be products, services, APIs, policies, processes, plans, guidance, standards, or other tangible items that enable security and/or privacy.\n"
            + "\n"
            + "The `type` indicates which of these component types is represented.\n"
            + "\n"
            + "A group of components may be aggregated into a `capability`. For example, an account management capability that consists of an account management process, and a Lightweight Directory Access Protocol (LDAP) software implementation.\n"
            + "\n"
            + "Capabilities are expressed by combining one or more components.",
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-component-prop-name", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "version", description = "The version of the component."), @AllowedValue(value = "patch-level", description = "The specific patch level of the component."), @AllowedValue(value = "model", description = "The model of system used by the asset."), @AllowedValue(value = "release-date", description = "The date the component was released, such as a software release date or policy publication date."), @AllowedValue(value = "validation-type", description = "Used with component-type='validation' to provide a well-known name for a kind of validation."), @AllowedValue(value = "validation-reference", description = "Used with component-type='validation' to indicate the validating body's assigned identifier for their validation of this component."), @AllowedValue(value = "asset-type", description = "Simple indication of the asset's function, such as Router, Storage Array, DNS Server."), @AllowedValue(value = "asset-id", description = "An organizationally specific identifier that is used to uniquely identify a logical or tangible item by the organization that owns the item."), @AllowedValue(value = "asset-tag", description = "An asset tag assigned by the organization responsible for maintaining the logical or tangible item."), @AllowedValue(value = "public", description = "Identifies whether the asset is publicly accessible (yes/no)"), @AllowedValue(value = "virtual", description = "Identifies whether the asset is virtualized (yes/no)"), @AllowedValue(value = "vlan-id", description = "Virtual LAN identifier of the asset."), @AllowedValue(value = "network-id", description = "The network identifier of the asset."), @AllowedValue(value = "label", description = "A human-readable label for the parent context."), @AllowedValue(value = "sort-id", description = "An alternative identifier, whose value is easily sortable among other such values in the document."), @AllowedValue(value = "baseline-configuration-name", description = "The name of the baseline configuration for the asset."), @AllowedValue(value = "allows-authenticated-scan", description = "Can the asset be check with an authenticated scan? (yes/no)"), @AllowedValue(value = "function", description = "The function provided by the asset for the system."), @AllowedValue(value = "hardware-model", description = "\\*\\*(deprecated)\\*\\* Use 'model' instead.", deprecatedVersion = "1.2.0"), @AllowedValue(value = "os-name", description = "The name of the operating system used by the asset."), @AllowedValue(value = "os-version", description = "The version of the operating system used by the asset."), @AllowedValue(value = "software-name", description = "The software product name used by the asset."), @AllowedValue(value = "software-version", description = "The software product version used by the asset."), @AllowedValue(value = "software-patch-level", description = "The software product patch level used by the asset.")}), @AllowedValues(id = "oscal-component-link-rel-type", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = {@AllowedValue(value = "depends-on", description = "A reference to another component that this component has a dependency on."), @AllowedValue(value = "validation", description = "A reference to another component of component-type=validation, that is a validation (e.g., FIPS 140-2) for this component"), @AllowedValue(value = "proof-of-compliance", description = "A pointer to a validation record (e.g., FIPS 140-2) or other compliance information."), @AllowedValue(value = "baseline-template", description = "A reference to the baseline template used to configure the asset."), @AllowedValue(value = "uses-service", description = "This service is used by the referenced component identifier."), @AllowedValue(value = "system-security-plan", description = "A link to the system security plan of the external system."), @AllowedValue(value = "uses-network", description = "This component uses the network provided by the identified network component.")}), @AllowedValues(id = "oscal-component-role-id", level = IConstraint.Level.ERROR, target = "responsible-role/@role-id|control-implementation/implemented-requirement/responsible-role/@role-id|control-implementation/implemented-requirement/statement/responsible-role/@role-id", allowOthers = true, values = {@AllowedValue(value = "asset-owner", description = "Accountable for ensuring the asset is managed in accordance with organizational policies and procedures."), @AllowedValue(value = "asset-administrator", description = "Responsible for administering a set of assets."), @AllowedValue(value = "security-operations", description = "Members of the security operations center (SOC)."), @AllowedValue(value = "network-operations", description = "Members of the network operations center (NOC)."), @AllowedValue(value = "incident-response", description = "Responsible for responding to an event that could lead to loss of, or disruption to, an organization's operations, services or functions."), @AllowedValue(value = "help-desk", description = "Responsible for providing information and support to users."), @AllowedValue(value = "configuration-management", description = "Responsible for the configuration management processes governing changes to the asset."), @AllowedValue(value = "maintainer", description = "Responsible for the creation and maintenance of a component."), @AllowedValue(value = "provider", description = "Organization responsible for providing the component, if this is different from the \"maintainer\" (e.g., a reseller).")}), @AllowedValues(id = "oscal-component-asset-type-value", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='asset-type']/@value", allowOthers = true, values = {@AllowedValue(value = "operating-system", description = "System software that manages computer hardware, software resources, and provides common services for computer programs."), @AllowedValue(value = "database", description = "An electronic collection of data, or information, that is specially organized for rapid search and retrieval."), @AllowedValue(value = "web-server", description = "A system that delivers content or services to end users over the Internet or an intranet."), @AllowedValue(value = "dns-server", description = "A system that resolves domain names to internet protocol (IP) addresses."), @AllowedValue(value = "email-server", description = "A computer system that sends and receives electronic mail messages."), @AllowedValue(value = "directory-server", description = "A system that stores, organizes and provides access to directory information in order to unify network resources."), @AllowedValue(value = "pbx", description = "A private branch exchange (PBX) provides a a private telephone switchboard."), @AllowedValue(value = "firewall", description = "A network security system that monitors and controls incoming and outgoing network traffic based on predetermined security rules."), @AllowedValue(value = "router", description = "A physical or virtual networking device that forwards data packets between computer networks."), @AllowedValue(value = "switch", description = "A physical or virtual networking device that connects devices within a computer network by using packet switching to receive and forward data to the destination device."), @AllowedValue(value = "storage-array", description = "A consolidated, block-level data storage capability."), @AllowedValue(value = "appliance", description = "A physical or virtual machine that centralizes hardware, software, or services for a specific purpose.")}), @AllowedValues(id = "oscal-component-allows-authenticated-scan-value", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='allows-authenticated-scan']/@value", values = {@AllowedValue(value = "yes", description = "The component allows an authenticated scan."), @AllowedValue(value = "no", description = "The component does not allow an authenticated scan.")}), @AllowedValues(id = "oscal-component-virtual-value", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='virtual']/@value", values = {@AllowedValue(value = "yes", description = "The component is virtualized."), @AllowedValue(value = "no", description = "The component is not virtualized.")}), @AllowedValues(id = "oscal-component-public-value", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='public']/@value", values = {@AllowedValue(value = "yes", description = "The component is publicly accessible."), @AllowedValue(value = "no", description = "The component is not publicly accessible.")}), @AllowedValues(id = "oscal-component-implementation-point-value", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='implementation-point']/@value", values = {@AllowedValue(value = "internal", description = "The component is implemented within the system boundary."), @AllowedValue(value = "external", description = "The component is implemented outside the system boundary.")}), @AllowedValues(id = "oscal-software-component-prop-name", level = IConstraint.Level.ERROR, target = "(.)[@type='software']/prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "software-identifier", description = "If a \"software\" component-type, the identifier, such as a SWID tag, for the software component.")), @AllowedValues(id = "oscal-service-component-link-rel-type", level = IConstraint.Level.ERROR, target = "(.)[@type='service']/link/@rel", allowOthers = true, values = {@AllowedValue(value = "provided-by", description = "This service is provided by the referenced component identifier."), @AllowedValue(value = "used-by", description = "This service is used by the referenced component identifier.")})}, indexHasKey = @IndexHasKey(id = "oscal-index-metadata-location-uuid", level = IConstraint.Level.ERROR, target = "prop[@name='physical-location']", indexName = "index-metadata-location-uuid", keyFields = @KeyField(target = "@value")), matches = {@Matches(id = "oscal-component-inherited-uuid-value-datatype", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='inherited-uuid']/@value", typeAdapter = UuidAdapter.class), @Matches(id = "oscal-component-release-date-value-datatype", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='release-date']/@value", typeAdapter = DateAdapter.class)}),
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-defined-component-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
)
public class DefinedComponent implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Provides a globally unique means to identify a given component.
   */
  @BoundFlag(
      formalName = "Component Identifier",
      description = "Provides a globally unique means to identify a given component.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * A category describing the purpose of the component.
   */
  @BoundFlag(
      formalName = "Component Type",
      description = "A category describing the purpose of the component.",
      name = "type",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-component-type", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "interconnection", description = "A connection to something outside this system."), @AllowedValue(value = "software", description = "Any software, operating system, or firmware."), @AllowedValue(value = "hardware", description = "A physical device."), @AllowedValue(value = "service", description = "A service that may provide APIs."), @AllowedValue(value = "policy", description = "An enforceable policy."), @AllowedValue(value = "physical", description = "A tangible asset used to provide physical protections or countermeasures."), @AllowedValue(value = "process-procedure", description = "A list of steps or actions to take to achieve some end result."), @AllowedValue(value = "plan", description = "An applicable plan."), @AllowedValue(value = "guidance", description = "Any guideline or recommendation."), @AllowedValue(value = "standard", description = "Any organizational or industry standard."), @AllowedValue(value = "validation", description = "An external assessment performed on some other component, that has been validated by a third-party.")}))
  )
  private String _type;

  /**
   * A human readable name for the component.
   */
  @BoundField(
      formalName = "Component Title",
      description = "A human readable name for the component.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A description of the component, including information about its function.
   */
  @BoundField(
      formalName = "Component Description",
      description = "A description of the component, including information about its function.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * A summary of the technological or business purpose of the component.
   */
  @BoundField(
      formalName = "Purpose",
      description = "A summary of the technological or business purpose of the component.",
      useName = "purpose",
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _purpose;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   */
  @BoundAssembly(
      formalName = "Responsible Role",
      description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
      useName = "responsible-role",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleRole> _responsibleRoles;

  /**
   * Information about the protocol used to provide a service.
   */
  @BoundAssembly(
      formalName = "Service Protocol Information",
      description = "Information about the protocol used to provide a service.",
      useName = "protocol",
      remarks = "Used for `service` components to define the protocols supported by the service.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "protocols", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Protocol> _protocols;

  /**
   * Defines how the component or capability supports a set of controls.
   */
  @BoundAssembly(
      formalName = "Control Implementation Set",
      description = "Defines how the component or capability supports a set of controls.",
      useName = "control-implementation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "control-implementations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ComponentControlImplementation> _controlImplementations;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.DefinedComponent} instance with no metadata.
   */
  public DefinedComponent() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.DefinedComponent} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public DefinedComponent(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Component Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given component.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Component Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given component.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Component Type}".
   *
   * <p>
   * A category describing the purpose of the component.
   *
   * @return the type value
   */
  @NonNull
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Component Type}".
   *
   * <p>
   * A category describing the purpose of the component.
   *
   * @param value
   *           the type value to set
   */
  public void setType(@NonNull String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Component Title}".
   *
   * <p>
   * A human readable name for the component.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Component Title}".
   *
   * <p>
   * A human readable name for the component.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Component Description}".
   *
   * <p>
   * A description of the component, including information about its function.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Component Description}".
   *
   * <p>
   * A description of the component, including information about its function.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Purpose}".
   *
   * <p>
   * A summary of the technological or business purpose of the component.
   *
   * @return the purpose value, or {@code null} if not set
   */
  @Nullable
  public MarkupLine getPurpose() {
    return _purpose;
  }

  /**
   * Set the "{@literal Purpose}".
   *
   * <p>
   * A summary of the technological or business purpose of the component.
   *
   * @param value
   *           the purpose value to set, or {@code null} to clear
   */
  public void setPurpose(@Nullable MarkupLine value) {
    _purpose = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @return the responsible-role value
   */
  @NonNull
  public List<ResponsibleRole> getResponsibleRoles() {
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleRoles);
  }

  /**
   * Set the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @param value
   *           the responsible-role value to set
   */
  public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
    _responsibleRoles = value;
  }

  /**
   * Add a new {@link ResponsibleRole} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return _responsibleRoles.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleRoles != null && _responsibleRoles.remove(value);
  }

  /**
   * Get the "{@literal Service Protocol Information}".
   *
   * <p>
   * Information about the protocol used to provide a service.
   *
   * @return the protocol value
   */
  @NonNull
  public List<Protocol> getProtocols() {
    if (_protocols == null) {
      _protocols = new LinkedList<>();
    }
    return ObjectUtils.notNull(_protocols);
  }

  /**
   * Set the "{@literal Service Protocol Information}".
   *
   * <p>
   * Information about the protocol used to provide a service.
   *
   * @param value
   *           the protocol value to set
   */
  public void setProtocols(@NonNull List<Protocol> value) {
    _protocols = value;
  }

  /**
   * Add a new {@link Protocol} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProtocol(Protocol item) {
    Protocol value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_protocols == null) {
      _protocols = new LinkedList<>();
    }
    return _protocols.add(value);
  }

  /**
   * Remove the first matching {@link Protocol} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProtocol(Protocol item) {
    Protocol value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _protocols != null && _protocols.remove(value);
  }

  /**
   * Get the "{@literal Control Implementation Set}".
   *
   * <p>
   * Defines how the component or capability supports a set of controls.
   *
   * @return the control-implementation value
   */
  @NonNull
  public List<ComponentControlImplementation> getControlImplementations() {
    if (_controlImplementations == null) {
      _controlImplementations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_controlImplementations);
  }

  /**
   * Set the "{@literal Control Implementation Set}".
   *
   * <p>
   * Defines how the component or capability supports a set of controls.
   *
   * @param value
   *           the control-implementation value to set
   */
  public void setControlImplementations(@NonNull List<ComponentControlImplementation> value) {
    _controlImplementations = value;
  }

  /**
   * Add a new {@link ComponentControlImplementation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addControlImplementation(ComponentControlImplementation item) {
    ComponentControlImplementation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_controlImplementations == null) {
      _controlImplementations = new LinkedList<>();
    }
    return _controlImplementations.add(value);
  }

  /**
   * Remove the first matching {@link ComponentControlImplementation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeControlImplementation(ComponentControlImplementation item) {
    ComponentControlImplementation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _controlImplementations != null && _controlImplementations.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
