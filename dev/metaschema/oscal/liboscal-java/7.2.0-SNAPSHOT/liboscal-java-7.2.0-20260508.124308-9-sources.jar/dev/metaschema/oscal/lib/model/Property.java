// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import dev.metaschema.oscal.lib.model.metadata.AbstractProperty;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
 */
@MetaschemaAssembly(
    formalName = "Property",
    description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
    name = "property",
    moduleClass = OscalMetadataModule.class,
    remarks = "Properties permit the deployment and management of arbitrary controlled values, within OSCAL objects. A property can be included for any purpose useful to an application or implementation. Typically, properties will be used to sort, filter, select, order, and arrange OSCAL content objects, to relate OSCAL objects to one another, or to associate an OSCAL object to class hierarchies, taxonomies, or external authorities. Thus, the lexical composition of properties may be constrained by external processes to ensure consistency.\n"
            + "\n"
            + "Property allows for associated remarks that describe why the specific property value was applied to the containing object, or the significance of the value in the context of the containing object.",
    valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-prop-name-values", level = IConstraint.Level.ERROR, target = ".[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "marking", description = "A label or descriptor that is tied to a sensitivity or classification marking system. An optional class can be used to define the specific marking system used for the associated value.")))
)
public class Property extends AbstractProperty implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A textual label, within a namespace, that identifies a specific attribute, characteristic, or quality of the property's containing object.
   */
  @BoundFlag(
      formalName = "Property Name",
      description = "A textual label, within a namespace, that identifies a specific attribute, characteristic, or quality of the property's containing object.",
      name = "name",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _name;

  /**
   * A unique identifier for a property.
   */
  @BoundFlag(
      formalName = "Property Universally Unique Identifier",
      description = "A unique identifier for a property.",
      name = "uuid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * A namespace qualifying the property's name. This allows different organizations to associate distinct semantics with the same name.
   */
  @BoundFlag(
      formalName = "Property Namespace",
      description = "A namespace qualifying the property's name. This allows different organizations to associate distinct semantics with the same name.",
      name = "ns",
      defaultValue = "http://csrc.nist.gov/ns/oscal",
      typeAdapter = UriAdapter.class,
      remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).\n"
              + "\n"
              + "When a `ns` is not provided, its value should be assumed to be `http://csrc.nist.gov/ns/oscal` and the name should be a name defined by the associated OSCAL model."
  )
  private URI _ns;

  /**
   * Indicates the value of the attribute, characteristic, or quality.
   */
  @BoundFlag(
      formalName = "Property Value",
      description = "Indicates the value of the attribute, characteristic, or quality.",
      name = "value",
      required = true,
      typeAdapter = StringAdapter.class
  )
  private String _value;

  /**
   * A textual label that provides a sub-type or characterization of the property's <code>name</code>.
   */
  @BoundFlag(
      formalName = "Property Class",
      description = "A textual label that provides a sub-type or characterization of the property's `name`.",
      name = "class",
      typeAdapter = TokenAdapter.class,
      remarks = "This can be used to further distinguish or discriminate between the semantics of multiple properties of the same object with the same `name` and `ns`, or to group properties into categories.\n"
              + "\n"
              + "A `class` can be used in validation rules to express extra constraints over named items of a specific `class` value. It is available for grouping, but unlike `group` is not expected specifically to designate any group membership as such."
  )
  private String _clazz;

  /**
   * An identifier for relating distinct sets of properties.
   */
  @BoundFlag(
      formalName = "Property Group",
      description = "An identifier for relating distinct sets of properties.",
      name = "group",
      typeAdapter = TokenAdapter.class,
      remarks = "Different sets of properties may relate to separate contexts. Declare a group on a property to associate it with one or more other properties in a given context."
  )
  private String _group;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Property} instance with no metadata.
   */
  public Property() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Property} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Property(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Property Name}".
   *
   * <p>
   * A textual label, within a namespace, that identifies a specific attribute, characteristic, or quality of the property's containing object.
   *
   * @return the name value
   */
  @NonNull
  public String getName() {
    return _name;
  }

  /**
   * Set the "{@literal Property Name}".
   *
   * <p>
   * A textual label, within a namespace, that identifies a specific attribute, characteristic, or quality of the property's containing object.
   *
   * @param value
   *           the name value to set
   */
  public void setName(@NonNull String value) {
    _name = value;
  }

  /**
   * Get the "{@literal Property Universally Unique Identifier}".
   *
   * <p>
   * A unique identifier for a property.
   *
   * @return the uuid value, or {@code null} if not set
   */
  @Nullable
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Property Universally Unique Identifier}".
   *
   * <p>
   * A unique identifier for a property.
   *
   * @param value
   *           the uuid value to set, or {@code null} to clear
   */
  public void setUuid(@Nullable UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Property Namespace}".
   *
   * <p>
   * A namespace qualifying the property's name. This allows different organizations to associate distinct semantics with the same name.
   *
   * @return the ns value, or {@code null} if not set
   */
  @Nullable
  public URI getNs() {
    return _ns;
  }

  /**
   * Set the "{@literal Property Namespace}".
   *
   * <p>
   * A namespace qualifying the property's name. This allows different organizations to associate distinct semantics with the same name.
   *
   * @param value
   *           the ns value to set, or {@code null} to clear
   */
  public void setNs(@Nullable URI value) {
    _ns = value;
  }

  /**
   * Get the "{@literal Property Value}".
   *
   * <p>
   * Indicates the value of the attribute, characteristic, or quality.
   *
   * @return the value value
   */
  @NonNull
  public String getValue() {
    return _value;
  }

  /**
   * Set the "{@literal Property Value}".
   *
   * <p>
   * Indicates the value of the attribute, characteristic, or quality.
   *
   * @param value
   *           the value value to set
   */
  public void setValue(@NonNull String value) {
    _value = value;
  }

  /**
   * Get the "{@literal Property Class}".
   *
   * <p>
   * A textual label that provides a sub-type or characterization of the property's <code>name</code>.
   *
   * @return the class value, or {@code null} if not set
   */
  @Nullable
  public String getClazz() {
    return _clazz;
  }

  /**
   * Set the "{@literal Property Class}".
   *
   * <p>
   * A textual label that provides a sub-type or characterization of the property's <code>name</code>.
   *
   * @param value
   *           the class value to set, or {@code null} to clear
   */
  public void setClazz(@Nullable String value) {
    _clazz = value;
  }

  /**
   * Get the "{@literal Property Group}".
   *
   * <p>
   * An identifier for relating distinct sets of properties.
   *
   * @return the group value, or {@code null} if not set
   */
  @Nullable
  public String getGroup() {
    return _group;
  }

  /**
   * Set the "{@literal Property Group}".
   *
   * <p>
   * An identifier for relating distinct sets of properties.
   *
   * @param value
   *           the group value to set, or {@code null} to clear
   */
  public void setGroup(@Nullable String value) {
    _group = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
