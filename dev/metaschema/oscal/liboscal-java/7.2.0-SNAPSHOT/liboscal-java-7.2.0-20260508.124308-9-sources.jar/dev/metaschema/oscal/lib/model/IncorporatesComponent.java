// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * The collection of components comprising this capability.
 */
@MetaschemaAssembly(
    formalName = "Incorporates Component",
    description = "The collection of components comprising this capability.",
    name = "incorporates-component",
    moduleClass = OscalComponentDefinitionModule.class
)
public class IncorporatesComponent implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a <code>component</code>.
   */
  @BoundFlag(
      formalName = "Component Reference",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a `component`.",
      name = "component-uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _componentUuid;

  /**
   * A description of the component, including information about its function.
   */
  @BoundField(
      formalName = "Component Description",
      description = "A description of the component, including information about its function.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.IncorporatesComponent} instance with no metadata.
   */
  public IncorporatesComponent() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.IncorporatesComponent} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public IncorporatesComponent(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Component Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a <code>component</code>.
   *
   * @return the component-uuid value
   */
  @NonNull
  public UUID getComponentUuid() {
    return _componentUuid;
  }

  /**
   * Set the "{@literal Component Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a <code>component</code>.
   *
   * @param value
   *           the component-uuid value to set
   */
  public void setComponentUuid(@NonNull UUID value) {
    _componentUuid = value;
  }

  /**
   * Get the "{@literal Component Description}".
   *
   * <p>
   * A description of the component, including information about its function.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Component Description}".
   *
   * <p>
   * A description of the component, including information about its function.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
