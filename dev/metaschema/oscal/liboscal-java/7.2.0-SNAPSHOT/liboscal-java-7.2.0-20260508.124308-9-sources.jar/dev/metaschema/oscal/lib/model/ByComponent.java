// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.HasCardinality;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Defines how the referenced component implements a set of controls.
 */
@MetaschemaAssembly(
    formalName = "Component Control Implementation",
    description = "Defines how the referenced component implements a set of controls.",
    name = "by-component",
    moduleClass = OscalSspModule.class,
    remarks = "Use of `set-parameter` in this context, sets the parameter for the control referenced in the containing `implemented-requirement` applied to the referenced component. If the `by-component` is used as a child of a `statement`, then the parameter value also applies only in the context of the referenced statement. If the same parameter is also set in the `control-implementation` or a specific `implemented-requirement`, then this `by-component/set-parameter` value will override the other value(s) in the context of the referenced component, control, and statement (if parent).",
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-by-component-link-rel-values", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = {@AllowedValue(value = "imported-from", description = "The hyperlink identifies a URI pointing to the `component` in a `component-definition` that originally described the `component` this component was based on."), @AllowedValue(value = "provided-by", description = "A reference to the UUID of a control or statement `by-component` object that is used as evidence of implementation.")}), @AllowedValues(id = "oscal-by-component-responsible-role-id-values", level = IConstraint.Level.ERROR, target = ".//responsible-role/@role-id", allowOthers = true, values = {@AllowedValue(value = "asset-owner", description = "Accountable for ensuring the asset is managed in accordance with organizational policies and procedures."), @AllowedValue(value = "asset-administrator", description = "Responsible for administering a set of assets."), @AllowedValue(value = "security-operations", description = "Members of the security operations center (SOC)."), @AllowedValue(value = "network-operations", description = "Members of the network operations center (NOC)."), @AllowedValue(value = "incident-response", description = "Responsible for responding to an event that could lead to loss of, or disruption to, an organization's operations, services or functions."), @AllowedValue(value = "help-desk", description = "Responsible for providing information and support to users."), @AllowedValue(value = "configuration-management", description = "Responsible for the configuration management processes governing changes to the asset."), @AllowedValue(value = "maintainer", description = "Responsible for the creation and maintenance of a component."), @AllowedValue(value = "provider", description = "Organization responsible for providing the component, if this is different from the \"maintainer\" (e.g., a reseller).")})}, indexHasKey = @IndexHasKey(id = "oscal-by-component-uuid-index", level = IConstraint.Level.ERROR, target = "link[@rel='provided-by']", indexName = "by-component-uuid", keyFields = @KeyField(target = "@href", pattern = "#(.*)"))),
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-ssp-by-component-set-parameter", level = IConstraint.Level.ERROR, target = "set-parameter", keyFields = @KeyField(target = "@param-id"), remarks = "Since multiple `set-parameter` entries can be provided, each parameter must be set only once."))
)
public class ByComponent implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the <code>component</code> that is implementing a given control.
   */
  @BoundFlag(
      formalName = "Component Universally Unique Identifier Reference",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to the `component` that is implementing a given control.",
      name = "component-uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _componentUuid;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this by-component entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>by-component</code> entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "By-Component Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this by-component entry elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `by-component` entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * An implementation statement that describes how a control or a control statement is implemented within the referenced system component.
   */
  @BoundField(
      formalName = "Control Implementation Description",
      description = "An implementation statement that describes how a control or a control statement is implemented within the referenced system component.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the parameter that will be set by the enclosed value.
   */
  @BoundAssembly(
      formalName = "Set Parameter Value",
      description = "Identifies the parameter that will be set by the enclosed value.",
      useName = "set-parameter",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "set-parameters", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SetParameter> _setParameters;

  /**
   * Indicates the degree to which the a given control is implemented.
   */
  @BoundAssembly(
      formalName = "Implementation Status",
      description = "Indicates the degree to which the a given control is implemented.",
      useName = "implementation-status",
      remarks = "The `implementation-status` is used to qualify the `status` value to indicate the degree to which the control is implemented."
  )
  private ImplementationStatus _implementationStatus;

  /**
   * Identifies content intended for external consumption, such as with leveraged organizations.
   */
  @BoundAssembly(
      formalName = "Export",
      description = "Identifies content intended for external consumption, such as with leveraged organizations.",
      useName = "export"
  )
  private Export _export;

  /**
   * Describes a control implementation inherited by a leveraging system.
   */
  @BoundAssembly(
      formalName = "Inherited Control Implementation",
      description = "Describes a control implementation inherited by a leveraging system.",
      useName = "inherited",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "inherited", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Inherited> _inherited;

  /**
   * Describes how this system satisfies a responsibility imposed by a leveraged system.
   */
  @BoundAssembly(
      formalName = "Satisfied Control Implementation Responsibility",
      description = "Describes how this system satisfies a responsibility imposed by a leveraged system.",
      useName = "satisfied",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "satisfied", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Satisfied> _satisfied;

  /**
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   */
  @BoundAssembly(
      formalName = "Responsible Role",
      description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
      useName = "responsible-role",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleRole> _responsibleRoles;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent} instance with no metadata.
   */
  public ByComponent() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ByComponent(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Component Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the <code>component</code> that is implementing a given control.
   *
   * @return the component-uuid value
   */
  @NonNull
  public UUID getComponentUuid() {
    return _componentUuid;
  }

  /**
   * Set the "{@literal Component Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the <code>component</code> that is implementing a given control.
   *
   * @param value
   *           the component-uuid value to set
   */
  public void setComponentUuid(@NonNull UUID value) {
    _componentUuid = value;
  }

  /**
   * Get the "{@literal By-Component Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this by-component entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>by-component</code> entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal By-Component Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this by-component entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>by-component</code> entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Control Implementation Description}".
   *
   * <p>
   * An implementation statement that describes how a control or a control statement is implemented within the referenced system component.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Control Implementation Description}".
   *
   * <p>
   * An implementation statement that describes how a control or a control statement is implemented within the referenced system component.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @return the set-parameter value
   */
  @NonNull
  public List<SetParameter> getSetParameters() {
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return ObjectUtils.notNull(_setParameters);
  }

  /**
   * Set the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @param value
   *           the set-parameter value to set
   */
  public void setSetParameters(@NonNull List<SetParameter> value) {
    _setParameters = value;
  }

  /**
   * Add a new {@link SetParameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return _setParameters.add(value);
  }

  /**
   * Remove the first matching {@link SetParameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _setParameters != null && _setParameters.remove(value);
  }

  /**
   * Get the "{@literal Implementation Status}".
   *
   * <p>
   * Indicates the degree to which the a given control is implemented.
   *
   * @return the implementation-status value, or {@code null} if not set
   */
  @Nullable
  public ImplementationStatus getImplementationStatus() {
    return _implementationStatus;
  }

  /**
   * Set the "{@literal Implementation Status}".
   *
   * <p>
   * Indicates the degree to which the a given control is implemented.
   *
   * @param value
   *           the implementation-status value to set, or {@code null} to clear
   */
  public void setImplementationStatus(@Nullable ImplementationStatus value) {
    _implementationStatus = value;
  }

  /**
   * Get the "{@literal Export}".
   *
   * <p>
   * Identifies content intended for external consumption, such as with leveraged organizations.
   *
   * @return the export value, or {@code null} if not set
   */
  @Nullable
  public Export getExport() {
    return _export;
  }

  /**
   * Set the "{@literal Export}".
   *
   * <p>
   * Identifies content intended for external consumption, such as with leveraged organizations.
   *
   * @param value
   *           the export value to set, or {@code null} to clear
   */
  public void setExport(@Nullable Export value) {
    _export = value;
  }

  /**
   * Get the "{@literal Inherited Control Implementation}".
   *
   * <p>
   * Describes a control implementation inherited by a leveraging system.
   *
   * @return the inherited value
   */
  @NonNull
  public List<Inherited> getInherited() {
    if (_inherited == null) {
      _inherited = new LinkedList<>();
    }
    return ObjectUtils.notNull(_inherited);
  }

  /**
   * Set the "{@literal Inherited Control Implementation}".
   *
   * <p>
   * Describes a control implementation inherited by a leveraging system.
   *
   * @param value
   *           the inherited value to set
   */
  public void setInherited(@NonNull List<Inherited> value) {
    _inherited = value;
  }

  /**
   * Add a new {@link Inherited} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addInherited(Inherited item) {
    Inherited value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_inherited == null) {
      _inherited = new LinkedList<>();
    }
    return _inherited.add(value);
  }

  /**
   * Remove the first matching {@link Inherited} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeInherited(Inherited item) {
    Inherited value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _inherited != null && _inherited.remove(value);
  }

  /**
   * Get the "{@literal Satisfied Control Implementation Responsibility}".
   *
   * <p>
   * Describes how this system satisfies a responsibility imposed by a leveraged system.
   *
   * @return the satisfied value
   */
  @NonNull
  public List<Satisfied> getSatisfied() {
    if (_satisfied == null) {
      _satisfied = new LinkedList<>();
    }
    return ObjectUtils.notNull(_satisfied);
  }

  /**
   * Set the "{@literal Satisfied Control Implementation Responsibility}".
   *
   * <p>
   * Describes how this system satisfies a responsibility imposed by a leveraged system.
   *
   * @param value
   *           the satisfied value to set
   */
  public void setSatisfied(@NonNull List<Satisfied> value) {
    _satisfied = value;
  }

  /**
   * Add a new {@link Satisfied} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSatisfied(Satisfied item) {
    Satisfied value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_satisfied == null) {
      _satisfied = new LinkedList<>();
    }
    return _satisfied.add(value);
  }

  /**
   * Remove the first matching {@link Satisfied} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSatisfied(Satisfied item) {
    Satisfied value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _satisfied != null && _satisfied.remove(value);
  }

  /**
   * Get the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @return the responsible-role value
   */
  @NonNull
  public List<ResponsibleRole> getResponsibleRoles() {
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleRoles);
  }

  /**
   * Set the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @param value
   *           the responsible-role value to set
   */
  public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
    _responsibleRoles = value;
  }

  /**
   * Add a new {@link ResponsibleRole} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return _responsibleRoles.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleRoles != null && _responsibleRoles.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Identifies content intended for external consumption, such as with leveraged organizations.
   */
  @MetaschemaAssembly(
      formalName = "Export",
      description = "Identifies content intended for external consumption, such as with leveraged organizations.",
      name = "export",
      moduleClass = OscalSspModule.class,
      valueConstraints = @ValueConstraints(indexHasKey = @IndexHasKey(id = "oscal-by-component-export-provided-uuid-index", level = IConstraint.Level.ERROR, target = "responsibility", indexName = "by-component-export-provided-uuid", keyFields = @KeyField(target = "@provided-uuid"))),
      modelConstraints = @AssemblyConstraints(cardinality = @HasCardinality(id = "oscal-by-component-export-provided-responsibility-cardinality", level = IConstraint.Level.ERROR, target = "provided|responsibility", minOccurs = 1))
  )
  public static class Export implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * An implementation statement that describes the aspects of the control or control statement implementation that can be available to another system leveraging this system.
     */
    @BoundField(
        formalName = "Control Implementation Export Description",
        description = "An implementation statement that describes the aspects of the control or control statement implementation that can be available to another system leveraging this system.",
        useName = "description",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Describes a capability which may be inherited by a leveraging system.
     */
    @BoundAssembly(
        formalName = "Provided Control Implementation",
        description = "Describes a capability which may be inherited by a leveraging system.",
        useName = "provided",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "provided", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Provided> _provided;

    /**
     * Describes a control implementation responsibility imposed on a leveraging system.
     */
    @BoundAssembly(
        formalName = "Control Implementation Responsibility",
        description = "Describes a control implementation responsibility imposed on a leveraging system.",
        useName = "responsibility",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "responsibilities", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Responsibility> _responsibilities;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Export} instance with no metadata.
     */
    public Export() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Export} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Export(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Control Implementation Export Description}".
     *
     * <p>
     * An implementation statement that describes the aspects of the control or control statement implementation that can be available to another system leveraging this system.
     *
     * @return the description value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Control Implementation Export Description}".
     *
     * <p>
     * An implementation statement that describes the aspects of the control or control statement implementation that can be available to another system leveraging this system.
     *
     * @param value
     *           the description value to set, or {@code null} to clear
     */
    public void setDescription(@Nullable MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Provided Control Implementation}".
     *
     * <p>
     * Describes a capability which may be inherited by a leveraging system.
     *
     * @return the provided value
     */
    @NonNull
    public List<Provided> getProvided() {
      if (_provided == null) {
        _provided = new LinkedList<>();
      }
      return ObjectUtils.notNull(_provided);
    }

    /**
     * Set the "{@literal Provided Control Implementation}".
     *
     * <p>
     * Describes a capability which may be inherited by a leveraging system.
     *
     * @param value
     *           the provided value to set
     */
    public void setProvided(@NonNull List<Provided> value) {
      _provided = value;
    }

    /**
     * Add a new {@link Provided} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProvided(Provided item) {
      Provided value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_provided == null) {
        _provided = new LinkedList<>();
      }
      return _provided.add(value);
    }

    /**
     * Remove the first matching {@link Provided} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProvided(Provided item) {
      Provided value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _provided != null && _provided.remove(value);
    }

    /**
     * Get the "{@literal Control Implementation Responsibility}".
     *
     * <p>
     * Describes a control implementation responsibility imposed on a leveraging system.
     *
     * @return the responsibility value
     */
    @NonNull
    public List<Responsibility> getResponsibilities() {
      if (_responsibilities == null) {
        _responsibilities = new LinkedList<>();
      }
      return ObjectUtils.notNull(_responsibilities);
    }

    /**
     * Set the "{@literal Control Implementation Responsibility}".
     *
     * <p>
     * Describes a control implementation responsibility imposed on a leveraging system.
     *
     * @param value
     *           the responsibility value to set
     */
    public void setResponsibilities(@NonNull List<Responsibility> value) {
      _responsibilities = value;
    }

    /**
     * Add a new {@link Responsibility} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addResponsibility(Responsibility item) {
      Responsibility value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_responsibilities == null) {
        _responsibilities = new LinkedList<>();
      }
      return _responsibilities.add(value);
    }

    /**
     * Remove the first matching {@link Responsibility} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeResponsibility(Responsibility item) {
      Responsibility value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _responsibilities != null && _responsibilities.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * Describes a capability which may be inherited by a leveraging system.
     */
    @MetaschemaAssembly(
        formalName = "Provided Control Implementation",
        description = "Describes a capability which may be inherited by a leveraging system.",
        name = "provided",
        moduleClass = OscalSspModule.class,
        modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-provided-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
    )
    public static class Provided implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this provided entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>provided</code> entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       */
      @BoundFlag(
          formalName = "Provided Universally Unique Identifier",
          description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this provided entry elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `provided` entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
          name = "uuid",
          required = true,
          typeAdapter = UuidAdapter.class
      )
      private UUID _uuid;

      /**
       * An implementation statement that describes the aspects of the control or control statement implementation that can be provided to another system leveraging this system.
       */
      @BoundField(
          formalName = "Provided Control Implementation Description",
          description = "An implementation statement that describes the aspects of the control or control statement implementation that can be provided to another system leveraging this system.",
          useName = "description",
          minOccurs = 1,
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _description;

      /**
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       */
      @BoundAssembly(
          formalName = "Property",
          description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
          useName = "prop",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Property> _props;

      /**
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       */
      @BoundAssembly(
          formalName = "Link",
          description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
          useName = "link",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Link> _links;

      /**
       * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
       */
      @BoundAssembly(
          formalName = "Responsible Role",
          description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
          useName = "responsible-role",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<ResponsibleRole> _responsibleRoles;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Export.Provided} instance with no metadata.
       */
      public Provided() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Export.Provided} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Provided(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Provided Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this provided entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>provided</code> entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @return the uuid value
       */
      @NonNull
      public UUID getUuid() {
        return _uuid;
      }

      /**
       * Set the "{@literal Provided Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this provided entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>provided</code> entry can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @param value
       *           the uuid value to set
       */
      public void setUuid(@NonNull UUID value) {
        _uuid = value;
      }

      /**
       * Get the "{@literal Provided Control Implementation Description}".
       *
       * <p>
       * An implementation statement that describes the aspects of the control or control statement implementation that can be provided to another system leveraging this system.
       *
       * @return the description value
       */
      @NonNull
      public MarkupMultiline getDescription() {
        return _description;
      }

      /**
       * Set the "{@literal Provided Control Implementation Description}".
       *
       * <p>
       * An implementation statement that describes the aspects of the control or control statement implementation that can be provided to another system leveraging this system.
       *
       * @param value
       *           the description value to set
       */
      public void setDescription(@NonNull MarkupMultiline value) {
        _description = value;
      }

      /**
       * Get the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @return the prop value
       */
      @NonNull
      public List<Property> getProps() {
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return ObjectUtils.notNull(_props);
      }

      /**
       * Set the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @param value
       *           the prop value to set
       */
      public void setProps(@NonNull List<Property> value) {
        _props = value;
      }

      /**
       * Add a new {@link Property} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return _props.add(value);
      }

      /**
       * Remove the first matching {@link Property} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _props != null && _props.remove(value);
      }

      /**
       * Get the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @return the link value
       */
      @NonNull
      public List<Link> getLinks() {
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return ObjectUtils.notNull(_links);
      }

      /**
       * Set the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @param value
       *           the link value to set
       */
      public void setLinks(@NonNull List<Link> value) {
        _links = value;
      }

      /**
       * Add a new {@link Link} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return _links.add(value);
      }

      /**
       * Remove the first matching {@link Link} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _links != null && _links.remove(value);
      }

      /**
       * Get the "{@literal Responsible Role}".
       *
       * <p>
       * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
       *
       * @return the responsible-role value
       */
      @NonNull
      public List<ResponsibleRole> getResponsibleRoles() {
        if (_responsibleRoles == null) {
          _responsibleRoles = new LinkedList<>();
        }
        return ObjectUtils.notNull(_responsibleRoles);
      }

      /**
       * Set the "{@literal Responsible Role}".
       *
       * <p>
       * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
       *
       * @param value
       *           the responsible-role value to set
       */
      public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
        _responsibleRoles = value;
      }

      /**
       * Add a new {@link ResponsibleRole} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addResponsibleRole(ResponsibleRole item) {
        ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_responsibleRoles == null) {
          _responsibleRoles = new LinkedList<>();
        }
        return _responsibleRoles.add(value);
      }

      /**
       * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeResponsibleRole(ResponsibleRole item) {
        ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _responsibleRoles != null && _responsibleRoles.remove(value);
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }

    /**
     * Describes a control implementation responsibility imposed on a leveraging system.
     */
    @MetaschemaAssembly(
        formalName = "Control Implementation Responsibility",
        description = "Describes a control implementation responsibility imposed on a leveraging system.",
        name = "responsibility",
        moduleClass = OscalSspModule.class,
        modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-responsibility-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
    )
    public static class Responsibility implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this responsibility elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>responsibility</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       */
      @BoundFlag(
          formalName = "Responsibility Universally Unique Identifier",
          description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this responsibility elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `responsibility` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
          name = "uuid",
          required = true,
          typeAdapter = UuidAdapter.class
      )
      private UUID _uuid;

      /**
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.
       */
      @BoundFlag(
          formalName = "Provided UUID",
          description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.",
          name = "provided-uuid",
          typeAdapter = UuidAdapter.class
      )
      private UUID _providedUuid;

      /**
       * An implementation statement that describes the aspects of the control or control statement implementation that a leveraging system must implement to satisfy the control provided by a leveraged system.
       */
      @BoundField(
          formalName = "Control Implementation Responsibility Description",
          description = "An implementation statement that describes the aspects of the control or control statement implementation that a leveraging system must implement to satisfy the control provided by a leveraged system.",
          useName = "description",
          minOccurs = 1,
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _description;

      /**
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       */
      @BoundAssembly(
          formalName = "Property",
          description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
          useName = "prop",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Property> _props;

      /**
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       */
      @BoundAssembly(
          formalName = "Link",
          description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
          useName = "link",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Link> _links;

      /**
       * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
       */
      @BoundAssembly(
          formalName = "Responsible Role",
          description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
          useName = "responsible-role",
          remarks = "A role defined at the by-component level takes precedence over the same role defined on the parent implemented-requirement or on the referenced component.",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<ResponsibleRole> _responsibleRoles;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Export.Responsibility} instance with no metadata.
       */
      public Responsibility() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Export.Responsibility} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Responsibility(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Responsibility Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this responsibility elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>responsibility</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @return the uuid value
       */
      @NonNull
      public UUID getUuid() {
        return _uuid;
      }

      /**
       * Set the "{@literal Responsibility Universally Unique Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this responsibility elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>responsibility</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @param value
       *           the uuid value to set
       */
      public void setUuid(@NonNull UUID value) {
        _uuid = value;
      }

      /**
       * Get the "{@literal Provided UUID}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.
       *
       * @return the provided-uuid value, or {@code null} if not set
       */
      @Nullable
      public UUID getProvidedUuid() {
        return _providedUuid;
      }

      /**
       * Set the "{@literal Provided UUID}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.
       *
       * @param value
       *           the provided-uuid value to set, or {@code null} to clear
       */
      public void setProvidedUuid(@Nullable UUID value) {
        _providedUuid = value;
      }

      /**
       * Get the "{@literal Control Implementation Responsibility Description}".
       *
       * <p>
       * An implementation statement that describes the aspects of the control or control statement implementation that a leveraging system must implement to satisfy the control provided by a leveraged system.
       *
       * @return the description value
       */
      @NonNull
      public MarkupMultiline getDescription() {
        return _description;
      }

      /**
       * Set the "{@literal Control Implementation Responsibility Description}".
       *
       * <p>
       * An implementation statement that describes the aspects of the control or control statement implementation that a leveraging system must implement to satisfy the control provided by a leveraged system.
       *
       * @param value
       *           the description value to set
       */
      public void setDescription(@NonNull MarkupMultiline value) {
        _description = value;
      }

      /**
       * Get the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @return the prop value
       */
      @NonNull
      public List<Property> getProps() {
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return ObjectUtils.notNull(_props);
      }

      /**
       * Set the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @param value
       *           the prop value to set
       */
      public void setProps(@NonNull List<Property> value) {
        _props = value;
      }

      /**
       * Add a new {@link Property} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return _props.add(value);
      }

      /**
       * Remove the first matching {@link Property} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _props != null && _props.remove(value);
      }

      /**
       * Get the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @return the link value
       */
      @NonNull
      public List<Link> getLinks() {
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return ObjectUtils.notNull(_links);
      }

      /**
       * Set the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @param value
       *           the link value to set
       */
      public void setLinks(@NonNull List<Link> value) {
        _links = value;
      }

      /**
       * Add a new {@link Link} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return _links.add(value);
      }

      /**
       * Remove the first matching {@link Link} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _links != null && _links.remove(value);
      }

      /**
       * Get the "{@literal Responsible Role}".
       *
       * <p>
       * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
       *
       * @return the responsible-role value
       */
      @NonNull
      public List<ResponsibleRole> getResponsibleRoles() {
        if (_responsibleRoles == null) {
          _responsibleRoles = new LinkedList<>();
        }
        return ObjectUtils.notNull(_responsibleRoles);
      }

      /**
       * Set the "{@literal Responsible Role}".
       *
       * <p>
       * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
       *
       * @param value
       *           the responsible-role value to set
       */
      public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
        _responsibleRoles = value;
      }

      /**
       * Add a new {@link ResponsibleRole} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addResponsibleRole(ResponsibleRole item) {
        ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_responsibleRoles == null) {
          _responsibleRoles = new LinkedList<>();
        }
        return _responsibleRoles.add(value);
      }

      /**
       * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeResponsibleRole(ResponsibleRole item) {
        ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _responsibleRoles != null && _responsibleRoles.remove(value);
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }

  /**
   * Describes a control implementation inherited by a leveraging system.
   */
  @MetaschemaAssembly(
      formalName = "Inherited Control Implementation",
      description = "Describes a control implementation inherited by a leveraging system.",
      name = "inherited",
      moduleClass = OscalSspModule.class,
      modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-inherited-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
  )
  public static class Inherited implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this inherited entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>inherited control implementation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Inherited Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this inherited entry elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `inherited control implementation` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.
     */
    @BoundFlag(
        formalName = "Provided UUID",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.",
        name = "provided-uuid",
        typeAdapter = UuidAdapter.class
    )
    private UUID _providedUuid;

    /**
     * An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is inheriting from a leveraged system.
     */
    @BoundField(
        formalName = "Inherited Control Implementation Description",
        description = "An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is inheriting from a leveraged system.",
        useName = "description",
        minOccurs = 1,
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     */
    @BoundAssembly(
        formalName = "Responsible Role",
        description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
        useName = "responsible-role",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ResponsibleRole> _responsibleRoles;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Inherited} instance with no metadata.
     */
    public Inherited() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Inherited} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Inherited(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Inherited Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this inherited entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>inherited control implementation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Inherited Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this inherited entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>inherited control implementation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Provided UUID}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.
     *
     * @return the provided-uuid value, or {@code null} if not set
     */
    @Nullable
    public UUID getProvidedUuid() {
      return _providedUuid;
    }

    /**
     * Set the "{@literal Provided UUID}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an inherited control implementation that a leveraging system is inheriting from a leveraged system.
     *
     * @param value
     *           the provided-uuid value to set, or {@code null} to clear
     */
    public void setProvidedUuid(@Nullable UUID value) {
      _providedUuid = value;
    }

    /**
     * Get the "{@literal Inherited Control Implementation Description}".
     *
     * <p>
     * An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is inheriting from a leveraged system.
     *
     * @return the description value
     */
    @NonNull
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Inherited Control Implementation Description}".
     *
     * <p>
     * An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is inheriting from a leveraged system.
     *
     * @param value
     *           the description value to set
     */
    public void setDescription(@NonNull MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @return the responsible-role value
     */
    @NonNull
    public List<ResponsibleRole> getResponsibleRoles() {
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return ObjectUtils.notNull(_responsibleRoles);
    }

    /**
     * Set the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @param value
     *           the responsible-role value to set
     */
    public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
      _responsibleRoles = value;
    }

    /**
     * Add a new {@link ResponsibleRole} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return _responsibleRoles.add(value);
    }

    /**
     * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _responsibleRoles != null && _responsibleRoles.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Describes how this system satisfies a responsibility imposed by a leveraged system.
   */
  @MetaschemaAssembly(
      formalName = "Satisfied Control Implementation Responsibility",
      description = "Describes how this system satisfies a responsibility imposed by a leveraged system.",
      name = "satisfied",
      moduleClass = OscalSspModule.class,
      modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-satisfied-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
  )
  public static class Satisfied implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this satisfied control implementation entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>control implementation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Satisfied Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this satisfied control implementation entry elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `control implementation` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a control implementation that satisfies a responsibility imposed by a leveraged system.
     */
    @BoundFlag(
        formalName = "Responsibility UUID",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a control implementation that satisfies a responsibility imposed by a leveraged system.",
        name = "responsibility-uuid",
        typeAdapter = UuidAdapter.class
    )
    private UUID _responsibilityUuid;

    /**
     * An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is implementing based on a requirement from a leveraged system.
     */
    @BoundField(
        formalName = "Satisfied Control Implementation Responsibility Description",
        description = "An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is implementing based on a requirement from a leveraged system.",
        useName = "description",
        minOccurs = 1,
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     */
    @BoundAssembly(
        formalName = "Responsible Role",
        description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
        useName = "responsible-role",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ResponsibleRole> _responsibleRoles;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Satisfied} instance with no metadata.
     */
    public Satisfied() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.ByComponent.Satisfied} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Satisfied(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Satisfied Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this satisfied control implementation entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>control implementation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Satisfied Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this satisfied control implementation entry elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>control implementation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Responsibility UUID}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a control implementation that satisfies a responsibility imposed by a leveraged system.
     *
     * @return the responsibility-uuid value, or {@code null} if not set
     */
    @Nullable
    public UUID getResponsibilityUuid() {
      return _responsibilityUuid;
    }

    /**
     * Set the "{@literal Responsibility UUID}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a control implementation that satisfies a responsibility imposed by a leveraged system.
     *
     * @param value
     *           the responsibility-uuid value to set, or {@code null} to clear
     */
    public void setResponsibilityUuid(@Nullable UUID value) {
      _responsibilityUuid = value;
    }

    /**
     * Get the "{@literal Satisfied Control Implementation Responsibility Description}".
     *
     * <p>
     * An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is implementing based on a requirement from a leveraged system.
     *
     * @return the description value
     */
    @NonNull
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Satisfied Control Implementation Responsibility Description}".
     *
     * <p>
     * An implementation statement that describes the aspects of a control or control statement implementation that a leveraging system is implementing based on a requirement from a leveraged system.
     *
     * @param value
     *           the description value to set
     */
    public void setDescription(@NonNull MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @return the responsible-role value
     */
    @NonNull
    public List<ResponsibleRole> getResponsibleRoles() {
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return ObjectUtils.notNull(_responsibleRoles);
    }

    /**
     * Set the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @param value
     *           the responsible-role value to set
     */
    public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
      _responsibleRoles = value;
    }

    /**
     * Add a new {@link ResponsibleRole} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return _responsibleRoles.add(value);
    }

    /**
     * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _responsibleRoles != null && _responsibleRoles.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
