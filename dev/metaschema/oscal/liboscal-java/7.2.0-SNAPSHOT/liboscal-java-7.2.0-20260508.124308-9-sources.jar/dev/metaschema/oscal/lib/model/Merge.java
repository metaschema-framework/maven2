// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.BooleanAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Provides structuring directives that instruct how controls are organized after profile resolution.
 */
@MetaschemaAssembly(
    formalName = "Merge Controls",
    description = "Provides structuring directives that instruct how controls are organized after profile resolution.",
    name = "merge",
    moduleClass = OscalProfileModule.class
)
public class Merge implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A Combine element defines how to resolve duplicate instances of the same control (e.g., controls with the same ID).
   */
  @BoundAssembly(
      formalName = "Combination Rule",
      description = "A Combine element defines how to resolve duplicate instances of the same control (e.g., controls with the same ID).",
      useName = "combine"
  )
  private Combine _combine;

  /**
   * Directs that controls appear without any grouping structure.
   */
  @BoundAssembly(
      formalName = "Flat Without Grouping",
      description = "Directs that controls appear without any grouping structure.",
      useName = "flat",
      minOccurs = 1
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private Flat _flat;

  /**
   * Indicates that the controls selected should retain their original grouping as defined in the import source.
   */
  @BoundField(
      formalName = "Group As-Is",
      description = "Indicates that the controls selected should retain their original grouping as defined in the import source.",
      useName = "as-is",
      minOccurs = 1,
      typeAdapter = BooleanAdapter.class
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private Boolean _asIs;

  /**
   * Provides an alternate grouping structure that selected controls will be placed in.
   */
  @BoundAssembly(
      formalName = "Custom Grouping",
      description = "Provides an alternate grouping structure that selected controls will be placed in.",
      useName = "custom",
      remarks = "The `custom` element represents a custom arrangement or organization of controls in the resolution of a catalog. This structuring directive gives the profile author the ability to define an entirely different organization of controls as compared to their source catalog(s).",
      minOccurs = 1
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private Custom _custom;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge} instance with no metadata.
   */
  public Merge() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Merge(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Combination Rule}".
   *
   * <p>
   * A Combine element defines how to resolve duplicate instances of the same control (e.g., controls with the same ID).
   *
   * @return the combine value, or {@code null} if not set
   */
  @Nullable
  public Combine getCombine() {
    return _combine;
  }

  /**
   * Set the "{@literal Combination Rule}".
   *
   * <p>
   * A Combine element defines how to resolve duplicate instances of the same control (e.g., controls with the same ID).
   *
   * @param value
   *           the combine value to set, or {@code null} to clear
   */
  public void setCombine(@Nullable Combine value) {
    _combine = value;
  }

  /**
   * Get the "{@literal Flat Without Grouping}".
   *
   * <p>
   * Directs that controls appear without any grouping structure.
   *
   * @return the flat value, or {@code null} if not set
   */
  @Nullable
  public Flat getFlat() {
    return _flat;
  }

  /**
   * Set the "{@literal Flat Without Grouping}".
   *
   * <p>
   * Directs that controls appear without any grouping structure.
   *
   * @param value
   *           the flat value to set, or {@code null} to clear
   */
  public void setFlat(@Nullable Flat value) {
    _flat = value;
  }

  /**
   * Get the "{@literal Group As-Is}".
   *
   * <p>
   * Indicates that the controls selected should retain their original grouping as defined in the import source.
   *
   * @return the as-is value, or {@code null} if not set
   */
  @Nullable
  public Boolean getAsIs() {
    return _asIs;
  }

  /**
   * Set the "{@literal Group As-Is}".
   *
   * <p>
   * Indicates that the controls selected should retain their original grouping as defined in the import source.
   *
   * @param value
   *           the as-is value to set, or {@code null} to clear
   */
  public void setAsIs(@Nullable Boolean value) {
    _asIs = value;
  }

  /**
   * Get the "{@literal Custom Grouping}".
   *
   * <p>
   * Provides an alternate grouping structure that selected controls will be placed in.
   *
   * @return the custom value, or {@code null} if not set
   */
  @Nullable
  public Custom getCustom() {
    return _custom;
  }

  /**
   * Set the "{@literal Custom Grouping}".
   *
   * <p>
   * Provides an alternate grouping structure that selected controls will be placed in.
   *
   * @param value
   *           the custom value to set, or {@code null} to clear
   */
  public void setCustom(@Nullable Custom value) {
    _custom = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * A Combine element defines how to resolve duplicate instances of the same control (e.g., controls with the same ID).
   */
  @MetaschemaAssembly(
      formalName = "Combination Rule",
      description = "A Combine element defines how to resolve duplicate instances of the same control (e.g., controls with the same ID).",
      name = "combine",
      moduleClass = OscalProfileModule.class,
      valueConstraints = @ValueConstraints(expect = @Expect(id = "oscal-profile-req-merge-combine", level = IConstraint.Level.ERROR, test = "not(@method='merge')"))
  )
  public static class Combine implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * Declare how clashing controls should be handled.
     */
    @BoundFlag(
        formalName = "Combination Method",
        description = "Declare how clashing controls should be handled.",
        name = "method",
        typeAdapter = StringAdapter.class,
        valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-profile-merge-combine-method-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "use-first", description = "Use the first definition - the first control with a given ID is used; subsequent ones are discarded"), @AllowedValue(value = "merge", description = "\\*\\*(*deprecated* )\\*\\* \\*\\*(*unspecified*)\\*\\* Merge - controls with the same ID are combined", deprecatedVersion = "1.0.1"), @AllowedValue(value = "keep", description = "Keep - controls with the same ID are kept, retaining the clash")}))
    )
    private String _method;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge.Combine} instance with no metadata.
     */
    public Combine() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge.Combine} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Combine(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Combination Method}".
     *
     * <p>
     * Declare how clashing controls should be handled.
     *
     * @return the method value, or {@code null} if not set
     */
    @Nullable
    public String getMethod() {
      return _method;
    }

    /**
     * Set the "{@literal Combination Method}".
     *
     * <p>
     * Declare how clashing controls should be handled.
     *
     * @param value
     *           the method value to set, or {@code null} to clear
     */
    public void setMethod(@Nullable String value) {
      _method = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Directs that controls appear without any grouping structure.
   */
  @MetaschemaAssembly(
      formalName = "Flat Without Grouping",
      description = "Directs that controls appear without any grouping structure.",
      name = "flat",
      moduleClass = OscalProfileModule.class
  )
  public static class Flat implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge.Flat} instance with no metadata.
     */
    public Flat() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge.Flat} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Flat(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Provides an alternate grouping structure that selected controls will be placed in.
   */
  @MetaschemaAssembly(
      formalName = "Custom Grouping",
      description = "Provides an alternate grouping structure that selected controls will be placed in.",
      name = "custom",
      moduleClass = OscalProfileModule.class,
      remarks = "The `custom` element represents a custom arrangement or organization of controls in the resolution of a catalog. This structuring directive gives the profile author the ability to define an entirely different organization of controls as compared to their source catalog(s)."
  )
  public static class Custom implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A group of (selected) controls or of groups of controls.
     */
    @BoundAssembly(
        formalName = "Control Group",
        description = "A group of (selected) controls or of groups of controls.",
        useName = "group",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "groups", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ProfileGroup> _groups;

    /**
     * Specifies which controls to use in the containing context.
     */
    @BoundAssembly(
        formalName = "Insert Controls",
        description = "Specifies which controls to use in the containing context.",
        useName = "insert-controls",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "insert-controls", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<InsertControls> _insertControls;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge.Custom} instance with no metadata.
     */
    public Custom() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Merge.Custom} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Custom(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Control Group}".
     *
     * <p>
     * A group of (selected) controls or of groups of controls.
     *
     * @return the group value
     */
    @NonNull
    public List<ProfileGroup> getGroups() {
      if (_groups == null) {
        _groups = new LinkedList<>();
      }
      return ObjectUtils.notNull(_groups);
    }

    /**
     * Set the "{@literal Control Group}".
     *
     * <p>
     * A group of (selected) controls or of groups of controls.
     *
     * @param value
     *           the group value to set
     */
    public void setGroups(@NonNull List<ProfileGroup> value) {
      _groups = value;
    }

    /**
     * Add a new {@link ProfileGroup} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addGroup(ProfileGroup item) {
      ProfileGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_groups == null) {
        _groups = new LinkedList<>();
      }
      return _groups.add(value);
    }

    /**
     * Remove the first matching {@link ProfileGroup} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeGroup(ProfileGroup item) {
      ProfileGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _groups != null && _groups.remove(value);
    }

    /**
     * Get the "{@literal Insert Controls}".
     *
     * <p>
     * Specifies which controls to use in the containing context.
     *
     * @return the insert-controls value
     */
    @NonNull
    public List<InsertControls> getInsertControls() {
      if (_insertControls == null) {
        _insertControls = new LinkedList<>();
      }
      return ObjectUtils.notNull(_insertControls);
    }

    /**
     * Set the "{@literal Insert Controls}".
     *
     * <p>
     * Specifies which controls to use in the containing context.
     *
     * @param value
     *           the insert-controls value to set
     */
    public void setInsertControls(@NonNull List<InsertControls> value) {
      _insertControls = value;
    }

    /**
     * Add a new {@link InsertControls} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addInsertControls(InsertControls item) {
      InsertControls value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_insertControls == null) {
        _insertControls = new LinkedList<>();
      }
      return _insertControls.add(value);
    }

    /**
     * Remove the first matching {@link InsertControls} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeInsertControls(InsertControls item) {
      InsertControls value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _insertControls != null && _insertControls.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
