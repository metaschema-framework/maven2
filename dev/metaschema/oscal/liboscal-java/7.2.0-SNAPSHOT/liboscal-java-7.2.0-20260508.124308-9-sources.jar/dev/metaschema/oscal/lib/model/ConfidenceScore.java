// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DecimalAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
 */
@MetaschemaAssembly(
    formalName = "Confidence Score",
    description = "This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.",
    name = "confidence-score",
    moduleClass = OscalMappingCommonModule.class
)
public class ConfidenceScore implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  @BoundField(
      useName = "category",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, target = ".[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]", allowOthers = true, values = {@AllowedValue(value = "unspecified", description = "No category is specified for the confidence score."), @AllowedValue(value = "high", description = "High confidence in the mapping."), @AllowedValue(value = "medium", description = "Medium confidence in the mapping."), @AllowedValue(value = "low", description = "Low confidence in the mapping.")}))
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private String _category;

  /**
   * A decimal value from 0-1, representing a percentage.
   */
  @BoundField(
      formalName = "Percentage",
      description = "A decimal value from 0-1, representing a percentage.",
      useName = "percentage",
      typeAdapter = DecimalAdapter.class
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private BigDecimal _percentage;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ConfidenceScore} instance with no metadata.
   */
  public ConfidenceScore() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ConfidenceScore} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ConfidenceScore(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the {@code category} property.
   *
   * @return the category value, or {@code null} if not set
   */
  @Nullable
  public String getCategory() {
    return _category;
  }

  /**
   * Set the {@code category} property.
   *
   * @param value
   *           the category value to set, or {@code null} to clear
   */
  public void setCategory(@Nullable String value) {
    _category = value;
  }

  /**
   * Get the "{@literal Percentage}".
   *
   * <p>
   * A decimal value from 0-1, representing a percentage.
   *
   * @return the percentage value, or {@code null} if not set
   */
  @Nullable
  public BigDecimal getPercentage() {
    return _percentage;
  }

  /**
   * Set the "{@literal Percentage}".
   *
   * <p>
   * A decimal value from 0-1, representing a percentage.
   *
   * @param value
   *           the percentage value to set, or {@code null} to clear
   */
  public void setPercentage(@Nullable BigDecimal value) {
    _percentage = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
