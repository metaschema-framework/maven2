// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.databind.IBindingContext;
import dev.metaschema.databind.model.AbstractBoundModule;
import dev.metaschema.databind.model.IBoundModule;
import dev.metaschema.databind.model.annotations.MetaschemaModule;
import java.net.URI;
import java.util.List;

/**
 * OSCAL Assessment Layer Format -- Common Modules
 * <p>This contains all modules common to the assessment plan, assessment results, and POAM models.</p>
 * <p>The root of the OSCAL Assessment Plan format is <code>assessment-plan</code>.</p>
 * <p>The root of the OSCAL Assessment Results format is <code>assessment-results</code>.</p>
 * <p>The root of the OSCAL Plan of Action and Milestones (POA&amp;M) format is <code>plan-of-action-and-milestones</code>.</p>
 */
@MetaschemaModule(
    fields = ThreatId.class,
    assemblies = {
        ImportSsp.class,
        LocalObjective.class,
        AssessmentMethod.class,
        Activity.class,
        Task.class,
        ReviewedControls.class,
        AssessmentCommonSelectControlById.class,
        SelectObjectiveById.class,
        AssessmentSubjectPlaceholder.class,
        AssessmentSubject.class,
        SelectSubjectById.class,
        SubjectReference.class,
        AssessmentAssets.class,
        FindingTarget.class,
        Finding.class,
        RelatedObservation.class,
        AssociatedRisk.class,
        Observation.class,
        Origin.class,
        OriginActor.class,
        RelatedTask.class,
        Risk.class,
        LoggedBy.class,
        Characterization.class,
        Response.class,
        AssessmentPart.class
    },
    imports = {
        OscalControlCommonModule.class,
        OscalImplementationCommonModule.class
    },
    remarks = "This contains all modules common to the assessment plan, assessment results, and POAM models.\n"
            + "\n"
            + "The root of the OSCAL Assessment Plan format is `assessment-plan`.\n"
            + "\n"
            + "The root of the OSCAL Assessment Results format is `assessment-results`.\n"
            + "\n"
            + "The root of the OSCAL Plan of Action and Milestones (POA\\&M) format is `plan-of-action-and-milestones`."
)
public final class OscalAssessmentCommonModule extends AbstractBoundModule {
  private static final MarkupLine NAME = MarkupLine.fromMarkdown("OSCAL Assessment Layer Format -- Common Modules");

  private static final String SHORT_NAME = "oscal-assessment-common";

  private static final String VERSION = "1.2.1";

  private static final URI XML_NAMESPACE = URI.create("http://csrc.nist.gov/ns/oscal/1.0");

  private static final URI JSON_BASE_URI = URI.create("http://csrc.nist.gov/ns/oscal");

  private static final MarkupMultiline REMARKS = MarkupMultiline.fromMarkdown("This contains all modules common to the assessment plan, assessment results, and POAM models.\n"
      + "\n"
      + "The root of the OSCAL Assessment Plan format is `assessment-plan`.\n"
      + "\n"
      + "The root of the OSCAL Assessment Results format is `assessment-results`.\n"
      + "\n"
      + "The root of the OSCAL Plan of Action and Milestones (POA\\&M) format is `plan-of-action-and-milestones`.");

  /**
   * Construct a new module instance.
   *
   * @param importedModules
   *           modules imported by this module
   * @param bindingContext
   *           the binding context to associate with this module
   */
  public OscalAssessmentCommonModule(List<? extends IBoundModule> importedModules,
      IBindingContext bindingContext) {
    super(importedModules, bindingContext);
  }

  @Override
  public MarkupLine getName() {
    return NAME;
  }

  @Override
  public String getShortName() {
    return SHORT_NAME;
  }

  @Override
  public String getVersion() {
    return VERSION;
  }

  @Override
  public URI getXmlNamespace() {
    return XML_NAMESPACE;
  }

  @Override
  public URI getJsonBaseUri() {
    return JSON_BASE_URI;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return REMARKS;
  }
}
