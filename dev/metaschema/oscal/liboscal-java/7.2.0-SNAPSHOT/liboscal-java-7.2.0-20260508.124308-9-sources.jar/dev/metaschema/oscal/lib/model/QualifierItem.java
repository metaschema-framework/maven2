// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.
 */
@MetaschemaAssembly(
    formalName = "Relationship Qualifier",
    description = "Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.",
    name = "qualifier-item",
    moduleClass = OscalMappingCommonModule.class
)
public class QualifierItem implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The focus of the qualifier.
   */
  @BoundFlag(
      formalName = "Subject",
      description = "The focus of the qualifier.",
      name = "subject",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "source", description = "This qualifier is related to the source in the mapped relationship."), @AllowedValue(value = "target", description = "This qualifier is related to the target in the mapped relationship."), @AllowedValue(value = "both", description = "This qualifier is related to both the source and target in the mapped relationship.")}))
  )
  private String _subject;

  /**
   * The predicate describes how the qualifer applies to the subject.
   */
  @BoundFlag(
      formalName = "Predicate",
      description = "The predicate describes how the qualifer applies to the subject.",
      name = "predicate",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "has-requirement", description = "The subject has a requirement that must be met for the relationship to be satisfied."), @AllowedValue(value = "has-incompatibility", description = "The subject has an incompatibility which impacts the relationship.")}))
  )
  private String _predicate;

  /**
   * The category expresses the resolvable nature of the predicate.
   */
  @BoundFlag(
      formalName = "Category",
      description = "The category expresses the resolvable nature of the predicate.",
      name = "category",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "restricted", description = "A restriction exists, and is defined in the description."), @AllowedValue(value = "addressable", description = "The qualifier is addressable, and is outlined in the description."), @AllowedValue(value = "blocked", description = "The mapping is blocked due to the reason noted in the description.")}))
  )
  private String _category;

  /**
   * Details that outline what requirements must be met, or cannot be met. If the qualifier identifies a gap, this should idenfity the gap, and any incompatibilities.
   */
  @BoundField(
      formalName = "Description of the qualifier",
      description = "Details that outline what requirements must be met, or cannot be met. If the qualifier identifies a gap, this should idenfity the gap, and any incompatibilities.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.QualifierItem} instance with no metadata.
   */
  public QualifierItem() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.QualifierItem} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public QualifierItem(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Subject}".
   *
   * <p>
   * The focus of the qualifier.
   *
   * @return the subject value
   */
  @NonNull
  public String getSubject() {
    return _subject;
  }

  /**
   * Set the "{@literal Subject}".
   *
   * <p>
   * The focus of the qualifier.
   *
   * @param value
   *           the subject value to set
   */
  public void setSubject(@NonNull String value) {
    _subject = value;
  }

  /**
   * Get the "{@literal Predicate}".
   *
   * <p>
   * The predicate describes how the qualifer applies to the subject.
   *
   * @return the predicate value
   */
  @NonNull
  public String getPredicate() {
    return _predicate;
  }

  /**
   * Set the "{@literal Predicate}".
   *
   * <p>
   * The predicate describes how the qualifer applies to the subject.
   *
   * @param value
   *           the predicate value to set
   */
  public void setPredicate(@NonNull String value) {
    _predicate = value;
  }

  /**
   * Get the "{@literal Category}".
   *
   * <p>
   * The category expresses the resolvable nature of the predicate.
   *
   * @return the category value
   */
  @NonNull
  public String getCategory() {
    return _category;
  }

  /**
   * Set the "{@literal Category}".
   *
   * <p>
   * The category expresses the resolvable nature of the predicate.
   *
   * @param value
   *           the category value to set
   */
  public void setCategory(@NonNull String value) {
    _category = value;
  }

  /**
   * Get the "{@literal Description of the qualifier}".
   *
   * <p>
   * Details that outline what requirements must be met, or cannot be met. If the qualifier identifies a gap, this should idenfity the gap, and any incompatibilities.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Description of the qualifier}".
   *
   * <p>
   * Details that outline what requirements must be met, or cannot be met. If the qualifier identifies a gap, this should idenfity the gap, and any incompatibilities.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
