// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes the operational status of the system.
 */
@MetaschemaAssembly(
    formalName = "Status",
    description = "Describes the operational status of the system.",
    name = "status",
    moduleClass = OscalSspModule.class,
    remarks = "If 'other' is selected, a remark must be included to describe the current state."
)
public class Status implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The current operating status.
   */
  @BoundFlag(
      formalName = "State",
      description = "The current operating status.",
      name = "state",
      required = true,
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-status-state-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "operational", description = "The system is currently operating in production."), @AllowedValue(value = "under-development", description = "The system is being designed, developed, or implemented"), @AllowedValue(value = "under-major-modification", description = "The system is undergoing a major change, development, or transition."), @AllowedValue(value = "disposition", description = "The system is no longer operational."), @AllowedValue(value = "other", description = "Some other state.")}))
  )
  private String _state;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Status} instance with no metadata.
   */
  public Status() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Status} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Status(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal State}".
   *
   * <p>
   * The current operating status.
   *
   * @return the state value
   */
  @NonNull
  public String getState() {
    return _state;
  }

  /**
   * Set the "{@literal State}".
   *
   * <p>
   * The current operating status.
   *
   * @param value
   *           the state value to set
   */
  public void setState(@NonNull String value) {
    _state = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
