// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A grouping of other components and/or capabilities.
 */
@MetaschemaAssembly(
    formalName = "Capability",
    description = "A grouping of other components and/or capabilities.",
    name = "capability",
    moduleClass = OscalComponentDefinitionModule.class,
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-component-definition-capability-incorporates-component", level = IConstraint.Level.ERROR, target = "incorporates-component", keyFields = @KeyField(target = "@component-uuid"), remarks = "A given `component` must not be referenced more than once within the same `capability`."))
)
public class Capability implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Provides a globally unique means to identify a given capability.
   */
  @BoundFlag(
      formalName = "Capability Identifier",
      description = "Provides a globally unique means to identify a given capability.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The capability's human-readable name.
   */
  @BoundFlag(
      formalName = "Capability Name",
      description = "The capability's human-readable name.",
      name = "name",
      required = true,
      typeAdapter = StringAdapter.class
  )
  private String _name;

  /**
   * A summary of the capability.
   */
  @BoundField(
      formalName = "Capability Description",
      description = "A summary of the capability.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * The collection of components comprising this capability.
   */
  @BoundAssembly(
      formalName = "Incorporates Component",
      description = "The collection of components comprising this capability.",
      useName = "incorporates-component",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "incorporates-components", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<IncorporatesComponent> _incorporatesComponents;

  /**
   * Defines how the component or capability supports a set of controls.
   */
  @BoundAssembly(
      formalName = "Control Implementation Set",
      description = "Defines how the component or capability supports a set of controls.",
      useName = "control-implementation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "control-implementations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ComponentControlImplementation> _controlImplementations;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Capability} instance with no metadata.
   */
  public Capability() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Capability} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Capability(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Capability Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given capability.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Capability Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given capability.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Capability Name}".
   *
   * <p>
   * The capability's human-readable name.
   *
   * @return the name value
   */
  @NonNull
  public String getName() {
    return _name;
  }

  /**
   * Set the "{@literal Capability Name}".
   *
   * <p>
   * The capability's human-readable name.
   *
   * @param value
   *           the name value to set
   */
  public void setName(@NonNull String value) {
    _name = value;
  }

  /**
   * Get the "{@literal Capability Description}".
   *
   * <p>
   * A summary of the capability.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Capability Description}".
   *
   * <p>
   * A summary of the capability.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Incorporates Component}".
   *
   * <p>
   * The collection of components comprising this capability.
   *
   * @return the incorporates-component value
   */
  @NonNull
  public List<IncorporatesComponent> getIncorporatesComponents() {
    if (_incorporatesComponents == null) {
      _incorporatesComponents = new LinkedList<>();
    }
    return ObjectUtils.notNull(_incorporatesComponents);
  }

  /**
   * Set the "{@literal Incorporates Component}".
   *
   * <p>
   * The collection of components comprising this capability.
   *
   * @param value
   *           the incorporates-component value to set
   */
  public void setIncorporatesComponents(@NonNull List<IncorporatesComponent> value) {
    _incorporatesComponents = value;
  }

  /**
   * Add a new {@link IncorporatesComponent} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addIncorporatesComponent(IncorporatesComponent item) {
    IncorporatesComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_incorporatesComponents == null) {
      _incorporatesComponents = new LinkedList<>();
    }
    return _incorporatesComponents.add(value);
  }

  /**
   * Remove the first matching {@link IncorporatesComponent} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeIncorporatesComponent(IncorporatesComponent item) {
    IncorporatesComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _incorporatesComponents != null && _incorporatesComponents.remove(value);
  }

  /**
   * Get the "{@literal Control Implementation Set}".
   *
   * <p>
   * Defines how the component or capability supports a set of controls.
   *
   * @return the control-implementation value
   */
  @NonNull
  public List<ComponentControlImplementation> getControlImplementations() {
    if (_controlImplementations == null) {
      _controlImplementations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_controlImplementations);
  }

  /**
   * Set the "{@literal Control Implementation Set}".
   *
   * <p>
   * Defines how the component or capability supports a set of controls.
   *
   * @param value
   *           the control-implementation value to set
   */
  public void setControlImplementations(@NonNull List<ComponentControlImplementation> value) {
    _controlImplementations = value;
  }

  /**
   * Add a new {@link ComponentControlImplementation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addControlImplementation(ComponentControlImplementation item) {
    ComponentControlImplementation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_controlImplementations == null) {
      _controlImplementations = new LinkedList<>();
    }
    return _controlImplementations.add(value);
  }

  /**
   * Remove the first matching {@link ComponentControlImplementation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeControlImplementation(ComponentControlImplementation item) {
    ComponentControlImplementation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _controlImplementations != null && _controlImplementations.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
