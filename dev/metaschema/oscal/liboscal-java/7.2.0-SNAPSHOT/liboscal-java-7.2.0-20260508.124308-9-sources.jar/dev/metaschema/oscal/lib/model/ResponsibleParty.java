// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
 */
@MetaschemaAssembly(
    formalName = "Responsible Party",
    description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
    name = "responsible-party",
    moduleClass = OscalMetadataModule.class,
    remarks = "A `responsible-party` requires one or more `party-uuid` references creating a strong relationship arc between the referenced `role-id` and the reference parties. This differs in semantics from `responsible-role` which doesn't require that a `party-uuid` is referenced.\n"
            + "\n"
            + "The scope of use of this object determines if the responsibility has been performed or will be performed in the future. The containing object will describe the intent.",
    valueConstraints = @ValueConstraints(indexHasKey = @IndexHasKey(id = "oscal-metadata-responsible-party-index-metadata-role-id", level = IConstraint.Level.ERROR, indexName = "index-metadata-role-id", keyFields = @KeyField(target = "@role-id")))
)
public class ResponsibleParty implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A reference to a <code>role</code> performed by a <code>party</code>.
   */
  @BoundFlag(
      formalName = "Responsible Role",
      description = "A reference to a `role` performed by a `party`.",
      name = "role-id",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _roleId;

  /**
   * Specifies one or more parties responsible for performing the associated <code>role</code>.
   */
  @BoundField(
      formalName = "Party Universally Unique Identifier Reference",
      description = "Specifies one or more parties responsible for performing the associated `role`.",
      useName = "party-uuid",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "party-uuids", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = UuidAdapter.class,
      valueConstraints = @ValueConstraints(indexHasKey = @IndexHasKey(id = "oscal-index-metadata-party-uuid", level = IConstraint.Level.ERROR, indexName = "index-metadata-party-uuid", keyFields = @KeyField))
  )
  private List<UUID> _partyUuids;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ResponsibleParty} instance with no metadata.
   */
  public ResponsibleParty() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ResponsibleParty} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ResponsibleParty(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a <code>role</code> performed by a <code>party</code>.
   *
   * @return the role-id value
   */
  @NonNull
  public String getRoleId() {
    return _roleId;
  }

  /**
   * Set the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a <code>role</code> performed by a <code>party</code>.
   *
   * @param value
   *           the role-id value to set
   */
  public void setRoleId(@NonNull String value) {
    _roleId = value;
  }

  /**
   * Get the "{@literal Party Universally Unique Identifier Reference}".
   *
   * <p>
   * Specifies one or more parties responsible for performing the associated <code>role</code>.
   *
   * @return the party-uuid value
   */
  @NonNull
  public List<UUID> getPartyUuids() {
    if (_partyUuids == null) {
      _partyUuids = new LinkedList<>();
    }
    return ObjectUtils.notNull(_partyUuids);
  }

  /**
   * Set the "{@literal Party Universally Unique Identifier Reference}".
   *
   * <p>
   * Specifies one or more parties responsible for performing the associated <code>role</code>.
   *
   * @param value
   *           the party-uuid value to set
   */
  public void setPartyUuids(@NonNull List<UUID> value) {
    _partyUuids = value;
  }

  /**
   * Add a new {@link UUID} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addPartyUuid(UUID item) {
    UUID value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_partyUuids == null) {
      _partyUuids = new LinkedList<>();
    }
    return _partyUuids.add(value);
  }

  /**
   * Remove the first matching {@link UUID} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removePartyUuid(UUID item) {
    UUID value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _partyUuids != null && _partyUuids.remove(value);
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
