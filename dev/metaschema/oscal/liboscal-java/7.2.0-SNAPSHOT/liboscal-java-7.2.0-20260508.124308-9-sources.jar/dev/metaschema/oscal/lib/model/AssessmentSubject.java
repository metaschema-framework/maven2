// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
 */
@MetaschemaAssembly(
    formalName = "Subject of Assessment",
    description = "Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.",
    name = "assessment-subject",
    moduleClass = OscalAssessmentCommonModule.class,
    remarks = "Processing of an include/exclude pair starts with processing the include, then removing matching entries in the exclude."
)
public class AssessmentSubject implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Indicates the type of assessment subject, such as a component, inventory, item, location, or party represented by this selection statement.
   */
  @BoundFlag(
      formalName = "Subject Type",
      description = "Indicates the type of assessment subject, such as a component, inventory, item, location, or party represented by this selection statement.",
      name = "type",
      required = true,
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-assessment-subject-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "component", description = "The referenced assessment subject is a component defined in the SSP, or in the `local-definitions` of an Assessment Plan or Assessment Results."), @AllowedValue(value = "inventory-item", description = "The referenced assessment subject is a inventory item defined in the SSP, or in the `local-definitions` of an Assessment Plan or Assessment Results."), @AllowedValue(value = "location", description = "The referenced assessment subject is a `location` defined in the `metadata` of the SSP, Assessment Plan, or Assessment Results."), @AllowedValue(value = "party", description = "The referenced assessment subject is a person or team to interview, who is defined as a `party` in the `metadata` of the SSP, Assessment Plan, or Assessment Results."), @AllowedValue(value = "user", description = "The referenced assessment subject is a `user` defined in the SSP, or in the `local-definitions` of an Assessment Plan or Assessment Results.")}))
  )
  private String _type;

  /**
   * A human-readable description of the collection of subjects being included in this assessment.
   */
  @BoundField(
      formalName = "Include Subjects Description",
      description = "A human-readable description of the collection of subjects being included in this assessment.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Include all controls from the imported catalog or profile resources.
   */
  @BoundAssembly(
      formalName = "Include All",
      description = "Include all controls from the imported catalog or profile resources.",
      useName = "include-all",
      minOccurs = 1
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private IncludeAll _includeAll;

  /**
   * Identifies a set of assessment subjects to include/exclude by UUID.
   */
  @BoundAssembly(
      formalName = "Select Assessment Subject",
      description = "Identifies a set of assessment subjects to include/exclude by UUID.",
      useName = "include-subject",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "include-subjects", inJson = JsonGroupAsBehavior.LIST)
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private List<SelectSubjectById> _includeSubjects;

  /**
   * Identifies a set of assessment subjects to include/exclude by UUID.
   */
  @BoundAssembly(
      formalName = "Select Assessment Subject",
      description = "Identifies a set of assessment subjects to include/exclude by UUID.",
      useName = "exclude-subject",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "exclude-subjects", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SelectSubjectById> _excludeSubjects;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentSubject} instance with no metadata.
   */
  public AssessmentSubject() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentSubject} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public AssessmentSubject(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Subject Type}".
   *
   * <p>
   * Indicates the type of assessment subject, such as a component, inventory, item, location, or party represented by this selection statement.
   *
   * @return the type value
   */
  @NonNull
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Subject Type}".
   *
   * <p>
   * Indicates the type of assessment subject, such as a component, inventory, item, location, or party represented by this selection statement.
   *
   * @param value
   *           the type value to set
   */
  public void setType(@NonNull String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Include Subjects Description}".
   *
   * <p>
   * A human-readable description of the collection of subjects being included in this assessment.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Include Subjects Description}".
   *
   * <p>
   * A human-readable description of the collection of subjects being included in this assessment.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Include All}".
   *
   * <p>
   * Include all controls from the imported catalog or profile resources.
   *
   * @return the include-all value, or {@code null} if not set
   */
  @Nullable
  public IncludeAll getIncludeAll() {
    return _includeAll;
  }

  /**
   * Set the "{@literal Include All}".
   *
   * <p>
   * Include all controls from the imported catalog or profile resources.
   *
   * @param value
   *           the include-all value to set, or {@code null} to clear
   */
  public void setIncludeAll(@Nullable IncludeAll value) {
    _includeAll = value;
  }

  /**
   * Get the "{@literal Select Assessment Subject}".
   *
   * <p>
   * Identifies a set of assessment subjects to include/exclude by UUID.
   *
   * @return the include-subject value
   */
  @NonNull
  public List<SelectSubjectById> getIncludeSubjects() {
    if (_includeSubjects == null) {
      _includeSubjects = new LinkedList<>();
    }
    return ObjectUtils.notNull(_includeSubjects);
  }

  /**
   * Set the "{@literal Select Assessment Subject}".
   *
   * <p>
   * Identifies a set of assessment subjects to include/exclude by UUID.
   *
   * @param value
   *           the include-subject value to set
   */
  public void setIncludeSubjects(@NonNull List<SelectSubjectById> value) {
    _includeSubjects = value;
  }

  /**
   * Add a new {@link SelectSubjectById} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addIncludeSubject(SelectSubjectById item) {
    SelectSubjectById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_includeSubjects == null) {
      _includeSubjects = new LinkedList<>();
    }
    return _includeSubjects.add(value);
  }

  /**
   * Remove the first matching {@link SelectSubjectById} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeIncludeSubject(SelectSubjectById item) {
    SelectSubjectById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _includeSubjects != null && _includeSubjects.remove(value);
  }

  /**
   * Get the "{@literal Select Assessment Subject}".
   *
   * <p>
   * Identifies a set of assessment subjects to include/exclude by UUID.
   *
   * @return the exclude-subject value
   */
  @NonNull
  public List<SelectSubjectById> getExcludeSubjects() {
    if (_excludeSubjects == null) {
      _excludeSubjects = new LinkedList<>();
    }
    return ObjectUtils.notNull(_excludeSubjects);
  }

  /**
   * Set the "{@literal Select Assessment Subject}".
   *
   * <p>
   * Identifies a set of assessment subjects to include/exclude by UUID.
   *
   * @param value
   *           the exclude-subject value to set
   */
  public void setExcludeSubjects(@NonNull List<SelectSubjectById> value) {
    _excludeSubjects = value;
  }

  /**
   * Add a new {@link SelectSubjectById} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addExcludeSubject(SelectSubjectById item) {
    SelectSubjectById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_excludeSubjects == null) {
      _excludeSubjects = new LinkedList<>();
    }
    return _excludeSubjects.add(value);
  }

  /**
   * Remove the first matching {@link SelectSubjectById} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeExcludeSubject(SelectSubjectById item) {
    SelectSubjectById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _excludeSubjects != null && _excludeSubjects.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
