// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A collection of relationship-based control and/or control statement mappings.
 */
@MetaschemaAssembly(
    formalName = "Mapping Collection",
    description = "A collection of relationship-based control and/or control statement mappings.",
    name = "mapping-collection",
    moduleClass = OscalMappingModule.class,
    rootName = "mapping-collection",
    remarks = "A mapping collection affirmatively declares the relationships that exist between sets of controls and/or control statements in a source and target. It is expected that inferences can be made based on what is mapped; however, no inferences should be made based on what is not mapped, since it is impossible to quantify how complete or granular a given mapping is.",
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-mapping-collection-index-metadata-scoped-role-id", formalName = "In-Scope Role Identifiers", description = "An index of role identifiers that are in-scope for the mapping-collection model.", level = IConstraint.Level.ERROR, target = "metadata/role", name = "index-imports-metadata-role-id", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-mapping-collection-index-metadata-scoped-location-uuid", level = IConstraint.Level.ERROR, target = "metadata/location", name = "index-imports-metadata-location-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-mapping-collection-index-metadata-scoped-party-uuid", level = IConstraint.Level.ERROR, target = "metadata/party", name = "index-imports-metadata-party-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-mapping-collection-index-metadata-scoped-party-organization-uuid", level = IConstraint.Level.ERROR, target = "metadata/party[@type='organization']", name = "index-imports-metadata-party-organization-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-mapping-collection-index-metadata-scoped-property-uuid", level = IConstraint.Level.ERROR, target = ".//prop[@uuid]", name = "index-imports-metadata-property-uuid", keyFields = @KeyField(target = "@uuid"))}, unique = {@IsUnique(id = "oscal-unique-document-id", formalName = "Unique Document Identifier", description = "Ensure all document identifiers have a unique combination of @scheme and value.", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-property-in-context-location", formalName = "Unique Properties", description = "Ensure all properties are unique for a given location using a unique combination of @ns, @name, @class. @group. and @value.", level = IConstraint.Level.ERROR, target = ".//prop", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-link-in-context-location", formalName = "Unique Links", description = "Ensure all links are unique for a given location using a unique combination of @href, @rel, and @media-type.", level = IConstraint.Level.ERROR, target = ".//link", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type"), @KeyField(target = "@resource-fragment")}), @IsUnique(id = "oscal-unique-responsibility-in-context-location", formalName = "Unique Responsibilities", description = "Ensure all responsible-roles and responsible-parties are unique for a given location using a unique combination of @role-id and the combination of @party-uuid values.", level = IConstraint.Level.ERROR, target = ".//(responsible-party|responsible-role)", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@role-id"), @KeyField(target = "@party-uuid")}, remarks = "Since `responsible-party` and `responsible-role` associate multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.")})
)
public class MappingCollection extends AbstractOscalInstance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A globally unique identifier with cross-instance scope for this catalog instance. This UUID should be changed when this document is revised.
   */
  @BoundFlag(
      formalName = "Mapping Collection Universally Unique Identifier",
      description = "A globally unique identifier with cross-instance scope for this catalog instance. This UUID should be changed when this document is revised.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Provides information about the containing document, and defines concepts that are shared across the document.
   */
  @BoundAssembly(
      formalName = "Document Metadata",
      description = "Provides information about the containing document, and defines concepts that are shared across the document.",
      useName = "metadata",
      minOccurs = 1
  )
  private Metadata _metadata;

  /**
   * Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.
   */
  @BoundAssembly(
      formalName = "Mapping Provenance",
      description = "Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.",
      useName = "provenance",
      minOccurs = 1
  )
  private MappingProvenance _provenance;

  /**
   * A mapping between two target resources.
   */
  @BoundAssembly(
      formalName = "Control Mapping",
      description = "A mapping between two target resources.",
      useName = "mapping",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "mappings")
  )
  private List<Mapping> _mappings;

  /**
   * A collection of resources that may be referenced from within the OSCAL document instance.
   */
  @BoundAssembly(
      formalName = "Back matter",
      description = "A collection of resources that may be referenced from within the OSCAL document instance.",
      useName = "back-matter",
      remarks = "Back matter including references and resources."
  )
  private BackMatter _backMatter;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappingCollection} instance with no metadata.
   */
  public MappingCollection() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappingCollection} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public MappingCollection(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Mapping Collection Universally Unique Identifier}".
   *
   * <p>
   * A globally unique identifier with cross-instance scope for this catalog instance. This UUID should be changed when this document is revised.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Mapping Collection Universally Unique Identifier}".
   *
   * <p>
   * A globally unique identifier with cross-instance scope for this catalog instance. This UUID should be changed when this document is revised.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @return the metadata value
   */
  @NonNull
  public Metadata getMetadata() {
    return _metadata;
  }

  /**
   * Set the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @param value
   *           the metadata value to set
   */
  public void setMetadata(@NonNull Metadata value) {
    _metadata = value;
  }

  /**
   * Get the "{@literal Mapping Provenance}".
   *
   * <p>
   * Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.
   *
   * @return the provenance value
   */
  @NonNull
  public MappingProvenance getProvenance() {
    return _provenance;
  }

  /**
   * Set the "{@literal Mapping Provenance}".
   *
   * <p>
   * Describes requirements, incompatibilities and gaps that are identified between a target and source in a mapping item.
   *
   * @param value
   *           the provenance value to set
   */
  public void setProvenance(@NonNull MappingProvenance value) {
    _provenance = value;
  }

  /**
   * Get the "{@literal Control Mapping}".
   *
   * <p>
   * A mapping between two target resources.
   *
   * @return the mapping value
   */
  @NonNull
  public List<Mapping> getMappings() {
    if (_mappings == null) {
      _mappings = new LinkedList<>();
    }
    return ObjectUtils.notNull(_mappings);
  }

  /**
   * Set the "{@literal Control Mapping}".
   *
   * <p>
   * A mapping between two target resources.
   *
   * @param value
   *           the mapping value to set
   */
  public void setMappings(@NonNull List<Mapping> value) {
    _mappings = value;
  }

  /**
   * Add a new {@link Mapping} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addMapping(Mapping item) {
    Mapping value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_mappings == null) {
      _mappings = new LinkedList<>();
    }
    return _mappings.add(value);
  }

  /**
   * Remove the first matching {@link Mapping} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeMapping(Mapping item) {
    Mapping value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _mappings != null && _mappings.remove(value);
  }

  /**
   * Get the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @return the back-matter value, or {@code null} if not set
   */
  @Nullable
  public BackMatter getBackMatter() {
    return _backMatter;
  }

  /**
   * Set the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @param value
   *           the back-matter value to set, or {@code null} to clear
   */
  public void setBackMatter(@Nullable BackMatter value) {
    _backMatter = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
