// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Let;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Designates a referenced source catalog or profile that provides a source of control information for use in creating a new overlay or baseline.
 */
@MetaschemaAssembly(
    formalName = "Import Resource",
    description = "Designates a referenced source catalog or profile that provides a source of control information for use in creating a new overlay or baseline.",
    name = "import",
    moduleClass = OscalProfileModule.class,
    remarks = "The contents of the `import` element indicate which controls from the source will be included. Controls from the source catalog or profile may be either selected, using the `include-all` or `include-controls` directives, or de-selected (using an `exclude-controls` directive).",
    valueConstraints = @ValueConstraints(lets = @Let(name = "resolved-profile-import", target = ".[@href] ! resolve-profile(doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(@href))))/catalog"), expect = @Expect(id = "oscal-profile-import-include-exclude-control-id-in-imported-catalog", formalName = "In-Scope Control Identifier", description = "Each referenced control identifier must match a control in the catalog resolved by the surrounding profile import.", level = IConstraint.Level.ERROR, target = "(include-controls|exclude-controls)/with-id", test = "let $id := . return exists($resolved-profile-import//control[@id = $id])", message = "Control identifier '{ . }' was not found in the imported catalog."))
)
public class ProfileImport implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A resolvable URL reference to the base catalog or profile that this profile is tailoring.
   */
  @BoundFlag(
      formalName = "Catalog or Profile Reference",
      description = "A resolvable URL reference to the base catalog or profile that this profile is tailoring.",
      name = "href",
      required = true,
      typeAdapter = UriReferenceAdapter.class,
      remarks = "This value may be one of:\n"
              + "\n"
              + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
              + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
              + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to a `back-matter` resource in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object))."
  )
  private URI _href;

  /**
   * Include all controls from the imported catalog or profile resources.
   */
  @BoundAssembly(
      formalName = "Include All",
      description = "Include all controls from the imported catalog or profile resources.",
      useName = "include-all",
      remarks = "Identifies that all controls are to be included from the imported catalog or profile.",
      minOccurs = 1
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private IncludeAll _includeAll;

  /**
   * Select a control or controls from an imported control set.
   */
  @BoundAssembly(
      formalName = "Select Control",
      description = "Select a control or controls from an imported control set.",
      useName = "include-controls",
      remarks = "If `with-child-controls` is \"yes\" on the call to a control, any controls appearing within it (child controls) will be selected, with no additional `call` directives required. This flag provides a way to include controls with all their dependent controls (enhancements) without having to call them individually.",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "include-controls", inJson = JsonGroupAsBehavior.LIST)
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private List<ControlCommonSelectControlById> _includeControls;

  /**
   * Select a control or controls from an imported control set.
   */
  @BoundAssembly(
      formalName = "Select Control",
      description = "Select a control or controls from an imported control set.",
      useName = "exclude-controls",
      remarks = "Identifies which controls to exclude, or eliminate, from the set of included controls by control identifier or match pattern.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "exclude-controls", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlCommonSelectControlById> _excludeControls;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ProfileImport} instance with no metadata.
   */
  public ProfileImport() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ProfileImport} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ProfileImport(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Catalog or Profile Reference}".
   *
   * <p>
   * A resolvable URL reference to the base catalog or profile that this profile is tailoring.
   *
   * @return the href value
   */
  @NonNull
  public URI getHref() {
    return _href;
  }

  /**
   * Set the "{@literal Catalog or Profile Reference}".
   *
   * <p>
   * A resolvable URL reference to the base catalog or profile that this profile is tailoring.
   *
   * @param value
   *           the href value to set
   */
  public void setHref(@NonNull URI value) {
    _href = value;
  }

  /**
   * Get the "{@literal Include All}".
   *
   * <p>
   * Include all controls from the imported catalog or profile resources.
   *
   * @return the include-all value, or {@code null} if not set
   */
  @Nullable
  public IncludeAll getIncludeAll() {
    return _includeAll;
  }

  /**
   * Set the "{@literal Include All}".
   *
   * <p>
   * Include all controls from the imported catalog or profile resources.
   *
   * @param value
   *           the include-all value to set, or {@code null} to clear
   */
  public void setIncludeAll(@Nullable IncludeAll value) {
    _includeAll = value;
  }

  /**
   * Get the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @return the include-controls value
   */
  @NonNull
  public List<ControlCommonSelectControlById> getIncludeControls() {
    if (_includeControls == null) {
      _includeControls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_includeControls);
  }

  /**
   * Set the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @param value
   *           the include-controls value to set
   */
  public void setIncludeControls(@NonNull List<ControlCommonSelectControlById> value) {
    _includeControls = value;
  }

  /**
   * Add a new {@link ControlCommonSelectControlById} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addIncludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_includeControls == null) {
      _includeControls = new LinkedList<>();
    }
    return _includeControls.add(value);
  }

  /**
   * Remove the first matching {@link ControlCommonSelectControlById} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeIncludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _includeControls != null && _includeControls.remove(value);
  }

  /**
   * Get the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @return the exclude-controls value
   */
  @NonNull
  public List<ControlCommonSelectControlById> getExcludeControls() {
    if (_excludeControls == null) {
      _excludeControls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_excludeControls);
  }

  /**
   * Set the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @param value
   *           the exclude-controls value to set
   */
  public void setExcludeControls(@NonNull List<ControlCommonSelectControlById> value) {
    _excludeControls = value;
  }

  /**
   * Add a new {@link ControlCommonSelectControlById} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addExcludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_excludeControls == null) {
      _excludeControls = new LinkedList<>();
    }
    return _excludeControls.add(value);
  }

  /**
   * Remove the first matching {@link ControlCommonSelectControlById} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeExcludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _excludeControls != null && _excludeControls.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
