// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.datatype.adapter.EmailAddressAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.XmlGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.HasCardinality;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import dev.metaschema.oscal.lib.model.metadata.AbstractMetadata;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Provides information about the containing document, and defines concepts that are shared across the document.
 */
@MetaschemaAssembly(
    formalName = "Document Metadata",
    description = "Provides information about the containing document, and defines concepts that are shared across the document.",
    name = "metadata",
    moduleClass = OscalMetadataModule.class,
    remarks = "All OSCAL documents use the same metadata structure, that provides a consistent way of expressing OSCAL document metadata across all OSCAL models. The metadata section also includes declarations of individual objects (i.e., roles, location, parties) that may be referenced within and across linked OSCAL documents.\n"
            + "\n"
            + "The metadata in an OSCAL document has few required fields, representing only the bare minimum data needed to differentiate one instance from another. Tools and users creating OSCAL documents may choose to use any of the optional fields, as well as extension mechanisms (e.g., properties, links) to go beyond this minimum to suit their use cases.\n"
            + "\n"
            + "A publisher of OSCAL content can use the `published`, `last-modified`, and `version` fields to establish information about an individual in a sequence of successive revisions of a given OSCAL-based publication. The metadata for a previous revision can be represented as a `revision` within this object. Links may also be provided using the `predecessor-version` and `successor-version` link relations to provide for direct access to the related resource. These relations can be provided as a link child of this object or as `link` within a given `revision`.\n"
            + "\n"
            + "A `responsible-party` entry in this context refers to roles and parties that have responsibility relative to the production, review, publication, and use of the containing document.",
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-metadata-responsible-party-role-ids", level = IConstraint.Level.ERROR, target = "responsible-party/@role-id", allowOthers = true, values = {@AllowedValue(value = "creator", description = "Indicates the person or organization that created this content."), @AllowedValue(value = "prepared-by", description = "Indicates the person or organization that prepared this content."), @AllowedValue(value = "prepared-for", description = "Indicates the person or organization for which this content was created."), @AllowedValue(value = "content-approver", description = "Indicates the person or organization responsible for all content represented in the \"document\"."), @AllowedValue(value = "contact", description = "Indicates the person or organization to contact for questions or support related to this content.")}), @AllowedValues(id = "oscal-metadata-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "keywords", description = "The value identifies a comma-seperated listing of keywords associated with this content. These keywords may be used as search terms for indexing and other applications.")), @AllowedValues(id = "oscal-metadata-link-rel-values", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = {@AllowedValue(value = "canonical", description = "The link identifies the authoritative location for this resource. Defined by [RFC 6596](https://tools.ietf.org/html/rfc6596)."), @AllowedValue(value = "alternate", description = "The link identifies an alternative location or format for this resource. Defined by [the HTML Living Standard](https://html.spec.whatwg.org/multipage/links.html#linkTypes)"), @AllowedValue(value = "latest-version", description = "This link identifies a resource containing the latest version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829)."), @AllowedValue(value = "predecessor-version", description = "This link identifies a resource containing the predecessor version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829)."), @AllowedValue(value = "successor-version", description = "This link identifies a resource containing the predecessor version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829).")}), @AllowedValues(id = "oscal-metadata-allowed-roles", formalName = "Standard Role Identifiers", description = "The values provided here represent standardized role identifiers for common roles.", level = IConstraint.Level.ERROR, target = "responsible-party/@role-id", allowOthers = true, values = {@AllowedValue(value = "creator", description = "Indicates the organization that created this content."), @AllowedValue(value = "prepared-by", description = "Indicates the organization that prepared this content."), @AllowedValue(value = "prepared-for", description = "Indicates the organization for which this content was created."), @AllowedValue(value = "content-approver", description = "Indicates the organization responsible for all content represented in the \"document\"."), @AllowedValue(value = "contact", description = "Indicates the organization to contact for questions or support related to this content.")}), @AllowedValues(id = "oscal-metadata-allowed-props", formalName = "Metadata Keywords Property", level = IConstraint.Level.ERROR, target = "prop[not(@ns) or @ns='http://csrc.nist.gov/ns/oscal']/@name", values = @AllowedValue(value = "keywords", description = "The value identifies a comma-separated listing of keywords associated with this content. These keywords may be used as search terms for indexing and other applications.")), @AllowedValues(id = "oscal-allowed-link-rels", formalName = "Standard Metadata Link Relations", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = {@AllowedValue(value = "canonical", description = "The link identifies the authoritative location for this file. Defined by [RFC 6596](https://tools.ietf.org/html/rfc6596)."), @AllowedValue(value = "alternate", description = "The link identifies an alternative location or format for this file. Defined by [the HTML Living Standard](https://html.spec.whatwg.org/multipage/links.html#linkTypes)"), @AllowedValue(value = "latest-version", description = "This link identifies a resource containing the latest version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829)."), @AllowedValue(value = "predecessor-version", description = "This link identifies a resource containing the predecessor version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829)."), @AllowedValue(value = "successor-version", description = "This link identifies a resource containing the predecessor version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829).")})}),
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-index-metadata-roles", level = IConstraint.Level.ERROR, target = "role", name = "index-metadata-role-ids", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-index-metadata-property-uuid", level = IConstraint.Level.ERROR, target = ".//prop", name = "index-metadata-property-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-index-metadata-role-id", level = IConstraint.Level.ERROR, target = "role", name = "index-metadata-role-id", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-index-metadata-location-uuid", level = IConstraint.Level.ERROR, target = "location", name = "index-metadata-location-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-index-metadata-party-uuid", level = IConstraint.Level.ERROR, target = "party", name = "index-metadata-party-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-index-metadata-party-organizations-uuid", level = IConstraint.Level.ERROR, target = "party[@type='organization']", name = "index-metadata-party-organizations-uuid", keyFields = @KeyField(target = "@uuid"))}, unique = {@IsUnique(id = "oscal-unique-metadata-doc-id", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-metadata-property", level = IConstraint.Level.ERROR, target = "prop", keyFields = {@KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-metadata-link", level = IConstraint.Level.ERROR, target = "link", keyFields = {@KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type")}), @IsUnique(id = "oscal-unique-metadata-responsible-party", level = IConstraint.Level.ERROR, target = "responsible-party", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-party` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."), @IsUnique(id = "oscal-metadata-unique-document-id", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}, remarks = "The combination of `scheme` and the field value must be unique.")})
)
public class Metadata extends AbstractMetadata implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A name given to the document, which may be used by a tool for display and navigation.
   */
  @BoundField(
      formalName = "Document Title",
      description = "A name given to the document, which may be used by a tool for display and navigation.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * The date and time the document was last made available.
   */
  @BoundField(
      formalName = "Publication Timestamp",
      description = "The date and time the document was last made available.",
      useName = "published",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _published;

  /**
   * The date and time the document was last stored for later retrieval.
   */
  @BoundField(
      formalName = "Last Modified Timestamp",
      description = "The date and time the document was last stored for later retrieval.",
      useName = "last-modified",
      minOccurs = 1,
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _lastModified;

  /**
   * Used to distinguish a specific revision of an OSCAL document from other previous and future versions.
   */
  @BoundField(
      formalName = "Document Version",
      description = "Used to distinguish a specific revision of an OSCAL document from other previous and future versions.",
      useName = "version",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _version;

  /**
   * The OSCAL model version the document was authored against and will conform to as valid.
   */
  @BoundField(
      formalName = "OSCAL Version",
      description = "The OSCAL model version the document was authored against and will conform to as valid.",
      useName = "oscal-version",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _oscalVersion;

  /**
   * An entry in a sequential list of revisions to the containing document, expected to be in reverse chronological order (i.e. latest first).
   */
  @BoundAssembly(
      formalName = "Revision History Entry",
      description = "An entry in a sequential list of revisions to the containing document, expected to be in reverse chronological order (i.e. latest first).",
      useName = "revision",
      remarks = "While `published`, `last-modified`, and `oscal-version` are not required, values for these entries should be provided if the information is known. A `link` with a `rel` of \"source\" should be provided if the information is known.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "revisions", inJson = JsonGroupAsBehavior.LIST, inXml = XmlGroupAsBehavior.GROUPED)
  )
  private List<Revision> _revisions;

  /**
   * A document identifier qualified by an identifier <code>scheme</code>.
   */
  @BoundField(
      formalName = "Document Identifier",
      description = "A document identifier qualified by an identifier `scheme`.",
      useName = "document-id",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "document-ids", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<DocumentId> _documentIds;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Defines a function, which might be assigned to a party in a specific situation.
   */
  @BoundAssembly(
      formalName = "Role",
      description = "Defines a function, which might be assigned to a party in a specific situation.",
      useName = "role",
      remarks = "Permissible values to be determined closer to the application (e.g. by a receiving authority).\n"
              + "\n"
              + "OSCAL has defined a set of standardized roles for consistent use in OSCAL documents. This allows tools consuming OSCAL content to infer specific semantics when these roles are used. These roles are documented in the specific contexts of their use (e.g., responsible-party, responsible-role). When using such a role, it is necessary to define these roles in this list, which will then allow such a role to be referenced.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "roles", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Role> _roles;

  /**
   * A physical point of presence, which may be associated with people, organizations, or other concepts within the current or linked OSCAL document.
   */
  @BoundAssembly(
      formalName = "Location",
      description = "A physical point of presence, which may be associated with people, organizations, or other concepts within the current or linked OSCAL document.",
      useName = "location",
      remarks = "An address might be sensitive in nature. In such cases a title, mailing address, email-address, and/or phone number may be used instead.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "locations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Location> _locations;

  /**
   * An organization or person, which may be associated with roles or other concepts within the current or linked OSCAL document.
   */
  @BoundAssembly(
      formalName = "Party",
      description = "An organization or person, which may be associated with roles or other concepts within the current or linked OSCAL document.",
      useName = "party",
      remarks = "A party can be optionally associated with either an address or a location. While providing a meaningful location for a party is desired, there are some cases where it might not be possible to provide an exact location or even any location.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "parties", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Party> _parties;

  /**
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   */
  @BoundAssembly(
      formalName = "Responsible Party",
      description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
      useName = "responsible-party",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleParty> _responsibleParties;

  /**
   * An action applied by a role within a given party to the content.
   */
  @BoundAssembly(
      formalName = "Action",
      description = "An action applied by a role within a given party to the content.",
      useName = "action",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "actions", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Action> _actions;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata} instance with no metadata.
   */
  public Metadata() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Metadata(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Document Title}".
   *
   * <p>
   * A name given to the document, which may be used by a tool for display and navigation.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Document Title}".
   *
   * <p>
   * A name given to the document, which may be used by a tool for display and navigation.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Publication Timestamp}".
   *
   * <p>
   * The date and time the document was last made available.
   *
   * @return the published value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getPublished() {
    return _published;
  }

  /**
   * Set the "{@literal Publication Timestamp}".
   *
   * <p>
   * The date and time the document was last made available.
   *
   * @param value
   *           the published value to set, or {@code null} to clear
   */
  public void setPublished(@Nullable ZonedDateTime value) {
    _published = value;
  }

  /**
   * Get the "{@literal Last Modified Timestamp}".
   *
   * <p>
   * The date and time the document was last stored for later retrieval.
   *
   * @return the last-modified value
   */
  @NonNull
  public ZonedDateTime getLastModified() {
    return _lastModified;
  }

  /**
   * Set the "{@literal Last Modified Timestamp}".
   *
   * <p>
   * The date and time the document was last stored for later retrieval.
   *
   * @param value
   *           the last-modified value to set
   */
  public void setLastModified(@NonNull ZonedDateTime value) {
    _lastModified = value;
  }

  /**
   * Get the "{@literal Document Version}".
   *
   * <p>
   * Used to distinguish a specific revision of an OSCAL document from other previous and future versions.
   *
   * @return the version value
   */
  @NonNull
  public String getVersion() {
    return _version;
  }

  /**
   * Set the "{@literal Document Version}".
   *
   * <p>
   * Used to distinguish a specific revision of an OSCAL document from other previous and future versions.
   *
   * @param value
   *           the version value to set
   */
  public void setVersion(@NonNull String value) {
    _version = value;
  }

  /**
   * Get the "{@literal OSCAL Version}".
   *
   * <p>
   * The OSCAL model version the document was authored against and will conform to as valid.
   *
   * @return the oscal-version value
   */
  @NonNull
  public String getOscalVersion() {
    return _oscalVersion;
  }

  /**
   * Set the "{@literal OSCAL Version}".
   *
   * <p>
   * The OSCAL model version the document was authored against and will conform to as valid.
   *
   * @param value
   *           the oscal-version value to set
   */
  public void setOscalVersion(@NonNull String value) {
    _oscalVersion = value;
  }

  /**
   * Get the "{@literal Revision History Entry}".
   *
   * <p>
   * An entry in a sequential list of revisions to the containing document, expected to be in reverse chronological order (i.e. latest first).
   *
   * @return the revision value
   */
  @NonNull
  public List<Revision> getRevisions() {
    if (_revisions == null) {
      _revisions = new LinkedList<>();
    }
    return ObjectUtils.notNull(_revisions);
  }

  /**
   * Set the "{@literal Revision History Entry}".
   *
   * <p>
   * An entry in a sequential list of revisions to the containing document, expected to be in reverse chronological order (i.e. latest first).
   *
   * @param value
   *           the revision value to set
   */
  public void setRevisions(@NonNull List<Revision> value) {
    _revisions = value;
  }

  /**
   * Add a new {@link Revision} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRevision(Revision item) {
    Revision value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_revisions == null) {
      _revisions = new LinkedList<>();
    }
    return _revisions.add(value);
  }

  /**
   * Remove the first matching {@link Revision} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRevision(Revision item) {
    Revision value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _revisions != null && _revisions.remove(value);
  }

  /**
   * Get the "{@literal Document Identifier}".
   *
   * <p>
   * A document identifier qualified by an identifier <code>scheme</code>.
   *
   * @return the document-id value
   */
  @NonNull
  public List<DocumentId> getDocumentIds() {
    if (_documentIds == null) {
      _documentIds = new LinkedList<>();
    }
    return ObjectUtils.notNull(_documentIds);
  }

  /**
   * Set the "{@literal Document Identifier}".
   *
   * <p>
   * A document identifier qualified by an identifier <code>scheme</code>.
   *
   * @param value
   *           the document-id value to set
   */
  public void setDocumentIds(@NonNull List<DocumentId> value) {
    _documentIds = value;
  }

  /**
   * Add a new {@link DocumentId} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addDocumentId(DocumentId item) {
    DocumentId value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_documentIds == null) {
      _documentIds = new LinkedList<>();
    }
    return _documentIds.add(value);
  }

  /**
   * Remove the first matching {@link DocumentId} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeDocumentId(DocumentId item) {
    DocumentId value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _documentIds != null && _documentIds.remove(value);
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Role}".
   *
   * <p>
   * Defines a function, which might be assigned to a party in a specific situation.
   *
   * @return the role value
   */
  @NonNull
  public List<Role> getRoles() {
    if (_roles == null) {
      _roles = new LinkedList<>();
    }
    return ObjectUtils.notNull(_roles);
  }

  /**
   * Set the "{@literal Role}".
   *
   * <p>
   * Defines a function, which might be assigned to a party in a specific situation.
   *
   * @param value
   *           the role value to set
   */
  public void setRoles(@NonNull List<Role> value) {
    _roles = value;
  }

  /**
   * Add a new {@link Role} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRole(Role item) {
    Role value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_roles == null) {
      _roles = new LinkedList<>();
    }
    return _roles.add(value);
  }

  /**
   * Remove the first matching {@link Role} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRole(Role item) {
    Role value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _roles != null && _roles.remove(value);
  }

  /**
   * Get the "{@literal Location}".
   *
   * <p>
   * A physical point of presence, which may be associated with people, organizations, or other concepts within the current or linked OSCAL document.
   *
   * @return the location value
   */
  @NonNull
  public List<Location> getLocations() {
    if (_locations == null) {
      _locations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_locations);
  }

  /**
   * Set the "{@literal Location}".
   *
   * <p>
   * A physical point of presence, which may be associated with people, organizations, or other concepts within the current or linked OSCAL document.
   *
   * @param value
   *           the location value to set
   */
  public void setLocations(@NonNull List<Location> value) {
    _locations = value;
  }

  /**
   * Add a new {@link Location} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLocation(Location item) {
    Location value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_locations == null) {
      _locations = new LinkedList<>();
    }
    return _locations.add(value);
  }

  /**
   * Remove the first matching {@link Location} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLocation(Location item) {
    Location value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _locations != null && _locations.remove(value);
  }

  /**
   * Get the "{@literal Party}".
   *
   * <p>
   * An organization or person, which may be associated with roles or other concepts within the current or linked OSCAL document.
   *
   * @return the party value
   */
  @NonNull
  public List<Party> getParties() {
    if (_parties == null) {
      _parties = new LinkedList<>();
    }
    return ObjectUtils.notNull(_parties);
  }

  /**
   * Set the "{@literal Party}".
   *
   * <p>
   * An organization or person, which may be associated with roles or other concepts within the current or linked OSCAL document.
   *
   * @param value
   *           the party value to set
   */
  public void setParties(@NonNull List<Party> value) {
    _parties = value;
  }

  /**
   * Add a new {@link Party} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addParty(Party item) {
    Party value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_parties == null) {
      _parties = new LinkedList<>();
    }
    return _parties.add(value);
  }

  /**
   * Remove the first matching {@link Party} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeParty(Party item) {
    Party value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _parties != null && _parties.remove(value);
  }

  /**
   * Get the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @return the responsible-party value
   */
  @NonNull
  public List<ResponsibleParty> getResponsibleParties() {
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleParties);
  }

  /**
   * Set the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @param value
   *           the responsible-party value to set
   */
  public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
    _responsibleParties = value;
  }

  /**
   * Add a new {@link ResponsibleParty} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return _responsibleParties.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleParties != null && _responsibleParties.remove(value);
  }

  /**
   * Get the "{@literal Action}".
   *
   * <p>
   * An action applied by a role within a given party to the content.
   *
   * @return the action value
   */
  @NonNull
  public List<Action> getActions() {
    if (_actions == null) {
      _actions = new LinkedList<>();
    }
    return ObjectUtils.notNull(_actions);
  }

  /**
   * Set the "{@literal Action}".
   *
   * <p>
   * An action applied by a role within a given party to the content.
   *
   * @param value
   *           the action value to set
   */
  public void setActions(@NonNull List<Action> value) {
    _actions = value;
  }

  /**
   * Add a new {@link Action} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAction(Action item) {
    Action value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_actions == null) {
      _actions = new LinkedList<>();
    }
    return _actions.add(value);
  }

  /**
   * Remove the first matching {@link Action} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAction(Action item) {
    Action value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _actions != null && _actions.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * An entry in a sequential list of revisions to the containing document, expected to be in reverse chronological order (i.e. latest first).
   */
  @MetaschemaAssembly(
      formalName = "Revision History Entry",
      description = "An entry in a sequential list of revisions to the containing document, expected to be in reverse chronological order (i.e. latest first).",
      name = "revision",
      moduleClass = OscalMetadataModule.class,
      remarks = "While `published`, `last-modified`, and `oscal-version` are not required, values for these entries should be provided if the information is known. A `link` with a `rel` of \"source\" should be provided if the information is known.",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-revision-link-rel-types", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = {@AllowedValue(value = "canonical", description = "The link identifies the authoritative location for this resource. Defined by [RFC 6596](https://tools.ietf.org/html/rfc6596)."), @AllowedValue(value = "alternate", description = "The link identifies an alternative location or format for this resource. Defined by [the HTML Living Standard](https://html.spec.whatwg.org/multipage/links.html#linkTypes)"), @AllowedValue(value = "predecessor-version", description = "This link identifies a resource containing the predecessor version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829)."), @AllowedValue(value = "successor-version", description = "This link identifies a resource containing the predecessor version in the version history. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829)."), @AllowedValue(value = "version-history", description = "This link identifies a resource containing the version history of this document. Defined by [RFC 5829](https://tools.ietf.org/html/rfc5829).")}))
  )
  public static class Revision implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A name given to the document revision, which may be used by a tool for display and navigation.
     */
    @BoundField(
        formalName = "Document Title",
        description = "A name given to the document revision, which may be used by a tool for display and navigation.",
        useName = "title",
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * The date and time the document was last made available.
     */
    @BoundField(
        formalName = "Publication Timestamp",
        description = "The date and time the document was last made available.",
        useName = "published",
        typeAdapter = DateTimeWithTZAdapter.class
    )
    private ZonedDateTime _published;

    /**
     * The date and time the document was last stored for later retrieval.
     */
    @BoundField(
        formalName = "Last Modified Timestamp",
        description = "The date and time the document was last stored for later retrieval.",
        useName = "last-modified",
        typeAdapter = DateTimeWithTZAdapter.class
    )
    private ZonedDateTime _lastModified;

    /**
     * Used to distinguish a specific revision of an OSCAL document from other previous and future versions.
     */
    @BoundField(
        formalName = "Document Version",
        description = "Used to distinguish a specific revision of an OSCAL document from other previous and future versions.",
        useName = "version",
        minOccurs = 1,
        typeAdapter = StringAdapter.class
    )
    private String _version;

    /**
     * The OSCAL model version the document was authored against and will conform to as valid.
     */
    @BoundField(
        formalName = "OSCAL Version",
        description = "The OSCAL model version the document was authored against and will conform to as valid.",
        useName = "oscal-version",
        typeAdapter = StringAdapter.class
    )
    private String _oscalVersion;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Revision} instance with no metadata.
     */
    public Revision() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Revision} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Revision(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Document Title}".
     *
     * <p>
     * A name given to the document revision, which may be used by a tool for display and navigation.
     *
     * @return the title value, or {@code null} if not set
     */
    @Nullable
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal Document Title}".
     *
     * <p>
     * A name given to the document revision, which may be used by a tool for display and navigation.
     *
     * @param value
     *           the title value to set, or {@code null} to clear
     */
    public void setTitle(@Nullable MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Publication Timestamp}".
     *
     * <p>
     * The date and time the document was last made available.
     *
     * @return the published value, or {@code null} if not set
     */
    @Nullable
    public ZonedDateTime getPublished() {
      return _published;
    }

    /**
     * Set the "{@literal Publication Timestamp}".
     *
     * <p>
     * The date and time the document was last made available.
     *
     * @param value
     *           the published value to set, or {@code null} to clear
     */
    public void setPublished(@Nullable ZonedDateTime value) {
      _published = value;
    }

    /**
     * Get the "{@literal Last Modified Timestamp}".
     *
     * <p>
     * The date and time the document was last stored for later retrieval.
     *
     * @return the last-modified value, or {@code null} if not set
     */
    @Nullable
    public ZonedDateTime getLastModified() {
      return _lastModified;
    }

    /**
     * Set the "{@literal Last Modified Timestamp}".
     *
     * <p>
     * The date and time the document was last stored for later retrieval.
     *
     * @param value
     *           the last-modified value to set, or {@code null} to clear
     */
    public void setLastModified(@Nullable ZonedDateTime value) {
      _lastModified = value;
    }

    /**
     * Get the "{@literal Document Version}".
     *
     * <p>
     * Used to distinguish a specific revision of an OSCAL document from other previous and future versions.
     *
     * @return the version value
     */
    @NonNull
    public String getVersion() {
      return _version;
    }

    /**
     * Set the "{@literal Document Version}".
     *
     * <p>
     * Used to distinguish a specific revision of an OSCAL document from other previous and future versions.
     *
     * @param value
     *           the version value to set
     */
    public void setVersion(@NonNull String value) {
      _version = value;
    }

    /**
     * Get the "{@literal OSCAL Version}".
     *
     * <p>
     * The OSCAL model version the document was authored against and will conform to as valid.
     *
     * @return the oscal-version value, or {@code null} if not set
     */
    @Nullable
    public String getOscalVersion() {
      return _oscalVersion;
    }

    /**
     * Set the "{@literal OSCAL Version}".
     *
     * <p>
     * The OSCAL model version the document was authored against and will conform to as valid.
     *
     * @param value
     *           the oscal-version value to set, or {@code null} to clear
     */
    public void setOscalVersion(@Nullable String value) {
      _oscalVersion = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Defines a function, which might be assigned to a party in a specific situation.
   */
  @MetaschemaAssembly(
      formalName = "Role",
      description = "Defines a function, which might be assigned to a party in a specific situation.",
      name = "role",
      moduleClass = OscalMetadataModule.class,
      remarks = "Permissible values to be determined closer to the application (e.g. by a receiving authority).\n"
              + "\n"
              + "OSCAL has defined a set of standardized roles for consistent use in OSCAL documents. This allows tools consuming OSCAL content to infer specific semantics when these roles are used. These roles are documented in the specific contexts of their use (e.g., responsible-party, responsible-role). When using such a role, it is necessary to define these roles in this list, which will then allow such a role to be referenced."
  )
  public static class Role implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A unique identifier for the role.
     */
    @BoundFlag(
        formalName = "Role Identifier",
        description = "A unique identifier for the role.",
        name = "id",
        required = true,
        typeAdapter = TokenAdapter.class
    )
    private String _id;

    /**
     * A name given to the role, which may be used by a tool for display and navigation.
     */
    @BoundField(
        formalName = "Role Title",
        description = "A name given to the role, which may be used by a tool for display and navigation.",
        useName = "title",
        minOccurs = 1,
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * A short common name, abbreviation, or acronym for the role.
     */
    @BoundField(
        formalName = "Role Short Name",
        description = "A short common name, abbreviation, or acronym for the role.",
        useName = "short-name",
        typeAdapter = StringAdapter.class
    )
    private String _shortName;

    /**
     * A summary of the role's purpose and associated responsibilities.
     */
    @BoundField(
        formalName = "Role Description",
        description = "A summary of the role's purpose and associated responsibilities.",
        useName = "description",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Role} instance with no metadata.
     */
    public Role() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Role} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Role(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Role Identifier}".
     *
     * <p>
     * A unique identifier for the role.
     *
     * @return the id value
     */
    @NonNull
    public String getId() {
      return _id;
    }

    /**
     * Set the "{@literal Role Identifier}".
     *
     * <p>
     * A unique identifier for the role.
     *
     * @param value
     *           the id value to set
     */
    public void setId(@NonNull String value) {
      _id = value;
    }

    /**
     * Get the "{@literal Role Title}".
     *
     * <p>
     * A name given to the role, which may be used by a tool for display and navigation.
     *
     * @return the title value
     */
    @NonNull
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal Role Title}".
     *
     * <p>
     * A name given to the role, which may be used by a tool for display and navigation.
     *
     * @param value
     *           the title value to set
     */
    public void setTitle(@NonNull MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Role Short Name}".
     *
     * <p>
     * A short common name, abbreviation, or acronym for the role.
     *
     * @return the short-name value, or {@code null} if not set
     */
    @Nullable
    public String getShortName() {
      return _shortName;
    }

    /**
     * Set the "{@literal Role Short Name}".
     *
     * <p>
     * A short common name, abbreviation, or acronym for the role.
     *
     * @param value
     *           the short-name value to set, or {@code null} to clear
     */
    public void setShortName(@Nullable String value) {
      _shortName = value;
    }

    /**
     * Get the "{@literal Role Description}".
     *
     * <p>
     * A summary of the role's purpose and associated responsibilities.
     *
     * @return the description value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Role Description}".
     *
     * <p>
     * A summary of the role's purpose and associated responsibilities.
     *
     * @param value
     *           the description value to set, or {@code null} to clear
     */
    public void setDescription(@Nullable MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * A physical point of presence, which may be associated with people, organizations, or other concepts within the current or linked OSCAL document.
   */
  @MetaschemaAssembly(
      formalName = "Location",
      description = "A physical point of presence, which may be associated with people, organizations, or other concepts within the current or linked OSCAL document.",
      name = "location",
      moduleClass = OscalMetadataModule.class,
      remarks = "An address might be sensitive in nature. In such cases a title, mailing address, email-address, and/or phone number may be used instead.",
      valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-metadata-location-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "type", description = "Characterizes the kind of location.")), @AllowedValues(id = "oscal-metadata-location-prop-type-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='type']/@value", allowOthers = true, values = @AllowedValue(value = "data-center", description = "A location that contains computing assets. A `class` can be used to indicate the sub-type of data-center as *primary* or *alternate*.")), @AllowedValues(id = "oscal-metadata-location-prop-type-data-center-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='type' and @value='data-center']/@class", allowOthers = true, values = {@AllowedValue(value = "primary", description = "The location is a data-center used for normal operations."), @AllowedValue(value = "alternate", description = "The location is a data-center used for fail-over or backup operations.")})}),
      modelConstraints = @AssemblyConstraints(cardinality = {@HasCardinality(id = "oscal-metadata-location-address-cardinality", description = "In most cases, it is useful to define a location. In some cases, defining an explicit location may represent a security risk.", level = IConstraint.Level.WARNING, target = "address", minOccurs = 1), @HasCardinality(id = "oscal-metadata-location-title-address-email-address-telephone-cardinality", description = "A location must have at least a title, address, email-address, or telephone number.", level = IConstraint.Level.ERROR, target = "title|address|email-address|telephone-number", minOccurs = 1)})
  )
  public static class Location implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A unique ID for the location, for reference.
     */
    @BoundFlag(
        formalName = "Location Universally Unique Identifier",
        description = "A unique ID for the location, for reference.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A name given to the location, which may be used by a tool for display and navigation.
     */
    @BoundField(
        formalName = "Location Title",
        description = "A name given to the location, which may be used by a tool for display and navigation.",
        useName = "title",
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * A postal address for the location.
     */
    @BoundAssembly(
        formalName = "Address",
        description = "A postal address for the location.",
        useName = "address",
        remarks = "The physical address of the location, which will provided for physical locations. Virtual locations can omit this data item."
    )
    private Address _address;

    /**
     * An email address as defined by <a href="https://tools.ietf.org/html/rfc5322#section-3.4.1">RFC 5322 Section 3.4.1</a>.
     */
    @BoundField(
        formalName = "Email Address",
        description = "An email address as defined by [RFC 5322 Section 3.4.1](https://tools.ietf.org/html/rfc5322#section-3.4.1).",
        useName = "email-address",
        remarks = "A contact email associated with the location.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "email-addresses", inJson = JsonGroupAsBehavior.LIST),
        typeAdapter = EmailAddressAdapter.class
    )
    private List<String> _emailAddresses;

    /**
     * A telephone service number as defined by <a href="https://www.itu.int/rec/T-REC-E.164-201011-I/en">ITU-T E.164</a>.
     */
    @BoundField(
        formalName = "Telephone Number",
        description = "A telephone service number as defined by [ITU-T E.164](https://www.itu.int/rec/T-REC-E.164-201011-I/en).",
        useName = "telephone-number",
        remarks = "A phone number used to contact the location.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "telephone-numbers", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<TelephoneNumber> _telephoneNumbers;

    /**
     * The uniform resource locator (URL) for a web site or other resource associated with the location.
     */
    @BoundField(
        formalName = "Location URL",
        description = "The uniform resource locator (URL) for a web site or other resource associated with the location.",
        useName = "url",
        remarks = "This data field is deprecated in favor of using a link with an appropriate relationship.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "urls", inJson = JsonGroupAsBehavior.LIST),
        typeAdapter = UriAdapter.class
    )
    private List<URI> _urls;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Location} instance with no metadata.
     */
    public Location() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Location} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Location(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Location Universally Unique Identifier}".
     *
     * <p>
     * A unique ID for the location, for reference.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Location Universally Unique Identifier}".
     *
     * <p>
     * A unique ID for the location, for reference.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Location Title}".
     *
     * <p>
     * A name given to the location, which may be used by a tool for display and navigation.
     *
     * @return the title value, or {@code null} if not set
     */
    @Nullable
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal Location Title}".
     *
     * <p>
     * A name given to the location, which may be used by a tool for display and navigation.
     *
     * @param value
     *           the title value to set, or {@code null} to clear
     */
    public void setTitle(@Nullable MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Address}".
     *
     * <p>
     * A postal address for the location.
     *
     * @return the address value, or {@code null} if not set
     */
    @Nullable
    public Address getAddress() {
      return _address;
    }

    /**
     * Set the "{@literal Address}".
     *
     * <p>
     * A postal address for the location.
     *
     * @param value
     *           the address value to set, or {@code null} to clear
     */
    public void setAddress(@Nullable Address value) {
      _address = value;
    }

    /**
     * Get the "{@literal Email Address}".
     *
     * <p>
     * An email address as defined by <a href="https://tools.ietf.org/html/rfc5322#section-3.4.1">RFC 5322 Section 3.4.1</a>.
     *
     * @return the email-address value
     */
    @NonNull
    public List<String> getEmailAddresses() {
      if (_emailAddresses == null) {
        _emailAddresses = new LinkedList<>();
      }
      return ObjectUtils.notNull(_emailAddresses);
    }

    /**
     * Set the "{@literal Email Address}".
     *
     * <p>
     * An email address as defined by <a href="https://tools.ietf.org/html/rfc5322#section-3.4.1">RFC 5322 Section 3.4.1</a>.
     *
     * @param value
     *           the email-address value to set
     */
    public void setEmailAddresses(@NonNull List<String> value) {
      _emailAddresses = value;
    }

    /**
     * Add a new {@link String} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addEmailAddress(String item) {
      String value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_emailAddresses == null) {
        _emailAddresses = new LinkedList<>();
      }
      return _emailAddresses.add(value);
    }

    /**
     * Remove the first matching {@link String} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeEmailAddress(String item) {
      String value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _emailAddresses != null && _emailAddresses.remove(value);
    }

    /**
     * Get the "{@literal Telephone Number}".
     *
     * <p>
     * A telephone service number as defined by <a href="https://www.itu.int/rec/T-REC-E.164-201011-I/en">ITU-T E.164</a>.
     *
     * @return the telephone-number value
     */
    @NonNull
    public List<TelephoneNumber> getTelephoneNumbers() {
      if (_telephoneNumbers == null) {
        _telephoneNumbers = new LinkedList<>();
      }
      return ObjectUtils.notNull(_telephoneNumbers);
    }

    /**
     * Set the "{@literal Telephone Number}".
     *
     * <p>
     * A telephone service number as defined by <a href="https://www.itu.int/rec/T-REC-E.164-201011-I/en">ITU-T E.164</a>.
     *
     * @param value
     *           the telephone-number value to set
     */
    public void setTelephoneNumbers(@NonNull List<TelephoneNumber> value) {
      _telephoneNumbers = value;
    }

    /**
     * Add a new {@link TelephoneNumber} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addTelephoneNumber(TelephoneNumber item) {
      TelephoneNumber value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_telephoneNumbers == null) {
        _telephoneNumbers = new LinkedList<>();
      }
      return _telephoneNumbers.add(value);
    }

    /**
     * Remove the first matching {@link TelephoneNumber} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeTelephoneNumber(TelephoneNumber item) {
      TelephoneNumber value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _telephoneNumbers != null && _telephoneNumbers.remove(value);
    }

    /**
     * Get the "{@literal Location URL}".
     *
     * <p>
     * The uniform resource locator (URL) for a web site or other resource associated with the location.
     *
     * @return the url value
     */
    @NonNull
    public List<URI> getUrls() {
      if (_urls == null) {
        _urls = new LinkedList<>();
      }
      return ObjectUtils.notNull(_urls);
    }

    /**
     * Set the "{@literal Location URL}".
     *
     * <p>
     * The uniform resource locator (URL) for a web site or other resource associated with the location.
     *
     * @param value
     *           the url value to set
     */
    public void setUrls(@NonNull List<URI> value) {
      _urls = value;
    }

    /**
     * Add a new {@link URI} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addUrl(URI item) {
      URI value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_urls == null) {
        _urls = new LinkedList<>();
      }
      return _urls.add(value);
    }

    /**
     * Remove the first matching {@link URI} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeUrl(URI item) {
      URI value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _urls != null && _urls.remove(value);
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * An organization or person, which may be associated with roles or other concepts within the current or linked OSCAL document.
   */
  @MetaschemaAssembly(
      formalName = "Party",
      description = "An organization or person, which may be associated with roles or other concepts within the current or linked OSCAL document.",
      name = "party",
      moduleClass = OscalMetadataModule.class,
      remarks = "A party can be optionally associated with either an address or a location. While providing a meaningful location for a party is desired, there are some cases where it might not be possible to provide an exact location or even any location.",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-party-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "mail-stop", description = "A mail stop associated with the party."), @AllowedValue(value = "office", description = "The name or number of the party's office."), @AllowedValue(value = "job-title", description = "The formal job title of a person.")}))
  )
  public static class Party implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A unique identifier for the party.
     */
    @BoundFlag(
        formalName = "Party Universally Unique Identifier",
        description = "A unique identifier for the party.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A category describing the kind of party the object describes.
     */
    @BoundFlag(
        formalName = "Party Type",
        description = "A category describing the kind of party the object describes.",
        name = "type",
        required = true,
        typeAdapter = StringAdapter.class,
        valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-party-type-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "person", description = "A human being regarded as an individual."), @AllowedValue(value = "organization", description = "An organized group of one or more `person` individuals with a specific purpose.")}))
    )
    private String _type;

    /**
     * The full name of the party. This is typically the legal name associated with the party.
     */
    @BoundField(
        formalName = "Party Name",
        description = "The full name of the party. This is typically the legal name associated with the party.",
        useName = "name",
        typeAdapter = StringAdapter.class
    )
    private String _name;

    /**
     * A short common name, abbreviation, or acronym for the party.
     */
    @BoundField(
        formalName = "Party Short Name",
        description = "A short common name, abbreviation, or acronym for the party.",
        useName = "short-name",
        typeAdapter = StringAdapter.class
    )
    private String _shortName;

    /**
     * An identifier for a person or organization using a designated scheme. e.g. an Open Researcher and Contributor ID (ORCID).
     */
    @BoundField(
        formalName = "Party External Identifier",
        description = "An identifier for a person or organization using a designated scheme. e.g. an Open Researcher and Contributor ID (ORCID).",
        useName = "external-id",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "external-ids", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ExternalId> _externalIds;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * An email address as defined by <a href="https://tools.ietf.org/html/rfc5322#section-3.4.1">RFC 5322 Section 3.4.1</a>.
     */
    @BoundField(
        formalName = "Email Address",
        description = "An email address as defined by [RFC 5322 Section 3.4.1](https://tools.ietf.org/html/rfc5322#section-3.4.1).",
        useName = "email-address",
        remarks = "This is a contact email associated with the party.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "email-addresses", inJson = JsonGroupAsBehavior.LIST),
        typeAdapter = EmailAddressAdapter.class
    )
    private List<String> _emailAddresses;

    /**
     * A telephone service number as defined by <a href="https://www.itu.int/rec/T-REC-E.164-201011-I/en">ITU-T E.164</a>.
     */
    @BoundField(
        formalName = "Telephone Number",
        description = "A telephone service number as defined by [ITU-T E.164](https://www.itu.int/rec/T-REC-E.164-201011-I/en).",
        useName = "telephone-number",
        remarks = "A phone number used to contact the party.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "telephone-numbers", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<TelephoneNumber> _telephoneNumbers;

    /**
     * A postal address for the location.
     */
    @BoundAssembly(
        formalName = "Address",
        description = "A postal address for the location.",
        useName = "address",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "addresses", inJson = JsonGroupAsBehavior.LIST)
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private List<Address> _addresses;

    /**
     * Reference to a location by UUID.
     */
    @BoundField(
        formalName = "Location Universally Unique Identifier Reference",
        description = "Reference to a location by UUID.",
        useName = "location-uuid",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "location-uuids", inJson = JsonGroupAsBehavior.LIST),
        typeAdapter = UuidAdapter.class,
        valueConstraints = @ValueConstraints(indexHasKey = @IndexHasKey(id = "oscal-index-metadata-location-uuid", level = IConstraint.Level.ERROR, indexName = "index-metadata-location-uuid", keyFields = @KeyField))
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private List<UUID> _locationUuids;

    /**
     * A reference to another <code>party</code> by UUID, typically an organization, that this subject is associated with.
     */
    @BoundField(
        formalName = "Organizational Affiliation",
        description = "A reference to another `party` by UUID, typically an organization, that this subject is associated with.",
        useName = "member-of-organization",
        remarks = "Since the reference target of an organizational affiliation must be another `party` (whether further qualified as person or organization) as indicated by its `uuid`. As a [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier with uniqueness across document and trans-document scope, this `uuid` value is sufficient to reference the data item locally or globally across related documents, e.g., in an imported OSCAL instance.\n"
                + "\n"
                + "Parties of both the `person` or `organization` type can be associated with an organization using the `member-of-organization`.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "member-of-organizations", inJson = JsonGroupAsBehavior.LIST),
        typeAdapter = UuidAdapter.class,
        valueConstraints = @ValueConstraints(indexHasKey = @IndexHasKey(id = "oscal-index-metadata-party-organizations-uuid", level = IConstraint.Level.ERROR, indexName = "index-metadata-party-organizations-uuid", keyFields = @KeyField))
    )
    private List<UUID> _memberOfOrganizations;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Party} instance with no metadata.
     */
    public Party() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Party} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Party(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Party Universally Unique Identifier}".
     *
     * <p>
     * A unique identifier for the party.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Party Universally Unique Identifier}".
     *
     * <p>
     * A unique identifier for the party.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Party Type}".
     *
     * <p>
     * A category describing the kind of party the object describes.
     *
     * @return the type value
     */
    @NonNull
    public String getType() {
      return _type;
    }

    /**
     * Set the "{@literal Party Type}".
     *
     * <p>
     * A category describing the kind of party the object describes.
     *
     * @param value
     *           the type value to set
     */
    public void setType(@NonNull String value) {
      _type = value;
    }

    /**
     * Get the "{@literal Party Name}".
     *
     * <p>
     * The full name of the party. This is typically the legal name associated with the party.
     *
     * @return the name value, or {@code null} if not set
     */
    @Nullable
    public String getName() {
      return _name;
    }

    /**
     * Set the "{@literal Party Name}".
     *
     * <p>
     * The full name of the party. This is typically the legal name associated with the party.
     *
     * @param value
     *           the name value to set, or {@code null} to clear
     */
    public void setName(@Nullable String value) {
      _name = value;
    }

    /**
     * Get the "{@literal Party Short Name}".
     *
     * <p>
     * A short common name, abbreviation, or acronym for the party.
     *
     * @return the short-name value, or {@code null} if not set
     */
    @Nullable
    public String getShortName() {
      return _shortName;
    }

    /**
     * Set the "{@literal Party Short Name}".
     *
     * <p>
     * A short common name, abbreviation, or acronym for the party.
     *
     * @param value
     *           the short-name value to set, or {@code null} to clear
     */
    public void setShortName(@Nullable String value) {
      _shortName = value;
    }

    /**
     * Get the "{@literal Party External Identifier}".
     *
     * <p>
     * An identifier for a person or organization using a designated scheme. e.g. an Open Researcher and Contributor ID (ORCID).
     *
     * @return the external-id value
     */
    @NonNull
    public List<ExternalId> getExternalIds() {
      if (_externalIds == null) {
        _externalIds = new LinkedList<>();
      }
      return ObjectUtils.notNull(_externalIds);
    }

    /**
     * Set the "{@literal Party External Identifier}".
     *
     * <p>
     * An identifier for a person or organization using a designated scheme. e.g. an Open Researcher and Contributor ID (ORCID).
     *
     * @param value
     *           the external-id value to set
     */
    public void setExternalIds(@NonNull List<ExternalId> value) {
      _externalIds = value;
    }

    /**
     * Add a new {@link ExternalId} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addExternalId(ExternalId item) {
      ExternalId value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_externalIds == null) {
        _externalIds = new LinkedList<>();
      }
      return _externalIds.add(value);
    }

    /**
     * Remove the first matching {@link ExternalId} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeExternalId(ExternalId item) {
      ExternalId value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _externalIds != null && _externalIds.remove(value);
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Email Address}".
     *
     * <p>
     * An email address as defined by <a href="https://tools.ietf.org/html/rfc5322#section-3.4.1">RFC 5322 Section 3.4.1</a>.
     *
     * @return the email-address value
     */
    @NonNull
    public List<String> getEmailAddresses() {
      if (_emailAddresses == null) {
        _emailAddresses = new LinkedList<>();
      }
      return ObjectUtils.notNull(_emailAddresses);
    }

    /**
     * Set the "{@literal Email Address}".
     *
     * <p>
     * An email address as defined by <a href="https://tools.ietf.org/html/rfc5322#section-3.4.1">RFC 5322 Section 3.4.1</a>.
     *
     * @param value
     *           the email-address value to set
     */
    public void setEmailAddresses(@NonNull List<String> value) {
      _emailAddresses = value;
    }

    /**
     * Add a new {@link String} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addEmailAddress(String item) {
      String value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_emailAddresses == null) {
        _emailAddresses = new LinkedList<>();
      }
      return _emailAddresses.add(value);
    }

    /**
     * Remove the first matching {@link String} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeEmailAddress(String item) {
      String value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _emailAddresses != null && _emailAddresses.remove(value);
    }

    /**
     * Get the "{@literal Telephone Number}".
     *
     * <p>
     * A telephone service number as defined by <a href="https://www.itu.int/rec/T-REC-E.164-201011-I/en">ITU-T E.164</a>.
     *
     * @return the telephone-number value
     */
    @NonNull
    public List<TelephoneNumber> getTelephoneNumbers() {
      if (_telephoneNumbers == null) {
        _telephoneNumbers = new LinkedList<>();
      }
      return ObjectUtils.notNull(_telephoneNumbers);
    }

    /**
     * Set the "{@literal Telephone Number}".
     *
     * <p>
     * A telephone service number as defined by <a href="https://www.itu.int/rec/T-REC-E.164-201011-I/en">ITU-T E.164</a>.
     *
     * @param value
     *           the telephone-number value to set
     */
    public void setTelephoneNumbers(@NonNull List<TelephoneNumber> value) {
      _telephoneNumbers = value;
    }

    /**
     * Add a new {@link TelephoneNumber} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addTelephoneNumber(TelephoneNumber item) {
      TelephoneNumber value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_telephoneNumbers == null) {
        _telephoneNumbers = new LinkedList<>();
      }
      return _telephoneNumbers.add(value);
    }

    /**
     * Remove the first matching {@link TelephoneNumber} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeTelephoneNumber(TelephoneNumber item) {
      TelephoneNumber value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _telephoneNumbers != null && _telephoneNumbers.remove(value);
    }

    /**
     * Get the "{@literal Address}".
     *
     * <p>
     * A postal address for the location.
     *
     * @return the address value
     */
    @NonNull
    public List<Address> getAddresses() {
      if (_addresses == null) {
        _addresses = new LinkedList<>();
      }
      return ObjectUtils.notNull(_addresses);
    }

    /**
     * Set the "{@literal Address}".
     *
     * <p>
     * A postal address for the location.
     *
     * @param value
     *           the address value to set
     */
    public void setAddresses(@NonNull List<Address> value) {
      _addresses = value;
    }

    /**
     * Add a new {@link Address} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addAddress(Address item) {
      Address value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_addresses == null) {
        _addresses = new LinkedList<>();
      }
      return _addresses.add(value);
    }

    /**
     * Remove the first matching {@link Address} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeAddress(Address item) {
      Address value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _addresses != null && _addresses.remove(value);
    }

    /**
     * Get the "{@literal Location Universally Unique Identifier Reference}".
     *
     * <p>
     * Reference to a location by UUID.
     *
     * @return the location-uuid value
     */
    @NonNull
    public List<UUID> getLocationUuids() {
      if (_locationUuids == null) {
        _locationUuids = new LinkedList<>();
      }
      return ObjectUtils.notNull(_locationUuids);
    }

    /**
     * Set the "{@literal Location Universally Unique Identifier Reference}".
     *
     * <p>
     * Reference to a location by UUID.
     *
     * @param value
     *           the location-uuid value to set
     */
    public void setLocationUuids(@NonNull List<UUID> value) {
      _locationUuids = value;
    }

    /**
     * Add a new {@link UUID} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLocationUuid(UUID item) {
      UUID value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_locationUuids == null) {
        _locationUuids = new LinkedList<>();
      }
      return _locationUuids.add(value);
    }

    /**
     * Remove the first matching {@link UUID} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLocationUuid(UUID item) {
      UUID value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _locationUuids != null && _locationUuids.remove(value);
    }

    /**
     * Get the "{@literal Organizational Affiliation}".
     *
     * <p>
     * A reference to another <code>party</code> by UUID, typically an organization, that this subject is associated with.
     *
     * @return the member-of-organization value
     */
    @NonNull
    public List<UUID> getMemberOfOrganizations() {
      if (_memberOfOrganizations == null) {
        _memberOfOrganizations = new LinkedList<>();
      }
      return ObjectUtils.notNull(_memberOfOrganizations);
    }

    /**
     * Set the "{@literal Organizational Affiliation}".
     *
     * <p>
     * A reference to another <code>party</code> by UUID, typically an organization, that this subject is associated with.
     *
     * @param value
     *           the member-of-organization value to set
     */
    public void setMemberOfOrganizations(@NonNull List<UUID> value) {
      _memberOfOrganizations = value;
    }

    /**
     * Add a new {@link UUID} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addMemberOfOrganization(UUID item) {
      UUID value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_memberOfOrganizations == null) {
        _memberOfOrganizations = new LinkedList<>();
      }
      return _memberOfOrganizations.add(value);
    }

    /**
     * Remove the first matching {@link UUID} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeMemberOfOrganization(UUID item) {
      UUID value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _memberOfOrganizations != null && _memberOfOrganizations.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * An identifier for a person or organization using a designated scheme. e.g. an Open Researcher and Contributor ID (ORCID).
     */
    @MetaschemaField(
        formalName = "Party External Identifier",
        description = "An identifier for a person or organization using a designated scheme. e.g. an Open Researcher and Contributor ID (ORCID).",
        name = "external-id",
        moduleClass = OscalMetadataModule.class
    )
    public static class ExternalId implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * Indicates the type of external identifier.
       */
      @BoundFlag(
          formalName = "External Identifier Schema",
          description = "Indicates the type of external identifier.",
          name = "scheme",
          required = true,
          typeAdapter = UriAdapter.class,
          remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).",
          valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-party-external-id-values", level = IConstraint.Level.ERROR, allowOthers = true, values = @AllowedValue(value = "http://orcid.org/", description = "The identifier is Open Researcher and Contributor ID (ORCID).")))
      )
      private URI _scheme;

      /**
       * The field value.
       */
      @BoundFieldValue(
          valueKeyName = "id"
      )
      private String _id;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Party.ExternalId} instance with no metadata.
       */
      public ExternalId() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Metadata.Party.ExternalId} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public ExternalId(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal External Identifier Schema}".
       *
       * <p>
       * Indicates the type of external identifier.
       *
       * @return the scheme value
       */
      @NonNull
      public URI getScheme() {
        return _scheme;
      }

      /**
       * Set the "{@literal External Identifier Schema}".
       *
       * <p>
       * Indicates the type of external identifier.
       *
       * @param value
       *           the scheme value to set
       */
      public void setScheme(@NonNull URI value) {
        _scheme = value;
      }

      /**
       * Get the field value.
       *
       * @return the value
       */
      @Nullable
      public String getId() {
        return _id;
      }

      /**
       * Set the field value.
       *
       * @param value
       *           the value to set
       */
      public void setId(@Nullable String value) {
        _id = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }
}
