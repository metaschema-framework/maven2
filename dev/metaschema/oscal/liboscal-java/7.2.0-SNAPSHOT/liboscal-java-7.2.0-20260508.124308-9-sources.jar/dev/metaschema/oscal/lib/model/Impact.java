// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * The expected level of impact resulting from the described information.
 */
@MetaschemaAssembly(
    formalName = "Impact Level",
    description = "The expected level of impact resulting from the described information.",
    name = "impact",
    moduleClass = OscalSspModule.class
)
public class Impact implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * The prescribed base (Confidentiality, Integrity, or Availability) security impact level.
   */
  @BoundField(
      formalName = "Base Level (Confidentiality, Integrity, or Availability)",
      description = "The prescribed base (Confidentiality, Integrity, or Availability) security impact level.",
      useName = "base",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _base;

  /**
   * The selected (Confidentiality, Integrity, or Availability) security impact level.
   */
  @BoundField(
      formalName = "Selected Level (Confidentiality, Integrity, or Availability)",
      description = "The selected (Confidentiality, Integrity, or Availability) security impact level.",
      useName = "selected",
      typeAdapter = StringAdapter.class
  )
  private String _selected;

  /**
   * If the selected security level is different from the base security level, this contains the justification for the change.
   */
  @BoundField(
      formalName = "Adjustment Justification",
      description = "If the selected security level is different from the base security level, this contains the justification for the change.",
      useName = "adjustment-justification",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _adjustmentJustification;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Impact} instance with no metadata.
   */
  public Impact() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Impact} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Impact(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Base Level (Confidentiality, Integrity, or Availability)}".
   *
   * <p>
   * The prescribed base (Confidentiality, Integrity, or Availability) security impact level.
   *
   * @return the base value
   */
  @NonNull
  public String getBase() {
    return _base;
  }

  /**
   * Set the "{@literal Base Level (Confidentiality, Integrity, or Availability)}".
   *
   * <p>
   * The prescribed base (Confidentiality, Integrity, or Availability) security impact level.
   *
   * @param value
   *           the base value to set
   */
  public void setBase(@NonNull String value) {
    _base = value;
  }

  /**
   * Get the "{@literal Selected Level (Confidentiality, Integrity, or Availability)}".
   *
   * <p>
   * The selected (Confidentiality, Integrity, or Availability) security impact level.
   *
   * @return the selected value, or {@code null} if not set
   */
  @Nullable
  public String getSelected() {
    return _selected;
  }

  /**
   * Set the "{@literal Selected Level (Confidentiality, Integrity, or Availability)}".
   *
   * <p>
   * The selected (Confidentiality, Integrity, or Availability) security impact level.
   *
   * @param value
   *           the selected value to set, or {@code null} to clear
   */
  public void setSelected(@Nullable String value) {
    _selected = value;
  }

  /**
   * Get the "{@literal Adjustment Justification}".
   *
   * <p>
   * If the selected security level is different from the base security level, this contains the justification for the change.
   *
   * @return the adjustment-justification value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getAdjustmentJustification() {
    return _adjustmentJustification;
  }

  /**
   * Set the "{@literal Adjustment Justification}".
   *
   * <p>
   * If the selected security level is different from the base security level, this contains the justification for the change.
   *
   * @param value
   *           the adjustment-justification value to set, or {@code null} to clear
   */
  public void setAdjustmentJustification(@Nullable MarkupMultiline value) {
    _adjustmentJustification = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
