// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A telephone service number as defined by <a href="https://www.itu.int/rec/T-REC-E.164-201011-I/en">ITU-T E.164</a>.
 */
@MetaschemaField(
    formalName = "Telephone Number",
    description = "A telephone service number as defined by [ITU-T E.164](https://www.itu.int/rec/T-REC-E.164-201011-I/en).",
    name = "telephone-number",
    moduleClass = OscalMetadataModule.class,
    valueConstraints = @ValueConstraints(matches = @Matches(id = "oscal-metadata-telephone-number-regex", level = IConstraint.Level.WARNING, pattern = "^[0-9]{3}[0-9]{1,12}$", remarks = "Providing a country code provides an international means to interpret the phone number."))
)
public class TelephoneNumber implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Indicates the type of phone number.
   */
  @BoundFlag(
      formalName = "type flag",
      description = "Indicates the type of phone number.",
      name = "type",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-telephone-number-type-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "home", description = "A home phone number."), @AllowedValue(value = "office", description = "An office phone number."), @AllowedValue(value = "mobile", description = "A mobile phone number.")}))
  )
  private String _type;

  /**
   * The field value.
   */
  @BoundFieldValue(
      valueKeyName = "number"
  )
  private String _number;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.TelephoneNumber} instance with no metadata.
   */
  public TelephoneNumber() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.TelephoneNumber} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public TelephoneNumber(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal type flag}".
   *
   * <p>
   * Indicates the type of phone number.
   *
   * @return the type value, or {@code null} if not set
   */
  @Nullable
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal type flag}".
   *
   * <p>
   * Indicates the type of phone number.
   *
   * @param value
   *           the type value to set, or {@code null} to clear
   */
  public void setType(@Nullable String value) {
    _type = value;
  }

  /**
   * Get the field value.
   *
   * @return the value
   */
  @Nullable
  public String getNumber() {
    return _number;
  }

  /**
   * Set the field value.
   *
   * @param value
   *           the value to set
   */
  public void setNumber(@Nullable String value) {
    _number = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
