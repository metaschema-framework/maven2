// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Defines how the component or capability supports a set of controls.
 */
@MetaschemaAssembly(
    formalName = "Control Implementation Set",
    description = "Defines how the component or capability supports a set of controls.",
    name = "control-implementation",
    moduleClass = OscalComponentDefinitionModule.class,
    remarks = "Use of `set-parameter` in this context, sets the parameter for all controls referenced by any `implemented-requirement` contained in this context. Any `set-parameter` defined in a child context will override this value. If not overridden by a child, this value applies in the child context.",
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-component-definition-control-implementation-set-parameter", level = IConstraint.Level.ERROR, target = "set-parameter", keyFields = @KeyField(target = "@param-id"), remarks = "Since multiple `set-parameter` entries can be provided, each parameter must be set only once."))
)
public class ComponentControlImplementation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Provides a means to identify a set of control implementations that are supported by a given component or capability.
   */
  @BoundFlag(
      formalName = "Control Implementation Set Identifier",
      description = "Provides a means to identify a set of control implementations that are supported by a given component or capability.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * A reference to an OSCAL catalog or profile providing the referenced control or subcontrol definition.
   */
  @BoundFlag(
      formalName = "Source Resource Reference",
      description = "A reference to an OSCAL catalog or profile providing the referenced control or subcontrol definition.",
      name = "source",
      required = true,
      typeAdapter = UriReferenceAdapter.class,
      remarks = "This value may be one of:\n"
              + "\n"
              + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
              + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
              + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to a `back-matter` resource in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object))."
  )
  private URI _source;

  /**
   * A description of how the specified set of controls are implemented for the containing component or capability.
   */
  @BoundField(
      formalName = "Control Implementation Description",
      description = "A description of how the specified set of controls are implemented for the containing component or capability.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the parameter that will be set by the enclosed value.
   */
  @BoundAssembly(
      formalName = "Set Parameter Value",
      description = "Identifies the parameter that will be set by the enclosed value.",
      useName = "set-parameter",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "set-parameters", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SetParameter> _setParameters;

  /**
   * Describes how the containing component or capability implements an individual control.
   */
  @BoundAssembly(
      formalName = "Control Implementation",
      description = "Describes how the containing component or capability implements an individual control.",
      useName = "implemented-requirement",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "implemented-requirements", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ComponentImplementedRequirement> _implementedRequirements;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ComponentControlImplementation} instance with no metadata.
   */
  public ComponentControlImplementation() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ComponentControlImplementation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ComponentControlImplementation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Control Implementation Set Identifier}".
   *
   * <p>
   * Provides a means to identify a set of control implementations that are supported by a given component or capability.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Control Implementation Set Identifier}".
   *
   * <p>
   * Provides a means to identify a set of control implementations that are supported by a given component or capability.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Source Resource Reference}".
   *
   * <p>
   * A reference to an OSCAL catalog or profile providing the referenced control or subcontrol definition.
   *
   * @return the source value
   */
  @NonNull
  public URI getSource() {
    return _source;
  }

  /**
   * Set the "{@literal Source Resource Reference}".
   *
   * <p>
   * A reference to an OSCAL catalog or profile providing the referenced control or subcontrol definition.
   *
   * @param value
   *           the source value to set
   */
  public void setSource(@NonNull URI value) {
    _source = value;
  }

  /**
   * Get the "{@literal Control Implementation Description}".
   *
   * <p>
   * A description of how the specified set of controls are implemented for the containing component or capability.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Control Implementation Description}".
   *
   * <p>
   * A description of how the specified set of controls are implemented for the containing component or capability.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @return the set-parameter value
   */
  @NonNull
  public List<SetParameter> getSetParameters() {
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return ObjectUtils.notNull(_setParameters);
  }

  /**
   * Set the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @param value
   *           the set-parameter value to set
   */
  public void setSetParameters(@NonNull List<SetParameter> value) {
    _setParameters = value;
  }

  /**
   * Add a new {@link SetParameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return _setParameters.add(value);
  }

  /**
   * Remove the first matching {@link SetParameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _setParameters != null && _setParameters.remove(value);
  }

  /**
   * Get the "{@literal Control Implementation}".
   *
   * <p>
   * Describes how the containing component or capability implements an individual control.
   *
   * @return the implemented-requirement value
   */
  @NonNull
  public List<ComponentImplementedRequirement> getImplementedRequirements() {
    if (_implementedRequirements == null) {
      _implementedRequirements = new LinkedList<>();
    }
    return ObjectUtils.notNull(_implementedRequirements);
  }

  /**
   * Set the "{@literal Control Implementation}".
   *
   * <p>
   * Describes how the containing component or capability implements an individual control.
   *
   * @param value
   *           the implemented-requirement value to set
   */
  public void setImplementedRequirements(@NonNull List<ComponentImplementedRequirement> value) {
    _implementedRequirements = value;
  }

  /**
   * Add a new {@link ComponentImplementedRequirement} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addImplementedRequirement(ComponentImplementedRequirement item) {
    ComponentImplementedRequirement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_implementedRequirements == null) {
      _implementedRequirements = new LinkedList<>();
    }
    return _implementedRequirements.add(value);
  }

  /**
   * Remove the first matching {@link ComponentImplementedRequirement} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeImplementedRequirement(ComponentImplementedRequirement item) {
    ComponentImplementedRequirement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _implementedRequirements != null && _implementedRequirements.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
