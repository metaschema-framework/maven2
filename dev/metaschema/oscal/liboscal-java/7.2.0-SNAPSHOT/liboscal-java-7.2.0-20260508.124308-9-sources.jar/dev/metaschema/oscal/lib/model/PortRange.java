// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.NonNegativeIntegerAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Where applicable this is the transport layer protocol port range an IPv4-based or IPv6-based service uses.
 */
@MetaschemaAssembly(
    formalName = "Port Range",
    description = "Where applicable this is the transport layer protocol port range an IPv4-based or IPv6-based service uses.",
    name = "port-range",
    moduleClass = OscalImplementationCommonModule.class,
    remarks = "To be validated as a natural number (integer \\>= 1). A single port uses the same value for start and end. Use multiple 'port-range' entries for non-contiguous ranges.",
    valueConstraints = @ValueConstraints(expect = {@Expect(id = "oscal-component-protocol-port-range-has-start", level = IConstraint.Level.WARNING, test = "exists(@start)", message = "A port range should have a start port given."), @Expect(id = "oscal-component-protocol-port-range-has-end", level = IConstraint.Level.WARNING, test = "exists(@end)", message = "A port range should have an end port given. To define a single port, the start and end should be the same value."), @Expect(id = "oscal-component-protocol-port-range-starts-before-end", level = IConstraint.Level.WARNING, test = "not(@start > @end)", message = "The port range start should not be after its end.")})
)
public class PortRange implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Indicates the starting port number in a port range for a transport layer protocol
   */
  @BoundFlag(
      formalName = "Start",
      description = "Indicates the starting port number in a port range for a transport layer protocol",
      name = "start",
      typeAdapter = NonNegativeIntegerAdapter.class,
      remarks = "Should be a number within a permitted range"
  )
  private BigInteger _start;

  /**
   * Indicates the ending port number in a port range for a transport layer protocol
   */
  @BoundFlag(
      formalName = "End",
      description = "Indicates the ending port number in a port range for a transport layer protocol",
      name = "end",
      typeAdapter = NonNegativeIntegerAdapter.class,
      remarks = "Should be a number within a permitted range"
  )
  private BigInteger _end;

  /**
   * Indicates the transport type.
   */
  @BoundFlag(
      formalName = "Transport",
      description = "Indicates the transport type.",
      name = "transport",
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-component-protocol-transport-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "TCP", description = "Transmission Control Protocol"), @AllowedValue(value = "UDP", description = "User Datagram Protocol")}))
  )
  private String _transport;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.PortRange} instance with no metadata.
   */
  public PortRange() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.PortRange} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public PortRange(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Start}".
   *
   * <p>
   * Indicates the starting port number in a port range for a transport layer protocol
   *
   * @return the start value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getStart() {
    return _start;
  }

  /**
   * Set the "{@literal Start}".
   *
   * <p>
   * Indicates the starting port number in a port range for a transport layer protocol
   *
   * @param value
   *           the start value to set, or {@code null} to clear
   */
  public void setStart(@Nullable BigInteger value) {
    _start = value;
  }

  /**
   * Get the "{@literal End}".
   *
   * <p>
   * Indicates the ending port number in a port range for a transport layer protocol
   *
   * @return the end value, or {@code null} if not set
   */
  @Nullable
  public BigInteger getEnd() {
    return _end;
  }

  /**
   * Set the "{@literal End}".
   *
   * <p>
   * Indicates the ending port number in a port range for a transport layer protocol
   *
   * @param value
   *           the end value to set, or {@code null} to clear
   */
  public void setEnd(@Nullable BigInteger value) {
    _end = value;
  }

  /**
   * Get the "{@literal Transport}".
   *
   * <p>
   * Indicates the transport type.
   *
   * @return the transport value, or {@code null} if not set
   */
  @Nullable
  public String getTransport() {
    return _transport;
  }

  /**
   * Set the "{@literal Transport}".
   *
   * <p>
   * Indicates the transport type.
   *
   * @param value
   *           the transport value to set, or {@code null} to clear
   */
  public void setTransport(@Nullable String value) {
    _transport = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
