// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes how the system satisfies a set of controls.
 */
@MetaschemaAssembly(
    formalName = "Control Implementation",
    description = "Describes how the system satisfies a set of controls.",
    name = "control-implementation",
    moduleClass = OscalSspModule.class,
    remarks = "Use of `set-parameter` in this context, sets the parameter for all controls referenced by any `implemented-requirement` contained in this context. Any `set-parameter` defined in a child context will override this value. If not overridden by a child, this value applies in the child context.",
    modelConstraints = @AssemblyConstraints(index = @Index(id = "oscal-by-component-export-provided-uuid-index", level = IConstraint.Level.ERROR, target = "implemented-requirement//by-component/export/provided", name = "by-component-export-provided-uuid", keyFields = @KeyField(target = "@uuid")), unique = @IsUnique(id = "oscal-unique-ssp-control-implementation-set-parameter", level = IConstraint.Level.ERROR, target = "set-parameter", keyFields = @KeyField(target = "@param-id"), remarks = "Since multiple `set-parameter` entries can be provided, each parameter must be set only once."))
)
public class ControlImplementation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A statement describing important things to know about how this set of control satisfaction documentation is approached.
   */
  @BoundField(
      formalName = "Control Implementation Description",
      description = "A statement describing important things to know about how this set of control satisfaction documentation is approached.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * Identifies the parameter that will be set by the enclosed value.
   */
  @BoundAssembly(
      formalName = "Set Parameter Value",
      description = "Identifies the parameter that will be set by the enclosed value.",
      useName = "set-parameter",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "set-parameters", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SetParameter> _setParameters;

  /**
   * Describes how the system satisfies the requirements of an individual control.
   */
  @BoundAssembly(
      formalName = "Control-based Requirement",
      description = "Describes how the system satisfies the requirements of an individual control.",
      useName = "implemented-requirement",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "implemented-requirements", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ImplementedRequirement> _implementedRequirements;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ControlImplementation} instance with no metadata.
   */
  public ControlImplementation() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ControlImplementation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ControlImplementation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Control Implementation Description}".
   *
   * <p>
   * A statement describing important things to know about how this set of control satisfaction documentation is approached.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Control Implementation Description}".
   *
   * <p>
   * A statement describing important things to know about how this set of control satisfaction documentation is approached.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @return the set-parameter value
   */
  @NonNull
  public List<SetParameter> getSetParameters() {
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return ObjectUtils.notNull(_setParameters);
  }

  /**
   * Set the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @param value
   *           the set-parameter value to set
   */
  public void setSetParameters(@NonNull List<SetParameter> value) {
    _setParameters = value;
  }

  /**
   * Add a new {@link SetParameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return _setParameters.add(value);
  }

  /**
   * Remove the first matching {@link SetParameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _setParameters != null && _setParameters.remove(value);
  }

  /**
   * Get the "{@literal Control-based Requirement}".
   *
   * <p>
   * Describes how the system satisfies the requirements of an individual control.
   *
   * @return the implemented-requirement value
   */
  @NonNull
  public List<ImplementedRequirement> getImplementedRequirements() {
    if (_implementedRequirements == null) {
      _implementedRequirements = new LinkedList<>();
    }
    return ObjectUtils.notNull(_implementedRequirements);
  }

  /**
   * Set the "{@literal Control-based Requirement}".
   *
   * <p>
   * Describes how the system satisfies the requirements of an individual control.
   *
   * @param value
   *           the implemented-requirement value to set
   */
  public void setImplementedRequirements(@NonNull List<ImplementedRequirement> value) {
    _implementedRequirements = value;
  }

  /**
   * Add a new {@link ImplementedRequirement} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addImplementedRequirement(ImplementedRequirement item) {
    ImplementedRequirement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_implementedRequirements == null) {
      _implementedRequirements = new LinkedList<>();
    }
    return _implementedRequirements.add(value);
  }

  /**
   * Remove the first matching {@link ImplementedRequirement} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeImplementedRequirement(ImplementedRequirement item) {
    ImplementedRequirement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _implementedRequirements != null && _implementedRequirements.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
