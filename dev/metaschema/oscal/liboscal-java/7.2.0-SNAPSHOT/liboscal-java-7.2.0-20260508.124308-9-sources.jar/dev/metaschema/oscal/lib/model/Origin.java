// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies the source of the finding, such as a tool, interviewed person, or activity.
 */
@MetaschemaAssembly(
    formalName = "Origin",
    description = "Identifies the source of the finding, such as a tool, interviewed person, or activity.",
    name = "origin",
    moduleClass = OscalAssessmentCommonModule.class
)
public class Origin implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.
   */
  @BoundAssembly(
      formalName = "Originating Actor",
      description = "The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.",
      useName = "actor",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "actors", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<OriginActor> _actors;

  /**
   * Identifies an individual task for which the containing object is a consequence of.
   */
  @BoundAssembly(
      formalName = "Task Reference",
      description = "Identifies an individual task for which the containing object is a consequence of.",
      useName = "related-task",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "related-tasks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<RelatedTask> _relatedTasks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Origin} instance with no metadata.
   */
  public Origin() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Origin} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Origin(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Originating Actor}".
   *
   * <p>
   * The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.
   *
   * @return the actor value
   */
  @NonNull
  public List<OriginActor> getActors() {
    if (_actors == null) {
      _actors = new LinkedList<>();
    }
    return ObjectUtils.notNull(_actors);
  }

  /**
   * Set the "{@literal Originating Actor}".
   *
   * <p>
   * The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.
   *
   * @param value
   *           the actor value to set
   */
  public void setActors(@NonNull List<OriginActor> value) {
    _actors = value;
  }

  /**
   * Add a new {@link OriginActor} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addActor(OriginActor item) {
    OriginActor value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_actors == null) {
      _actors = new LinkedList<>();
    }
    return _actors.add(value);
  }

  /**
   * Remove the first matching {@link OriginActor} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeActor(OriginActor item) {
    OriginActor value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _actors != null && _actors.remove(value);
  }

  /**
   * Get the "{@literal Task Reference}".
   *
   * <p>
   * Identifies an individual task for which the containing object is a consequence of.
   *
   * @return the related-task value
   */
  @NonNull
  public List<RelatedTask> getRelatedTasks() {
    if (_relatedTasks == null) {
      _relatedTasks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedTasks);
  }

  /**
   * Set the "{@literal Task Reference}".
   *
   * <p>
   * Identifies an individual task for which the containing object is a consequence of.
   *
   * @param value
   *           the related-task value to set
   */
  public void setRelatedTasks(@NonNull List<RelatedTask> value) {
    _relatedTasks = value;
  }

  /**
   * Add a new {@link RelatedTask} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRelatedTask(RelatedTask item) {
    RelatedTask value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedTasks == null) {
      _relatedTasks = new LinkedList<>();
    }
    return _relatedTasks.add(value);
  }

  /**
   * Remove the first matching {@link RelatedTask} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRelatedTask(RelatedTask item) {
    RelatedTask value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedTasks != null && _relatedTasks.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
