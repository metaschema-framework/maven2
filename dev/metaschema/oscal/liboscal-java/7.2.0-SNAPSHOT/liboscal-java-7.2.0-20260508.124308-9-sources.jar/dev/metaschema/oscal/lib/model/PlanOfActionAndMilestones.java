// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_poam_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Let;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A plan of action and milestones which identifies initial and residual risks, deviations, and disposition, such as those required by FedRAMP.
 */
@MetaschemaAssembly(
    formalName = "Plan of Action and Milestones (POA&M)",
    description = "A plan of action and milestones which identifies initial and residual risks, deviations, and disposition, such as those required by FedRAMP.",
    name = "plan-of-action-and-milestones",
    moduleClass = OscalPoamModule.class,
    rootName = "plan-of-action-and-milestones",
    remarks = "Either an OSCAL-based SSP must be imported, or a unique system-id must be specified. Both may be present.",
    valueConstraints = @ValueConstraints(lets = @Let(name = "all-imports", target = "recurse-depth('.[import-ap]/doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-ap/@href)))/assessment-plan|.[import-ssp]/doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-ssp/@href)))/system-security-plan|.[import-profile]/resolve-profile(doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-profile/@href))))/catalog')")),
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-poam-index-metadata-scoped-role-id", formalName = "In-Scope Role Identifiers", description = "An index of role identifiers that are in-scope for the plan-of-action-and-milestones model. Roles are collected from imported system-securtity-plans, which in turn includes referenced profiles and catalogs. For a given role @id, a locally declared role takes precedence over a role that is imported, the role that was last imported.", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/role ! map:entry(@id,.))?*", name = "index-imports-metadata-role-id", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-poam-index-metadata-scoped-location-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/location ! map:entry(@uuid,.))?*", name = "index-imports-metadata-location-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-poam-index-metadata-scoped-party-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-poam-index-metadata-scoped-party-organization-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party[@type='organization'] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-organization-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-poam-index-metadata-scoped-property-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports//prop[@uuid] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-property-uuid", keyFields = @KeyField(target = "@uuid"))}, unique = {@IsUnique(id = "oscal-unique-document-id", formalName = "Unique Document Identifier", description = "Ensure all document identifiers have a unique combination of @scheme and value.", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-property-in-context-location", formalName = "Unique Properties", description = "Ensure all properties are unique for a given location using a unique combination of @ns, @name, @class. @group. and @value.", level = IConstraint.Level.ERROR, target = ".//prop", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-link-in-context-location", formalName = "Unique Links", description = "Ensure all links are unique for a given location using a unique combination of @href, @rel, and @media-type.", level = IConstraint.Level.ERROR, target = ".//link", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type"), @KeyField(target = "@resource-fragment")}), @IsUnique(id = "oscal-unique-responsibility-in-context-location", formalName = "Unique Responsibilities", description = "Ensure all responsible-roles and responsible-parties are unique for a given location using a unique combination of @role-id and the combination of @party-uuid values.", level = IConstraint.Level.ERROR, target = ".//(responsible-party|responsible-role)", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@role-id"), @KeyField(target = "@party-uuid")}, remarks = "Since `responsible-party` and `responsible-role` associate multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.")})
)
public class PlanOfActionAndMilestones extends AbstractOscalInstance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance">instance</a>scope that can be used to reference this POA&amp;M instance in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers">this OSCAL instance</a>. This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "POA&M Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance)scope that can be used to reference this POA\\&M instance in [this OSCAL instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Provides information about the containing document, and defines concepts that are shared across the document.
   */
  @BoundAssembly(
      formalName = "Document Metadata",
      description = "Provides information about the containing document, and defines concepts that are shared across the document.",
      useName = "metadata",
      minOccurs = 1
  )
  private Metadata _metadata;

  /**
   * Used by the assessment plan and POA&amp;M to import information about the system.
   */
  @BoundAssembly(
      formalName = "Import System Security Plan",
      description = "Used by the assessment plan and POA\\&M to import information about the system.",
      useName = "import-ssp",
      remarks = "Used by the POA\\&M to import information about the system."
  )
  private ImportSsp _importSsp;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this system identification property elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. When referencing an externally defined <code>system identification</code>, the <code>system identification</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same system across revisions of the document.
   */
  @BoundField(
      formalName = "System Identification",
      description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this system identification property elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). When referencing an externally defined `system identification`, the `system identification` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same system across revisions of the document.",
      useName = "system-id"
  )
  private SystemId _systemId;

  /**
   * Allows components, and inventory-items to be defined within the POA&amp;M for circumstances where no OSCAL-based SSP exists, or is not delivered with the POA&amp;M.
   */
  @BoundAssembly(
      formalName = "Local Definitions",
      description = "Allows components, and inventory-items to be defined within the POA\\&M for circumstances where no OSCAL-based SSP exists, or is not delivered with the POA\\&M.",
      useName = "local-definitions"
  )
  private LocalDefinitions _localDefinitions;

  /**
   * Describes an individual observation.
   */
  @BoundAssembly(
      formalName = "Observation",
      description = "Describes an individual observation.",
      useName = "observation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "observations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Observation> _observations;

  /**
   * An identified risk.
   */
  @BoundAssembly(
      formalName = "Identified Risk",
      description = "An identified risk.",
      useName = "risk",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "risks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Risk> _risks;

  /**
   * Describes an individual finding.
   */
  @BoundAssembly(
      formalName = "Finding",
      description = "Describes an individual finding.",
      useName = "finding",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "findings", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Finding> _findings;

  /**
   * Describes an individual POA&amp;M item.
   */
  @BoundAssembly(
      formalName = "POA&M Item",
      description = "Describes an individual POA\\&M item.",
      useName = "poam-item",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "poam-items", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<PoamItem> _poamItems;

  /**
   * A collection of resources that may be referenced from within the OSCAL document instance.
   */
  @BoundAssembly(
      formalName = "Back matter",
      description = "A collection of resources that may be referenced from within the OSCAL document instance.",
      useName = "back-matter"
  )
  private BackMatter _backMatter;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.PlanOfActionAndMilestones} instance with no metadata.
   */
  public PlanOfActionAndMilestones() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.PlanOfActionAndMilestones} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public PlanOfActionAndMilestones(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal POA&M Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance">instance</a>scope that can be used to reference this POA&amp;M instance in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers">this OSCAL instance</a>. This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal POA&M Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#instance">instance</a>scope that can be used to reference this POA&amp;M instance in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#poam-identifiers">this OSCAL instance</a>. This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @return the metadata value
   */
  @NonNull
  public Metadata getMetadata() {
    return _metadata;
  }

  /**
   * Set the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @param value
   *           the metadata value to set
   */
  public void setMetadata(@NonNull Metadata value) {
    _metadata = value;
  }

  /**
   * Get the "{@literal Import System Security Plan}".
   *
   * <p>
   * Used by the assessment plan and POA&amp;M to import information about the system.
   *
   * @return the import-ssp value, or {@code null} if not set
   */
  @Nullable
  public ImportSsp getImportSsp() {
    return _importSsp;
  }

  /**
   * Set the "{@literal Import System Security Plan}".
   *
   * <p>
   * Used by the assessment plan and POA&amp;M to import information about the system.
   *
   * @param value
   *           the import-ssp value to set, or {@code null} to clear
   */
  public void setImportSsp(@Nullable ImportSsp value) {
    _importSsp = value;
  }

  /**
   * Get the "{@literal System Identification}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this system identification property elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. When referencing an externally defined <code>system identification</code>, the <code>system identification</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same system across revisions of the document.
   *
   * @return the system-id value, or {@code null} if not set
   */
  @Nullable
  public SystemId getSystemId() {
    return _systemId;
  }

  /**
   * Set the "{@literal System Identification}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this system identification property elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. When referencing an externally defined <code>system identification</code>, the <code>system identification</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same system across revisions of the document.
   *
   * @param value
   *           the system-id value to set, or {@code null} to clear
   */
  public void setSystemId(@Nullable SystemId value) {
    _systemId = value;
  }

  /**
   * Get the "{@literal Local Definitions}".
   *
   * <p>
   * Allows components, and inventory-items to be defined within the POA&amp;M for circumstances where no OSCAL-based SSP exists, or is not delivered with the POA&amp;M.
   *
   * @return the local-definitions value, or {@code null} if not set
   */
  @Nullable
  public LocalDefinitions getLocalDefinitions() {
    return _localDefinitions;
  }

  /**
   * Set the "{@literal Local Definitions}".
   *
   * <p>
   * Allows components, and inventory-items to be defined within the POA&amp;M for circumstances where no OSCAL-based SSP exists, or is not delivered with the POA&amp;M.
   *
   * @param value
   *           the local-definitions value to set, or {@code null} to clear
   */
  public void setLocalDefinitions(@Nullable LocalDefinitions value) {
    _localDefinitions = value;
  }

  /**
   * Get the "{@literal Observation}".
   *
   * <p>
   * Describes an individual observation.
   *
   * @return the observation value
   */
  @NonNull
  public List<Observation> getObservations() {
    if (_observations == null) {
      _observations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_observations);
  }

  /**
   * Set the "{@literal Observation}".
   *
   * <p>
   * Describes an individual observation.
   *
   * @param value
   *           the observation value to set
   */
  public void setObservations(@NonNull List<Observation> value) {
    _observations = value;
  }

  /**
   * Add a new {@link Observation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addObservation(Observation item) {
    Observation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_observations == null) {
      _observations = new LinkedList<>();
    }
    return _observations.add(value);
  }

  /**
   * Remove the first matching {@link Observation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeObservation(Observation item) {
    Observation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _observations != null && _observations.remove(value);
  }

  /**
   * Get the "{@literal Identified Risk}".
   *
   * <p>
   * An identified risk.
   *
   * @return the risk value
   */
  @NonNull
  public List<Risk> getRisks() {
    if (_risks == null) {
      _risks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_risks);
  }

  /**
   * Set the "{@literal Identified Risk}".
   *
   * <p>
   * An identified risk.
   *
   * @param value
   *           the risk value to set
   */
  public void setRisks(@NonNull List<Risk> value) {
    _risks = value;
  }

  /**
   * Add a new {@link Risk} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRisk(Risk item) {
    Risk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_risks == null) {
      _risks = new LinkedList<>();
    }
    return _risks.add(value);
  }

  /**
   * Remove the first matching {@link Risk} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRisk(Risk item) {
    Risk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _risks != null && _risks.remove(value);
  }

  /**
   * Get the "{@literal Finding}".
   *
   * <p>
   * Describes an individual finding.
   *
   * @return the finding value
   */
  @NonNull
  public List<Finding> getFindings() {
    if (_findings == null) {
      _findings = new LinkedList<>();
    }
    return ObjectUtils.notNull(_findings);
  }

  /**
   * Set the "{@literal Finding}".
   *
   * <p>
   * Describes an individual finding.
   *
   * @param value
   *           the finding value to set
   */
  public void setFindings(@NonNull List<Finding> value) {
    _findings = value;
  }

  /**
   * Add a new {@link Finding} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addFinding(Finding item) {
    Finding value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_findings == null) {
      _findings = new LinkedList<>();
    }
    return _findings.add(value);
  }

  /**
   * Remove the first matching {@link Finding} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeFinding(Finding item) {
    Finding value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _findings != null && _findings.remove(value);
  }

  /**
   * Get the "{@literal POA&M Item}".
   *
   * <p>
   * Describes an individual POA&amp;M item.
   *
   * @return the poam-item value
   */
  @NonNull
  public List<PoamItem> getPoamItems() {
    if (_poamItems == null) {
      _poamItems = new LinkedList<>();
    }
    return ObjectUtils.notNull(_poamItems);
  }

  /**
   * Set the "{@literal POA&M Item}".
   *
   * <p>
   * Describes an individual POA&amp;M item.
   *
   * @param value
   *           the poam-item value to set
   */
  public void setPoamItems(@NonNull List<PoamItem> value) {
    _poamItems = value;
  }

  /**
   * Add a new {@link PoamItem} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addPoamItem(PoamItem item) {
    PoamItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_poamItems == null) {
      _poamItems = new LinkedList<>();
    }
    return _poamItems.add(value);
  }

  /**
   * Remove the first matching {@link PoamItem} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removePoamItem(PoamItem item) {
    PoamItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _poamItems != null && _poamItems.remove(value);
  }

  /**
   * Get the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @return the back-matter value, or {@code null} if not set
   */
  @Nullable
  public BackMatter getBackMatter() {
    return _backMatter;
  }

  /**
   * Set the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @param value
   *           the back-matter value to set, or {@code null} to clear
   */
  public void setBackMatter(@Nullable BackMatter value) {
    _backMatter = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
