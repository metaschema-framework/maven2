// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies an individual task for which the containing object is a consequence of.
 */
@MetaschemaAssembly(
    formalName = "Task Reference",
    description = "Identifies an individual task for which the containing object is a consequence of.",
    name = "related-task",
    moduleClass = OscalAssessmentCommonModule.class,
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-ssp-related-task-responsible-party", level = IConstraint.Level.ERROR, target = "responsible-party", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-party` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
)
public class RelatedTask implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique task.
   */
  @BoundFlag(
      formalName = "Task Universally Unique Identifier Reference",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a unique task.",
      name = "task-uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _taskUuid;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   */
  @BoundAssembly(
      formalName = "Responsible Party",
      description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
      useName = "responsible-party",
      remarks = "Identifies the person or organization responsible for performing a specific role defined by the activity.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleParty> _responsibleParties;

  /**
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   */
  @BoundAssembly(
      formalName = "Subject of Assessment",
      description = "Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.",
      useName = "subject",
      remarks = "The assessment subjects that the task was performed against.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "subjects", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AssessmentSubject> _subjects;

  /**
   * Used to detail assessment subjects that were identified by this task.
   */
  @BoundAssembly(
      formalName = "Identified Subject",
      description = "Used to detail assessment subjects that were identified by this task.",
      useName = "identified-subject"
  )
  private IdentifiedSubject _identifiedSubject;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.RelatedTask} instance with no metadata.
   */
  public RelatedTask() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.RelatedTask} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public RelatedTask(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Task Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique task.
   *
   * @return the task-uuid value
   */
  @NonNull
  public UUID getTaskUuid() {
    return _taskUuid;
  }

  /**
   * Set the "{@literal Task Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique task.
   *
   * @param value
   *           the task-uuid value to set
   */
  public void setTaskUuid(@NonNull UUID value) {
    _taskUuid = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @return the responsible-party value
   */
  @NonNull
  public List<ResponsibleParty> getResponsibleParties() {
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleParties);
  }

  /**
   * Set the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @param value
   *           the responsible-party value to set
   */
  public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
    _responsibleParties = value;
  }

  /**
   * Add a new {@link ResponsibleParty} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return _responsibleParties.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleParties != null && _responsibleParties.remove(value);
  }

  /**
   * Get the "{@literal Subject of Assessment}".
   *
   * <p>
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   *
   * @return the subject value
   */
  @NonNull
  public List<AssessmentSubject> getSubjects() {
    if (_subjects == null) {
      _subjects = new LinkedList<>();
    }
    return ObjectUtils.notNull(_subjects);
  }

  /**
   * Set the "{@literal Subject of Assessment}".
   *
   * <p>
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   *
   * @param value
   *           the subject value to set
   */
  public void setSubjects(@NonNull List<AssessmentSubject> value) {
    _subjects = value;
  }

  /**
   * Add a new {@link AssessmentSubject} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSubject(AssessmentSubject item) {
    AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_subjects == null) {
      _subjects = new LinkedList<>();
    }
    return _subjects.add(value);
  }

  /**
   * Remove the first matching {@link AssessmentSubject} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSubject(AssessmentSubject item) {
    AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _subjects != null && _subjects.remove(value);
  }

  /**
   * Get the "{@literal Identified Subject}".
   *
   * <p>
   * Used to detail assessment subjects that were identified by this task.
   *
   * @return the identified-subject value, or {@code null} if not set
   */
  @Nullable
  public IdentifiedSubject getIdentifiedSubject() {
    return _identifiedSubject;
  }

  /**
   * Set the "{@literal Identified Subject}".
   *
   * <p>
   * Used to detail assessment subjects that were identified by this task.
   *
   * @param value
   *           the identified-subject value to set, or {@code null} to clear
   */
  public void setIdentifiedSubject(@Nullable IdentifiedSubject value) {
    _identifiedSubject = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Used to detail assessment subjects that were identified by this task.
   */
  @MetaschemaAssembly(
      formalName = "Identified Subject",
      description = "Used to detail assessment subjects that were identified by this task.",
      name = "identified-subject",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class IdentifiedSubject implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique assessment subject placeholder defined by this task.
     */
    @BoundFlag(
        formalName = "Assessment Subject Placeholder Universally Unique Identifier Reference",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a unique assessment subject placeholder defined by this task.",
        name = "subject-placeholder-uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _subjectPlaceholderUuid;

    /**
     * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
     */
    @BoundAssembly(
        formalName = "Subject of Assessment",
        description = "Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.",
        useName = "subject",
        remarks = "The assessment subjects that the task identified, which will be used by another task through a subject-placeholder reference. Such a task will \"consume\" these subjects.",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "subjects", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<AssessmentSubject> _subjects;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.RelatedTask.IdentifiedSubject} instance with no metadata.
     */
    public IdentifiedSubject() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.RelatedTask.IdentifiedSubject} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public IdentifiedSubject(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Assessment Subject Placeholder Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique assessment subject placeholder defined by this task.
     *
     * @return the subject-placeholder-uuid value
     */
    @NonNull
    public UUID getSubjectPlaceholderUuid() {
      return _subjectPlaceholderUuid;
    }

    /**
     * Set the "{@literal Assessment Subject Placeholder Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique assessment subject placeholder defined by this task.
     *
     * @param value
     *           the subject-placeholder-uuid value to set
     */
    public void setSubjectPlaceholderUuid(@NonNull UUID value) {
      _subjectPlaceholderUuid = value;
    }

    /**
     * Get the "{@literal Subject of Assessment}".
     *
     * <p>
     * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
     *
     * @return the subject value
     */
    @NonNull
    public List<AssessmentSubject> getSubjects() {
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return ObjectUtils.notNull(_subjects);
    }

    /**
     * Set the "{@literal Subject of Assessment}".
     *
     * <p>
     * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
     *
     * @param value
     *           the subject value to set
     */
    public void setSubjects(@NonNull List<AssessmentSubject> value) {
      _subjects = value;
    }

    /**
     * Add a new {@link AssessmentSubject} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addSubject(AssessmentSubject item) {
      AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return _subjects.add(value);
    }

    /**
     * Remove the first matching {@link AssessmentSubject} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeSubject(AssessmentSubject item) {
      AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _subjects != null && _subjects.remove(value);
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
