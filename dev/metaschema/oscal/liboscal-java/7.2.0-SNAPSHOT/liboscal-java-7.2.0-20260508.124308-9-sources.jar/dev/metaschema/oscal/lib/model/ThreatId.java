// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A pointer, by ID, to an externally-defined threat.
 */
@MetaschemaField(
    formalName = "Threat ID",
    description = "A pointer, by ID, to an externally-defined threat.",
    name = "threat-id",
    moduleClass = OscalAssessmentCommonModule.class
)
public class ThreatId implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Specifies the source of the threat information.
   */
  @BoundFlag(
      formalName = "Threat Type Identification System",
      description = "Specifies the source of the threat information.",
      name = "system",
      required = true,
      typeAdapter = UriAdapter.class,
      remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-threat-id-system", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "http://fedramp.gov", description = "\\*\\*deprecated\\*\\* The value conforms to FedRAMP definitions. This value has been deprecated; use `http://fedramp.gov/ns/oscal` instead.", deprecatedVersion = "1.0.3"), @AllowedValue(value = "http://fedramp.gov/ns/oscal", description = "The value conforms to FedRAMP definitions.")}))
  )
  private URI _system;

  /**
   * An optional location for the threat data, from which this ID originates.
   */
  @BoundFlag(
      formalName = "Threat Information Resource Reference",
      description = "An optional location for the threat data, from which this ID originates.",
      name = "href",
      typeAdapter = UriReferenceAdapter.class,
      remarks = "This value may be one of:\n"
              + "\n"
              + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
              + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
              + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to a `back-matter` resource in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object))."
  )
  private URI _href;

  /**
   * The field value.
   */
  @BoundFieldValue(
      valueKeyName = "id",
      typeAdapter = UriAdapter.class
  )
  private URI _id;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ThreatId} instance with no metadata.
   */
  public ThreatId() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ThreatId} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ThreatId(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Threat Type Identification System}".
   *
   * <p>
   * Specifies the source of the threat information.
   *
   * @return the system value
   */
  @NonNull
  public URI getSystem() {
    return _system;
  }

  /**
   * Set the "{@literal Threat Type Identification System}".
   *
   * <p>
   * Specifies the source of the threat information.
   *
   * @param value
   *           the system value to set
   */
  public void setSystem(@NonNull URI value) {
    _system = value;
  }

  /**
   * Get the "{@literal Threat Information Resource Reference}".
   *
   * <p>
   * An optional location for the threat data, from which this ID originates.
   *
   * @return the href value, or {@code null} if not set
   */
  @Nullable
  public URI getHref() {
    return _href;
  }

  /**
   * Set the "{@literal Threat Information Resource Reference}".
   *
   * <p>
   * An optional location for the threat data, from which this ID originates.
   *
   * @param value
   *           the href value to set, or {@code null} to clear
   */
  public void setHref(@Nullable URI value) {
    _href = value;
  }

  /**
   * Get the field value.
   *
   * @return the value
   */
  @Nullable
  public URI getId() {
    return _id;
  }

  /**
   * Set the field value.
   *
   * @param value
   *           the value to set
   */
  public void setId(@Nullable URI value) {
    _id = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
