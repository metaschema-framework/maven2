// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A reference to a resource that is either the source or the target of a mapping.
 */
@MetaschemaAssembly(
    formalName = "Mapped Resource Reference",
    description = "A reference to a resource that is either the source or the target of a mapping.",
    name = "mapping-resource-reference",
    moduleClass = OscalMappingCommonModule.class
)
public class MappingResourceReference implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * An optional namespace qualifying the resource's <code>type</code>.
   */
  @BoundFlag(
      formalName = "Resource Type Namespace",
      description = "An optional namespace qualifying the resource's `type`.",
      name = "ns",
      defaultValue = "http://csrc.nist.gov/ns/oscal",
      typeAdapter = UriAdapter.class,
      remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).\n"
              + "\n"
              + "When a `ns` is not provided, its value should be assumed to be `http://csrc.nist.gov/ns/oscal` and the type should be a type defined by the associated OSCAL model."
  )
  private URI _ns;

  /**
   * The semantic type of the resource.
   */
  @BoundFlag(
      formalName = "Resource Type",
      description = "The semantic type of the resource.",
      name = "type",
      required = true,
      typeAdapter = TokenAdapter.class,
      remarks = "The `type` value must be interpreted in the context of the associated `ns` value.\n"
              + "\n"
              + "When a `ns` is not provided, its value should be assumed to be `http://csrc.nist.gov/ns/oscal` and this type should be set to one of the OSCAL defined values.",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "catalog", description = "The mapped resource is a control catalog."), @AllowedValue(value = "profile", description = "The mapped resource is a control profile. A resolved profile is also accepted.")}))
  )
  private String _type;

  /**
   * A resolvable URL reference to the base catalog or profile that this profile is tailoring.
   */
  @BoundFlag(
      formalName = "Catalog or Profile Reference",
      description = "A resolvable URL reference to the base catalog or profile that this profile is tailoring.",
      name = "href",
      required = true,
      typeAdapter = UriReferenceAdapter.class,
      remarks = "This value may be one of:\n"
              + "\n"
              + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
              + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
              + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to a `back-matter` resource in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object))."
  )
  private URI _href;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappingResourceReference} instance with no metadata.
   */
  public MappingResourceReference() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.MappingResourceReference} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public MappingResourceReference(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Resource Type Namespace}".
   *
   * <p>
   * An optional namespace qualifying the resource's <code>type</code>.
   *
   * @return the ns value, or {@code null} if not set
   */
  @Nullable
  public URI getNs() {
    return _ns;
  }

  /**
   * Set the "{@literal Resource Type Namespace}".
   *
   * <p>
   * An optional namespace qualifying the resource's <code>type</code>.
   *
   * @param value
   *           the ns value to set, or {@code null} to clear
   */
  public void setNs(@Nullable URI value) {
    _ns = value;
  }

  /**
   * Get the "{@literal Resource Type}".
   *
   * <p>
   * The semantic type of the resource.
   *
   * @return the type value
   */
  @NonNull
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Resource Type}".
   *
   * <p>
   * The semantic type of the resource.
   *
   * @param value
   *           the type value to set
   */
  public void setType(@NonNull String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Catalog or Profile Reference}".
   *
   * <p>
   * A resolvable URL reference to the base catalog or profile that this profile is tailoring.
   *
   * @return the href value
   */
  @NonNull
  public URI getHref() {
    return _href;
  }

  /**
   * Set the "{@literal Catalog or Profile Reference}".
   *
   * <p>
   * A resolvable URL reference to the base catalog or profile that this profile is tailoring.
   *
   * @param value
   *           the href value to set
   */
  public void setHref(@NonNull URI value) {
    _href = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
