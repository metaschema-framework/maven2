// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Information about the protocol used to provide a service.
 */
@MetaschemaAssembly(
    formalName = "Service Protocol Information",
    description = "Information about the protocol used to provide a service.",
    name = "protocol",
    moduleClass = OscalImplementationCommonModule.class,
    valueConstraints = @ValueConstraints(expect = @Expect(id = "oscal-component-protocol-uuid", level = IConstraint.Level.WARNING, test = "@uuid", message = "It is a best practice to provide a UUID."))
)
public class Protocol implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this service protocol information elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>service protocol</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Service Protocol Information Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this service protocol information elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `service protocol` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The common name of the protocol, which should be the appropriate &quot;service name&quot; from the <a href="https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml">IANA Service Name and Transport Protocol Port Number Registry</a>.
   */
  @BoundFlag(
      formalName = "Protocol Name",
      description = "The common name of the protocol, which should be the appropriate \"service name\" from the [IANA Service Name and Transport Protocol Port Number Registry](https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml).",
      name = "name",
      typeAdapter = StringAdapter.class,
      remarks = "The short name of the protocol (e.g., https)."
  )
  private String _name;

  /**
   * A human readable name for the protocol (e.g., Transport Layer Security).
   */
  @BoundField(
      formalName = "Protocol Title",
      description = "A human readable name for the protocol (e.g., Transport Layer Security).",
      useName = "title",
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * Where applicable this is the transport layer protocol port range an IPv4-based or IPv6-based service uses.
   */
  @BoundAssembly(
      formalName = "Port Range",
      description = "Where applicable this is the transport layer protocol port range an IPv4-based or IPv6-based service uses.",
      useName = "port-range",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "port-ranges", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<PortRange> _portRanges;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Protocol} instance with no metadata.
   */
  public Protocol() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Protocol} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Protocol(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Service Protocol Information Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this service protocol information elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>service protocol</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value, or {@code null} if not set
   */
  @Nullable
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Service Protocol Information Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this service protocol information elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>service protocol</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set, or {@code null} to clear
   */
  public void setUuid(@Nullable UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Protocol Name}".
   *
   * <p>
   * The common name of the protocol, which should be the appropriate &quot;service name&quot; from the <a href="https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml">IANA Service Name and Transport Protocol Port Number Registry</a>.
   *
   * @return the name value, or {@code null} if not set
   */
  @Nullable
  public String getName() {
    return _name;
  }

  /**
   * Set the "{@literal Protocol Name}".
   *
   * <p>
   * The common name of the protocol, which should be the appropriate &quot;service name&quot; from the <a href="https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml">IANA Service Name and Transport Protocol Port Number Registry</a>.
   *
   * @param value
   *           the name value to set, or {@code null} to clear
   */
  public void setName(@Nullable String value) {
    _name = value;
  }

  /**
   * Get the "{@literal Protocol Title}".
   *
   * <p>
   * A human readable name for the protocol (e.g., Transport Layer Security).
   *
   * @return the title value, or {@code null} if not set
   */
  @Nullable
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Protocol Title}".
   *
   * <p>
   * A human readable name for the protocol (e.g., Transport Layer Security).
   *
   * @param value
   *           the title value to set, or {@code null} to clear
   */
  public void setTitle(@Nullable MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Port Range}".
   *
   * <p>
   * Where applicable this is the transport layer protocol port range an IPv4-based or IPv6-based service uses.
   *
   * @return the port-range value
   */
  @NonNull
  public List<PortRange> getPortRanges() {
    if (_portRanges == null) {
      _portRanges = new LinkedList<>();
    }
    return ObjectUtils.notNull(_portRanges);
  }

  /**
   * Set the "{@literal Port Range}".
   *
   * <p>
   * Where applicable this is the transport layer protocol port range an IPv4-based or IPv6-based service uses.
   *
   * @param value
   *           the port-range value to set
   */
  public void setPortRanges(@NonNull List<PortRange> value) {
    _portRanges = value;
  }

  /**
   * Add a new {@link PortRange} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addPortRange(PortRange item) {
    PortRange value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_portRanges == null) {
      _portRanges = new LinkedList<>();
    }
    return _portRanges.add(value);
  }

  /**
   * Remove the first matching {@link PortRange} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removePortRange(PortRange item) {
    PortRange value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _portRanges != null && _portRanges.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
