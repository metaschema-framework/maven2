// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A document identifier qualified by an identifier <code>scheme</code>.
 */
@MetaschemaField(
    formalName = "Document Identifier",
    description = "A document identifier qualified by an identifier `scheme`.",
    name = "document-id",
    moduleClass = OscalMetadataModule.class
)
public class DocumentId implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Qualifies the kind of document identifier using a URI. If the scheme is not provided the value of the element will be interpreted as a string of characters.
   */
  @BoundFlag(
      formalName = "Document Identification Scheme",
      description = "Qualifies the kind of document identifier using a URI. If the scheme is not provided the value of the element will be interpreted as a string of characters.",
      name = "scheme",
      typeAdapter = UriAdapter.class,
      remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-document-id-scheme-values", level = IConstraint.Level.ERROR, allowOthers = true, values = @AllowedValue(value = "http://www.doi.org/", description = "A [Digital Object Identifier](https://www.doi.org/hb.html) (DOI); use is preferred, since this allows for retrieval of a full bibliographic record.")))
  )
  private URI _scheme;

  /**
   * The field value.
   */
  @BoundFieldValue(
      valueKeyName = "identifier"
  )
  private String _identifier;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.DocumentId} instance with no metadata.
   */
  public DocumentId() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.DocumentId} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public DocumentId(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Document Identification Scheme}".
   *
   * <p>
   * Qualifies the kind of document identifier using a URI. If the scheme is not provided the value of the element will be interpreted as a string of characters.
   *
   * @return the scheme value, or {@code null} if not set
   */
  @Nullable
  public URI getScheme() {
    return _scheme;
  }

  /**
   * Set the "{@literal Document Identification Scheme}".
   *
   * <p>
   * Qualifies the kind of document identifier using a URI. If the scheme is not provided the value of the element will be interpreted as a string of characters.
   *
   * @param value
   *           the scheme value to set, or {@code null} to clear
   */
  public void setScheme(@Nullable URI value) {
    _scheme = value;
  }

  /**
   * Get the field value.
   *
   * @return the value
   */
  @Nullable
  public String getIdentifier() {
    return _identifier;
  }

  /**
   * Set the field value.
   *
   * @param value
   *           the value to set
   */
  public void setIdentifier(@Nullable String value) {
    _identifier = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
