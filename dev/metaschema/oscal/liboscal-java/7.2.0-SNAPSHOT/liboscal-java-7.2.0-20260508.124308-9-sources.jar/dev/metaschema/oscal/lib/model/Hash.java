// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A representation of a cryptographic digest generated over a resource using a specified hash algorithm.
 */
@MetaschemaField(
    formalName = "Hash",
    description = "A representation of a cryptographic digest generated over a resource using a specified hash algorithm.",
    name = "hash",
    moduleClass = OscalMetadataModule.class,
    valueConstraints = @ValueConstraints(matches = {@Matches(id = "oscal-check-hash-length-SHA2-3-224", level = IConstraint.Level.ERROR, target = ".[@algorithm=('SHA-224','SHA3-224')]", pattern = "^[0-9a-fA-F]{56}$"), @Matches(id = "oscal-check-hash-length-SHA2-3-256", level = IConstraint.Level.ERROR, target = ".[@algorithm=('SHA-256','SHA3-256')]", pattern = "^[0-9a-fA-F]{64}$"), @Matches(id = "oscal-check-hash-length-SHA2-3-384", level = IConstraint.Level.ERROR, target = ".[@algorithm=('SHA-384','SHA3-384')]", pattern = "^[0-9a-fA-F]{96}$"), @Matches(id = "oscal-check-hash-length-SHA2-3-512", level = IConstraint.Level.ERROR, target = ".[@algorithm=('SHA-512','SHA3-512')]", pattern = "^[0-9a-fA-F]{128}$")})
)
public class Hash implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The digest method by which a hash is derived.
   */
  @BoundFlag(
      formalName = "Hash algorithm",
      description = "The digest method by which a hash is derived.",
      name = "algorithm",
      required = true,
      typeAdapter = StringAdapter.class,
      remarks = "Any other value used MUST be a value defined in the W3C [XML Security Algorithm Cross-Reference](https://www.w3.org/TR/xmlsec-algorithms/#digest-method-uris) Digest Methods (W3C, April 2013) or [RFC 6931 Section 2.1.5](https://tools.ietf.org/html/rfc6931#section-2.1.5) New SHA Functions.",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-back-matter-resource-hash-algorithm-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "SHA-224", description = "The SHA-224 algorithm as defined by [NIST FIPS 180-4](https://doi.org/10.6028/NIST.FIPS.180-4)."), @AllowedValue(value = "SHA-256", description = "The SHA-256 algorithm as defined by [NIST FIPS 180-4](https://doi.org/10.6028/NIST.FIPS.180-4)."), @AllowedValue(value = "SHA-384", description = "The SHA-384 algorithm as defined by [NIST FIPS 180-4](https://doi.org/10.6028/NIST.FIPS.180-4)."), @AllowedValue(value = "SHA-512", description = "The SHA-512 algorithm as defined by [NIST FIPS 180-4](https://doi.org/10.6028/NIST.FIPS.180-4)."), @AllowedValue(value = "SHA3-224", description = "The SHA3-224 algorithm as defined by [NIST FIPS 202](https://doi.org/10.6028/NIST.FIPS.202)."), @AllowedValue(value = "SHA3-256", description = "The SHA3-256 algorithm as defined by [NIST FIPS 202](https://doi.org/10.6028/NIST.FIPS.202)."), @AllowedValue(value = "SHA3-384", description = "The SHA3-384 algorithm as defined by [NIST FIPS 202](https://doi.org/10.6028/NIST.FIPS.202)."), @AllowedValue(value = "SHA3-512", description = "The SHA3-512 algorithm as defined by [NIST FIPS 202](https://doi.org/10.6028/NIST.FIPS.202).")}))
  )
  private String _algorithm;

  /**
   * The field value.
   */
  @BoundFieldValue(
      valueKeyName = "value"
  )
  private String _value;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Hash} instance with no metadata.
   */
  public Hash() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Hash} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Hash(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Hash algorithm}".
   *
   * <p>
   * The digest method by which a hash is derived.
   *
   * @return the algorithm value
   */
  @NonNull
  public String getAlgorithm() {
    return _algorithm;
  }

  /**
   * Set the "{@literal Hash algorithm}".
   *
   * <p>
   * The digest method by which a hash is derived.
   *
   * @param value
   *           the algorithm value to set
   */
  public void setAlgorithm(@NonNull String value) {
    _algorithm = value;
  }

  /**
   * Get the field value.
   *
   * @return the value
   */
  @Nullable
  public String getValue() {
    return _value;
  }

  /**
   * Set the field value.
   *
   * @param value
   *           the value to set
   */
  public void setValue(@Nullable String value) {
    _value = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
