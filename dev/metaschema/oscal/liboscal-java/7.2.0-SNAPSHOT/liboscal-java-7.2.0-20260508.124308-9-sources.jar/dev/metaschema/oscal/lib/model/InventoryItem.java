// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A single managed inventory item within the system.
 */
@MetaschemaAssembly(
    formalName = "Inventory Item",
    description = "A single managed inventory item within the system.",
    name = "inventory-item",
    moduleClass = OscalImplementationCommonModule.class,
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-inventory-item-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "ipv4-address", description = "The Internet Protocol v4 Address of the asset."), @AllowedValue(value = "ipv6-address", description = "The Internet Protocol v6 Address of the asset."), @AllowedValue(value = "fqdn", description = "The full-qualified domain name (FQDN) of the asset."), @AllowedValue(value = "uri", description = "A Uniform Resource Identifier (URI) for the asset."), @AllowedValue(value = "serial-number", description = "A serial number for the asset."), @AllowedValue(value = "netbios-name", description = "The NetBIOS name for the asset."), @AllowedValue(value = "mac-address", description = "The media access control (MAC) address for the asset."), @AllowedValue(value = "physical-location", description = "The physical location of the asset's hardware (e.g., Data Center ID, Cage#, Rack#, or other meaningful location identifiers)."), @AllowedValue(value = "is-scanned", description = "is the asset subjected to network scans? (yes/no)"), @AllowedValue(value = "asset-type", description = "Simple indication of the asset's function, such as Router, Storage Array, DNS Server."), @AllowedValue(value = "asset-id", description = "An organizationally specific identifier that is used to uniquely identify a logical or tangible item by the organization that owns the item."), @AllowedValue(value = "asset-tag", description = "An asset tag assigned by the organization responsible for maintaining the logical or tangible item."), @AllowedValue(value = "public", description = "Identifies whether the asset is publicly accessible (yes/no)"), @AllowedValue(value = "virtual", description = "Identifies whether the asset is virtualized (yes/no)"), @AllowedValue(value = "vlan-id", description = "Virtual LAN identifier of the asset."), @AllowedValue(value = "network-id", description = "The network identifier of the asset."), @AllowedValue(value = "label", description = "A human-readable label for the parent context."), @AllowedValue(value = "sort-id", description = "An alternative identifier, whose value is easily sortable among other such values in the document."), @AllowedValue(value = "baseline-configuration-name", description = "The name of the baseline configuration for the asset."), @AllowedValue(value = "allows-authenticated-scan", description = "Can the asset be check with an authenticated scan? (yes/no)"), @AllowedValue(value = "function", description = "The function provided by the asset for the system."), @AllowedValue(value = "hardware-model", description = "\\*\\*(deprecated)\\*\\* Use 'model' instead.", deprecatedVersion = "1.2.0"), @AllowedValue(value = "model", description = "The model of system used by the asset."), @AllowedValue(value = "os-name", description = "The name of the operating system used by the asset."), @AllowedValue(value = "os-version", description = "The version of the operating system used by the asset."), @AllowedValue(value = "software-name", description = "The software product name used by the asset."), @AllowedValue(value = "software-version", description = "The software product version used by the asset."), @AllowedValue(value = "software-patch-level", description = "The software product patch level used by the asset.")}), @AllowedValues(id = "oscal-inventory-item-prop-asset-type-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='asset-type']/@value", allowOthers = true, values = {@AllowedValue(value = "operating-system", description = "System software that manages computer hardware, software resources, and provides common services for computer programs."), @AllowedValue(value = "database", description = "An electronic collection of data, or information, that is specially organized for rapid search and retrieval."), @AllowedValue(value = "web-server", description = "A system that delivers content or services to end users over the Internet or an intranet."), @AllowedValue(value = "dns-server", description = "A system that resolves domain names to internet protocol (IP) addresses."), @AllowedValue(value = "email-server", description = "A computer system that sends and receives electronic mail messages."), @AllowedValue(value = "directory-server", description = "A system that stores, organizes and provides access to directory information in order to unify network resources."), @AllowedValue(value = "pbx", description = "A private branch exchange (PBX) provides a a private telephone switchboard."), @AllowedValue(value = "firewall", description = "A network security system that monitors and controls incoming and outgoing network traffic based on predetermined security rules."), @AllowedValue(value = "router", description = "A physical or virtual networking device that forwards data packets between computer networks."), @AllowedValue(value = "switch", description = "A physical or virtual networking device that connects devices within a computer network by using packet switching to receive and forward data to the destination device."), @AllowedValue(value = "storage-array", description = "A consolidated, block-level data storage capability."), @AllowedValue(value = "appliance", description = "A physical or virtual machine that centralizes hardware, software, or services for a specific purpose.")}), @AllowedValues(id = "oscal-inventory-item-hardware-service-software-prop-name-values", level = IConstraint.Level.ERROR, target = "(.)[@type=('software', 'hardware', 'service')]/prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "vendor-name", description = "The name of the company or organization")), @AllowedValues(id = "oscal-inventory-item-prop-is-scanned-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='is-scanned']/@value", values = {@AllowedValue(value = "yes", description = "The asset is included in periodic vulnerability scanning."), @AllowedValue(value = "no", description = "The asset is not included in periodic vulnerability scanning.")}), @AllowedValues(id = "oscal-inventory-item-link-rel-values", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = @AllowedValue(value = "baseline-template", description = "A reference to the baseline template used to configure the asset.")), @AllowedValues(id = "oscal-inventory-item-responsible-party-role-id-values", level = IConstraint.Level.ERROR, target = "responsible-party/@role-id", allowOthers = true, values = {@AllowedValue(value = "asset-owner", description = "Accountable for ensuring the asset is managed in accordance with organizational policies and procedures."), @AllowedValue(value = "asset-administrator", description = "Responsible for administering a set of assets."), @AllowedValue(value = "security-operations", description = "Members of the security operations center (SOC)."), @AllowedValue(value = "network-operations", description = "Members of the network operations center (NOC)."), @AllowedValue(value = "incident-response", description = "Responsible for responding to an event that could lead to loss of, or disruption to, an organization's operations, services or functions."), @AllowedValue(value = "help-desk", description = "Responsible for providing information and support to users."), @AllowedValue(value = "configuration-management", description = "Responsible for the configuration management processes governing changes to the asset."), @AllowedValue(value = "maintainer", description = "Responsible for the creation and maintenance of a component."), @AllowedValue(value = "provider", description = "Organization responsible for providing the component, if this is different from the \"maintainer\" (e.g., a reseller).")})}, indexHasKey = {@IndexHasKey(id = "oscal-index-inventory-item-responsible-party-role-id", level = IConstraint.Level.ERROR, target = "responsible-party", indexName = "index-metadata-role-id", keyFields = @KeyField(target = "@role-id")), @IndexHasKey(id = "oscal-index-inventory-item-responsible-party-party-uuid", level = IConstraint.Level.ERROR, target = "responsible-party", indexName = "index-metadata-party-uuid", keyFields = @KeyField(target = "party-uuid"))}),
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-inventory-item-responsible-party", level = IConstraint.Level.ERROR, target = "responsible-party", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-party` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
)
public class InventoryItem implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this inventory item elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>inventory item</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Inventory Item Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this inventory item elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `inventory item` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * A summary of the inventory item stating its purpose within the system.
   */
  @BoundField(
      formalName = "Inventory Item Description",
      description = "A summary of the inventory item stating its purpose within the system.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   */
  @BoundAssembly(
      formalName = "Responsible Party",
      description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
      useName = "responsible-party",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleParty> _responsibleParties;

  /**
   * The set of components that are implemented in a given system inventory item.
   */
  @BoundAssembly(
      formalName = "Implemented Component",
      description = "The set of components that are implemented in a given system inventory item.",
      useName = "implemented-component",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "implemented-components", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ImplementedComponent> _implementedComponents;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.InventoryItem} instance with no metadata.
   */
  public InventoryItem() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.InventoryItem} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public InventoryItem(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Inventory Item Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this inventory item elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>inventory item</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Inventory Item Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this inventory item elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>inventory item</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Inventory Item Description}".
   *
   * <p>
   * A summary of the inventory item stating its purpose within the system.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Inventory Item Description}".
   *
   * <p>
   * A summary of the inventory item stating its purpose within the system.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @return the responsible-party value
   */
  @NonNull
  public List<ResponsibleParty> getResponsibleParties() {
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleParties);
  }

  /**
   * Set the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @param value
   *           the responsible-party value to set
   */
  public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
    _responsibleParties = value;
  }

  /**
   * Add a new {@link ResponsibleParty} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return _responsibleParties.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleParties != null && _responsibleParties.remove(value);
  }

  /**
   * Get the "{@literal Implemented Component}".
   *
   * <p>
   * The set of components that are implemented in a given system inventory item.
   *
   * @return the implemented-component value
   */
  @NonNull
  public List<ImplementedComponent> getImplementedComponents() {
    if (_implementedComponents == null) {
      _implementedComponents = new LinkedList<>();
    }
    return ObjectUtils.notNull(_implementedComponents);
  }

  /**
   * Set the "{@literal Implemented Component}".
   *
   * <p>
   * The set of components that are implemented in a given system inventory item.
   *
   * @param value
   *           the implemented-component value to set
   */
  public void setImplementedComponents(@NonNull List<ImplementedComponent> value) {
    _implementedComponents = value;
  }

  /**
   * Add a new {@link ImplementedComponent} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addImplementedComponent(ImplementedComponent item) {
    ImplementedComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_implementedComponents == null) {
      _implementedComponents = new LinkedList<>();
    }
    return _implementedComponents.add(value);
  }

  /**
   * Remove the first matching {@link ImplementedComponent} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeImplementedComponent(ImplementedComponent item) {
    ImplementedComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _implementedComponents != null && _implementedComponents.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * The set of components that are implemented in a given system inventory item.
   */
  @MetaschemaAssembly(
      formalName = "Implemented Component",
      description = "The set of components that are implemented in a given system inventory item.",
      name = "implemented-component",
      moduleClass = OscalImplementationCommonModule.class,
      valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-implemented-component-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "version", description = "The version of the component."), @AllowedValue(value = "patch-level", description = "The specific patch level of the component."), @AllowedValue(value = "model", description = "The model of system used by the asset."), @AllowedValue(value = "release-date", description = "The date the component was released, such as a software release date or policy publication date."), @AllowedValue(value = "validation-type", description = "Used with component-type='validation' to provide a well-known name for a kind of validation."), @AllowedValue(value = "validation-reference", description = "Used with component-type='validation' to indicate the validating body's assigned identifier for their validation of this component."), @AllowedValue(value = "asset-type", description = "Simple indication of the asset's function, such as Router, Storage Array, DNS Server."), @AllowedValue(value = "asset-id", description = "An organizationally specific identifier that is used to uniquely identify a logical or tangible item by the organization that owns the item."), @AllowedValue(value = "asset-tag", description = "An asset tag assigned by the organization responsible for maintaining the logical or tangible item."), @AllowedValue(value = "public", description = "Identifies whether the asset is publicly accessible (yes/no)"), @AllowedValue(value = "virtual", description = "Identifies whether the asset is virtualized (yes/no)"), @AllowedValue(value = "vlan-id", description = "Virtual LAN identifier of the asset."), @AllowedValue(value = "network-id", description = "The network identifier of the asset."), @AllowedValue(value = "label", description = "A human-readable label for the parent context."), @AllowedValue(value = "sort-id", description = "An alternative identifier, whose value is easily sortable among other such values in the document."), @AllowedValue(value = "baseline-configuration-name", description = "The name of the baseline configuration for the asset."), @AllowedValue(value = "allows-authenticated-scan", description = "Can the asset be check with an authenticated scan? (yes/no)"), @AllowedValue(value = "function", description = "The function provided by the asset for the system."), @AllowedValue(value = "hardware-model", description = "\\*\\*(deprecated)\\*\\* Use 'model' instead.", deprecatedVersion = "1.2.0"), @AllowedValue(value = "os-name", description = "The name of the operating system used by the asset."), @AllowedValue(value = "os-version", description = "The version of the operating system used by the asset."), @AllowedValue(value = "software-name", description = "The software product name used by the asset."), @AllowedValue(value = "software-version", description = "The software product version used by the asset."), @AllowedValue(value = "software-patch-level", description = "The software product patch level used by the asset.")}), @AllowedValues(id = "oscal-implemented-component-responsible-party-role-id-values", level = IConstraint.Level.ERROR, target = "responsible-party/@role-id", allowOthers = true, values = {@AllowedValue(value = "asset-owner", description = "Accountable for ensuring the asset is managed in accordance with organizational policies and procedures."), @AllowedValue(value = "asset-administrator", description = "Responsible for administering a set of assets."), @AllowedValue(value = "security-operations", description = "Members of the security operations center (SOC)."), @AllowedValue(value = "network-operations", description = "Members of the network operations center (NOC)."), @AllowedValue(value = "incident-response", description = "Responsible for responding to an event that could lead to loss of, or disruption to, an organization's operations, services or functions."), @AllowedValue(value = "help-desk", description = "Responsible for providing information and support to users."), @AllowedValue(value = "configuration-management", description = "Responsible for the configuration management processes governing changes to the asset.")})}),
      modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-implemented-component-responsible-party", level = IConstraint.Level.ERROR, target = "responsible-party", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-party` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
  )
  public static class ImplementedComponent implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a <code>component</code> that is implemented as part of an inventory item.
     */
    @BoundFlag(
        formalName = "Component Universally Unique Identifier Reference",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a `component` that is implemented as part of an inventory item.",
        name = "component-uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _componentUuid;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
     */
    @BoundAssembly(
        formalName = "Responsible Party",
        description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
        useName = "responsible-party",
        remarks = "This construct is used to either: 1) associate a party or parties to a role defined on the component using the `responsible-role` construct, or 2) to define a party or parties that are responsible for a role defined within the context of the containing `inventory-item`.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ResponsibleParty> _responsibleParties;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.InventoryItem.ImplementedComponent} instance with no metadata.
     */
    public ImplementedComponent() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.InventoryItem.ImplementedComponent} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public ImplementedComponent(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Component Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a <code>component</code> that is implemented as part of an inventory item.
     *
     * @return the component-uuid value
     */
    @NonNull
    public UUID getComponentUuid() {
      return _componentUuid;
    }

    /**
     * Set the "{@literal Component Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a <code>component</code> that is implemented as part of an inventory item.
     *
     * @param value
     *           the component-uuid value to set
     */
    public void setComponentUuid(@NonNull UUID value) {
      _componentUuid = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Responsible Party}".
     *
     * <p>
     * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
     *
     * @return the responsible-party value
     */
    @NonNull
    public List<ResponsibleParty> getResponsibleParties() {
      if (_responsibleParties == null) {
        _responsibleParties = new LinkedList<>();
      }
      return ObjectUtils.notNull(_responsibleParties);
    }

    /**
     * Set the "{@literal Responsible Party}".
     *
     * <p>
     * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
     *
     * @param value
     *           the responsible-party value to set
     */
    public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
      _responsibleParties = value;
    }

    /**
     * Add a new {@link ResponsibleParty} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addResponsibleParty(ResponsibleParty item) {
      ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_responsibleParties == null) {
        _responsibleParties = new LinkedList<>();
      }
      return _responsibleParties.add(value);
    }

    /**
     * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeResponsibleParty(ResponsibleParty item) {
      ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _responsibleParties != null && _responsibleParties.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
