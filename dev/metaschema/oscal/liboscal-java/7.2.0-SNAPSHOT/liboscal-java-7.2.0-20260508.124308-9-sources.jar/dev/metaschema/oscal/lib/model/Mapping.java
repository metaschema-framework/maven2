// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A mapping between two target resources.
 */
@MetaschemaAssembly(
    formalName = "Control Mapping",
    description = "A mapping between two target resources.",
    name = "mapping",
    moduleClass = OscalMappingCommonModule.class
)
public class Mapping implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mapping definition elsewhere in this or other OSCAL instances. The locally defined <em>UUID</em> of the <code> mapping</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same mapping across revisions of the document.
   */
  @BoundFlag(
      formalName = "Mapping Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this mapping definition elsewhere in this or other OSCAL instances. The locally defined *UUID* of the ` mapping` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same mapping across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The method used to complete the overall mapping.
   */
  @BoundFlag(
      formalName = "Method",
      description = "The method used to complete the overall mapping.",
      name = "method",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "human", description = "Human"), @AllowedValue(value = "automation", description = "Automation"), @AllowedValue(value = "hybrid", description = "Hybrid")}))
  )
  private String _method;

  /**
   * The method used for relating controls within the mapping. The supported methods are aligned with the <a href="https://doi.org/10.6028/NIST.IR.8477">NIST Interagency Report (IR) 8477</a>, Section 4.3 Set Theory Relationship Mapping.
   */
  @BoundFlag(
      formalName = "Matching",
      description = "The method used for relating controls within the mapping. The supported methods are aligned with the [NIST Interagency Report (IR) 8477](https://doi.org/10.6028/NIST.IR.8477), Section 4.3 Set Theory Relationship Mapping.",
      name = "matching-rationale",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "syntactic", description = "Syntactic: How similar is the *wording* that expresses the two concepts. This is a word-for-word analysis of the relationship, not an interpretation of the language."), @AllowedValue(value = "semantic", description = "Semantic: How similar are the *meanings* of the two concepts? This involves some interpretation of each concept’s language."), @AllowedValue(value = "functional", description = "Functional: How similar are the *results* of executing the two concepts? This involves understanding what will happen if the two concepts are implemented, performed, or otherwise executed.")}))
  )
  private String _matchingRationale;

  /**
   * The current status of this mapping document.
   */
  @BoundFlag(
      formalName = "Status",
      description = "The current status of this mapping document.",
      name = "status",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "complete", description = "Complete"), @AllowedValue(value = "not-complete", description = "Not Complete"), @AllowedValue(value = "draft", description = "Draft"), @AllowedValue(value = "deprecated", description = "Deprecated"), @AllowedValue(value = "superseded", description = "Superseded")}))
  )
  private String _status;

  /**
   * A reference to a resource that is either the source or the target of a mapping.
   */
  @BoundAssembly(
      formalName = "Mapped Resource Reference",
      description = "A reference to a resource that is either the source or the target of a mapping.",
      useName = "source-resource",
      minOccurs = 1
  )
  private MappingResourceReference _sourceResource;

  /**
   * A reference to a resource that is either the source or the target of a mapping.
   */
  @BoundAssembly(
      formalName = "Mapped Resource Reference",
      description = "A reference to a resource that is either the source or the target of a mapping.",
      useName = "target-resource",
      minOccurs = 1
  )
  private MappingResourceReference _targetResource;

  /**
   * A relationship-based mapping between a source and target set consisting of members (i.e., controls, control statements) from the respective source and target.
   */
  @BoundAssembly(
      formalName = "Mapping Entry",
      description = "A relationship-based mapping between a source and target set consisting of members (i.e., controls, control statements) from the respective source and target.",
      useName = "map",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "maps", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<MappingEntry> _maps;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Description of the context and intended use of the mapping set.
   */
  @BoundField(
      formalName = "Mapping Description",
      description = "Description of the context and intended use of the mapping set.",
      useName = "mapping-description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _mappingDescription;

  /**
   * A <em>by-id</em> collection of all controls that were not mapped at all in this <code> mapping-collection</code>. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the <code> relationship-gal</code>.
   */
  @BoundAssembly(
      formalName = "Gap Summary",
      description = "A *by-id* collection of all controls that were not mapped at all in this ` mapping-collection`. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the ` relationship-gal`.",
      useName = "source-gap-summary"
  )
  private GapSummary _sourceGapSummary;

  /**
   * A <em>by-id</em> collection of all controls that were not mapped at all in this <code> mapping-collection</code>. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the <code> relationship-gal</code>.
   */
  @BoundAssembly(
      formalName = "Gap Summary",
      description = "A *by-id* collection of all controls that were not mapped at all in this ` mapping-collection`. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the ` relationship-gal`.",
      useName = "target-gap-summary"
  )
  private GapSummary _targetGapSummary;

  /**
   * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
   */
  @BoundAssembly(
      formalName = "Confidence Score",
      description = "This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.",
      useName = "confidence-score"
  )
  private ConfidenceScore _confidenceScore;

  /**
   * A decimal value from 0-1, representing the percentage coverage of the targets by the sources.
   */
  @BoundField(
      formalName = "Coverage",
      description = "A decimal value from 0-1, representing the percentage coverage of the targets by the sources.",
      useName = "coverage"
  )
  private Coverage _coverage;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Mapping} instance with no metadata.
   */
  public Mapping() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Mapping} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Mapping(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Mapping Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mapping definition elsewhere in this or other OSCAL instances. The locally defined <em>UUID</em> of the <code> mapping</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same mapping across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Mapping Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mapping definition elsewhere in this or other OSCAL instances. The locally defined <em>UUID</em> of the <code> mapping</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same mapping across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Method}".
   *
   * <p>
   * The method used to complete the overall mapping.
   *
   * @return the method value, or {@code null} if not set
   */
  @Nullable
  public String getMethod() {
    return _method;
  }

  /**
   * Set the "{@literal Method}".
   *
   * <p>
   * The method used to complete the overall mapping.
   *
   * @param value
   *           the method value to set, or {@code null} to clear
   */
  public void setMethod(@Nullable String value) {
    _method = value;
  }

  /**
   * Get the "{@literal Matching}".
   *
   * <p>
   * The method used for relating controls within the mapping. The supported methods are aligned with the <a href="https://doi.org/10.6028/NIST.IR.8477">NIST Interagency Report (IR) 8477</a>, Section 4.3 Set Theory Relationship Mapping.
   *
   * @return the matching-rationale value, or {@code null} if not set
   */
  @Nullable
  public String getMatchingRationale() {
    return _matchingRationale;
  }

  /**
   * Set the "{@literal Matching}".
   *
   * <p>
   * The method used for relating controls within the mapping. The supported methods are aligned with the <a href="https://doi.org/10.6028/NIST.IR.8477">NIST Interagency Report (IR) 8477</a>, Section 4.3 Set Theory Relationship Mapping.
   *
   * @param value
   *           the matching-rationale value to set, or {@code null} to clear
   */
  public void setMatchingRationale(@Nullable String value) {
    _matchingRationale = value;
  }

  /**
   * Get the "{@literal Status}".
   *
   * <p>
   * The current status of this mapping document.
   *
   * @return the status value, or {@code null} if not set
   */
  @Nullable
  public String getStatus() {
    return _status;
  }

  /**
   * Set the "{@literal Status}".
   *
   * <p>
   * The current status of this mapping document.
   *
   * @param value
   *           the status value to set, or {@code null} to clear
   */
  public void setStatus(@Nullable String value) {
    _status = value;
  }

  /**
   * Get the "{@literal Mapped Resource Reference}".
   *
   * <p>
   * A reference to a resource that is either the source or the target of a mapping.
   *
   * @return the source-resource value
   */
  @NonNull
  public MappingResourceReference getSourceResource() {
    return _sourceResource;
  }

  /**
   * Set the "{@literal Mapped Resource Reference}".
   *
   * <p>
   * A reference to a resource that is either the source or the target of a mapping.
   *
   * @param value
   *           the source-resource value to set
   */
  public void setSourceResource(@NonNull MappingResourceReference value) {
    _sourceResource = value;
  }

  /**
   * Get the "{@literal Mapped Resource Reference}".
   *
   * <p>
   * A reference to a resource that is either the source or the target of a mapping.
   *
   * @return the target-resource value
   */
  @NonNull
  public MappingResourceReference getTargetResource() {
    return _targetResource;
  }

  /**
   * Set the "{@literal Mapped Resource Reference}".
   *
   * <p>
   * A reference to a resource that is either the source or the target of a mapping.
   *
   * @param value
   *           the target-resource value to set
   */
  public void setTargetResource(@NonNull MappingResourceReference value) {
    _targetResource = value;
  }

  /**
   * Get the "{@literal Mapping Entry}".
   *
   * <p>
   * A relationship-based mapping between a source and target set consisting of members (i.e., controls, control statements) from the respective source and target.
   *
   * @return the map value
   */
  @NonNull
  public List<MappingEntry> getMaps() {
    if (_maps == null) {
      _maps = new LinkedList<>();
    }
    return ObjectUtils.notNull(_maps);
  }

  /**
   * Set the "{@literal Mapping Entry}".
   *
   * <p>
   * A relationship-based mapping between a source and target set consisting of members (i.e., controls, control statements) from the respective source and target.
   *
   * @param value
   *           the map value to set
   */
  public void setMaps(@NonNull List<MappingEntry> value) {
    _maps = value;
  }

  /**
   * Add a new {@link MappingEntry} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addMap(MappingEntry item) {
    MappingEntry value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_maps == null) {
      _maps = new LinkedList<>();
    }
    return _maps.add(value);
  }

  /**
   * Remove the first matching {@link MappingEntry} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeMap(MappingEntry item) {
    MappingEntry value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _maps != null && _maps.remove(value);
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  /**
   * Get the "{@literal Mapping Description}".
   *
   * <p>
   * Description of the context and intended use of the mapping set.
   *
   * @return the mapping-description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getMappingDescription() {
    return _mappingDescription;
  }

  /**
   * Set the "{@literal Mapping Description}".
   *
   * <p>
   * Description of the context and intended use of the mapping set.
   *
   * @param value
   *           the mapping-description value to set, or {@code null} to clear
   */
  public void setMappingDescription(@Nullable MarkupMultiline value) {
    _mappingDescription = value;
  }

  /**
   * Get the "{@literal Gap Summary}".
   *
   * <p>
   * A <em>by-id</em> collection of all controls that were not mapped at all in this <code> mapping-collection</code>. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the <code> relationship-gal</code>.
   *
   * @return the source-gap-summary value, or {@code null} if not set
   */
  @Nullable
  public GapSummary getSourceGapSummary() {
    return _sourceGapSummary;
  }

  /**
   * Set the "{@literal Gap Summary}".
   *
   * <p>
   * A <em>by-id</em> collection of all controls that were not mapped at all in this <code> mapping-collection</code>. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the <code> relationship-gal</code>.
   *
   * @param value
   *           the source-gap-summary value to set, or {@code null} to clear
   */
  public void setSourceGapSummary(@Nullable GapSummary value) {
    _sourceGapSummary = value;
  }

  /**
   * Get the "{@literal Gap Summary}".
   *
   * <p>
   * A <em>by-id</em> collection of all controls that were not mapped at all in this <code> mapping-collection</code>. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the <code> relationship-gal</code>.
   *
   * @return the target-gap-summary value, or {@code null} if not set
   */
  @Nullable
  public GapSummary getTargetGapSummary() {
    return _targetGapSummary;
  }

  /**
   * Set the "{@literal Gap Summary}".
   *
   * <p>
   * A <em>by-id</em> collection of all controls that were not mapped at all in this <code> mapping-collection</code>. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the <code> relationship-gal</code>.
   *
   * @param value
   *           the target-gap-summary value to set, or {@code null} to clear
   */
  public void setTargetGapSummary(@Nullable GapSummary value) {
    _targetGapSummary = value;
  }

  /**
   * Get the "{@literal Confidence Score}".
   *
   * <p>
   * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
   *
   * @return the confidence-score value, or {@code null} if not set
   */
  @Nullable
  public ConfidenceScore getConfidenceScore() {
    return _confidenceScore;
  }

  /**
   * Set the "{@literal Confidence Score}".
   *
   * <p>
   * This records either a string category or a decimal value from 0-1 representing a percentage. Both of these values describe an estimation of the author's confidence that this mapping is correct and accurate.
   *
   * @param value
   *           the confidence-score value to set, or {@code null} to clear
   */
  public void setConfidenceScore(@Nullable ConfidenceScore value) {
    _confidenceScore = value;
  }

  /**
   * Get the "{@literal Coverage}".
   *
   * <p>
   * A decimal value from 0-1, representing the percentage coverage of the targets by the sources.
   *
   * @return the coverage value, or {@code null} if not set
   */
  @Nullable
  public Coverage getCoverage() {
    return _coverage;
  }

  /**
   * Set the "{@literal Coverage}".
   *
   * <p>
   * A decimal value from 0-1, representing the percentage coverage of the targets by the sources.
   *
   * @param value
   *           the coverage value to set, or {@code null} to clear
   */
  public void setCoverage(@Nullable Coverage value) {
    _coverage = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
