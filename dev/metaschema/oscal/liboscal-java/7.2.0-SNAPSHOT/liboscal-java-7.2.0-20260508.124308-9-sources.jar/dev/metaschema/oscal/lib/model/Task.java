// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.datatype.adapter.PositiveIntegerAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.math.BigInteger;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
 */
@MetaschemaAssembly(
    formalName = "Task",
    description = "Represents a scheduled event or milestone, which may be associated with a series of assessment actions.",
    name = "task",
    moduleClass = OscalAssessmentCommonModule.class
)
public class Task implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this task elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>task</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Task Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this task elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `task` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The type of task.
   */
  @BoundFlag(
      formalName = "Task Type",
      description = "The type of task.",
      name = "type",
      required = true,
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-task-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "milestone", description = "The task represents a planned milestone."), @AllowedValue(value = "action", description = "The task represents a specific assessment action to be performed.")}))
  )
  private String _type;

  /**
   * The title for this task.
   */
  @BoundField(
      formalName = "Task Title",
      description = "The title for this task.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of this task.
   */
  @BoundField(
      formalName = "Task Description",
      description = "A human-readable description of this task.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * The timing under which the task is intended to occur.
   */
  @BoundAssembly(
      formalName = "Event Timing",
      description = "The timing under which the task is intended to occur.",
      useName = "timing"
  )
  private Timing _timing;

  /**
   * Used to indicate that a task is dependent on another task.
   */
  @BoundAssembly(
      formalName = "Task Dependency",
      description = "Used to indicate that a task is dependent on another task.",
      useName = "dependency",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "dependencies", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Dependency> _dependencies;

  /**
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   */
  @BoundAssembly(
      formalName = "Task",
      description = "Represents a scheduled event or milestone, which may be associated with a series of assessment actions.",
      useName = "task",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "tasks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Task> _tasks;

  /**
   * Identifies an individual activity to be performed as part of a task.
   */
  @BoundAssembly(
      formalName = "Associated Activity",
      description = "Identifies an individual activity to be performed as part of a task.",
      useName = "associated-activity",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "associated-activities", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AssociatedActivity> _associatedActivities;

  /**
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   */
  @BoundAssembly(
      formalName = "Subject of Assessment",
      description = "Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.",
      useName = "subject",
      remarks = "The assessment subjects that the activity was performed against.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "subjects", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AssessmentSubject> _subjects;

  /**
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   */
  @BoundAssembly(
      formalName = "Responsible Role",
      description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
      useName = "responsible-role",
      remarks = "Identifies the person or organization responsible for performing a specific role related to the task.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleRole> _responsibleRoles;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Task} instance with no metadata.
   */
  public Task() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Task} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Task(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Task Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this task elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>task</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Task Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this task elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>task</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Task Type}".
   *
   * <p>
   * The type of task.
   *
   * @return the type value
   */
  @NonNull
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Task Type}".
   *
   * <p>
   * The type of task.
   *
   * @param value
   *           the type value to set
   */
  public void setType(@NonNull String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Task Title}".
   *
   * <p>
   * The title for this task.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Task Title}".
   *
   * <p>
   * The title for this task.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Task Description}".
   *
   * <p>
   * A human-readable description of this task.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Task Description}".
   *
   * <p>
   * A human-readable description of this task.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Event Timing}".
   *
   * <p>
   * The timing under which the task is intended to occur.
   *
   * @return the timing value, or {@code null} if not set
   */
  @Nullable
  public Timing getTiming() {
    return _timing;
  }

  /**
   * Set the "{@literal Event Timing}".
   *
   * <p>
   * The timing under which the task is intended to occur.
   *
   * @param value
   *           the timing value to set, or {@code null} to clear
   */
  public void setTiming(@Nullable Timing value) {
    _timing = value;
  }

  /**
   * Get the "{@literal Task Dependency}".
   *
   * <p>
   * Used to indicate that a task is dependent on another task.
   *
   * @return the dependency value
   */
  @NonNull
  public List<Dependency> getDependencies() {
    if (_dependencies == null) {
      _dependencies = new LinkedList<>();
    }
    return ObjectUtils.notNull(_dependencies);
  }

  /**
   * Set the "{@literal Task Dependency}".
   *
   * <p>
   * Used to indicate that a task is dependent on another task.
   *
   * @param value
   *           the dependency value to set
   */
  public void setDependencies(@NonNull List<Dependency> value) {
    _dependencies = value;
  }

  /**
   * Add a new {@link Dependency} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addDependency(Dependency item) {
    Dependency value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_dependencies == null) {
      _dependencies = new LinkedList<>();
    }
    return _dependencies.add(value);
  }

  /**
   * Remove the first matching {@link Dependency} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeDependency(Dependency item) {
    Dependency value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _dependencies != null && _dependencies.remove(value);
  }

  /**
   * Get the "{@literal Task}".
   *
   * <p>
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   *
   * @return the task value
   */
  @NonNull
  public List<Task> getTasks() {
    if (_tasks == null) {
      _tasks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_tasks);
  }

  /**
   * Set the "{@literal Task}".
   *
   * <p>
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   *
   * @param value
   *           the task value to set
   */
  public void setTasks(@NonNull List<Task> value) {
    _tasks = value;
  }

  /**
   * Add a new {@link Task} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addTask(Task item) {
    Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_tasks == null) {
      _tasks = new LinkedList<>();
    }
    return _tasks.add(value);
  }

  /**
   * Remove the first matching {@link Task} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeTask(Task item) {
    Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _tasks != null && _tasks.remove(value);
  }

  /**
   * Get the "{@literal Associated Activity}".
   *
   * <p>
   * Identifies an individual activity to be performed as part of a task.
   *
   * @return the associated-activity value
   */
  @NonNull
  public List<AssociatedActivity> getAssociatedActivities() {
    if (_associatedActivities == null) {
      _associatedActivities = new LinkedList<>();
    }
    return ObjectUtils.notNull(_associatedActivities);
  }

  /**
   * Set the "{@literal Associated Activity}".
   *
   * <p>
   * Identifies an individual activity to be performed as part of a task.
   *
   * @param value
   *           the associated-activity value to set
   */
  public void setAssociatedActivities(@NonNull List<AssociatedActivity> value) {
    _associatedActivities = value;
  }

  /**
   * Add a new {@link AssociatedActivity} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAssociatedActivity(AssociatedActivity item) {
    AssociatedActivity value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_associatedActivities == null) {
      _associatedActivities = new LinkedList<>();
    }
    return _associatedActivities.add(value);
  }

  /**
   * Remove the first matching {@link AssociatedActivity} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAssociatedActivity(AssociatedActivity item) {
    AssociatedActivity value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _associatedActivities != null && _associatedActivities.remove(value);
  }

  /**
   * Get the "{@literal Subject of Assessment}".
   *
   * <p>
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   *
   * @return the subject value
   */
  @NonNull
  public List<AssessmentSubject> getSubjects() {
    if (_subjects == null) {
      _subjects = new LinkedList<>();
    }
    return ObjectUtils.notNull(_subjects);
  }

  /**
   * Set the "{@literal Subject of Assessment}".
   *
   * <p>
   * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
   *
   * @param value
   *           the subject value to set
   */
  public void setSubjects(@NonNull List<AssessmentSubject> value) {
    _subjects = value;
  }

  /**
   * Add a new {@link AssessmentSubject} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSubject(AssessmentSubject item) {
    AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_subjects == null) {
      _subjects = new LinkedList<>();
    }
    return _subjects.add(value);
  }

  /**
   * Remove the first matching {@link AssessmentSubject} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSubject(AssessmentSubject item) {
    AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _subjects != null && _subjects.remove(value);
  }

  /**
   * Get the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @return the responsible-role value
   */
  @NonNull
  public List<ResponsibleRole> getResponsibleRoles() {
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleRoles);
  }

  /**
   * Set the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @param value
   *           the responsible-role value to set
   */
  public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
    _responsibleRoles = value;
  }

  /**
   * Add a new {@link ResponsibleRole} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return _responsibleRoles.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleRoles != null && _responsibleRoles.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * The timing under which the task is intended to occur.
   */
  @MetaschemaAssembly(
      formalName = "Event Timing",
      description = "The timing under which the task is intended to occur.",
      name = "timing",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class Timing implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * The task is intended to occur on the specified date.
     */
    @BoundAssembly(
        formalName = "On Date Condition",
        description = "The task is intended to occur on the specified date.",
        useName = "on-date",
        minOccurs = 1
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private OnDate _onDate;

    /**
     * The task is intended to occur within the specified date range.
     */
    @BoundAssembly(
        formalName = "On Date Range Condition",
        description = "The task is intended to occur within the specified date range.",
        useName = "within-date-range",
        minOccurs = 1
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private WithinDateRange _withinDateRange;

    /**
     * The task is intended to occur at the specified frequency.
     */
    @BoundAssembly(
        formalName = "Frequency Condition",
        description = "The task is intended to occur at the specified frequency.",
        useName = "at-frequency",
        minOccurs = 1
    )
    @BoundChoice(
        choiceId = "choice-1"
    )
    private AtFrequency _atFrequency;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing} instance with no metadata.
     */
    public Timing() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Timing(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal On Date Condition}".
     *
     * <p>
     * The task is intended to occur on the specified date.
     *
     * @return the on-date value, or {@code null} if not set
     */
    @Nullable
    public OnDate getOnDate() {
      return _onDate;
    }

    /**
     * Set the "{@literal On Date Condition}".
     *
     * <p>
     * The task is intended to occur on the specified date.
     *
     * @param value
     *           the on-date value to set, or {@code null} to clear
     */
    public void setOnDate(@Nullable OnDate value) {
      _onDate = value;
    }

    /**
     * Get the "{@literal On Date Range Condition}".
     *
     * <p>
     * The task is intended to occur within the specified date range.
     *
     * @return the within-date-range value, or {@code null} if not set
     */
    @Nullable
    public WithinDateRange getWithinDateRange() {
      return _withinDateRange;
    }

    /**
     * Set the "{@literal On Date Range Condition}".
     *
     * <p>
     * The task is intended to occur within the specified date range.
     *
     * @param value
     *           the within-date-range value to set, or {@code null} to clear
     */
    public void setWithinDateRange(@Nullable WithinDateRange value) {
      _withinDateRange = value;
    }

    /**
     * Get the "{@literal Frequency Condition}".
     *
     * <p>
     * The task is intended to occur at the specified frequency.
     *
     * @return the at-frequency value, or {@code null} if not set
     */
    @Nullable
    public AtFrequency getAtFrequency() {
      return _atFrequency;
    }

    /**
     * Set the "{@literal Frequency Condition}".
     *
     * <p>
     * The task is intended to occur at the specified frequency.
     *
     * @param value
     *           the at-frequency value to set, or {@code null} to clear
     */
    public void setAtFrequency(@Nullable AtFrequency value) {
      _atFrequency = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * The task is intended to occur on the specified date.
     */
    @MetaschemaAssembly(
        formalName = "On Date Condition",
        description = "The task is intended to occur on the specified date.",
        name = "on-date",
        moduleClass = OscalAssessmentCommonModule.class
    )
    public static class OnDate implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * The task must occur on the specified date.
       */
      @BoundFlag(
          formalName = "On Date Condition",
          description = "The task must occur on the specified date.",
          name = "date",
          required = true,
          typeAdapter = DateTimeWithTZAdapter.class
      )
      private ZonedDateTime _date;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing.OnDate} instance with no metadata.
       */
      public OnDate() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing.OnDate} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public OnDate(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal On Date Condition}".
       *
       * <p>
       * The task must occur on the specified date.
       *
       * @return the date value
       */
      @NonNull
      public ZonedDateTime getDate() {
        return _date;
      }

      /**
       * Set the "{@literal On Date Condition}".
       *
       * <p>
       * The task must occur on the specified date.
       *
       * @param value
       *           the date value to set
       */
      public void setDate(@NonNull ZonedDateTime value) {
        _date = value;
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }

    /**
     * The task is intended to occur within the specified date range.
     */
    @MetaschemaAssembly(
        formalName = "On Date Range Condition",
        description = "The task is intended to occur within the specified date range.",
        name = "within-date-range",
        moduleClass = OscalAssessmentCommonModule.class
    )
    public static class WithinDateRange implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * The task must occur on or after the specified date.
       */
      @BoundFlag(
          formalName = "Start Date Condition",
          description = "The task must occur on or after the specified date.",
          name = "start",
          required = true,
          typeAdapter = DateTimeWithTZAdapter.class
      )
      private ZonedDateTime _start;

      /**
       * The task must occur on or before the specified date.
       */
      @BoundFlag(
          formalName = "End Date Condition",
          description = "The task must occur on or before the specified date.",
          name = "end",
          required = true,
          typeAdapter = DateTimeWithTZAdapter.class
      )
      private ZonedDateTime _end;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing.WithinDateRange} instance with no metadata.
       */
      public WithinDateRange() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing.WithinDateRange} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public WithinDateRange(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Start Date Condition}".
       *
       * <p>
       * The task must occur on or after the specified date.
       *
       * @return the start value
       */
      @NonNull
      public ZonedDateTime getStart() {
        return _start;
      }

      /**
       * Set the "{@literal Start Date Condition}".
       *
       * <p>
       * The task must occur on or after the specified date.
       *
       * @param value
       *           the start value to set
       */
      public void setStart(@NonNull ZonedDateTime value) {
        _start = value;
      }

      /**
       * Get the "{@literal End Date Condition}".
       *
       * <p>
       * The task must occur on or before the specified date.
       *
       * @return the end value
       */
      @NonNull
      public ZonedDateTime getEnd() {
        return _end;
      }

      /**
       * Set the "{@literal End Date Condition}".
       *
       * <p>
       * The task must occur on or before the specified date.
       *
       * @param value
       *           the end value to set
       */
      public void setEnd(@NonNull ZonedDateTime value) {
        _end = value;
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }

    /**
     * The task is intended to occur at the specified frequency.
     */
    @MetaschemaAssembly(
        formalName = "Frequency Condition",
        description = "The task is intended to occur at the specified frequency.",
        name = "at-frequency",
        moduleClass = OscalAssessmentCommonModule.class
    )
    public static class AtFrequency implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * The task must occur after the specified period has elapsed.
       */
      @BoundFlag(
          formalName = "Period",
          description = "The task must occur after the specified period has elapsed.",
          name = "period",
          required = true,
          typeAdapter = PositiveIntegerAdapter.class
      )
      private BigInteger _period;

      /**
       * The unit of time for the period.
       */
      @BoundFlag(
          formalName = "Time Unit",
          description = "The unit of time for the period.",
          name = "unit",
          required = true,
          typeAdapter = StringAdapter.class,
          valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-timing-unit-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "seconds", description = "The period is specified in seconds."), @AllowedValue(value = "minutes", description = "The period is specified in minutes."), @AllowedValue(value = "hours", description = "The period is specified in hours."), @AllowedValue(value = "days", description = "The period is specified in days."), @AllowedValue(value = "months", description = "The period is specified in calendar months."), @AllowedValue(value = "years", description = "The period is specified in calendar years.")}))
      )
      private String _unit;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing.AtFrequency} instance with no metadata.
       */
      public AtFrequency() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Timing.AtFrequency} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public AtFrequency(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Period}".
       *
       * <p>
       * The task must occur after the specified period has elapsed.
       *
       * @return the period value
       */
      @NonNull
      public BigInteger getPeriod() {
        return _period;
      }

      /**
       * Set the "{@literal Period}".
       *
       * <p>
       * The task must occur after the specified period has elapsed.
       *
       * @param value
       *           the period value to set
       */
      public void setPeriod(@NonNull BigInteger value) {
        _period = value;
      }

      /**
       * Get the "{@literal Time Unit}".
       *
       * <p>
       * The unit of time for the period.
       *
       * @return the unit value
       */
      @NonNull
      public String getUnit() {
        return _unit;
      }

      /**
       * Set the "{@literal Time Unit}".
       *
       * <p>
       * The unit of time for the period.
       *
       * @param value
       *           the unit value to set
       */
      public void setUnit(@NonNull String value) {
        _unit = value;
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }

  /**
   * Used to indicate that a task is dependent on another task.
   */
  @MetaschemaAssembly(
      formalName = "Task Dependency",
      description = "Used to indicate that a task is dependent on another task.",
      name = "dependency",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class Dependency implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique task.
     */
    @BoundFlag(
        formalName = "Task Universally Unique Identifier Reference",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a unique task.",
        name = "task-uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _taskUuid;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Dependency} instance with no metadata.
     */
    public Dependency() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.Dependency} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Dependency(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Task Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique task.
     *
     * @return the task-uuid value
     */
    @NonNull
    public UUID getTaskUuid() {
      return _taskUuid;
    }

    /**
     * Set the "{@literal Task Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a unique task.
     *
     * @param value
     *           the task-uuid value to set
     */
    public void setTaskUuid(@NonNull UUID value) {
      _taskUuid = value;
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }

  /**
   * Identifies an individual activity to be performed as part of a task.
   */
  @MetaschemaAssembly(
      formalName = "Associated Activity",
      description = "Identifies an individual activity to be performed as part of a task.",
      name = "associated-activity",
      moduleClass = OscalAssessmentCommonModule.class,
      modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-associated-activity-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
  )
  public static class AssociatedActivity implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an activity defined in the list of activities.
     */
    @BoundFlag(
        formalName = "Activity Universally Unique Identifier Reference",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to an activity defined in the list of activities.",
        name = "activity-uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _activityUuid;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     */
    @BoundAssembly(
        formalName = "Responsible Role",
        description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
        useName = "responsible-role",
        remarks = "Identifies the person or organization responsible for performing a specific role defined by the activity.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ResponsibleRole> _responsibleRoles;

    /**
     * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
     */
    @BoundAssembly(
        formalName = "Subject of Assessment",
        description = "Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.",
        useName = "subject",
        minOccurs = 1,
        maxOccurs = -1,
        groupAs = @GroupAs(name = "subjects", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<AssessmentSubject> _subjects;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.AssociatedActivity} instance with no metadata.
     */
    public AssociatedActivity() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Task.AssociatedActivity} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public AssociatedActivity(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Activity Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an activity defined in the list of activities.
     *
     * @return the activity-uuid value
     */
    @NonNull
    public UUID getActivityUuid() {
      return _activityUuid;
    }

    /**
     * Set the "{@literal Activity Universally Unique Identifier Reference}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to an activity defined in the list of activities.
     *
     * @param value
     *           the activity-uuid value to set
     */
    public void setActivityUuid(@NonNull UUID value) {
      _activityUuid = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @return the responsible-role value
     */
    @NonNull
    public List<ResponsibleRole> getResponsibleRoles() {
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return ObjectUtils.notNull(_responsibleRoles);
    }

    /**
     * Set the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @param value
     *           the responsible-role value to set
     */
    public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
      _responsibleRoles = value;
    }

    /**
     * Add a new {@link ResponsibleRole} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return _responsibleRoles.add(value);
    }

    /**
     * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _responsibleRoles != null && _responsibleRoles.remove(value);
    }

    /**
     * Get the "{@literal Subject of Assessment}".
     *
     * <p>
     * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
     *
     * @return the subject value
     */
    @NonNull
    public List<AssessmentSubject> getSubjects() {
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return ObjectUtils.notNull(_subjects);
    }

    /**
     * Set the "{@literal Subject of Assessment}".
     *
     * <p>
     * Identifies system elements being assessed, such as components, inventory items, and locations. In the assessment plan, this identifies a planned assessment subject. In the assessment results this is an actual assessment subject, and reflects any changes from the plan. exactly what will be the focus of this assessment. Any subjects not identified in this way are out-of-scope.
     *
     * @param value
     *           the subject value to set
     */
    public void setSubjects(@NonNull List<AssessmentSubject> value) {
      _subjects = value;
    }

    /**
     * Add a new {@link AssessmentSubject} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addSubject(AssessmentSubject item) {
      AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return _subjects.add(value);
    }

    /**
     * Remove the first matching {@link AssessmentSubject} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeSubject(AssessmentSubject item) {
      AssessmentSubject value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _subjects != null && _subjects.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
