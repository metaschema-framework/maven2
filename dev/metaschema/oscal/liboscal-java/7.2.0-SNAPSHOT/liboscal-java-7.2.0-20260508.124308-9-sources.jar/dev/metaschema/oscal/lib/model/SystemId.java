// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundFieldValue;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaField;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this system identification property elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. When referencing an externally defined <code>system identification</code>, the <code>system identification</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same system across revisions of the document.
 */
@MetaschemaField(
    formalName = "System Identification",
    description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this system identification property elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). When referencing an externally defined `system identification`, the `system identification` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same system across revisions of the document.",
    name = "system-id",
    moduleClass = OscalImplementationCommonModule.class
)
public class SystemId implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Identifies the identification system from which the provided identifier was assigned.
   */
  @BoundFlag(
      formalName = "Identification System Type",
      description = "Identifies the identification system from which the provided identifier was assigned.",
      name = "identifier-type",
      typeAdapter = UriAdapter.class,
      remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-system-identifier-type-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "http://fedramp.gov", description = "\\*\\*deprecated\\*\\* The identifier was assigned by FedRAMP. This has been deprecated; use `http://fedramp.gov/ns/oscal` instead.", deprecatedVersion = "1.0.3"), @AllowedValue(value = "http://fedramp.gov/ns/oscal", description = "The identifier was assigned by FedRAMP."), @AllowedValue(value = "https://ietf.org/rfc/rfc4122", description = "\\*\\*deprecated\\*\\* A Universally Unique Identifier (UUID) as defined by RFC4122. This value has been deprecated; use `http://datatracker.ietf.org/doc/html/rfc4122` instead.", deprecatedVersion = "1.0.3"), @AllowedValue(value = "http://ietf.org/rfc/rfc4122", description = "\\*\\*deprecated\\*\\* A Universally Unique Identifier (UUID) as defined by RFC4122. This value has been deprecated; use `http://datatracker.ietf.org/doc/html/rfc4122` instead.", deprecatedVersion = "1.1.4"), @AllowedValue(value = "http://datatracker.ietf.org/doc/html/rfc4122", description = "A Universally Unique Identifier (UUID) as defined by RFC4122.")}))
  )
  private URI _identifierType;

  /**
   * The field value.
   */
  @BoundFieldValue(
      valueKeyName = "id"
  )
  private String _id;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemId} instance with no metadata.
   */
  public SystemId() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemId} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SystemId(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Identification System Type}".
   *
   * <p>
   * Identifies the identification system from which the provided identifier was assigned.
   *
   * @return the identifier-type value, or {@code null} if not set
   */
  @Nullable
  public URI getIdentifierType() {
    return _identifierType;
  }

  /**
   * Set the "{@literal Identification System Type}".
   *
   * <p>
   * Identifies the identification system from which the provided identifier was assigned.
   *
   * @param value
   *           the identifier-type value to set, or {@code null} to clear
   */
  public void setIdentifierType(@Nullable URI value) {
    _identifierType = value;
  }

  /**
   * Get the field value.
   *
   * @return the value
   */
  @Nullable
  public String getId() {
    return _id;
  }

  /**
   * Set the field value.
   *
   * @param value
   *           the value to set
   */
  public void setId(@Nullable String value) {
    _id = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
