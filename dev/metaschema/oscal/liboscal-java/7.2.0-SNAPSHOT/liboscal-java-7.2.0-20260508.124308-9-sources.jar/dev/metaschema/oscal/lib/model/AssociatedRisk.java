// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Relates the finding to a set of referenced risks that were used to determine the finding.
 */
@MetaschemaAssembly(
    formalName = "Associated Risk",
    description = "Relates the finding to a set of referenced risks that were used to determine the finding.",
    name = "associated-risk",
    moduleClass = OscalAssessmentCommonModule.class
)
public class AssociatedRisk implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a risk defined in the list of risks.
   */
  @BoundFlag(
      formalName = "Risk Universally Unique Identifier Reference",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a risk defined in the list of risks.",
      name = "risk-uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _riskUuid;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssociatedRisk} instance with no metadata.
   */
  public AssociatedRisk() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssociatedRisk} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public AssociatedRisk(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Risk Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a risk defined in the list of risks.
   *
   * @return the risk-uuid value
   */
  @NonNull
  public UUID getRiskUuid() {
    return _riskUuid;
  }

  /**
   * Set the "{@literal Risk Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a risk defined in the list of risks.
   *
   * @param value
   *           the risk-uuid value to set
   */
  public void setRiskUuid(@NonNull UUID value) {
    _riskUuid = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
