// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.datatype.object.AmbiguousDate;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Contains the characteristics of the system, such as its name, purpose, and security impact level.
 */
@MetaschemaAssembly(
    formalName = "System Characteristics",
    description = "Contains the characteristics of the system, such as its name, purpose, and security impact level.",
    name = "system-characteristics",
    moduleClass = OscalSspModule.class,
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-system-characteristics-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "identity-assurance-level", description = "A value of 1, 2, or 3 as defined by [SP 800-63-3](https://doi.org/10.6028/NIST.SP.800-63-3)."), @AllowedValue(value = "authenticator-assurance-level", description = "A value of 1, 2, or 3 as defined by [SP 800-63-3](https://doi.org/10.6028/NIST.SP.800-63-3)."), @AllowedValue(value = "federation-assurance-level", description = "A value of 1, 2, or 3 as defined by [SP 800-63-3](https://doi.org/10.6028/NIST.SP.800-63-3).")}), @AllowedValues(id = "oscal-system-characteristics-prop-sp-800-63-assurance-level-values", level = IConstraint.Level.ERROR, target = "prop[@name=('identity-assurance-level','authenticator-assurance-level','federation-assurance-level')]/@value", values = {@AllowedValue(value = "1", description = "As defined by [SP 800-63-3](https://doi.org/10.6028/NIST.SP.800-63-3)."), @AllowedValue(value = "2", description = "As defined by [SP 800-63-3](https://doi.org/10.6028/NIST.SP.800-63-3)."), @AllowedValue(value = "3", description = "As defined by [SP 800-63-3](https://doi.org/10.6028/NIST.SP.800-63-3).")}), @AllowedValues(id = "oscal-system-characteristics-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "cloud-deployment-model", description = "The associated value is one of: public-cloud, private-cloud, community-cloud, government-only-cloud, hybrid-cloud, or other."), @AllowedValue(value = "cloud-service-model", description = "The associated value is one of: saas, paas, iaas, or other.")}), @AllowedValues(id = "oscal-system-characteristics-prop-cloud-deployment-model-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='cloud-deployment-model']/@value", values = {@AllowedValue(value = "public-cloud", description = "The public cloud deployment model as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145)."), @AllowedValue(value = "private-cloud", description = "The private cloud deployment model as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145)."), @AllowedValue(value = "community-cloud", description = "The community cloud deployment model as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145)."), @AllowedValue(value = "hybrid-cloud", description = "The hybrid cloud deployment model as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145)."), @AllowedValue(value = "government-only-cloud", description = "A specific type of community-cloud for use only by government services."), @AllowedValue(value = "other", description = "Any other type of cloud deployment model that is exclusive to the other choices.")}, remarks = "The hybrid cloud deployment model, as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145), can be supported by selecting two or more of the existing deployment models."), @AllowedValues(id = "oscal-system-characteristics-prop-cloud-service-model-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='cloud-service-model']/@value", values = {@AllowedValue(value = "saas", description = "Software as a service (SaaS) cloud service model as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145)."), @AllowedValue(value = "paas", description = "Platform as a service (PaaS) cloud service model as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145)."), @AllowedValue(value = "iaas", description = "Infrastructure as a service (IaaS) cloud service model as defined by [The NIST Definition of Cloud Computing](https://doi.org/10.6028/NIST.SP.800-145)."), @AllowedValue(value = "other", description = "Any other type of cloud service model that is exclusive to the other choices.")}), @AllowedValues(id = "oscal-system-characteristics-responsible-party-role-id-values", level = IConstraint.Level.ERROR, target = "responsible-party/@role-id", allowOthers = true, values = {@AllowedValue(value = "authorizing-official", description = "The authorizing official for this system."), @AllowedValue(value = "authorizing-official-poc", description = "The authorizing official's designated point of contact (POC) for this system."), @AllowedValue(value = "system-owner", description = "The executive ultimately accountable for the system."), @AllowedValue(value = "system-poc-management", description = "The primary management-level point of contact (POC) for the system."), @AllowedValue(value = "system-poc-technical", description = "The primary technical point of contact (POC) for the system."), @AllowedValue(value = "system-poc-other", description = "Other point of contact (POC) for the system that is not the management or technical POC."), @AllowedValue(value = "information-system-security-officer", description = "The primary role responsible for ensuring the organization operates the system securely."), @AllowedValue(value = "privacy-poc", description = "The point of contact (POC) responsible for identifying privacy information within the system, and ensuring its protection if present.")})}),
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-ssp-system-characteristics-responsible-party", level = IConstraint.Level.ERROR, target = "responsible-party", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-party` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
)
public class SystemCharacteristics implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this system identification property elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. When referencing an externally defined <code>system identification</code>, the <code>system identification</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same system across revisions of the document.
   */
  @BoundField(
      formalName = "System Identification",
      description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this system identification property elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). When referencing an externally defined `system identification`, the `system identification` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same system across revisions of the document.",
      useName = "system-id",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "system-ids", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SystemId> _systemIds;

  /**
   * The full name of the system.
   */
  @BoundField(
      formalName = "System Name - Full",
      description = "The full name of the system.",
      useName = "system-name",
      minOccurs = 1,
      typeAdapter = StringAdapter.class
  )
  private String _systemName;

  /**
   * A short name for the system, such as an acronym, that is suitable for display in a data table or summary list.
   */
  @BoundField(
      formalName = "System Name - Short",
      description = "A short name for the system, such as an acronym, that is suitable for display in a data table or summary list.",
      useName = "system-name-short",
      remarks = "Since `system-name-short` is optional, if the `system-name-short` is not provided, the `system-name` can be used as a substitute.",
      typeAdapter = StringAdapter.class
  )
  private String _systemNameShort;

  /**
   * A summary of the system.
   */
  @BoundField(
      formalName = "System Description",
      description = "A summary of the system.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * The date the system received its authorization.
   */
  @BoundField(
      formalName = "System Authorization Date",
      description = "The date the system received its authorization.",
      useName = "date-authorized",
      typeAdapter = DateAdapter.class
  )
  private AmbiguousDate _dateAuthorized;

  /**
   * The overall information system sensitivity categorization, such as defined by <a href="https://doi.org/10.6028/NIST.FIPS.199">FIPS-199</a>.
   */
  @BoundField(
      formalName = "Security Sensitivity Level",
      description = "The overall information system sensitivity categorization, such as defined by [FIPS-199](https://doi.org/10.6028/NIST.FIPS.199).",
      useName = "security-sensitivity-level",
      remarks = "Often, organizations require the security sensitivity level to correspond with the highest confidentiality, integrity, or availability level identified by `security-impact-level`.",
      typeAdapter = StringAdapter.class
  )
  private String _securitySensitivityLevel;

  /**
   * Contains details about all information types that are stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
   */
  @BoundAssembly(
      formalName = "System Information",
      description = "Contains details about all information types that are stored, processed, or transmitted by the system, such as privacy information, and those defined in [NIST SP 800-60](https://doi.org/10.6028/NIST.SP.800-60v2r1).",
      useName = "system-information",
      minOccurs = 1
  )
  private SystemInformation _systemInformation;

  /**
   * The overall level of expected impact resulting from unauthorized disclosure, modification, or loss of access to information.
   */
  @BoundAssembly(
      formalName = "Security Impact Level",
      description = "The overall level of expected impact resulting from unauthorized disclosure, modification, or loss of access to information.",
      useName = "security-impact-level"
  )
  private SecurityImpactLevel _securityImpactLevel;

  /**
   * Describes the operational status of the system.
   */
  @BoundAssembly(
      formalName = "Status",
      description = "Describes the operational status of the system.",
      useName = "status",
      minOccurs = 1
  )
  private Status _status;

  /**
   * A description of this system's authorization boundary, optionally supplemented by diagrams that illustrate the authorization boundary.
   */
  @BoundAssembly(
      formalName = "Authorization Boundary",
      description = "A description of this system's authorization boundary, optionally supplemented by diagrams that illustrate the authorization boundary.",
      useName = "authorization-boundary",
      minOccurs = 1
  )
  private AuthorizationBoundary _authorizationBoundary;

  /**
   * A description of the system's network architecture, optionally supplemented by diagrams that illustrate the network architecture.
   */
  @BoundAssembly(
      formalName = "Network Architecture",
      description = "A description of the system's network architecture, optionally supplemented by diagrams that illustrate the network architecture.",
      useName = "network-architecture"
  )
  private NetworkArchitecture _networkArchitecture;

  /**
   * A description of the logical flow of information within the system and across its boundaries, optionally supplemented by diagrams that illustrate these flows.
   */
  @BoundAssembly(
      formalName = "Data Flow",
      description = "A description of the logical flow of information within the system and across its boundaries, optionally supplemented by diagrams that illustrate these flows.",
      useName = "data-flow"
  )
  private DataFlow _dataFlow;

  /**
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   */
  @BoundAssembly(
      formalName = "Responsible Party",
      description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
      useName = "responsible-party",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleParty> _responsibleParties;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemCharacteristics} instance with no metadata.
   */
  public SystemCharacteristics() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemCharacteristics} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SystemCharacteristics(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal System Identification}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this system identification property elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. When referencing an externally defined <code>system identification</code>, the <code>system identification</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same system across revisions of the document.
   *
   * @return the system-id value
   */
  @NonNull
  public List<SystemId> getSystemIds() {
    if (_systemIds == null) {
      _systemIds = new LinkedList<>();
    }
    return ObjectUtils.notNull(_systemIds);
  }

  /**
   * Set the "{@literal System Identification}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this system identification property elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. When referencing an externally defined <code>system identification</code>, the <code>system identification</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference). This string should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same system across revisions of the document.
   *
   * @param value
   *           the system-id value to set
   */
  public void setSystemIds(@NonNull List<SystemId> value) {
    _systemIds = value;
  }

  /**
   * Add a new {@link SystemId} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSystemId(SystemId item) {
    SystemId value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_systemIds == null) {
      _systemIds = new LinkedList<>();
    }
    return _systemIds.add(value);
  }

  /**
   * Remove the first matching {@link SystemId} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSystemId(SystemId item) {
    SystemId value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _systemIds != null && _systemIds.remove(value);
  }

  /**
   * Get the "{@literal System Name - Full}".
   *
   * <p>
   * The full name of the system.
   *
   * @return the system-name value
   */
  @NonNull
  public String getSystemName() {
    return _systemName;
  }

  /**
   * Set the "{@literal System Name - Full}".
   *
   * <p>
   * The full name of the system.
   *
   * @param value
   *           the system-name value to set
   */
  public void setSystemName(@NonNull String value) {
    _systemName = value;
  }

  /**
   * Get the "{@literal System Name - Short}".
   *
   * <p>
   * A short name for the system, such as an acronym, that is suitable for display in a data table or summary list.
   *
   * @return the system-name-short value, or {@code null} if not set
   */
  @Nullable
  public String getSystemNameShort() {
    return _systemNameShort;
  }

  /**
   * Set the "{@literal System Name - Short}".
   *
   * <p>
   * A short name for the system, such as an acronym, that is suitable for display in a data table or summary list.
   *
   * @param value
   *           the system-name-short value to set, or {@code null} to clear
   */
  public void setSystemNameShort(@Nullable String value) {
    _systemNameShort = value;
  }

  /**
   * Get the "{@literal System Description}".
   *
   * <p>
   * A summary of the system.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal System Description}".
   *
   * <p>
   * A summary of the system.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal System Authorization Date}".
   *
   * <p>
   * The date the system received its authorization.
   *
   * @return the date-authorized value, or {@code null} if not set
   */
  @Nullable
  public AmbiguousDate getDateAuthorized() {
    return _dateAuthorized;
  }

  /**
   * Set the "{@literal System Authorization Date}".
   *
   * <p>
   * The date the system received its authorization.
   *
   * @param value
   *           the date-authorized value to set, or {@code null} to clear
   */
  public void setDateAuthorized(@Nullable AmbiguousDate value) {
    _dateAuthorized = value;
  }

  /**
   * Get the "{@literal Security Sensitivity Level}".
   *
   * <p>
   * The overall information system sensitivity categorization, such as defined by <a href="https://doi.org/10.6028/NIST.FIPS.199">FIPS-199</a>.
   *
   * @return the security-sensitivity-level value, or {@code null} if not set
   */
  @Nullable
  public String getSecuritySensitivityLevel() {
    return _securitySensitivityLevel;
  }

  /**
   * Set the "{@literal Security Sensitivity Level}".
   *
   * <p>
   * The overall information system sensitivity categorization, such as defined by <a href="https://doi.org/10.6028/NIST.FIPS.199">FIPS-199</a>.
   *
   * @param value
   *           the security-sensitivity-level value to set, or {@code null} to clear
   */
  public void setSecuritySensitivityLevel(@Nullable String value) {
    _securitySensitivityLevel = value;
  }

  /**
   * Get the "{@literal System Information}".
   *
   * <p>
   * Contains details about all information types that are stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
   *
   * @return the system-information value
   */
  @NonNull
  public SystemInformation getSystemInformation() {
    return _systemInformation;
  }

  /**
   * Set the "{@literal System Information}".
   *
   * <p>
   * Contains details about all information types that are stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
   *
   * @param value
   *           the system-information value to set
   */
  public void setSystemInformation(@NonNull SystemInformation value) {
    _systemInformation = value;
  }

  /**
   * Get the "{@literal Security Impact Level}".
   *
   * <p>
   * The overall level of expected impact resulting from unauthorized disclosure, modification, or loss of access to information.
   *
   * @return the security-impact-level value, or {@code null} if not set
   */
  @Nullable
  public SecurityImpactLevel getSecurityImpactLevel() {
    return _securityImpactLevel;
  }

  /**
   * Set the "{@literal Security Impact Level}".
   *
   * <p>
   * The overall level of expected impact resulting from unauthorized disclosure, modification, or loss of access to information.
   *
   * @param value
   *           the security-impact-level value to set, or {@code null} to clear
   */
  public void setSecurityImpactLevel(@Nullable SecurityImpactLevel value) {
    _securityImpactLevel = value;
  }

  /**
   * Get the "{@literal Status}".
   *
   * <p>
   * Describes the operational status of the system.
   *
   * @return the status value
   */
  @NonNull
  public Status getStatus() {
    return _status;
  }

  /**
   * Set the "{@literal Status}".
   *
   * <p>
   * Describes the operational status of the system.
   *
   * @param value
   *           the status value to set
   */
  public void setStatus(@NonNull Status value) {
    _status = value;
  }

  /**
   * Get the "{@literal Authorization Boundary}".
   *
   * <p>
   * A description of this system's authorization boundary, optionally supplemented by diagrams that illustrate the authorization boundary.
   *
   * @return the authorization-boundary value
   */
  @NonNull
  public AuthorizationBoundary getAuthorizationBoundary() {
    return _authorizationBoundary;
  }

  /**
   * Set the "{@literal Authorization Boundary}".
   *
   * <p>
   * A description of this system's authorization boundary, optionally supplemented by diagrams that illustrate the authorization boundary.
   *
   * @param value
   *           the authorization-boundary value to set
   */
  public void setAuthorizationBoundary(@NonNull AuthorizationBoundary value) {
    _authorizationBoundary = value;
  }

  /**
   * Get the "{@literal Network Architecture}".
   *
   * <p>
   * A description of the system's network architecture, optionally supplemented by diagrams that illustrate the network architecture.
   *
   * @return the network-architecture value, or {@code null} if not set
   */
  @Nullable
  public NetworkArchitecture getNetworkArchitecture() {
    return _networkArchitecture;
  }

  /**
   * Set the "{@literal Network Architecture}".
   *
   * <p>
   * A description of the system's network architecture, optionally supplemented by diagrams that illustrate the network architecture.
   *
   * @param value
   *           the network-architecture value to set, or {@code null} to clear
   */
  public void setNetworkArchitecture(@Nullable NetworkArchitecture value) {
    _networkArchitecture = value;
  }

  /**
   * Get the "{@literal Data Flow}".
   *
   * <p>
   * A description of the logical flow of information within the system and across its boundaries, optionally supplemented by diagrams that illustrate these flows.
   *
   * @return the data-flow value, or {@code null} if not set
   */
  @Nullable
  public DataFlow getDataFlow() {
    return _dataFlow;
  }

  /**
   * Set the "{@literal Data Flow}".
   *
   * <p>
   * A description of the logical flow of information within the system and across its boundaries, optionally supplemented by diagrams that illustrate these flows.
   *
   * @param value
   *           the data-flow value to set, or {@code null} to clear
   */
  public void setDataFlow(@Nullable DataFlow value) {
    _dataFlow = value;
  }

  /**
   * Get the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @return the responsible-party value
   */
  @NonNull
  public List<ResponsibleParty> getResponsibleParties() {
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleParties);
  }

  /**
   * Set the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @param value
   *           the responsible-party value to set
   */
  public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
    _responsibleParties = value;
  }

  /**
   * Add a new {@link ResponsibleParty} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return _responsibleParties.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleParties != null && _responsibleParties.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
