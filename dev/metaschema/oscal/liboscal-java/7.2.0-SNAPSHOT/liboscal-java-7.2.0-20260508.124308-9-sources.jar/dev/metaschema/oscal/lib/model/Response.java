// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes either recommended or an actual plan for addressing the risk.
 */
@MetaschemaAssembly(
    formalName = "Risk Response",
    description = "Describes either recommended or an actual plan for addressing the risk.",
    name = "response",
    moduleClass = OscalAssessmentCommonModule.class,
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-response-prop-name", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "type", description = "Risk Response Type")), @AllowedValues(id = "oscal-response-prop-type-value", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='type']/@value", values = {@AllowedValue(value = "avoid", description = "The risk will be eliminated."), @AllowedValue(value = "mitigate", description = "The risk will be reduced."), @AllowedValue(value = "transfer", description = "The risk will be transferred to another organization or entity."), @AllowedValue(value = "accept", description = "The risk will continue to exist without further efforts to address it. (Sometimes referred to as \"Operationally required\")"), @AllowedValue(value = "share", description = "The risk will be partially transferred to another organization or entity."), @AllowedValue(value = "contingency", description = "Plans will be made to address the risk impact if the risk occurs. (This is a form of mitigation.)"), @AllowedValue(value = "none", description = "No response, such as when the identified risk is found to be a false positive.")})})
)
public class Response implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this remediation elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk response</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Remediation Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this remediation elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `risk response` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Identifies whether this is a recommendation, such as from an assessor or tool, or an actual plan accepted by the system owner.
   */
  @BoundFlag(
      formalName = "Remediation Intent",
      description = "Identifies whether this is a recommendation, such as from an assessor or tool, or an actual plan accepted by the system owner.",
      name = "lifecycle",
      required = true,
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-response-lifecycle-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "recommendation", description = "Recommended remediation."), @AllowedValue(value = "planned", description = "The actions intended to resolve the risk."), @AllowedValue(value = "completed", description = "This remediation activities were performed to address the risk.")}))
  )
  private String _lifecycle;

  /**
   * The title for this response activity.
   */
  @BoundField(
      formalName = "Response Title",
      description = "The title for this response activity.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of this response plan.
   */
  @BoundField(
      formalName = "Response Description",
      description = "A human-readable description of this response plan.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   */
  @BoundAssembly(
      formalName = "Origin",
      description = "Identifies the source of the finding, such as a tool, interviewed person, or activity.",
      useName = "origin",
      remarks = "Used to identify the individual and/or tool that generated this recommended or planned response.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "origins", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Origin> _origins;

  /**
   * Identifies an asset required to achieve remediation.
   */
  @BoundAssembly(
      formalName = "Required Asset",
      description = "Identifies an asset required to achieve remediation.",
      useName = "required-asset",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "required-assets", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<RequiredAsset> _requiredAssets;

  /**
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   */
  @BoundAssembly(
      formalName = "Task",
      description = "Represents a scheduled event or milestone, which may be associated with a series of assessment actions.",
      useName = "task",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "tasks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Task> _tasks;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Response} instance with no metadata.
   */
  public Response() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Response} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Response(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Remediation Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this remediation elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk response</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Remediation Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this remediation elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>risk response</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Remediation Intent}".
   *
   * <p>
   * Identifies whether this is a recommendation, such as from an assessor or tool, or an actual plan accepted by the system owner.
   *
   * @return the lifecycle value
   */
  @NonNull
  public String getLifecycle() {
    return _lifecycle;
  }

  /**
   * Set the "{@literal Remediation Intent}".
   *
   * <p>
   * Identifies whether this is a recommendation, such as from an assessor or tool, or an actual plan accepted by the system owner.
   *
   * @param value
   *           the lifecycle value to set
   */
  public void setLifecycle(@NonNull String value) {
    _lifecycle = value;
  }

  /**
   * Get the "{@literal Response Title}".
   *
   * <p>
   * The title for this response activity.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Response Title}".
   *
   * <p>
   * The title for this response activity.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Response Description}".
   *
   * <p>
   * A human-readable description of this response plan.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Response Description}".
   *
   * <p>
   * A human-readable description of this response plan.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @return the origin value
   */
  @NonNull
  public List<Origin> getOrigins() {
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return ObjectUtils.notNull(_origins);
  }

  /**
   * Set the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @param value
   *           the origin value to set
   */
  public void setOrigins(@NonNull List<Origin> value) {
    _origins = value;
  }

  /**
   * Add a new {@link Origin} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return _origins.add(value);
  }

  /**
   * Remove the first matching {@link Origin} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _origins != null && _origins.remove(value);
  }

  /**
   * Get the "{@literal Required Asset}".
   *
   * <p>
   * Identifies an asset required to achieve remediation.
   *
   * @return the required-asset value
   */
  @NonNull
  public List<RequiredAsset> getRequiredAssets() {
    if (_requiredAssets == null) {
      _requiredAssets = new LinkedList<>();
    }
    return ObjectUtils.notNull(_requiredAssets);
  }

  /**
   * Set the "{@literal Required Asset}".
   *
   * <p>
   * Identifies an asset required to achieve remediation.
   *
   * @param value
   *           the required-asset value to set
   */
  public void setRequiredAssets(@NonNull List<RequiredAsset> value) {
    _requiredAssets = value;
  }

  /**
   * Add a new {@link RequiredAsset} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRequiredAsset(RequiredAsset item) {
    RequiredAsset value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_requiredAssets == null) {
      _requiredAssets = new LinkedList<>();
    }
    return _requiredAssets.add(value);
  }

  /**
   * Remove the first matching {@link RequiredAsset} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRequiredAsset(RequiredAsset item) {
    RequiredAsset value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _requiredAssets != null && _requiredAssets.remove(value);
  }

  /**
   * Get the "{@literal Task}".
   *
   * <p>
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   *
   * @return the task value
   */
  @NonNull
  public List<Task> getTasks() {
    if (_tasks == null) {
      _tasks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_tasks);
  }

  /**
   * Set the "{@literal Task}".
   *
   * <p>
   * Represents a scheduled event or milestone, which may be associated with a series of assessment actions.
   *
   * @param value
   *           the task value to set
   */
  public void setTasks(@NonNull List<Task> value) {
    _tasks = value;
  }

  /**
   * Add a new {@link Task} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addTask(Task item) {
    Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_tasks == null) {
      _tasks = new LinkedList<>();
    }
    return _tasks.add(value);
  }

  /**
   * Remove the first matching {@link Task} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeTask(Task item) {
    Task value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _tasks != null && _tasks.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Identifies an asset required to achieve remediation.
   */
  @MetaschemaAssembly(
      formalName = "Required Asset",
      description = "Identifies an asset required to achieve remediation.",
      name = "required-asset",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class RequiredAsset implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this required asset elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>asset</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Required Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this required asset elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `asset` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
     */
    @BoundAssembly(
        formalName = "Identifies the Subject",
        description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented) identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.",
        useName = "subject",
        remarks = "Identifies an asset associated with this requirement, such as a party, system component, or inventory-item.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "subjects", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<SubjectReference> _subjects;

    /**
     * The title for this required asset.
     */
    @BoundField(
        formalName = "Title for Required Asset",
        description = "The title for this required asset.",
        useName = "title",
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * A human-readable description of this required asset.
     */
    @BoundField(
        formalName = "Description of Required Asset",
        description = "A human-readable description of this required asset.",
        useName = "description",
        minOccurs = 1,
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Response.RequiredAsset} instance with no metadata.
     */
    public RequiredAsset() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Response.RequiredAsset} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public RequiredAsset(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Required Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this required asset elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>asset</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Required Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this required asset elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>asset</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Identifies the Subject}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
     *
     * @return the subject value
     */
    @NonNull
    public List<SubjectReference> getSubjects() {
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return ObjectUtils.notNull(_subjects);
    }

    /**
     * Set the "{@literal Identifies the Subject}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
     *
     * @param value
     *           the subject value to set
     */
    public void setSubjects(@NonNull List<SubjectReference> value) {
      _subjects = value;
    }

    /**
     * Add a new {@link SubjectReference} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addSubject(SubjectReference item) {
      SubjectReference value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_subjects == null) {
        _subjects = new LinkedList<>();
      }
      return _subjects.add(value);
    }

    /**
     * Remove the first matching {@link SubjectReference} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeSubject(SubjectReference item) {
      SubjectReference value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _subjects != null && _subjects.remove(value);
    }

    /**
     * Get the "{@literal Title for Required Asset}".
     *
     * <p>
     * The title for this required asset.
     *
     * @return the title value, or {@code null} if not set
     */
    @Nullable
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal Title for Required Asset}".
     *
     * <p>
     * The title for this required asset.
     *
     * @param value
     *           the title value to set, or {@code null} to clear
     */
    public void setTitle(@Nullable MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Description of Required Asset}".
     *
     * <p>
     * A human-readable description of this required asset.
     *
     * @return the description value
     */
    @NonNull
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Description of Required Asset}".
     *
     * <p>
     * A human-readable description of this required asset.
     *
     * @param value
     *           the description value to set
     */
    public void setDescription(@NonNull MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
