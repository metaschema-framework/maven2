// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes an individual observation.
 */
@MetaschemaAssembly(
    formalName = "Observation",
    description = "Describes an individual observation.",
    name = "observation",
    moduleClass = OscalAssessmentCommonModule.class
)
public class Observation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <em>cross-instance</em> scope that can be used to reference this observation elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>observation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Observation Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with *cross-instance* scope that can be used to reference this observation elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `observation` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The title for this observation.
   */
  @BoundField(
      formalName = "Observation Title",
      description = "The title for this observation.",
      useName = "title",
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of this assessment observation.
   */
  @BoundField(
      formalName = "Observation Description",
      description = "A human-readable description of this assessment observation.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies how the observation was made.
   */
  @BoundField(
      formalName = "Observation Method",
      description = "Identifies how the observation was made.",
      useName = "method",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "methods", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-observation-method-type-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "EXAMINE", description = "An inspection was performed."), @AllowedValue(value = "INTERVIEW", description = "An interview was performed."), @AllowedValue(value = "TEST", description = "A manual or automated test was performed."), @AllowedValue(value = "UNKNOWN", description = "This is only for use when converting historic content to OSCAL, where the conversion process cannot initially identify the appropriate method(s).")}))
  )
  private List<String> _methods;

  /**
   * Identifies the nature of the observation. More than one may be used to further qualify and enable filtering.
   */
  @BoundField(
      formalName = "Observation Type",
      description = "Identifies the nature of the observation. More than one may be used to further qualify and enable filtering.",
      useName = "type",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "types", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-observation-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "ssp-statement-issue", description = "A difference between the SSP implementation statement, and actual implementation."), @AllowedValue(value = "control-objective", description = "An observation about the status of a the associated control objective."), @AllowedValue(value = "mitigation", description = "A mitigating factor was identified."), @AllowedValue(value = "finding", description = "\\*\\*(deprecated)\\*\\* Use 'discovery' instead.", deprecatedVersion = "1.1.4"), @AllowedValue(value = "discovery", description = "An observation of potential risk in the system's implementation, identified through security scanning tools, penetration testing, and other means."), @AllowedValue(value = "historic", description = "An observation from a past assessment, which was converted to OSCAL at a later date.")}))
  )
  private List<String> _types;

  /**
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   */
  @BoundAssembly(
      formalName = "Origin",
      description = "Identifies the source of the finding, such as a tool, interviewed person, or activity.",
      useName = "origin",
      remarks = "Used to identify the individual and/or tool that gathered the evidence resulting in the observation identification.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "origins", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Origin> _origins;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
   */
  @BoundAssembly(
      formalName = "Identifies the Subject",
      description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented) identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.",
      useName = "subject",
      remarks = "Identifies who was interviewed, or what was tested or inspected.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "subjects", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SubjectReference> _subjects;

  /**
   * Links this observation to relevant evidence.
   */
  @BoundAssembly(
      formalName = "Relevant Evidence",
      description = "Links this observation to relevant evidence.",
      useName = "relevant-evidence",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "relevant-evidence", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<RelevantEvidence> _relevantEvidence;

  /**
   * Date/time stamp identifying when the finding information was collected.
   */
  @BoundField(
      formalName = "Collected Field",
      description = "Date/time stamp identifying when the finding information was collected.",
      useName = "collected",
      minOccurs = 1,
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _collected;

  /**
   * Date/time identifying when the finding information is out-of-date and no longer valid. Typically used with continuous assessment scenarios.
   */
  @BoundField(
      formalName = "Expires Field",
      description = "Date/time identifying when the finding information is out-of-date and no longer valid. Typically used with continuous assessment scenarios.",
      useName = "expires",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _expires;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Observation} instance with no metadata.
   */
  public Observation() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Observation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Observation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Observation Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <em>cross-instance</em> scope that can be used to reference this observation elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>observation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Observation Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <em>cross-instance</em> scope that can be used to reference this observation elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>observation</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Observation Title}".
   *
   * <p>
   * The title for this observation.
   *
   * @return the title value, or {@code null} if not set
   */
  @Nullable
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Observation Title}".
   *
   * <p>
   * The title for this observation.
   *
   * @param value
   *           the title value to set, or {@code null} to clear
   */
  public void setTitle(@Nullable MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Observation Description}".
   *
   * <p>
   * A human-readable description of this assessment observation.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Observation Description}".
   *
   * <p>
   * A human-readable description of this assessment observation.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Observation Method}".
   *
   * <p>
   * Identifies how the observation was made.
   *
   * @return the method value
   */
  @NonNull
  public List<String> getMethods() {
    if (_methods == null) {
      _methods = new LinkedList<>();
    }
    return ObjectUtils.notNull(_methods);
  }

  /**
   * Set the "{@literal Observation Method}".
   *
   * <p>
   * Identifies how the observation was made.
   *
   * @param value
   *           the method value to set
   */
  public void setMethods(@NonNull List<String> value) {
    _methods = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addMethod(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_methods == null) {
      _methods = new LinkedList<>();
    }
    return _methods.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeMethod(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _methods != null && _methods.remove(value);
  }

  /**
   * Get the "{@literal Observation Type}".
   *
   * <p>
   * Identifies the nature of the observation. More than one may be used to further qualify and enable filtering.
   *
   * @return the type value
   */
  @NonNull
  public List<String> getTypes() {
    if (_types == null) {
      _types = new LinkedList<>();
    }
    return ObjectUtils.notNull(_types);
  }

  /**
   * Set the "{@literal Observation Type}".
   *
   * <p>
   * Identifies the nature of the observation. More than one may be used to further qualify and enable filtering.
   *
   * @param value
   *           the type value to set
   */
  public void setTypes(@NonNull List<String> value) {
    _types = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addType(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_types == null) {
      _types = new LinkedList<>();
    }
    return _types.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeType(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _types != null && _types.remove(value);
  }

  /**
   * Get the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @return the origin value
   */
  @NonNull
  public List<Origin> getOrigins() {
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return ObjectUtils.notNull(_origins);
  }

  /**
   * Set the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @param value
   *           the origin value to set
   */
  public void setOrigins(@NonNull List<Origin> value) {
    _origins = value;
  }

  /**
   * Add a new {@link Origin} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return _origins.add(value);
  }

  /**
   * Remove the first matching {@link Origin} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _origins != null && _origins.remove(value);
  }

  /**
   * Get the "{@literal Identifies the Subject}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
   *
   * @return the subject value
   */
  @NonNull
  public List<SubjectReference> getSubjects() {
    if (_subjects == null) {
      _subjects = new LinkedList<>();
    }
    return ObjectUtils.notNull(_subjects);
  }

  /**
   * Set the "{@literal Identifies the Subject}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> identifier reference to a resource. Use type to indicate whether the identified resource is a component, inventory item, location, user, or something else.
   *
   * @param value
   *           the subject value to set
   */
  public void setSubjects(@NonNull List<SubjectReference> value) {
    _subjects = value;
  }

  /**
   * Add a new {@link SubjectReference} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSubject(SubjectReference item) {
    SubjectReference value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_subjects == null) {
      _subjects = new LinkedList<>();
    }
    return _subjects.add(value);
  }

  /**
   * Remove the first matching {@link SubjectReference} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSubject(SubjectReference item) {
    SubjectReference value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _subjects != null && _subjects.remove(value);
  }

  /**
   * Get the "{@literal Relevant Evidence}".
   *
   * <p>
   * Links this observation to relevant evidence.
   *
   * @return the relevant-evidence value
   */
  @NonNull
  public List<RelevantEvidence> getRelevantEvidence() {
    if (_relevantEvidence == null) {
      _relevantEvidence = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relevantEvidence);
  }

  /**
   * Set the "{@literal Relevant Evidence}".
   *
   * <p>
   * Links this observation to relevant evidence.
   *
   * @param value
   *           the relevant-evidence value to set
   */
  public void setRelevantEvidence(@NonNull List<RelevantEvidence> value) {
    _relevantEvidence = value;
  }

  /**
   * Add a new {@link RelevantEvidence} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRelevantEvidence(RelevantEvidence item) {
    RelevantEvidence value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relevantEvidence == null) {
      _relevantEvidence = new LinkedList<>();
    }
    return _relevantEvidence.add(value);
  }

  /**
   * Remove the first matching {@link RelevantEvidence} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRelevantEvidence(RelevantEvidence item) {
    RelevantEvidence value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relevantEvidence != null && _relevantEvidence.remove(value);
  }

  /**
   * Get the "{@literal Collected Field}".
   *
   * <p>
   * Date/time stamp identifying when the finding information was collected.
   *
   * @return the collected value
   */
  @NonNull
  public ZonedDateTime getCollected() {
    return _collected;
  }

  /**
   * Set the "{@literal Collected Field}".
   *
   * <p>
   * Date/time stamp identifying when the finding information was collected.
   *
   * @param value
   *           the collected value to set
   */
  public void setCollected(@NonNull ZonedDateTime value) {
    _collected = value;
  }

  /**
   * Get the "{@literal Expires Field}".
   *
   * <p>
   * Date/time identifying when the finding information is out-of-date and no longer valid. Typically used with continuous assessment scenarios.
   *
   * @return the expires value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getExpires() {
    return _expires;
  }

  /**
   * Set the "{@literal Expires Field}".
   *
   * <p>
   * Date/time identifying when the finding information is out-of-date and no longer valid. Typically used with continuous assessment scenarios.
   *
   * @param value
   *           the expires value to set, or {@code null} to clear
   */
  public void setExpires(@Nullable ZonedDateTime value) {
    _expires = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Links this observation to relevant evidence.
   */
  @MetaschemaAssembly(
      formalName = "Relevant Evidence",
      description = "Links this observation to relevant evidence.",
      name = "relevant-evidence",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class RelevantEvidence implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A resolvable URL reference to relevant evidence.
     */
    @BoundFlag(
        formalName = "Relevant Evidence Reference",
        description = "A resolvable URL reference to relevant evidence.",
        name = "href",
        typeAdapter = UriReferenceAdapter.class,
        remarks = "This value may be one of:\n"
                + "\n"
                + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
                + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
                + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to a `back-matter` resource in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object))."
    )
    private URI _href;

    /**
     * A human-readable description of this evidence.
     */
    @BoundField(
        formalName = "Relevant Evidence Description",
        description = "A human-readable description of this evidence.",
        useName = "description",
        minOccurs = 1,
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Observation.RelevantEvidence} instance with no metadata.
     */
    public RelevantEvidence() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Observation.RelevantEvidence} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public RelevantEvidence(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Relevant Evidence Reference}".
     *
     * <p>
     * A resolvable URL reference to relevant evidence.
     *
     * @return the href value, or {@code null} if not set
     */
    @Nullable
    public URI getHref() {
      return _href;
    }

    /**
     * Set the "{@literal Relevant Evidence Reference}".
     *
     * <p>
     * A resolvable URL reference to relevant evidence.
     *
     * @param value
     *           the href value to set, or {@code null} to clear
     */
    public void setHref(@Nullable URI value) {
      _href = value;
    }

    /**
     * Get the "{@literal Relevant Evidence Description}".
     *
     * <p>
     * A human-readable description of this evidence.
     *
     * @return the description value
     */
    @NonNull
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Relevant Evidence Description}".
     *
     * <p>
     * A human-readable description of this evidence.
     *
     * @param value
     *           the description value to set
     */
    public void setDescription(@NonNull MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
