// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_control-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Include all controls from the imported catalog or profile resources.
 */
@MetaschemaAssembly(
    formalName = "Include All",
    description = "Include all controls from the imported catalog or profile resources.",
    name = "include-all",
    moduleClass = OscalControlCommonModule.class,
    remarks = "This element provides an alternative to calling controls individually from a catalog."
)
public class IncludeAll implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.IncludeAll} instance with no metadata.
   */
  public IncludeAll() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.IncludeAll} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public IncludeAll(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
