// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.HasCardinality;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.
 */
@MetaschemaAssembly(
    formalName = "Activity",
    description = "Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.",
    name = "activity",
    moduleClass = OscalAssessmentCommonModule.class,
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-activity-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "method", description = "The assessment method to use. This typically appears on parts with the name \"assessment\".")), @AllowedValues(id = "oscal-activity-type-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='method']/@value", values = {@AllowedValue(value = "INTERVIEW", description = "The process of holding discussions with individuals or groups of individuals within an organization to once again, facilitate assessor understanding, achieve clarification, or obtain evidence."), @AllowedValue(value = "EXAMINE", description = "The process of reviewing, inspecting, observing, studying, or analyzing one or more assessment objects (i.e., specifications, mechanisms, or activities)."), @AllowedValue(value = "TEST", description = "The process of exercising one or more assessment objects (i.e., activities or mechanisms) under specified conditions to compare actual with expected behavior.")})}),
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-activity-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."), cardinality = @HasCardinality(id = "oscal-activity-type-cardinality", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='method']", minOccurs = 1))
)
public class Activity implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment activity elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>activity</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Assessment Activity Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this assessment activity elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `activity` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The title for this included activity.
   */
  @BoundField(
      formalName = "Included Activity Title",
      description = "The title for this included activity.",
      useName = "title",
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of this included activity.
   */
  @BoundField(
      formalName = "Included Activity Description",
      description = "A human-readable description of this included activity.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies an individual step in a series of steps related to an activity, such as an assessment test or examination procedure.
   */
  @BoundAssembly(
      formalName = "Step",
      description = "Identifies an individual step in a series of steps related to an activity, such as an assessment test or examination procedure.",
      useName = "step",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "steps", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Step> _steps;

  /**
   * Identifies the controls being assessed and their control objectives.
   */
  @BoundAssembly(
      formalName = "Reviewed Controls and Control Objectives",
      description = "Identifies the controls being assessed and their control objectives.",
      useName = "related-controls",
      remarks = "This can be optionally used to define the set of controls and control objectives that are assessed or remediated by this activity."
  )
  private ReviewedControls _relatedControls;

  /**
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   */
  @BoundAssembly(
      formalName = "Responsible Role",
      description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
      useName = "responsible-role",
      remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleRole> _responsibleRoles;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Activity} instance with no metadata.
   */
  public Activity() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Activity} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Activity(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Assessment Activity Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment activity elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>activity</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Assessment Activity Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment activity elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>activity</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Included Activity Title}".
   *
   * <p>
   * The title for this included activity.
   *
   * @return the title value, or {@code null} if not set
   */
  @Nullable
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Included Activity Title}".
   *
   * <p>
   * The title for this included activity.
   *
   * @param value
   *           the title value to set, or {@code null} to clear
   */
  public void setTitle(@Nullable MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Included Activity Description}".
   *
   * <p>
   * A human-readable description of this included activity.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Included Activity Description}".
   *
   * <p>
   * A human-readable description of this included activity.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Step}".
   *
   * <p>
   * Identifies an individual step in a series of steps related to an activity, such as an assessment test or examination procedure.
   *
   * @return the step value
   */
  @NonNull
  public List<Step> getSteps() {
    if (_steps == null) {
      _steps = new LinkedList<>();
    }
    return ObjectUtils.notNull(_steps);
  }

  /**
   * Set the "{@literal Step}".
   *
   * <p>
   * Identifies an individual step in a series of steps related to an activity, such as an assessment test or examination procedure.
   *
   * @param value
   *           the step value to set
   */
  public void setSteps(@NonNull List<Step> value) {
    _steps = value;
  }

  /**
   * Add a new {@link Step} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addStep(Step item) {
    Step value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_steps == null) {
      _steps = new LinkedList<>();
    }
    return _steps.add(value);
  }

  /**
   * Remove the first matching {@link Step} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeStep(Step item) {
    Step value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _steps != null && _steps.remove(value);
  }

  /**
   * Get the "{@literal Reviewed Controls and Control Objectives}".
   *
   * <p>
   * Identifies the controls being assessed and their control objectives.
   *
   * @return the related-controls value, or {@code null} if not set
   */
  @Nullable
  public ReviewedControls getRelatedControls() {
    return _relatedControls;
  }

  /**
   * Set the "{@literal Reviewed Controls and Control Objectives}".
   *
   * <p>
   * Identifies the controls being assessed and their control objectives.
   *
   * @param value
   *           the related-controls value to set, or {@code null} to clear
   */
  public void setRelatedControls(@Nullable ReviewedControls value) {
    _relatedControls = value;
  }

  /**
   * Get the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @return the responsible-role value
   */
  @NonNull
  public List<ResponsibleRole> getResponsibleRoles() {
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleRoles);
  }

  /**
   * Set the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @param value
   *           the responsible-role value to set
   */
  public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
    _responsibleRoles = value;
  }

  /**
   * Add a new {@link ResponsibleRole} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return _responsibleRoles.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleRoles != null && _responsibleRoles.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Identifies an individual step in a series of steps related to an activity, such as an assessment test or examination procedure.
   */
  @MetaschemaAssembly(
      formalName = "Step",
      description = "Identifies an individual step in a series of steps related to an activity, such as an assessment test or examination procedure.",
      name = "step",
      moduleClass = OscalAssessmentCommonModule.class,
      modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-step-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since multiple `party-uuid` entries can be provided, each role-id must be referenced only once."))
  )
  public static class Step implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this step elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>step</code> (in a series of steps) can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Step Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this step elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `step` (in a series of steps) can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * The title for this step.
     */
    @BoundField(
        formalName = "Step Title",
        description = "The title for this step.",
        useName = "title",
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * A human-readable description of this step.
     */
    @BoundField(
        formalName = "Step Description",
        description = "A human-readable description of this step.",
        useName = "description",
        minOccurs = 1,
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Identifies the controls being assessed and their control objectives.
     */
    @BoundAssembly(
        formalName = "Reviewed Controls and Control Objectives",
        description = "Identifies the controls being assessed and their control objectives.",
        useName = "reviewed-controls",
        remarks = "This can be optionally used to define the set of controls and control objectives that are assessed by this step."
    )
    private ReviewedControls _reviewedControls;

    /**
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     */
    @BoundAssembly(
        formalName = "Responsible Role",
        description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
        useName = "responsible-role",
        remarks = "Identifies the roles, and optionally the parties, associated with this step that is part of an assessment activity.",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<ResponsibleRole> _responsibleRoles;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Activity.Step} instance with no metadata.
     */
    public Step() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Activity.Step} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Step(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Step Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this step elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>step</code> (in a series of steps) can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Step Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this step elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>step</code> (in a series of steps) can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Step Title}".
     *
     * <p>
     * The title for this step.
     *
     * @return the title value, or {@code null} if not set
     */
    @Nullable
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal Step Title}".
     *
     * <p>
     * The title for this step.
     *
     * @param value
     *           the title value to set, or {@code null} to clear
     */
    public void setTitle(@Nullable MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Step Description}".
     *
     * <p>
     * A human-readable description of this step.
     *
     * @return the description value
     */
    @NonNull
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Step Description}".
     *
     * <p>
     * A human-readable description of this step.
     *
     * @param value
     *           the description value to set
     */
    public void setDescription(@NonNull MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Reviewed Controls and Control Objectives}".
     *
     * <p>
     * Identifies the controls being assessed and their control objectives.
     *
     * @return the reviewed-controls value, or {@code null} if not set
     */
    @Nullable
    public ReviewedControls getReviewedControls() {
      return _reviewedControls;
    }

    /**
     * Set the "{@literal Reviewed Controls and Control Objectives}".
     *
     * <p>
     * Identifies the controls being assessed and their control objectives.
     *
     * @param value
     *           the reviewed-controls value to set, or {@code null} to clear
     */
    public void setReviewedControls(@Nullable ReviewedControls value) {
      _reviewedControls = value;
    }

    /**
     * Get the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @return the responsible-role value
     */
    @NonNull
    public List<ResponsibleRole> getResponsibleRoles() {
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return ObjectUtils.notNull(_responsibleRoles);
    }

    /**
     * Set the "{@literal Responsible Role}".
     *
     * <p>
     * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
     *
     * @param value
     *           the responsible-role value to set
     */
    public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
      _responsibleRoles = value;
    }

    /**
     * Add a new {@link ResponsibleRole} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_responsibleRoles == null) {
        _responsibleRoles = new LinkedList<>();
      }
      return _responsibleRoles.add(value);
    }

    /**
     * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeResponsibleRole(ResponsibleRole item) {
      ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _responsibleRoles != null && _responsibleRoles.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
