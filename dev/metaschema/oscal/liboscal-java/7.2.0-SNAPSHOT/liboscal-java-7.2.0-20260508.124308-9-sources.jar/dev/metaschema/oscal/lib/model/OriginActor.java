// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.
 */
@MetaschemaAssembly(
    formalName = "Originating Actor",
    description = "The actor that produces an observation, a finding, or a risk. One or more actor type can be used to specify a person that is using a tool.",
    name = "origin-actor",
    moduleClass = OscalAssessmentCommonModule.class
)
public class OriginActor implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * The kind of actor.
   */
  @BoundFlag(
      formalName = "Actor Type",
      description = "The kind of actor.",
      name = "type",
      required = true,
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-origin-actor-type-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "tool", description = "A reference to a tool component defined with the assessment assets."), @AllowedValue(value = "assessment-platform", description = "A reference to an assessment-platform defined with the assessment assets."), @AllowedValue(value = "party", description = "A reference to a party defined within the document metadata.")}))
  )
  private String _type;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the tool or person based on the associated type.
   */
  @BoundFlag(
      formalName = "Actor Universally Unique Identifier Reference",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to the tool or person based on the associated type.",
      name = "actor-uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _actorUuid;

  /**
   * For a party, this can optionally be used to specify the role the actor was performing.
   */
  @BoundFlag(
      formalName = "Actor Role",
      description = "For a party, this can optionally be used to specify the role the actor was performing.",
      name = "role-id",
      typeAdapter = TokenAdapter.class
  )
  private String _roleId;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.OriginActor} instance with no metadata.
   */
  public OriginActor() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.OriginActor} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public OriginActor(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Actor Type}".
   *
   * <p>
   * The kind of actor.
   *
   * @return the type value
   */
  @NonNull
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Actor Type}".
   *
   * <p>
   * The kind of actor.
   *
   * @param value
   *           the type value to set
   */
  public void setType(@NonNull String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Actor Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the tool or person based on the associated type.
   *
   * @return the actor-uuid value
   */
  @NonNull
  public UUID getActorUuid() {
    return _actorUuid;
  }

  /**
   * Set the "{@literal Actor Universally Unique Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the tool or person based on the associated type.
   *
   * @param value
   *           the actor-uuid value to set
   */
  public void setActorUuid(@NonNull UUID value) {
    _actorUuid = value;
  }

  /**
   * Get the "{@literal Actor Role}".
   *
   * <p>
   * For a party, this can optionally be used to specify the role the actor was performing.
   *
   * @return the role-id value, or {@code null} if not set
   */
  @Nullable
  public String getRoleId() {
    return _roleId;
  }

  /**
   * Set the "{@literal Actor Role}".
   *
   * <p>
   * For a party, this can optionally be used to specify the role the actor was performing.
   *
   * @param value
   *           the role-id value to set, or {@code null} to clear
   */
  public void setRoleId(@Nullable String value) {
    _roleId = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
