// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-results_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Let;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Security assessment results, such as those provided by a FedRAMP assessor in the FedRAMP Security Assessment Report.
 */
@MetaschemaAssembly(
    formalName = "Security Assessment Results (SAR)",
    description = "Security assessment results, such as those provided by a FedRAMP assessor in the FedRAMP Security Assessment Report.",
    name = "assessment-results",
    moduleClass = OscalArModule.class,
    rootName = "assessment-results",
    valueConstraints = @ValueConstraints(lets = @Let(name = "all-imports", target = "recurse-depth('.[import-ap]/doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-ap/@href)))/assessment-plan|.[import-ssp]/doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-ssp/@href)))/system-security-plan|.[import-profile]/resolve-profile(doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(import-profile/@href))))/catalog')")),
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-ar-index-metadata-scoped-role-id", formalName = "In-Scope Role Identifiers", description = "An index of role identifiers that are in-scope for the assessment-result model. Roles are collected from imported assessment-plans, which in turn includes referenced system-securtity-plans, which in turn includes referenced profiles and catalogs. For a given role @id, a locally declared role takes precedence over a role that is imported, the role that was last imported.", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/role ! map:entry(@id,.))?*", name = "index-imports-metadata-role-id", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-ar-index-metadata-scoped-location-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/location ! map:entry(@uuid,.))?*", name = "index-imports-metadata-location-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-ar-index-metadata-scoped-party-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-ar-index-metadata-scoped-party-organization-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party[@type='organization'] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-organization-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-ar-index-metadata-scoped-property-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports//prop[@uuid] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-property-uuid", keyFields = @KeyField(target = "@uuid"))}, unique = {@IsUnique(id = "oscal-unique-document-id", formalName = "Unique Document Identifier", description = "Ensure all document identifiers have a unique combination of @scheme and value.", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-property-in-context-location", formalName = "Unique Properties", description = "Ensure all properties are unique for a given location using a unique combination of @ns, @name, @class. @group. and @value.", level = IConstraint.Level.ERROR, target = ".//prop", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-link-in-context-location", formalName = "Unique Links", description = "Ensure all links are unique for a given location using a unique combination of @href, @rel, and @media-type.", level = IConstraint.Level.ERROR, target = ".//link", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type"), @KeyField(target = "@resource-fragment")}), @IsUnique(id = "oscal-unique-responsibility-in-context-location", formalName = "Unique Responsibilities", description = "Ensure all responsible-roles and responsible-parties are unique for a given location using a unique combination of @role-id and the combination of @party-uuid values.", level = IConstraint.Level.ERROR, target = ".//(responsible-party|responsible-role)", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@role-id"), @KeyField(target = "@party-uuid")}, remarks = "Since `responsible-party` and `responsible-role` associate multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.")})
)
public class AssessmentResults extends AbstractOscalInstance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment results instance in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment result</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Assessment Results Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this assessment results instance in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers). The locally defined *UUID* of the `assessment result` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Provides information about the containing document, and defines concepts that are shared across the document.
   */
  @BoundAssembly(
      formalName = "Document Metadata",
      description = "Provides information about the containing document, and defines concepts that are shared across the document.",
      useName = "metadata",
      minOccurs = 1
  )
  private Metadata _metadata;

  /**
   * Used by assessment-results to import information about the original plan for assessing the system.
   */
  @BoundAssembly(
      formalName = "Import Assessment Plan",
      description = "Used by assessment-results to import information about the original plan for assessing the system.",
      useName = "import-ap",
      remarks = "Used by the SAR to import information about the original plan for assessing the system.",
      minOccurs = 1
  )
  private ImportAp _importAp;

  /**
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   */
  @BoundAssembly(
      formalName = "Local Definitions",
      description = "Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.",
      useName = "local-definitions"
  )
  private LocalDefinitions _localDefinitions;

  /**
   * Used by the assessment results and POA&amp;M. In the assessment results, this identifies all of the assessment observations and findings, initial and residual risks, deviations, and disposition. In the POA&amp;M, this identifies initial and residual risks, deviations, and disposition.
   */
  @BoundAssembly(
      formalName = "Assessment Result",
      description = "Used by the assessment results and POA\\&M. In the assessment results, this identifies all of the assessment observations and findings, initial and residual risks, deviations, and disposition. In the POA\\&M, this identifies initial and residual risks, deviations, and disposition.",
      useName = "result",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "results", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Result> _results;

  /**
   * A collection of resources that may be referenced from within the OSCAL document instance.
   */
  @BoundAssembly(
      formalName = "Back matter",
      description = "A collection of resources that may be referenced from within the OSCAL document instance.",
      useName = "back-matter"
  )
  private BackMatter _backMatter;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentResults} instance with no metadata.
   */
  public AssessmentResults() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentResults} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public AssessmentResults(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Assessment Results Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment results instance in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment result</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Assessment Results Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment results instance in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>assessment result</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @return the metadata value
   */
  @NonNull
  public Metadata getMetadata() {
    return _metadata;
  }

  /**
   * Set the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @param value
   *           the metadata value to set
   */
  public void setMetadata(@NonNull Metadata value) {
    _metadata = value;
  }

  /**
   * Get the "{@literal Import Assessment Plan}".
   *
   * <p>
   * Used by assessment-results to import information about the original plan for assessing the system.
   *
   * @return the import-ap value
   */
  @NonNull
  public ImportAp getImportAp() {
    return _importAp;
  }

  /**
   * Set the "{@literal Import Assessment Plan}".
   *
   * <p>
   * Used by assessment-results to import information about the original plan for assessing the system.
   *
   * @param value
   *           the import-ap value to set
   */
  public void setImportAp(@NonNull ImportAp value) {
    _importAp = value;
  }

  /**
   * Get the "{@literal Local Definitions}".
   *
   * <p>
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   *
   * @return the local-definitions value, or {@code null} if not set
   */
  @Nullable
  public LocalDefinitions getLocalDefinitions() {
    return _localDefinitions;
  }

  /**
   * Set the "{@literal Local Definitions}".
   *
   * <p>
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   *
   * @param value
   *           the local-definitions value to set, or {@code null} to clear
   */
  public void setLocalDefinitions(@Nullable LocalDefinitions value) {
    _localDefinitions = value;
  }

  /**
   * Get the "{@literal Assessment Result}".
   *
   * <p>
   * Used by the assessment results and POA&amp;M. In the assessment results, this identifies all of the assessment observations and findings, initial and residual risks, deviations, and disposition. In the POA&amp;M, this identifies initial and residual risks, deviations, and disposition.
   *
   * @return the result value
   */
  @NonNull
  public List<Result> getResults() {
    if (_results == null) {
      _results = new LinkedList<>();
    }
    return ObjectUtils.notNull(_results);
  }

  /**
   * Set the "{@literal Assessment Result}".
   *
   * <p>
   * Used by the assessment results and POA&amp;M. In the assessment results, this identifies all of the assessment observations and findings, initial and residual risks, deviations, and disposition. In the POA&amp;M, this identifies initial and residual risks, deviations, and disposition.
   *
   * @param value
   *           the result value to set
   */
  public void setResults(@NonNull List<Result> value) {
    _results = value;
  }

  /**
   * Add a new {@link Result} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResult(Result item) {
    Result value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_results == null) {
      _results = new LinkedList<>();
    }
    return _results.add(value);
  }

  /**
   * Remove the first matching {@link Result} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResult(Result item) {
    Result value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _results != null && _results.remove(value);
  }

  /**
   * Get the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @return the back-matter value, or {@code null} if not set
   */
  @Nullable
  public BackMatter getBackMatter() {
    return _backMatter;
  }

  /**
   * Set the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @param value
   *           the back-matter value to set, or {@code null} to clear
   */
  public void setBackMatter(@Nullable BackMatter value) {
    _backMatter = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.
   */
  @MetaschemaAssembly(
      formalName = "Local Definitions",
      description = "Used to define data objects that are used in the assessment plan, that do not appear in the referenced SSP.",
      name = "local-definitions",
      moduleClass = OscalArModule.class
  )
  public static class LocalDefinitions implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.
     */
    @BoundAssembly(
        formalName = "Assessment-Specific Control Objective",
        description = "A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.",
        useName = "objectives-and-methods",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "objectives-and-methods", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<LocalObjective> _objectivesAndMethods;

    /**
     * Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.
     */
    @BoundAssembly(
        formalName = "Activity",
        description = "Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.",
        useName = "activity",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "activities", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Activity> _activities;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentResults.LocalDefinitions} instance with no metadata.
     */
    public LocalDefinitions() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentResults.LocalDefinitions} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public LocalDefinitions(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Assessment-Specific Control Objective}".
     *
     * <p>
     * A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.
     *
     * @return the objectives-and-methods value
     */
    @NonNull
    public List<LocalObjective> getObjectivesAndMethods() {
      if (_objectivesAndMethods == null) {
        _objectivesAndMethods = new LinkedList<>();
      }
      return ObjectUtils.notNull(_objectivesAndMethods);
    }

    /**
     * Set the "{@literal Assessment-Specific Control Objective}".
     *
     * <p>
     * A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.
     *
     * @param value
     *           the objectives-and-methods value to set
     */
    public void setObjectivesAndMethods(@NonNull List<LocalObjective> value) {
      _objectivesAndMethods = value;
    }

    /**
     * Add a new {@link LocalObjective} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addObjectivesAndMethods(LocalObjective item) {
      LocalObjective value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_objectivesAndMethods == null) {
        _objectivesAndMethods = new LinkedList<>();
      }
      return _objectivesAndMethods.add(value);
    }

    /**
     * Remove the first matching {@link LocalObjective} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeObjectivesAndMethods(LocalObjective item) {
      LocalObjective value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _objectivesAndMethods != null && _objectivesAndMethods.remove(value);
    }

    /**
     * Get the "{@literal Activity}".
     *
     * <p>
     * Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.
     *
     * @return the activity value
     */
    @NonNull
    public List<Activity> getActivities() {
      if (_activities == null) {
        _activities = new LinkedList<>();
      }
      return ObjectUtils.notNull(_activities);
    }

    /**
     * Set the "{@literal Activity}".
     *
     * <p>
     * Identifies an assessment or related process that can be performed. In the assessment plan, this is an intended activity which may be associated with an assessment task. In the assessment results, this an activity that was actually performed as part of an assessment.
     *
     * @param value
     *           the activity value to set
     */
    public void setActivities(@NonNull List<Activity> value) {
      _activities = value;
    }

    /**
     * Add a new {@link Activity} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addActivity(Activity item) {
      Activity value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_activities == null) {
        _activities = new LinkedList<>();
      }
      return _activities.add(value);
    }

    /**
     * Remove the first matching {@link Activity} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeActivity(Activity item) {
      Activity value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _activities != null && _activities.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
