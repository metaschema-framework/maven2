// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A collection of descriptive data about the containing object from a specific origin.
 */
@MetaschemaAssembly(
    formalName = "Characterization",
    description = "A collection of descriptive data about the containing object from a specific origin.",
    name = "characterization",
    moduleClass = OscalAssessmentCommonModule.class
)
public class Characterization implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   */
  @BoundAssembly(
      formalName = "Origin",
      description = "Identifies the source of the finding, such as a tool, interviewed person, or activity.",
      useName = "origin",
      remarks = "metadata about the specific actor that generated this descriptive data.",
      minOccurs = 1
  )
  private Origin _origin;

  /**
   * An individual characteristic that is part of a larger set produced by the same actor.
   */
  @BoundAssembly(
      formalName = "Facet",
      description = "An individual characteristic that is part of a larger set produced by the same actor.",
      useName = "facet",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "facets", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Facet> _facets;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Characterization} instance with no metadata.
   */
  public Characterization() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Characterization} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Characterization(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @return the origin value
   */
  @NonNull
  public Origin getOrigin() {
    return _origin;
  }

  /**
   * Set the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @param value
   *           the origin value to set
   */
  public void setOrigin(@NonNull Origin value) {
    _origin = value;
  }

  /**
   * Get the "{@literal Facet}".
   *
   * <p>
   * An individual characteristic that is part of a larger set produced by the same actor.
   *
   * @return the facet value
   */
  @NonNull
  public List<Facet> getFacets() {
    if (_facets == null) {
      _facets = new LinkedList<>();
    }
    return ObjectUtils.notNull(_facets);
  }

  /**
   * Set the "{@literal Facet}".
   *
   * <p>
   * An individual characteristic that is part of a larger set produced by the same actor.
   *
   * @param value
   *           the facet value to set
   */
  public void setFacets(@NonNull List<Facet> value) {
    _facets = value;
  }

  /**
   * Add a new {@link Facet} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addFacet(Facet item) {
    Facet value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_facets == null) {
      _facets = new LinkedList<>();
    }
    return _facets.add(value);
  }

  /**
   * Remove the first matching {@link Facet} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeFacet(Facet item) {
    Facet value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _facets != null && _facets.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * An individual characteristic that is part of a larger set produced by the same actor.
   */
  @MetaschemaAssembly(
      formalName = "Facet",
      description = "An individual characteristic that is part of a larger set produced by the same actor.",
      name = "facet",
      moduleClass = OscalAssessmentCommonModule.class,
      valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-facet-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "state", description = "Indicates if the facet is 'initial' as first identified, or 'adjusted' indicating that the value has be changed after some adjustments have been made (e.g., to identify residual risk).")), @AllowedValues(id = "oscal-facet-prop-state-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='state']/@value", values = {@AllowedValue(value = "initial", description = "As first identified."), @AllowedValue(value = "adjusted", description = "Indicates that residual risk remains after some adjustments have been made.")}), @AllowedValues(id = "oscal-facet-name-core-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://csrc.nist.gov/ns/oscal']/@name", values = {@AllowedValue(value = "likelihood", description = "General likelihood rating."), @AllowedValue(value = "impact", description = "General impact rating."), @AllowedValue(value = "risk", description = "General risk rating."), @AllowedValue(value = "severity", description = "General severity rating.")}), @AllowedValues(id = "oscal-facet-fedramp-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://fedramp.gov','http://fedramp.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "likelihood", description = "Likelihood as defined by FedRAMP. The `class` can be used to specify 'initial' and 'adjusted' risk states."), @AllowedValue(value = "impact", description = "Impact as defined by FedRAMP. The `class` can be used to specify 'initial' and 'adjusted' risk states."), @AllowedValue(value = "risk", description = "Risk as calculated according to FedRAMP. The `class` can be used to specify 'initial' and 'adjusted' risk states.")}), @AllowedValues(id = "oscal-facet-cve-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://cve.mitre.org']/@name", values = @AllowedValue(value = "cve-id", description = "An identifier managed by the CVE program (see https://cve.mitre.org/).")), @AllowedValues(id = "oscal-facet-cvss2-name-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0']/@name", values = {@AllowedValue(value = "access-vector", description = "Base: Access Vector"), @AllowedValue(value = "access-complexity", description = "Base: Access Complexity"), @AllowedValue(value = "authentication", description = "Base: Authentication"), @AllowedValue(value = "confidentiality-impact", description = "Base: Confidentiality Impact"), @AllowedValue(value = "integrity-impact", description = "Base: Integrity Impact"), @AllowedValue(value = "availability-impact", description = "Base: Availability Impact"), @AllowedValue(value = "exploitability", description = "Temporal: Exploitability"), @AllowedValue(value = "remediation-level", description = "Temporal: Remediation Level"), @AllowedValue(value = "report-confidence", description = "Temporal: Report Confidence"), @AllowedValue(value = "collateral-damage-potential", description = "Environmental: Collateral Damage Potential"), @AllowedValue(value = "target-distribution", description = "Environmental: Target Distribution"), @AllowedValue(value = "confidentiality-requirement", description = "Environmental: Confidentiality Requirement"), @AllowedValue(value = "integrity-requirement", description = "Environmental: Integrity Requirement"), @AllowedValue(value = "availability-requirement", description = "Environmental: Availability Requirement")}), @AllowedValues(id = "oscal-facet-cvss2-access-vector-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name='access-vector']/@value", values = {@AllowedValue(value = "local", description = "Local"), @AllowedValue(value = "adjacent-network", description = "Network Adjacent"), @AllowedValue(value = "network", description = "Network")}), @AllowedValues(id = "oscal-facet-cvss2-access-complexity-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name='access-complexity']/@value", values = {@AllowedValue(value = "high", description = "High"), @AllowedValue(value = "medium", description = "Medium"), @AllowedValue(value = "low", description = "Low")}), @AllowedValues(id = "oscal-facet-cvss2-authentication-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name='authentication']/@value", values = {@AllowedValue(value = "multiple", description = "Multiple"), @AllowedValue(value = "single", description = "Single"), @AllowedValue(value = "none", description = "None")}), @AllowedValues(id = "oscal-facet-cvss2-confidentiality-impact-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name=('confidentiality-impact', 'integrity-impact', 'availability-impact')]/@value", values = {@AllowedValue(value = "none", description = "None"), @AllowedValue(value = "partial", description = "Partial"), @AllowedValue(value = "complete", description = "Complete")}), @AllowedValues(id = "oscal-facet-cvss2-exploitability-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name='exploitability']/@value", values = {@AllowedValue(value = "unproven", description = "Unproven"), @AllowedValue(value = "proof-of-concept", description = "Proof-of-Concept"), @AllowedValue(value = "functional", description = "Functional"), @AllowedValue(value = "high", description = "High"), @AllowedValue(value = "not-defined", description = "Not Defined")}), @AllowedValues(id = "oscal-facet-cvss2-remediation-level-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name='remediation-level']/@value", values = {@AllowedValue(value = "official-fix", description = "Official Fix"), @AllowedValue(value = "temporary-fix", description = "Temporary Fix"), @AllowedValue(value = "workaround", description = "Workaround"), @AllowedValue(value = "unavailable", description = "Unavailable"), @AllowedValue(value = "not-defined", description = "Not Defined")}), @AllowedValues(id = "oscal-facet-cvss2-report-confidence-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name='report-confidence']/@value", values = {@AllowedValue(value = "unconfirmed", description = "Unconfirmed"), @AllowedValue(value = "uncorroborated", description = "Uncorroborated"), @AllowedValue(value = "confirmed", description = "Confirmed"), @AllowedValue(value = "not-defined", description = "Not Defined")}), @AllowedValues(id = "oscal-facet-cvss2-collateral-damage-potential-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name='collateral-damage-potential']/@value", values = {@AllowedValue(value = "none", description = "None"), @AllowedValue(value = "low", description = "Low (light loss)"), @AllowedValue(value = "low-medium", description = "Low Medium"), @AllowedValue(value = "medium-high", description = "Medium High"), @AllowedValue(value = "high", description = "High (catastrophic loss)"), @AllowedValue(value = "not-defined", description = "Not Defined")}), @AllowedValues(id = "oscal-facet-cvss2-cia-requirement-values", level = IConstraint.Level.ERROR, target = "(.)[@system='http://www.first.org/cvss/v2.0' and @name=('target-distribution', 'confidentiality-requirement', 'integrity-requirement', 'availability-requirement')]/@value", values = {@AllowedValue(value = "none", description = "None"), @AllowedValue(value = "low", description = "Low"), @AllowedValue(value = "medium", description = "Medium"), @AllowedValue(value = "high", description = "High"), @AllowedValue(value = "not-defined", description = "Not Defined")}), @AllowedValues(id = "oscal-facet-cvss3-name-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1')]/@name", values = {@AllowedValue(value = "attack-vector", description = "Base: Attack Vector"), @AllowedValue(value = "access-complexity", description = "Base: Attack Complexity"), @AllowedValue(value = "privileges-required", description = "Base: Privileges Required"), @AllowedValue(value = "user-interaction", description = "Base: User Interaction"), @AllowedValue(value = "scope", description = "Base: Scope"), @AllowedValue(value = "confidentiality-impact", description = "Base: Confidentiality Impact"), @AllowedValue(value = "integrity-impact", description = "Base: Integrity Impact"), @AllowedValue(value = "availability-impact", description = "Base: Availability Impact"), @AllowedValue(value = "exploit-code-maturity", description = "Temporal: Exploit Code Maturity"), @AllowedValue(value = "remediation-level", description = "Temporal: Remediation Level"), @AllowedValue(value = "report-confidence", description = "Temporal: Report Confidence"), @AllowedValue(value = "modified-attack-vector", description = "Environmental: Modified Attack Vector"), @AllowedValue(value = "modified-attack-complexity", description = "Environmental: Modified Attack Complexity"), @AllowedValue(value = "modified-privileges-required", description = "Environmental: Modified Privileges Required"), @AllowedValue(value = "modified-user-interaction", description = "Environmental: Modified User Interaction"), @AllowedValue(value = "modified-scope", description = "Environmental: Modified Scope"), @AllowedValue(value = "modified-confidentiality", description = "Environmental: Modified Confidentiality"), @AllowedValue(value = "modified-integrity", description = "Environmental: Modified Integrity"), @AllowedValue(value = "modified-availability", description = "Environmental: Modified Availability"), @AllowedValue(value = "confidentiality-requirement", description = "Environmental: Confidentiality Requirement Modifier"), @AllowedValue(value = "integrity-requirement", description = "Environmental: Integrity Requirement Modifier"), @AllowedValue(value = "availability-requirement", description = "Environmental: Availability Requirement Modifier")}), @AllowedValues(id = "oscal-facet-cvss3-access-vector-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='access-vector']/@value", values = {@AllowedValue(value = "network", description = "Network"), @AllowedValue(value = "adjacent", description = "Adjacent"), @AllowedValue(value = "local", description = "Local"), @AllowedValue(value = "physical", description = "Physical")}), @AllowedValues(id = "oscal-facet-cvss3-access-complexity-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='access-complexity']/@value", values = {@AllowedValue(value = "high", description = "High"), @AllowedValue(value = "low", description = "Low")}), @AllowedValues(id = "oscal-facet-cvss3-cia-impact-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name=('privileges-required', 'confidentiality-impact', 'integrity-impact', 'availability-impact')]/@value", values = {@AllowedValue(value = "none", description = "None"), @AllowedValue(value = "low", description = "Low"), @AllowedValue(value = "high", description = "High")}), @AllowedValues(id = "oscal-facet-cvss3-user-interaction", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='user-interaction']/@value", values = {@AllowedValue(value = "none", description = "None"), @AllowedValue(value = "required", description = "Required")}), @AllowedValues(id = "oscal-facet-cvss3-scope", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='scope']/@value", values = {@AllowedValue(value = "unchanged", description = "Unchanged"), @AllowedValue(value = "changed", description = "Changed")}), @AllowedValues(id = "oscal-facet-cvss3-exploit-code-maturity-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='exploit-code-maturity']/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "unproven", description = "Unproven"), @AllowedValue(value = "proof-of-concept", description = "Proof-of-Concept"), @AllowedValue(value = "functional", description = "Functional"), @AllowedValue(value = "high", description = "High")}), @AllowedValues(id = "oscal-facet-cvss3-remediation-level", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='remediation-level']/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "official-fix", description = "Official Fix"), @AllowedValue(value = "temporary-fix", description = "Temporary Fix"), @AllowedValue(value = "workaround", description = "Workaround"), @AllowedValue(value = "unavailable", description = "Unavailable")}), @AllowedValues(id = "oscal-facet-cvss3-report-confidence-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='report-confidence']/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "unknown", description = "Unknown"), @AllowedValue(value = "reasonable", description = "Reasonable"), @AllowedValue(value = "confirmed", description = "Confirmed")}), @AllowedValues(id = "oscal-facet-cvss3-cia-requirement-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name=('confidentiality-requirement', 'integrity-requirement', 'availability-requirement')]/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "low", description = "Low"), @AllowedValue(value = "medium", description = "Medium"), @AllowedValue(value = "high", description = "High")}), @AllowedValues(id = "oscal-facet-cvss3-modified-attack-vector-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='modified-attack-vector']/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "network", description = "Network"), @AllowedValue(value = "adjacent", description = "Adjacent"), @AllowedValue(value = "local", description = "Local"), @AllowedValue(value = "physical", description = "Physical")}), @AllowedValues(id = "oscal-facet-cvss3-modified-attack-complexity-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='modified-attack-complexity']/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "high", description = "High"), @AllowedValue(value = "low", description = "Low")}), @AllowedValues(id = "oscal-facet-cvss3-modified-cia-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name=('modified-privileges-required', 'modified-confidentiality', 'modified-integrity', 'modified-availability')]/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "none", description = "None"), @AllowedValue(value = "low", description = "Low"), @AllowedValue(value = "high", description = "High")}), @AllowedValues(id = "oscal-facet-cvss3-modified-user-interaction-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='modified-user-interaction']/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "none", description = "None"), @AllowedValue(value = "required", description = "Required")}), @AllowedValues(id = "oscal-facet-cvss3-modified-scope-values", level = IConstraint.Level.ERROR, target = "(.)[@system=('http://www.first.org/cvss/v3.0', 'http://www.first.org/cvss/v3.1') and @name='modified-scope']/@value", values = {@AllowedValue(value = "not-defined", description = "Not Defined"), @AllowedValue(value = "unchanged", description = "Unchanged"), @AllowedValue(value = "changed", description = "Changed")}), @AllowedValues(id = "oscal-cvss-v4.0-vectors", level = IConstraint.Level.ERROR, target = "(.)[@system=('https://www.first.org/cvss/v4-0')]/@name", values = {@AllowedValue(value = "av", description = "Base: Attack Vector"), @AllowedValue(value = "ac", description = "Base: Attack Complexity"), @AllowedValue(value = "at", description = "Base: Attack Requirements"), @AllowedValue(value = "pr", description = "Base: Privileges Required"), @AllowedValue(value = "ui", description = "Base: User Interaction"), @AllowedValue(value = "vc", description = "Base: Vulnerable System Confidentiality Impact"), @AllowedValue(value = "vi", description = "Base: Vulnerable System Integrity Impact"), @AllowedValue(value = "va", description = "Base: Vulnerable System Availability Impact"), @AllowedValue(value = "sc", description = "Base: Subsequent System Confidentiality Impact"), @AllowedValue(value = "si", description = "Base: Vulnerable System Integrity Impact"), @AllowedValue(value = "sa", description = "Base: Vulnerable System Availability Impact"), @AllowedValue(value = "s", description = "Supplemental: Safety"), @AllowedValue(value = "au", description = "Supplemental: Automatable"), @AllowedValue(value = "r", description = "Supplemental: Recovery"), @AllowedValue(value = "v", description = "Supplemental: Value Density"), @AllowedValue(value = "re", description = "Supplemental: Vulnerability Response Effort"), @AllowedValue(value = "u", description = "Supplemental: Provider Urgency"), @AllowedValue(value = "mav", description = "Environmental: Modified Attack Vector"), @AllowedValue(value = "mac", description = "Environmental: Modified Attack Complexity"), @AllowedValue(value = "mat", description = "Environmental: Modified Attack Requirements"), @AllowedValue(value = "mpr", description = "Environmental: Modified Privileges Required"), @AllowedValue(value = "mui", description = "Environmental: Modified User Interaction"), @AllowedValue(value = "mvc", description = "Environmental: Modified Vulnerable System Confidentiality"), @AllowedValue(value = "mvi", description = "Environmental: Modified Vulnerable System Integrity"), @AllowedValue(value = "mva", description = "Environmental: Modified Vulnerable System Availability"), @AllowedValue(value = "msc", description = "Environmental: Subsequent Vulnerable System Confidentiality"), @AllowedValue(value = "msi", description = "Environmental: Subsequent Vulnerable System Integrity"), @AllowedValue(value = "msa", description = "Environmental: Subsequent Vulnerable System Availability"), @AllowedValue(value = "cr", description = "Environmental: Confidentiality Requirements"), @AllowedValue(value = "ir", description = "Environmental: Integrity Requirements"), @AllowedValue(value = "ar", description = "Environmental: Availability Requirements"), @AllowedValue(value = "e", description = "Threat: Exploit Maturity")}), @AllowedValues(id = "oscal-cvss-v4.0-av-values", formalName = "Attack Vector Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='av']/@value", values = {@AllowedValue(value = "n", description = "Network"), @AllowedValue(value = "a", description = "Adjacent"), @AllowedValue(value = "l", description = "Local"), @AllowedValue(value = "p", description = "Physical")}), @AllowedValues(id = "oscal-cvss-v4.0-ac-values", formalName = "Attack Complexity Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='ac']/@value", values = {@AllowedValue(value = "h", description = "High"), @AllowedValue(value = "l", description = "Low")}), @AllowedValues(id = "oscal-cvss-v4.0-at-values", formalName = "Attack Requirements Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='at']/@value", values = {@AllowedValue(value = "n", description = "None"), @AllowedValue(value = "p", description = "Present")}), @AllowedValues(id = "oscal-cvss-v4.0-pr-cia-values", formalName = "Privileges Required, Confidentiality, Integrity, and Availability Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name=('pr','vc','vi','va','sc','si','sa')]/@value", values = {@AllowedValue(value = "n", description = "None"), @AllowedValue(value = "l", description = "Low"), @AllowedValue(value = "h", description = "High")}), @AllowedValues(id = "oscal-cvss-v4.0-ui-values", formalName = "User Interaction Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='ui']/@value", values = {@AllowedValue(value = "n", description = "None"), @AllowedValue(value = "p", description = "Passive"), @AllowedValue(value = "a", description = "Active")}), @AllowedValues(id = "oscal-cvss-v4.0-s-values", formalName = "Safety Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='s']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "Negligible"), @AllowedValue(value = "p", description = "Present")}), @AllowedValues(id = "oscal-cvss-v4.0-au-values", formalName = "Automatable Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='au']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "No"), @AllowedValue(value = "y", description = "Yes")}), @AllowedValues(id = "oscal-cvss-v4.0-r-values", formalName = "Recovery Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='r']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "a", description = "Automatic"), @AllowedValue(value = "u", description = "User"), @AllowedValue(value = "i", description = "Irrecoverable")}), @AllowedValues(id = "oscal-cvss-v4.0-v-values", formalName = "Value Density Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='v']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "a", description = "Automatic"), @AllowedValue(value = "u", description = "User"), @AllowedValue(value = "i", description = "Irrecoverable")}), @AllowedValues(id = "oscal-cvss-v4.0-re-values", formalName = "Vulnerability Response Effort Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='re']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "l", description = "Low"), @AllowedValue(value = "m", description = "Moderate"), @AllowedValue(value = "h", description = "High")}), @AllowedValues(id = "oscal-cvss-v4.0-u-values", formalName = "Provider Urgency Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='u']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "clear", description = "Clear"), @AllowedValue(value = "green", description = "Green"), @AllowedValue(value = "amber", description = "Amber"), @AllowedValue(value = "red", description = "Red")}), @AllowedValues(id = "oscal-cvss-v4.0-mav-values", formalName = "Modified Attack Vector Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='mav']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "Network"), @AllowedValue(value = "a", description = "Adjacent"), @AllowedValue(value = "l", description = "Local"), @AllowedValue(value = "p", description = "Physical")}), @AllowedValues(id = "oscal-cvss-v4.0-mac-values", formalName = "Modified Attack Complexity Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='mac']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "h", description = "High"), @AllowedValue(value = "l", description = "Low")}), @AllowedValues(id = "oscal-cvss-v4.0-mat-values", formalName = "Modified Attack Requirements Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='mat']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "None"), @AllowedValue(value = "p", description = "Present")}), @AllowedValues(id = "oscal-cvss-v4.0-mpr-mvs-cia-values", formalName = "Modified Privileges Required, and Vulnerable System Confidentiality, Integrity, and Availability Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name=('mpr','mvc','mvi')]/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "None"), @AllowedValue(value = "l", description = "Low"), @AllowedValue(value = "h", description = "High")}), @AllowedValues(id = "oscal-cvss-v4.0-mui-values", formalName = "Modified User Interaction Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='mui']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "None"), @AllowedValue(value = "p", description = "Passive"), @AllowedValue(value = "a", description = "Active")}), @AllowedValues(id = "oscal-cvss-v4.0-msc-values", formalName = "Modified Subsequent System Confidentiality Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='msc']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "Negligible"), @AllowedValue(value = "l", description = "Low"), @AllowedValue(value = "h", description = "High")}), @AllowedValues(id = "oscal-cvss-v4.0-msi-msa-cia-values", formalName = "Modified Safety-Related Subsequent System Integrity and Availability Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name=('msi','msa')]/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "n", description = "Negligible"), @AllowedValue(value = "l", description = "Low"), @AllowedValue(value = "h", description = "High"), @AllowedValue(value = "s", description = "Safety")}), @AllowedValues(id = "oscal-cvss-v4.0-env-cia-values", formalName = "Vulnerability Response Effort Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name=('cr','ir','ar')]/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "l", description = "Low"), @AllowedValue(value = "m", description = "Medium"), @AllowedValue(value = "h", description = "High")}), @AllowedValues(id = "oscal-cvss-v4.0-e-values", formalName = "Vulnerability Response Effort Values", level = IConstraint.Level.ERROR, target = ".[@system='https://www.first.org/cvss/v4-0' and @name='e']/@value", values = {@AllowedValue(value = "x", description = "Not Defined"), @AllowedValue(value = "a", description = "Attacked"), @AllowedValue(value = "p", description = "PoC"), @AllowedValue(value = "u", description = "Unreported")})})
  )
  public static class Facet implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * The name of the risk metric within the specified system.
     */
    @BoundFlag(
        formalName = "Facet Name",
        description = "The name of the risk metric within the specified system.",
        name = "name",
        required = true,
        typeAdapter = TokenAdapter.class
    )
    private String _name;

    /**
     * Specifies the naming system under which this risk metric is organized, which allows for the same names to be used in different systems controlled by different parties. This avoids the potential of a name clash.
     */
    @BoundFlag(
        formalName = "Naming System",
        description = "Specifies the naming system under which this risk metric is organized, which allows for the same names to be used in different systems controlled by different parties. This avoids the potential of a name clash.",
        name = "system",
        required = true,
        typeAdapter = UriAdapter.class,
        remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).",
        valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-characterization-facet-name-system-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "http://fedramp.gov", description = "\\*\\*deprecated\\*\\* The FedRAMP naming system. This has been deprecated; use `http://fedramp.gov/ns/oscal` instead.", deprecatedVersion = "1.0.3"), @AllowedValue(value = "http://fedramp.gov/ns/oscal", description = "The facet naming system defined by FedRAMP."), @AllowedValue(value = "http://csrc.nist.gov/ns/oscal", description = "The facet naming system defined by OSCAL."), @AllowedValue(value = "http://csrc.nist.gov/ns/oscal/unknown", description = "The facet is from an unknown taxonomy. The meaning of the name is tool or organization specific."), @AllowedValue(value = "http://cve.mitre.org", description = "The facet naming system defined by the CVE Program."), @AllowedValue(value = "http://www.first.org/cvss/v2.0", description = "The facet naming system for representing Common Vulnerability Scoring System (CVSS) vectors as defined by the the [Forum for Incident Response and Security Teams](https://www.first.org/) [CVSS Special Interest Group](https://www.first.org/cvss/) (CVSS-SIG) for [CVSS v2](https://www.first.org/cvss/v2/)."), @AllowedValue(value = "http://www.first.org/cvss/v3.0", description = "The facet naming system for representing Common Vulnerability Scoring System (CVSS) vectors as defined by the the [Forum for Incident Response and Security Teams](https://www.first.org/) [CVSS Special Interest Group](https://www.first.org/cvss/) (CVSS-SIG) for [CVSS v3.0](https://www.first.org/cvss/v3-0/)."), @AllowedValue(value = "http://www.first.org/cvss/v3.1", description = "The facet naming system for representing Common Vulnerability Scoring System (CVSS) vectors as defined by the the [Forum for Incident Response and Security Teams](https://www.first.org/) [CVSS Special Interest Group](https://www.first.org/cvss/) (CVSS-SIG) for [CVSS v3.1](https://www.first.org/cvss/v3-1/)."), @AllowedValue(value = "https://www.first.org/cvss/v4-0", description = "The facet naming system for representing Common Vulnerability Scoring System (CVSS) vectors as defined by the the [Forum for Incident Response and Security Teams](https://www.first.org/) [CVSS Special Interest Group](https://www.first.org/cvss/) (CVSS-SIG) for [CVSS v4.0](https://www.first.org/cvss/v4-0/).")}))
    )
    private URI _system;

    /**
     * Indicates the value of the facet.
     */
    @BoundFlag(
        formalName = "Facet Value",
        description = "Indicates the value of the facet.",
        name = "value",
        required = true,
        typeAdapter = StringAdapter.class
    )
    private String _value;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Characterization.Facet} instance with no metadata.
     */
    public Facet() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.Characterization.Facet} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Facet(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Facet Name}".
     *
     * <p>
     * The name of the risk metric within the specified system.
     *
     * @return the name value
     */
    @NonNull
    public String getName() {
      return _name;
    }

    /**
     * Set the "{@literal Facet Name}".
     *
     * <p>
     * The name of the risk metric within the specified system.
     *
     * @param value
     *           the name value to set
     */
    public void setName(@NonNull String value) {
      _name = value;
    }

    /**
     * Get the "{@literal Naming System}".
     *
     * <p>
     * Specifies the naming system under which this risk metric is organized, which allows for the same names to be used in different systems controlled by different parties. This avoids the potential of a name clash.
     *
     * @return the system value
     */
    @NonNull
    public URI getSystem() {
      return _system;
    }

    /**
     * Set the "{@literal Naming System}".
     *
     * <p>
     * Specifies the naming system under which this risk metric is organized, which allows for the same names to be used in different systems controlled by different parties. This avoids the potential of a name clash.
     *
     * @param value
     *           the system value to set
     */
    public void setSystem(@NonNull URI value) {
      _system = value;
    }

    /**
     * Get the "{@literal Facet Value}".
     *
     * <p>
     * Indicates the value of the facet.
     *
     * @return the value value
     */
    @NonNull
    public String getValue() {
      return _value;
    }

    /**
     * Set the "{@literal Facet Value}".
     *
     * <p>
     * Indicates the value of the facet.
     *
     * @param value
     *           the value value to set
     */
    public void setValue(@NonNull String value) {
      _value = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
