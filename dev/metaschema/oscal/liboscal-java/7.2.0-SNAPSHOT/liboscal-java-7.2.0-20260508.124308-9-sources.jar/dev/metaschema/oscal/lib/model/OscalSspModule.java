// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.databind.IBindingContext;
import dev.metaschema.databind.model.AbstractBoundModule;
import dev.metaschema.databind.model.IBoundModule;
import dev.metaschema.databind.model.annotations.MetaschemaModule;
import java.net.URI;
import java.util.List;

/**
 * OSCAL System Security Plan (SSP) Model
 * <p>The OSCAL Control SSP format can be used to describe the information typically specified in a system security plan, such as those defined in NIST SP 800-18.</p>
 * <p>The root of the OSCAL System Security Plan (SSP) format is <code>system-security-plan</code>.</p>
 */
@MetaschemaModule(
    assemblies = {
        SystemSecurityPlan.class,
        ImportProfile.class,
        SystemCharacteristics.class,
        SystemInformation.class,
        Impact.class,
        SecurityImpactLevel.class,
        Status.class,
        AuthorizationBoundary.class,
        Diagram.class,
        NetworkArchitecture.class,
        DataFlow.class,
        SystemImplementation.class,
        ControlImplementation.class,
        ImplementedRequirement.class,
        Statement.class,
        ByComponent.class
    },
    imports = {
        OscalMetadataModule.class,
        OscalImplementationCommonModule.class
    },
    remarks = "The OSCAL Control SSP format can be used to describe the information typically specified in a system security plan, such as those defined in NIST SP 800-18.\n"
            + "\n"
            + "The root of the OSCAL System Security Plan (SSP) format is `system-security-plan`."
)
public final class OscalSspModule extends AbstractBoundModule {
  private static final MarkupLine NAME = MarkupLine.fromMarkdown("OSCAL System Security Plan (SSP) Model");

  private static final String SHORT_NAME = "oscal-ssp";

  private static final String VERSION = "1.2.1";

  private static final URI XML_NAMESPACE = URI.create("http://csrc.nist.gov/ns/oscal/1.0");

  private static final URI JSON_BASE_URI = URI.create("http://csrc.nist.gov/ns/oscal");

  private static final MarkupMultiline REMARKS = MarkupMultiline.fromMarkdown("The OSCAL Control SSP format can be used to describe the information typically specified in a system security plan, such as those defined in NIST SP 800-18.\n"
      + "\n"
      + "The root of the OSCAL System Security Plan (SSP) format is `system-security-plan`.");

  /**
   * Construct a new module instance.
   *
   * @param importedModules
   *           modules imported by this module
   * @param bindingContext
   *           the binding context to associate with this module
   */
  public OscalSspModule(List<? extends IBoundModule> importedModules,
      IBindingContext bindingContext) {
    super(importedModules, bindingContext);
  }

  @Override
  public MarkupLine getName() {
    return NAME;
  }

  @Override
  public String getShortName() {
    return SHORT_NAME;
  }

  @Override
  public String getVersion() {
    return VERSION;
  }

  @Override
  public URI getXmlNamespace() {
    return XML_NAMESPACE;
  }

  @Override
  public URI getJsonBaseUri() {
    return JSON_BASE_URI;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return REMARKS;
  }
}
