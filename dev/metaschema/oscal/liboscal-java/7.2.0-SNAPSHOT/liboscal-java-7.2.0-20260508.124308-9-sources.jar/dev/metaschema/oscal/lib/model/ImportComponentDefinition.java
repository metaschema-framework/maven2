// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Loads a component definition from another resource.
 */
@MetaschemaAssembly(
    formalName = "Import Component Definition",
    description = "Loads a component definition from another resource.",
    name = "import-component-definition",
    moduleClass = OscalComponentDefinitionModule.class
)
public class ImportComponentDefinition implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A link to a resource that defines a set of components and/or capabilities to import into this collection.
   */
  @BoundFlag(
      formalName = "Hyperlink Reference",
      description = "A link to a resource that defines a set of components and/or capabilities to import into this collection.",
      name = "href",
      required = true,
      typeAdapter = UriReferenceAdapter.class,
      remarks = "This value may be one of:\n"
              + "\n"
              + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
              + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
              + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to a `back-matter` resource in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object))."
  )
  private URI _href;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImportComponentDefinition} instance with no metadata.
   */
  public ImportComponentDefinition() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImportComponentDefinition} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ImportComponentDefinition(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Hyperlink Reference}".
   *
   * <p>
   * A link to a resource that defines a set of components and/or capabilities to import into this collection.
   *
   * @return the href value
   */
  @NonNull
  public URI getHref() {
    return _href;
  }

  /**
   * Set the "{@literal Hyperlink Reference}".
   *
   * <p>
   * A link to a resource that defines a set of components and/or capabilities to import into this collection.
   *
   * @param value
   *           the href value to set
   */
  public void setHref(@NonNull URI value) {
    _href = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
