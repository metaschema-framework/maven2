// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A postal address for the location.
 */
@MetaschemaAssembly(
    formalName = "Address",
    description = "A postal address for the location.",
    name = "address",
    moduleClass = OscalMetadataModule.class
)
public class Address implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Indicates the type of address.
   */
  @BoundFlag(
      formalName = "Address Type",
      description = "Indicates the type of address.",
      name = "type",
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-metadata-address-location-type-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "home", description = "A home address."), @AllowedValue(value = "work", description = "A work address.")}))
  )
  private String _type;

  /**
   * A single line of an address.
   */
  @BoundField(
      formalName = "Address line",
      description = "A single line of an address.",
      useName = "addr-line",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "addr-lines", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = StringAdapter.class
  )
  private List<String> _addrLines;

  /**
   * City, town or geographical region for the mailing address.
   */
  @BoundField(
      formalName = "City",
      description = "City, town or geographical region for the mailing address.",
      useName = "city",
      typeAdapter = StringAdapter.class
  )
  private String _city;

  /**
   * State, province or analogous geographical region for a mailing address.
   */
  @BoundField(
      formalName = "State",
      description = "State, province or analogous geographical region for a mailing address.",
      useName = "state",
      typeAdapter = StringAdapter.class
  )
  private String _state;

  /**
   * Postal or ZIP code for mailing address.
   */
  @BoundField(
      formalName = "Postal Code",
      description = "Postal or ZIP code for mailing address.",
      useName = "postal-code",
      typeAdapter = StringAdapter.class
  )
  private String _postalCode;

  /**
   * The ISO 3166-1 alpha-2 country code for the mailing address.
   */
  @BoundField(
      formalName = "Country Code",
      description = "The ISO 3166-1 alpha-2 country code for the mailing address.",
      useName = "country",
      typeAdapter = StringAdapter.class,
      valueConstraints = @ValueConstraints(matches = @Matches(id = "oscal-metadata-location-address-country-regex", level = IConstraint.Level.ERROR, pattern = "[A-Z]{2}"))
  )
  private String _country;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Address} instance with no metadata.
   */
  public Address() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Address} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Address(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Address Type}".
   *
   * <p>
   * Indicates the type of address.
   *
   * @return the type value, or {@code null} if not set
   */
  @Nullable
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Address Type}".
   *
   * <p>
   * Indicates the type of address.
   *
   * @param value
   *           the type value to set, or {@code null} to clear
   */
  public void setType(@Nullable String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Address line}".
   *
   * <p>
   * A single line of an address.
   *
   * @return the addr-line value
   */
  @NonNull
  public List<String> getAddrLines() {
    if (_addrLines == null) {
      _addrLines = new LinkedList<>();
    }
    return ObjectUtils.notNull(_addrLines);
  }

  /**
   * Set the "{@literal Address line}".
   *
   * <p>
   * A single line of an address.
   *
   * @param value
   *           the addr-line value to set
   */
  public void setAddrLines(@NonNull List<String> value) {
    _addrLines = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAddrLine(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_addrLines == null) {
      _addrLines = new LinkedList<>();
    }
    return _addrLines.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAddrLine(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _addrLines != null && _addrLines.remove(value);
  }

  /**
   * Get the "{@literal City}".
   *
   * <p>
   * City, town or geographical region for the mailing address.
   *
   * @return the city value, or {@code null} if not set
   */
  @Nullable
  public String getCity() {
    return _city;
  }

  /**
   * Set the "{@literal City}".
   *
   * <p>
   * City, town or geographical region for the mailing address.
   *
   * @param value
   *           the city value to set, or {@code null} to clear
   */
  public void setCity(@Nullable String value) {
    _city = value;
  }

  /**
   * Get the "{@literal State}".
   *
   * <p>
   * State, province or analogous geographical region for a mailing address.
   *
   * @return the state value, or {@code null} if not set
   */
  @Nullable
  public String getState() {
    return _state;
  }

  /**
   * Set the "{@literal State}".
   *
   * <p>
   * State, province or analogous geographical region for a mailing address.
   *
   * @param value
   *           the state value to set, or {@code null} to clear
   */
  public void setState(@Nullable String value) {
    _state = value;
  }

  /**
   * Get the "{@literal Postal Code}".
   *
   * <p>
   * Postal or ZIP code for mailing address.
   *
   * @return the postal-code value, or {@code null} if not set
   */
  @Nullable
  public String getPostalCode() {
    return _postalCode;
  }

  /**
   * Set the "{@literal Postal Code}".
   *
   * <p>
   * Postal or ZIP code for mailing address.
   *
   * @param value
   *           the postal-code value to set, or {@code null} to clear
   */
  public void setPostalCode(@Nullable String value) {
    _postalCode = value;
  }

  /**
   * Get the "{@literal Country Code}".
   *
   * <p>
   * The ISO 3166-1 alpha-2 country code for the mailing address.
   *
   * @return the country value, or {@code null} if not set
   */
  @Nullable
  public String getCountry() {
    return _country;
  }

  /**
   * Set the "{@literal Country Code}".
   *
   * <p>
   * The ISO 3166-1 alpha-2 country code for the mailing address.
   *
   * @param value
   *           the country value to set, or {@code null} to clear
   */
  public void setCountry(@Nullable String value) {
    _country = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
