// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_mapping-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A <em>by-id</em> collection of all controls that were not mapped at all in this <code> mapping-collection</code>. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the <code> relationship-gal</code>.
 */
@MetaschemaAssembly(
    formalName = "Gap Summary",
    description = "A *by-id* collection of all controls that were not mapped at all in this ` mapping-collection`. If a control is partially mapped, the parts of the control are not mappable, the gap and discrepancies should be documented in the ` relationship-gal`.",
    name = "gap-summary",
    moduleClass = OscalMappingCommonModule.class
)
public class GapSummary implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mapping gap summary elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>SSP</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance).This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Gap Summary Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this mapping gap summary elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `SSP` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance).This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Select a control or controls from an imported control set.
   */
  @BoundAssembly(
      formalName = "Select Control",
      description = "Select a control or controls from an imported control set.",
      useName = "unmapped-controls",
      remarks = "If `with-child-controls` is \"yes\" on the call to a control, any controls appearing within it (child controls) will be selected, with no additional `call` directives required. This flag provides a way to include controls with all their dependent controls (enhancements) without having to call them individually.",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "unmapped-controls", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlCommonSelectControlById> _unmappedControls;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.GapSummary} instance with no metadata.
   */
  public GapSummary() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.GapSummary} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public GapSummary(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Gap Summary Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mapping gap summary elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>SSP</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance).This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Gap Summary Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this mapping gap summary elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>SSP</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance).This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @return the unmapped-controls value
   */
  @NonNull
  public List<ControlCommonSelectControlById> getUnmappedControls() {
    if (_unmappedControls == null) {
      _unmappedControls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_unmappedControls);
  }

  /**
   * Set the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @param value
   *           the unmapped-controls value to set
   */
  public void setUnmappedControls(@NonNull List<ControlCommonSelectControlById> value) {
    _unmappedControls = value;
  }

  /**
   * Add a new {@link ControlCommonSelectControlById} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addUnmappedControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_unmappedControls == null) {
      _unmappedControls = new LinkedList<>();
    }
    return _unmappedControls.add(value);
  }

  /**
   * Remove the first matching {@link ControlCommonSelectControlById} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeUnmappedControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _unmappedControls != null && _unmappedControls.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
