// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A type of user that interacts with the system based on an associated role.
 */
@MetaschemaAssembly(
    formalName = "System User",
    description = "A type of user that interacts with the system based on an associated role.",
    name = "system-user",
    moduleClass = OscalImplementationCommonModule.class,
    remarks = "Permissible values to be determined closer to the application, such as by a receiving authority.",
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-user-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "type", description = "The type of user, such as internal, external, or general-public."), @AllowedValue(value = "privilege-level", description = "The user's privilege level within the system, such as privileged, non-privileged, no-logical-access.")}), @AllowedValues(id = "oscal-user-prop-type-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='type']/@value", values = {@AllowedValue(value = "internal", description = "A user account for a person or entity that is part of the organization who owns or operates the system."), @AllowedValue(value = "external", description = "A user account for a person or entity that is not part of the organization who owns or operates the system."), @AllowedValue(value = "general-public", description = "A user of the system considered to be outside")}), @AllowedValues(id = "oscal-user-prop-privilege-level-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='privilege-level']/@value", values = {@AllowedValue(value = "privileged", description = "This role has elevated access to the system, such as a group or system administrator."), @AllowedValue(value = "non-privileged", description = "This role has typical user-level access to the system without elevated access."), @AllowedValue(value = "no-logical-access", description = "This role has no access to the system, such as a manager who approves access as part of a process.")}), @AllowedValues(id = "oscal-user-role-id-values", level = IConstraint.Level.ERROR, target = "role-id", allowOthers = true, values = {@AllowedValue(value = "asset-owner", description = "Accountable for ensuring the asset is managed in accordance with organizational policies and procedures."), @AllowedValue(value = "asset-administrator", description = "Responsible for administering a set of assets."), @AllowedValue(value = "security-operations", description = "Members of the security operations center (SOC)."), @AllowedValue(value = "network-operations", description = "Members of the network operations center (NOC)."), @AllowedValue(value = "incident-response", description = "Responsible for responding to an event that could lead to loss of, or disruption to, an organization's operations, services or functions."), @AllowedValue(value = "help-desk", description = "Responsible for providing information and support to users."), @AllowedValue(value = "configuration-management", description = "Responsible for the configuration management processes governing changes to the asset.")})})
)
public class SystemUser implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this user class elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>system user</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "User Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this user class elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope). The locally defined *UUID* of the `system user` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * A name given to the user, which may be used by a tool for display and navigation.
   */
  @BoundField(
      formalName = "User Title",
      description = "A name given to the user, which may be used by a tool for display and navigation.",
      useName = "title",
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A short common name, abbreviation, or acronym for the user.
   */
  @BoundField(
      formalName = "User Short Name",
      description = "A short common name, abbreviation, or acronym for the user.",
      useName = "short-name",
      typeAdapter = StringAdapter.class
  )
  private String _shortName;

  /**
   * A summary of the user's purpose within the system.
   */
  @BoundField(
      formalName = "User Description",
      description = "A summary of the user's purpose within the system.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Reference to a role by UUID.
   */
  @BoundField(
      formalName = "Role Identifier Reference",
      description = "Reference to a role by UUID.",
      useName = "role-id",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "role-ids", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(indexHasKey = @IndexHasKey(id = "oscal-index-metadata-role-id", level = IConstraint.Level.ERROR, indexName = "index-metadata-role-id", keyFields = @KeyField))
  )
  private List<String> _roleIds;

  /**
   * Identifies a specific system privilege held by the user, along with an associated description and/or rationale for the privilege.
   */
  @BoundAssembly(
      formalName = "Privilege",
      description = "Identifies a specific system privilege held by the user, along with an associated description and/or rationale for the privilege.",
      useName = "authorized-privilege",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "authorized-privileges", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AuthorizedPrivilege> _authorizedPrivileges;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemUser} instance with no metadata.
   */
  public SystemUser() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemUser} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SystemUser(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal User Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this user class elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>system user</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal User Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this user class elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>system user</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal User Title}".
   *
   * <p>
   * A name given to the user, which may be used by a tool for display and navigation.
   *
   * @return the title value, or {@code null} if not set
   */
  @Nullable
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal User Title}".
   *
   * <p>
   * A name given to the user, which may be used by a tool for display and navigation.
   *
   * @param value
   *           the title value to set, or {@code null} to clear
   */
  public void setTitle(@Nullable MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal User Short Name}".
   *
   * <p>
   * A short common name, abbreviation, or acronym for the user.
   *
   * @return the short-name value, or {@code null} if not set
   */
  @Nullable
  public String getShortName() {
    return _shortName;
  }

  /**
   * Set the "{@literal User Short Name}".
   *
   * <p>
   * A short common name, abbreviation, or acronym for the user.
   *
   * @param value
   *           the short-name value to set, or {@code null} to clear
   */
  public void setShortName(@Nullable String value) {
    _shortName = value;
  }

  /**
   * Get the "{@literal User Description}".
   *
   * <p>
   * A summary of the user's purpose within the system.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal User Description}".
   *
   * <p>
   * A summary of the user's purpose within the system.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Role Identifier Reference}".
   *
   * <p>
   * Reference to a role by UUID.
   *
   * @return the role-id value
   */
  @NonNull
  public List<String> getRoleIds() {
    if (_roleIds == null) {
      _roleIds = new LinkedList<>();
    }
    return ObjectUtils.notNull(_roleIds);
  }

  /**
   * Set the "{@literal Role Identifier Reference}".
   *
   * <p>
   * Reference to a role by UUID.
   *
   * @param value
   *           the role-id value to set
   */
  public void setRoleIds(@NonNull List<String> value) {
    _roleIds = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRoleId(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_roleIds == null) {
      _roleIds = new LinkedList<>();
    }
    return _roleIds.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRoleId(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _roleIds != null && _roleIds.remove(value);
  }

  /**
   * Get the "{@literal Privilege}".
   *
   * <p>
   * Identifies a specific system privilege held by the user, along with an associated description and/or rationale for the privilege.
   *
   * @return the authorized-privilege value
   */
  @NonNull
  public List<AuthorizedPrivilege> getAuthorizedPrivileges() {
    if (_authorizedPrivileges == null) {
      _authorizedPrivileges = new LinkedList<>();
    }
    return ObjectUtils.notNull(_authorizedPrivileges);
  }

  /**
   * Set the "{@literal Privilege}".
   *
   * <p>
   * Identifies a specific system privilege held by the user, along with an associated description and/or rationale for the privilege.
   *
   * @param value
   *           the authorized-privilege value to set
   */
  public void setAuthorizedPrivileges(@NonNull List<AuthorizedPrivilege> value) {
    _authorizedPrivileges = value;
  }

  /**
   * Add a new {@link AuthorizedPrivilege} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAuthorizedPrivilege(AuthorizedPrivilege item) {
    AuthorizedPrivilege value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_authorizedPrivileges == null) {
      _authorizedPrivileges = new LinkedList<>();
    }
    return _authorizedPrivileges.add(value);
  }

  /**
   * Remove the first matching {@link AuthorizedPrivilege} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAuthorizedPrivilege(AuthorizedPrivilege item) {
    AuthorizedPrivilege value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _authorizedPrivileges != null && _authorizedPrivileges.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
