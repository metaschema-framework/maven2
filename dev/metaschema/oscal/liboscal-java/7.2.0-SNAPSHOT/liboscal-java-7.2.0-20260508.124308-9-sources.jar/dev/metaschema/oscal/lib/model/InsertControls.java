// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Specifies which controls to use in the containing context.
 */
@MetaschemaAssembly(
    formalName = "Insert Controls",
    description = "Specifies which controls to use in the containing context.",
    name = "insert-controls",
    moduleClass = OscalProfileModule.class,
    remarks = "To be schema-valid, this element must contain either (but not both) a single `include-all` directive, or a sequence of `include-controls` directives.\n"
            + "\n"
            + "If this directive is not provided, then no controls are to be inserted; i.e., all controls are included explicitly."
)
public class InsertControls implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A designation of how a selection of controls in a profile is to be ordered.
   */
  @BoundFlag(
      formalName = "Order",
      description = "A designation of how a selection of controls in a profile is to be ordered.",
      name = "order",
      typeAdapter = TokenAdapter.class,
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-profile-insert-controls-order-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "keep", description = "Use the order of their appearance, using a depth-first traversal of the source profile's imports."), @AllowedValue(value = "ascending", description = "Sort all selected controls into ascending alphanumeric order by their ID."), @AllowedValue(value = "descending", description = "Sort all selected controls into descending alphanumeric order by their ID.")}))
  )
  private String _order;

  /**
   * Include all controls from the imported catalog or profile resources.
   */
  @BoundAssembly(
      formalName = "Include All",
      description = "Include all controls from the imported catalog or profile resources.",
      useName = "include-all",
      minOccurs = 1
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private IncludeAll _includeAll;

  /**
   * Select a control or controls from an imported control set.
   */
  @BoundAssembly(
      formalName = "Select Control",
      description = "Select a control or controls from an imported control set.",
      useName = "include-controls",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "include-controls", inJson = JsonGroupAsBehavior.LIST)
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private List<ControlCommonSelectControlById> _includeControls;

  /**
   * Select a control or controls from an imported control set.
   */
  @BoundAssembly(
      formalName = "Select Control",
      description = "Select a control or controls from an imported control set.",
      useName = "exclude-controls",
      remarks = "Identifies which controls to exclude, or eliminate, from the set of matching includes.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "exclude-controls", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlCommonSelectControlById> _excludeControls;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.InsertControls} instance with no metadata.
   */
  public InsertControls() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.InsertControls} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public InsertControls(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Order}".
   *
   * <p>
   * A designation of how a selection of controls in a profile is to be ordered.
   *
   * @return the order value, or {@code null} if not set
   */
  @Nullable
  public String getOrder() {
    return _order;
  }

  /**
   * Set the "{@literal Order}".
   *
   * <p>
   * A designation of how a selection of controls in a profile is to be ordered.
   *
   * @param value
   *           the order value to set, or {@code null} to clear
   */
  public void setOrder(@Nullable String value) {
    _order = value;
  }

  /**
   * Get the "{@literal Include All}".
   *
   * <p>
   * Include all controls from the imported catalog or profile resources.
   *
   * @return the include-all value, or {@code null} if not set
   */
  @Nullable
  public IncludeAll getIncludeAll() {
    return _includeAll;
  }

  /**
   * Set the "{@literal Include All}".
   *
   * <p>
   * Include all controls from the imported catalog or profile resources.
   *
   * @param value
   *           the include-all value to set, or {@code null} to clear
   */
  public void setIncludeAll(@Nullable IncludeAll value) {
    _includeAll = value;
  }

  /**
   * Get the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @return the include-controls value
   */
  @NonNull
  public List<ControlCommonSelectControlById> getIncludeControls() {
    if (_includeControls == null) {
      _includeControls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_includeControls);
  }

  /**
   * Set the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @param value
   *           the include-controls value to set
   */
  public void setIncludeControls(@NonNull List<ControlCommonSelectControlById> value) {
    _includeControls = value;
  }

  /**
   * Add a new {@link ControlCommonSelectControlById} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addIncludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_includeControls == null) {
      _includeControls = new LinkedList<>();
    }
    return _includeControls.add(value);
  }

  /**
   * Remove the first matching {@link ControlCommonSelectControlById} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeIncludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _includeControls != null && _includeControls.remove(value);
  }

  /**
   * Get the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @return the exclude-controls value
   */
  @NonNull
  public List<ControlCommonSelectControlById> getExcludeControls() {
    if (_excludeControls == null) {
      _excludeControls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_excludeControls);
  }

  /**
   * Set the "{@literal Select Control}".
   *
   * <p>
   * Select a control or controls from an imported control set.
   *
   * @param value
   *           the exclude-controls value to set
   */
  public void setExcludeControls(@NonNull List<ControlCommonSelectControlById> value) {
    _excludeControls = value;
  }

  /**
   * Add a new {@link ControlCommonSelectControlById} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addExcludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_excludeControls == null) {
      _excludeControls = new LinkedList<>();
    }
    return _excludeControls.add(value);
  }

  /**
   * Remove the first matching {@link ControlCommonSelectControlById} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeExcludeControls(ControlCommonSelectControlById item) {
    ControlCommonSelectControlById value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _excludeControls != null && _excludeControls.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
