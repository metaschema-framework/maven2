// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_control-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A prose statement that provides a recommendation for the use of a parameter.
 */
@MetaschemaAssembly(
    formalName = "Guideline",
    description = "A prose statement that provides a recommendation for the use of a parameter.",
    name = "parameter-guideline",
    moduleClass = OscalControlCommonModule.class
)
public class ParameterGuideline implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Prose permits multiple paragraphs, lists, tables etc.
   */
  @BoundField(
      formalName = "Guideline Text",
      description = "Prose permits multiple paragraphs, lists, tables etc.",
      useName = "prose",
      minOccurs = 1,
      inXmlWrapped = false,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _prose;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterGuideline} instance with no metadata.
   */
  public ParameterGuideline() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ParameterGuideline} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ParameterGuideline(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Guideline Text}".
   *
   * <p>
   * Prose permits multiple paragraphs, lists, tables etc.
   *
   * @return the prose value
   */
  @NonNull
  public MarkupMultiline getProse() {
    return _prose;
  }

  /**
   * Set the "{@literal Guideline Text}".
   *
   * <p>
   * Prose permits multiple paragraphs, lists, tables etc.
   *
   * @param value
   *           the prose value to set
   */
  public void setProse(@NonNull MarkupMultiline value) {
    _prose = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
