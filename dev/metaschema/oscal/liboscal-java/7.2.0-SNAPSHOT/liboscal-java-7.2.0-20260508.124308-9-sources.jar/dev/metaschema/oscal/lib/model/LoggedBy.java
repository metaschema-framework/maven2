// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Used to indicate who created a log entry in what role.
 */
@MetaschemaAssembly(
    formalName = "Logged By",
    description = "Used to indicate who created a log entry in what role.",
    name = "logged-by",
    moduleClass = OscalAssessmentCommonModule.class
)
public class LoggedBy implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the party who is making the log entry.
   */
  @BoundFlag(
      formalName = "Party UUID Reference",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to the party who is making the log entry.",
      name = "party-uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _partyUuid;

  /**
   * A point to the role-id of the role in which the party is making the log entry.
   */
  @BoundFlag(
      formalName = "Actor Role",
      description = "A point to the role-id of the role in which the party is making the log entry.",
      name = "role-id",
      typeAdapter = TokenAdapter.class
  )
  private String _roleId;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.LoggedBy} instance with no metadata.
   */
  public LoggedBy() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.LoggedBy} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public LoggedBy(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Party UUID Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the party who is making the log entry.
   *
   * @return the party-uuid value
   */
  @NonNull
  public UUID getPartyUuid() {
    return _partyUuid;
  }

  /**
   * Set the "{@literal Party UUID Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the party who is making the log entry.
   *
   * @param value
   *           the party-uuid value to set
   */
  public void setPartyUuid(@NonNull UUID value) {
    _partyUuid = value;
  }

  /**
   * Get the "{@literal Actor Role}".
   *
   * <p>
   * A point to the role-id of the role in which the party is making the log entry.
   *
   * @return the role-id value, or {@code null} if not set
   */
  @Nullable
  public String getRoleId() {
    return _roleId;
  }

  /**
   * Set the "{@literal Actor Role}".
   *
   * <p>
   * A point to the role-id of the role in which the party is making the log entry.
   *
   * @param value
   *           the role-id value to set, or {@code null} to clear
   */
  public void setRoleId(@Nullable String value) {
    _roleId = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
