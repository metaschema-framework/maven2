// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies the parameter that will be set by the enclosed value.
 */
@MetaschemaAssembly(
    formalName = "Set Parameter Value",
    description = "Identifies the parameter that will be set by the enclosed value.",
    name = "set-parameter",
    moduleClass = OscalImplementationCommonModule.class
)
public class SetParameter implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> reference to a <code>parameter</code> within a control, who's catalog has been imported into the current implementation context.
   */
  @BoundFlag(
      formalName = "Parameter ID",
      description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented) reference to a `parameter` within a control, who's catalog has been imported into the current implementation context.",
      name = "param-id",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _paramId;

  /**
   * A parameter value or set of values.
   */
  @BoundField(
      formalName = "Parameter Value",
      description = "A parameter value or set of values.",
      useName = "value",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "values", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = StringAdapter.class
  )
  private List<String> _values;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SetParameter} instance with no metadata.
   */
  public SetParameter() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SetParameter} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SetParameter(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Parameter ID}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> reference to a <code>parameter</code> within a control, who's catalog has been imported into the current implementation context.
   *
   * @return the param-id value
   */
  @NonNull
  public String getParamId() {
    return _paramId;
  }

  /**
   * Set the "{@literal Parameter ID}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a> reference to a <code>parameter</code> within a control, who's catalog has been imported into the current implementation context.
   *
   * @param value
   *           the param-id value to set
   */
  public void setParamId(@NonNull String value) {
    _paramId = value;
  }

  /**
   * Get the "{@literal Parameter Value}".
   *
   * <p>
   * A parameter value or set of values.
   *
   * @return the value value
   */
  @NonNull
  public List<String> getValues() {
    if (_values == null) {
      _values = new LinkedList<>();
    }
    return ObjectUtils.notNull(_values);
  }

  /**
   * Set the "{@literal Parameter Value}".
   *
   * <p>
   * A parameter value or set of values.
   *
   * @param value
   *           the value value to set
   */
  public void setValues(@NonNull List<String> value) {
    _values = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addValue(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_values == null) {
      _values = new LinkedList<>();
    }
    return _values.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeValue(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _values != null && _values.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
