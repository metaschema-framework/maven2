// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes how the containing component or capability implements an individual control.
 */
@MetaschemaAssembly(
    formalName = "Control Implementation",
    description = "Describes how the containing component or capability implements an individual control.",
    name = "implemented-requirement",
    moduleClass = OscalComponentDefinitionModule.class,
    remarks = "Implemented requirements within a component or capability in a component definition provide a means for component suppliers to suggest possible control implementation details, which may be used by a different party (e.g., component consumers) when authoring a system security plan. Thus, these requirements defined in a component definition are only a suggestion of how to implement, which may be adopted wholesale, changed, or ignored by a person defining an information system implementation.\n"
            + "\n"
            + "Use of `set-parameter` in this context, sets the parameter for the referenced control and any associated statements.",
    modelConstraints = @AssemblyConstraints(unique = {@IsUnique(id = "oscal-unique-component-definition-implemented-requirement-set-parameter", level = IConstraint.Level.ERROR, target = "set-parameter", keyFields = @KeyField(target = "@param-id"), remarks = "Since multiple `set-parameter` entries can be provided, each parameter must be set only once."), @IsUnique(id = "oscal-unique-component-definition-implemented-requirement-responsible-role", level = IConstraint.Level.ERROR, target = "responsible-role", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-role` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."), @IsUnique(id = "oscal-unique-component-definition-implemented-requirement-statement", level = IConstraint.Level.ERROR, target = "statement", keyFields = @KeyField(target = "@statement-id"), remarks = "Since `statement` entries can be referenced using the statement's statement-id, each statement must be referenced only once.")})
)
public class ComponentImplementedRequirement implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Provides a globally unique means to identify a given control implementation by a component.
   */
  @BoundFlag(
      formalName = "Control Implementation Identifier",
      description = "Provides a globally unique means to identify a given control implementation by a component.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   */
  @BoundFlag(
      formalName = "Control Identifier Reference",
      description = "A reference to a control with a corresponding `id` value. When referencing an externally defined `control`, the `Control Identifier Reference` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).",
      name = "control-id",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _controlId;

  /**
   * A suggestion from the supplier (e.g., component vendor or author) for how the specified control may be implemented if the containing component or capability is instantiated in a system security plan.
   */
  @BoundField(
      formalName = "Control Implementation Description",
      description = "A suggestion from the supplier (e.g., component vendor or author) for how the specified control may be implemented if the containing component or capability is instantiated in a system security plan.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the parameter that will be set by the enclosed value.
   */
  @BoundAssembly(
      formalName = "Set Parameter Value",
      description = "Identifies the parameter that will be set by the enclosed value.",
      useName = "set-parameter",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "set-parameters", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SetParameter> _setParameters;

  /**
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   */
  @BoundAssembly(
      formalName = "Responsible Role",
      description = "A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.",
      useName = "responsible-role",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-roles", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleRole> _responsibleRoles;

  /**
   * Identifies which statements within a control are addressed.
   */
  @BoundAssembly(
      formalName = "Control Statement Implementation",
      description = "Identifies which statements within a control are addressed.",
      useName = "statement",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "statements", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ComponentStatement> _statements;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ComponentImplementedRequirement} instance with no metadata.
   */
  public ComponentImplementedRequirement() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ComponentImplementedRequirement} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ComponentImplementedRequirement(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Control Implementation Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given control implementation by a component.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Control Implementation Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given control implementation by a component.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @return the control-id value
   */
  @NonNull
  public String getControlId() {
    return _controlId;
  }

  /**
   * Set the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @param value
   *           the control-id value to set
   */
  public void setControlId(@NonNull String value) {
    _controlId = value;
  }

  /**
   * Get the "{@literal Control Implementation Description}".
   *
   * <p>
   * A suggestion from the supplier (e.g., component vendor or author) for how the specified control may be implemented if the containing component or capability is instantiated in a system security plan.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Control Implementation Description}".
   *
   * <p>
   * A suggestion from the supplier (e.g., component vendor or author) for how the specified control may be implemented if the containing component or capability is instantiated in a system security plan.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @return the set-parameter value
   */
  @NonNull
  public List<SetParameter> getSetParameters() {
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return ObjectUtils.notNull(_setParameters);
  }

  /**
   * Set the "{@literal Set Parameter Value}".
   *
   * <p>
   * Identifies the parameter that will be set by the enclosed value.
   *
   * @param value
   *           the set-parameter value to set
   */
  public void setSetParameters(@NonNull List<SetParameter> value) {
    _setParameters = value;
  }

  /**
   * Add a new {@link SetParameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_setParameters == null) {
      _setParameters = new LinkedList<>();
    }
    return _setParameters.add(value);
  }

  /**
   * Remove the first matching {@link SetParameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeSetParameter(SetParameter item) {
    SetParameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _setParameters != null && _setParameters.remove(value);
  }

  /**
   * Get the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @return the responsible-role value
   */
  @NonNull
  public List<ResponsibleRole> getResponsibleRoles() {
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleRoles);
  }

  /**
   * Set the "{@literal Responsible Role}".
   *
   * <p>
   * A reference to a role with responsibility for performing a function relative to the containing object, optionally associated with a set of persons and/or organizations that perform that role.
   *
   * @param value
   *           the responsible-role value to set
   */
  public void setResponsibleRoles(@NonNull List<ResponsibleRole> value) {
    _responsibleRoles = value;
  }

  /**
   * Add a new {@link ResponsibleRole} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleRoles == null) {
      _responsibleRoles = new LinkedList<>();
    }
    return _responsibleRoles.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleRole} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleRole(ResponsibleRole item) {
    ResponsibleRole value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleRoles != null && _responsibleRoles.remove(value);
  }

  /**
   * Get the "{@literal Control Statement Implementation}".
   *
   * <p>
   * Identifies which statements within a control are addressed.
   *
   * @return the statement value
   */
  @NonNull
  public List<ComponentStatement> getStatements() {
    if (_statements == null) {
      _statements = new LinkedList<>();
    }
    return ObjectUtils.notNull(_statements);
  }

  /**
   * Set the "{@literal Control Statement Implementation}".
   *
   * <p>
   * Identifies which statements within a control are addressed.
   *
   * @param value
   *           the statement value to set
   */
  public void setStatements(@NonNull List<ComponentStatement> value) {
    _statements = value;
  }

  /**
   * Add a new {@link ComponentStatement} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addStatement(ComponentStatement item) {
    ComponentStatement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_statements == null) {
      _statements = new LinkedList<>();
    }
    return _statements.add(value);
  }

  /**
   * Remove the first matching {@link ComponentStatement} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeStatement(ComponentStatement item) {
    ComponentStatement value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _statements != null && _statements.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
