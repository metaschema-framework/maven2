// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Each OSCAL profile is defined by a <code>profile</code> element.
 */
@MetaschemaAssembly(
    formalName = "Profile",
    description = "Each OSCAL profile is defined by a `profile` element.",
    name = "profile",
    moduleClass = OscalProfileModule.class,
    rootName = "profile",
    remarks = "An OSCAL document that describes a tailoring of controls from one or more catalogs, with possible modification of multiple controls. It provides mechanisms by which controls may be selected (`import`), merged or (re)structured (`merge`), and amended (`modify`). OSCAL profiles may select subsets of controls, set parameter values for them in application, and even adjust the representation of controls as given in and by a catalog. They may also serve as sources for further modification in and by other profiles, that import them.",
    modelConstraints = @AssemblyConstraints(unique = {@IsUnique(id = "oscal-unique-document-id", formalName = "Unique Document Identifier", description = "Ensure all document identifiers have a unique combination of @scheme and value.", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-property-in-context-location", formalName = "Unique Properties", description = "Ensure all properties are unique for a given location using a unique combination of @ns, @name, @class. @group. and @value.", level = IConstraint.Level.ERROR, target = ".//prop", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-link-in-context-location", formalName = "Unique Links", description = "Ensure all links are unique for a given location using a unique combination of @href, @rel, and @media-type.", level = IConstraint.Level.ERROR, target = ".//link", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type"), @KeyField(target = "@resource-fragment")}), @IsUnique(id = "oscal-unique-responsibility-in-context-location", formalName = "Unique Responsibilities", description = "Ensure all responsible-roles and responsible-parties are unique for a given location using a unique combination of @role-id and the combination of @party-uuid values.", level = IConstraint.Level.ERROR, target = ".//(responsible-party|responsible-role)", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@role-id"), @KeyField(target = "@party-uuid")}, remarks = "Since `responsible-party` and `responsible-role` associate multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.")})
)
public class Profile extends AbstractOscalInstance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Provides a globally unique means to identify a given profile instance.
   */
  @BoundFlag(
      formalName = "Profile Universally Unique Identifier",
      description = "Provides a globally unique means to identify a given profile instance.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Provides information about the containing document, and defines concepts that are shared across the document.
   */
  @BoundAssembly(
      formalName = "Document Metadata",
      description = "Provides information about the containing document, and defines concepts that are shared across the document.",
      useName = "metadata",
      minOccurs = 1
  )
  private Metadata _metadata;

  /**
   * Designates a referenced source catalog or profile that provides a source of control information for use in creating a new overlay or baseline.
   */
  @BoundAssembly(
      formalName = "Import Resource",
      description = "Designates a referenced source catalog or profile that provides a source of control information for use in creating a new overlay or baseline.",
      useName = "import",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "imports", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ProfileImport> _imports;

  /**
   * Provides structuring directives that instruct how controls are organized after profile resolution.
   */
  @BoundAssembly(
      formalName = "Merge Controls",
      description = "Provides structuring directives that instruct how controls are organized after profile resolution.",
      useName = "merge"
  )
  private Merge _merge;

  /**
   * Set parameters or amend controls in resolution.
   */
  @BoundAssembly(
      formalName = "Modify Controls",
      description = "Set parameters or amend controls in resolution.",
      useName = "modify"
  )
  private Modify _modify;

  /**
   * A collection of resources that may be referenced from within the OSCAL document instance.
   */
  @BoundAssembly(
      formalName = "Back matter",
      description = "A collection of resources that may be referenced from within the OSCAL document instance.",
      useName = "back-matter"
  )
  private BackMatter _backMatter;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Profile} instance with no metadata.
   */
  public Profile() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Profile} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Profile(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Profile Universally Unique Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given profile instance.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Profile Universally Unique Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given profile instance.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @return the metadata value
   */
  @NonNull
  public Metadata getMetadata() {
    return _metadata;
  }

  /**
   * Set the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @param value
   *           the metadata value to set
   */
  public void setMetadata(@NonNull Metadata value) {
    _metadata = value;
  }

  /**
   * Get the "{@literal Import Resource}".
   *
   * <p>
   * Designates a referenced source catalog or profile that provides a source of control information for use in creating a new overlay or baseline.
   *
   * @return the import value
   */
  @NonNull
  public List<ProfileImport> getImports() {
    if (_imports == null) {
      _imports = new LinkedList<>();
    }
    return ObjectUtils.notNull(_imports);
  }

  /**
   * Set the "{@literal Import Resource}".
   *
   * <p>
   * Designates a referenced source catalog or profile that provides a source of control information for use in creating a new overlay or baseline.
   *
   * @param value
   *           the import value to set
   */
  public void setImports(@NonNull List<ProfileImport> value) {
    _imports = value;
  }

  /**
   * Add a new {@link ProfileImport} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addImport(ProfileImport item) {
    ProfileImport value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_imports == null) {
      _imports = new LinkedList<>();
    }
    return _imports.add(value);
  }

  /**
   * Remove the first matching {@link ProfileImport} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeImport(ProfileImport item) {
    ProfileImport value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _imports != null && _imports.remove(value);
  }

  /**
   * Get the "{@literal Merge Controls}".
   *
   * <p>
   * Provides structuring directives that instruct how controls are organized after profile resolution.
   *
   * @return the merge value, or {@code null} if not set
   */
  @Nullable
  public Merge getMerge() {
    return _merge;
  }

  /**
   * Set the "{@literal Merge Controls}".
   *
   * <p>
   * Provides structuring directives that instruct how controls are organized after profile resolution.
   *
   * @param value
   *           the merge value to set, or {@code null} to clear
   */
  public void setMerge(@Nullable Merge value) {
    _merge = value;
  }

  /**
   * Get the "{@literal Modify Controls}".
   *
   * <p>
   * Set parameters or amend controls in resolution.
   *
   * @return the modify value, or {@code null} if not set
   */
  @Nullable
  public Modify getModify() {
    return _modify;
  }

  /**
   * Set the "{@literal Modify Controls}".
   *
   * <p>
   * Set parameters or amend controls in resolution.
   *
   * @param value
   *           the modify value to set, or {@code null} to clear
   */
  public void setModify(@Nullable Modify value) {
    _modify = value;
  }

  /**
   * Get the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @return the back-matter value, or {@code null} if not set
   */
  @Nullable
  public BackMatter getBackMatter() {
    return _backMatter;
  }

  /**
   * Set the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @param value
   *           the back-matter value to set, or {@code null} to clear
   */
  public void setBackMatter(@Nullable BackMatter value) {
    _backMatter = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
