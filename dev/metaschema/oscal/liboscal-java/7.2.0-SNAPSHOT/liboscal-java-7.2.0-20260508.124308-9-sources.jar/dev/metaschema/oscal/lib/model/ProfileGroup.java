// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_profile_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundChoice;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A group of (selected) controls or of groups of controls.
 */
@MetaschemaAssembly(
    formalName = "Control Group",
    description = "A group of (selected) controls or of groups of controls.",
    name = "group",
    moduleClass = OscalProfileModule.class,
    remarks = "This construct mirrors the same construct that exists in an OSCAL catalog."
)
public class ProfileGroup implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Identifies the group.
   */
  @BoundFlag(
      formalName = "Group Identifier",
      description = "Identifies the group.",
      name = "id",
      typeAdapter = TokenAdapter.class,
      remarks = "This optional data element is available to support hyperlinking to formal groups or families as defined in control catalogs, among other operations."
  )
  private String _id;

  /**
   * A textual label that provides a sub-type or characterization of the group.
   */
  @BoundFlag(
      formalName = "Group Class",
      description = "A textual label that provides a sub-type or characterization of the group.",
      name = "class",
      typeAdapter = TokenAdapter.class,
      remarks = "A `class` can be used in validation rules to express extra constraints over named items of a specific `class` value.\n"
              + "\n"
              + "A `class` can also be used in an OSCAL profile as a means to target an alteration to control content."
  )
  private String _clazz;

  /**
   * A name to be given to the group for use in display.
   */
  @BoundField(
      formalName = "Group Title",
      description = "A name to be given to the group for use in display.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   */
  @BoundAssembly(
      formalName = "Parameter",
      description = "Parameters provide a mechanism for the dynamic assignment of value(s) in a control.",
      useName = "param",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "params", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Parameter> _params;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   */
  @BoundAssembly(
      formalName = "Part",
      description = "An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.",
      useName = "part",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "parts", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlPart> _parts;

  /**
   * A group of (selected) controls or of groups of controls.
   */
  @BoundAssembly(
      formalName = "Control Group",
      description = "A group of (selected) controls or of groups of controls.",
      useName = "group",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "groups", inJson = JsonGroupAsBehavior.LIST)
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private List<ProfileGroup> _groups;

  /**
   * Specifies which controls to use in the containing context.
   */
  @BoundAssembly(
      formalName = "Insert Controls",
      description = "Specifies which controls to use in the containing context.",
      useName = "insert-controls",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "insert-controls", inJson = JsonGroupAsBehavior.LIST)
  )
  @BoundChoice(
      choiceId = "choice-1"
  )
  private List<InsertControls> _insertControls;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ProfileGroup} instance with no metadata.
   */
  public ProfileGroup() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ProfileGroup} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ProfileGroup(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Group Identifier}".
   *
   * <p>
   * Identifies the group.
   *
   * @return the id value, or {@code null} if not set
   */
  @Nullable
  public String getId() {
    return _id;
  }

  /**
   * Set the "{@literal Group Identifier}".
   *
   * <p>
   * Identifies the group.
   *
   * @param value
   *           the id value to set, or {@code null} to clear
   */
  public void setId(@Nullable String value) {
    _id = value;
  }

  /**
   * Get the "{@literal Group Class}".
   *
   * <p>
   * A textual label that provides a sub-type or characterization of the group.
   *
   * @return the class value, or {@code null} if not set
   */
  @Nullable
  public String getClazz() {
    return _clazz;
  }

  /**
   * Set the "{@literal Group Class}".
   *
   * <p>
   * A textual label that provides a sub-type or characterization of the group.
   *
   * @param value
   *           the class value to set, or {@code null} to clear
   */
  public void setClazz(@Nullable String value) {
    _clazz = value;
  }

  /**
   * Get the "{@literal Group Title}".
   *
   * <p>
   * A name to be given to the group for use in display.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Group Title}".
   *
   * <p>
   * A name to be given to the group for use in display.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Parameter}".
   *
   * <p>
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   *
   * @return the param value
   */
  @NonNull
  public List<Parameter> getParams() {
    if (_params == null) {
      _params = new LinkedList<>();
    }
    return ObjectUtils.notNull(_params);
  }

  /**
   * Set the "{@literal Parameter}".
   *
   * <p>
   * Parameters provide a mechanism for the dynamic assignment of value(s) in a control.
   *
   * @param value
   *           the param value to set
   */
  public void setParams(@NonNull List<Parameter> value) {
    _params = value;
  }

  /**
   * Add a new {@link Parameter} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addParam(Parameter item) {
    Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_params == null) {
      _params = new LinkedList<>();
    }
    return _params.add(value);
  }

  /**
   * Remove the first matching {@link Parameter} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeParam(Parameter item) {
    Parameter value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _params != null && _params.remove(value);
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Part}".
   *
   * <p>
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   *
   * @return the part value
   */
  @NonNull
  public List<ControlPart> getParts() {
    if (_parts == null) {
      _parts = new LinkedList<>();
    }
    return ObjectUtils.notNull(_parts);
  }

  /**
   * Set the "{@literal Part}".
   *
   * <p>
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   *
   * @param value
   *           the part value to set
   */
  public void setParts(@NonNull List<ControlPart> value) {
    _parts = value;
  }

  /**
   * Add a new {@link ControlPart} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addPart(ControlPart item) {
    ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_parts == null) {
      _parts = new LinkedList<>();
    }
    return _parts.add(value);
  }

  /**
   * Remove the first matching {@link ControlPart} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removePart(ControlPart item) {
    ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _parts != null && _parts.remove(value);
  }

  /**
   * Get the "{@literal Control Group}".
   *
   * <p>
   * A group of (selected) controls or of groups of controls.
   *
   * @return the group value
   */
  @NonNull
  public List<ProfileGroup> getGroups() {
    if (_groups == null) {
      _groups = new LinkedList<>();
    }
    return ObjectUtils.notNull(_groups);
  }

  /**
   * Set the "{@literal Control Group}".
   *
   * <p>
   * A group of (selected) controls or of groups of controls.
   *
   * @param value
   *           the group value to set
   */
  public void setGroups(@NonNull List<ProfileGroup> value) {
    _groups = value;
  }

  /**
   * Add a new {@link ProfileGroup} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addGroup(ProfileGroup item) {
    ProfileGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_groups == null) {
      _groups = new LinkedList<>();
    }
    return _groups.add(value);
  }

  /**
   * Remove the first matching {@link ProfileGroup} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeGroup(ProfileGroup item) {
    ProfileGroup value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _groups != null && _groups.remove(value);
  }

  /**
   * Get the "{@literal Insert Controls}".
   *
   * <p>
   * Specifies which controls to use in the containing context.
   *
   * @return the insert-controls value
   */
  @NonNull
  public List<InsertControls> getInsertControls() {
    if (_insertControls == null) {
      _insertControls = new LinkedList<>();
    }
    return ObjectUtils.notNull(_insertControls);
  }

  /**
   * Set the "{@literal Insert Controls}".
   *
   * <p>
   * Specifies which controls to use in the containing context.
   *
   * @param value
   *           the insert-controls value to set
   */
  public void setInsertControls(@NonNull List<InsertControls> value) {
    _insertControls = value;
  }

  /**
   * Add a new {@link InsertControls} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addInsertControls(InsertControls item) {
    InsertControls value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_insertControls == null) {
      _insertControls = new LinkedList<>();
    }
    return _insertControls.add(value);
  }

  /**
   * Remove the first matching {@link InsertControls} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeInsertControls(InsertControls item) {
    InsertControls value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _insertControls != null && _insertControls.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
