// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.Expect;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Matches;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Contains details about all information types that are stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
 */
@MetaschemaAssembly(
    formalName = "System Information",
    description = "Contains details about all information types that are stored, processed, or transmitted by the system, such as privacy information, and those defined in [NIST SP 800-60](https://doi.org/10.6028/NIST.SP.800-60v2r1).",
    name = "system-information",
    moduleClass = OscalSspModule.class,
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-system-information-prop-name-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = @AllowedValue(value = "privacy-designation", description = "Is this a privacy sensitive system? yes or no")), @AllowedValues(id = "oscal-system-information-prop-privacy-designation-values", level = IConstraint.Level.ERROR, target = "prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='privacy-designation']/@value", values = {@AllowedValue(value = "yes", description = "The system is privacy sensitive."), @AllowedValue(value = "no", description = "The system is not privacy sensitive.")}), @AllowedValues(id = "oscal-system-information-link-rel-values", level = IConstraint.Level.ERROR, target = "link/@rel", allowOthers = true, values = @AllowedValue(value = "privacy-impact-assessment", description = "A link to the privacy impact assessment.")), @AllowedValues(id = "oscal-fips-199-impact-levels", level = IConstraint.Level.ERROR, target = "information-type/(confidentiality-impact|integrity-impact|availability-impact)/(base|selected)", allowOthers = true, values = {@AllowedValue(value = "fips-199-low", description = "A 'low' sensitivity level as defined in [FIPS-199](https://doi.org/10.6028/NIST.FIPS.199)."), @AllowedValue(value = "fips-199-moderate", description = "A 'moderate' sensitivity level as defined in [FIPS-199](https://doi.org/10.6028/NIST.FIPS.199)."), @AllowedValue(value = "fips-199-high", description = "A 'high' sensitivity level as defined in [FIPS-199](https://doi.org/10.6028/NIST.FIPS.199).")}, remarks = "FIPS-199 taxonomy is provided here as a starting point. We will provide other taxonomies based on community requests.")}, indexHasKey = @IndexHasKey(id = "oscal-system-information-index-back-matter-resource-pia-link-rel", level = IConstraint.Level.ERROR, target = "link[@rel='privacy-impact-assessment' and starts-with(@href,'#')]", indexName = "index-back-matter-resource", keyFields = @KeyField(target = "@href", pattern = "#(.*)")), matches = {@Matches(id = "oscal-system-information-pia-datatype-uri-reference", level = IConstraint.Level.ERROR, target = "link[@rel='privacy-impact-assessment']/@href[starts-with(.,'#')]", typeAdapter = UriReferenceAdapter.class), @Matches(id = "oscal-system-information-pia-datatype-uri", level = IConstraint.Level.ERROR, target = "link[@rel='privacy-impact-assessment']/@href[not(starts-with(.,'#'))]", typeAdapter = UriAdapter.class)})
)
public class SystemInformation implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Contains details about one information type that is stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
   */
  @BoundAssembly(
      formalName = "Information Type",
      description = "Contains details about one information type that is stored, processed, or transmitted by the system, such as privacy information, and those defined in [NIST SP 800-60](https://doi.org/10.6028/NIST.SP.800-60v2r1).",
      useName = "information-type",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "information-types", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<InformationType> _informationTypes;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemInformation} instance with no metadata.
   */
  public SystemInformation() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemInformation} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public SystemInformation(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Information Type}".
   *
   * <p>
   * Contains details about one information type that is stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
   *
   * @return the information-type value
   */
  @NonNull
  public List<InformationType> getInformationTypes() {
    if (_informationTypes == null) {
      _informationTypes = new LinkedList<>();
    }
    return ObjectUtils.notNull(_informationTypes);
  }

  /**
   * Set the "{@literal Information Type}".
   *
   * <p>
   * Contains details about one information type that is stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
   *
   * @param value
   *           the information-type value to set
   */
  public void setInformationTypes(@NonNull List<InformationType> value) {
    _informationTypes = value;
  }

  /**
   * Add a new {@link InformationType} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addInformationType(InformationType item) {
    InformationType value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_informationTypes == null) {
      _informationTypes = new LinkedList<>();
    }
    return _informationTypes.add(value);
  }

  /**
   * Remove the first matching {@link InformationType} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeInformationType(InformationType item) {
    InformationType value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _informationTypes != null && _informationTypes.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Contains details about one information type that is stored, processed, or transmitted by the system, such as privacy information, and those defined in <a href="https://doi.org/10.6028/NIST.SP.800-60v2r1">NIST SP 800-60</a>.
   */
  @MetaschemaAssembly(
      formalName = "Information Type",
      description = "Contains details about one information type that is stored, processed, or transmitted by the system, such as privacy information, and those defined in [NIST SP 800-60](https://doi.org/10.6028/NIST.SP.800-60v2r1).",
      name = "information-type",
      moduleClass = OscalSspModule.class,
      valueConstraints = @ValueConstraints(expect = @Expect(id = "oscal-information-type-uuid", level = IConstraint.Level.WARNING, test = "@uuid", message = "It is a best practice to provide a UUID."))
  )
  public static class InformationType implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this information type elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>information type</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Information Type Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this information type elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). The locally defined *UUID* of the `information type` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * A human readable name for the information type. This title should be meaningful within the context of the system.
     */
    @BoundField(
        formalName = "title field",
        description = "A human readable name for the information type. This title should be meaningful within the context of the system.",
        useName = "title",
        minOccurs = 1,
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * A summary of how this information type is used within the system.
     */
    @BoundField(
        formalName = "Information Type Description",
        description = "A summary of how this information type is used within the system.",
        useName = "description",
        minOccurs = 1,
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _description;

    /**
     * A set of information type identifiers qualified by the given identification <code>system</code> used, such as NIST SP 800-60.
     */
    @BoundAssembly(
        formalName = "Information Type Categorization",
        description = "A set of information type identifiers qualified by the given identification `system` used, such as NIST SP 800-60.",
        useName = "categorization",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "categorizations", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Categorization> _categorizations;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * The expected level of impact resulting from the unauthorized disclosure of the described information.
     */
    @BoundAssembly(
        formalName = "Confidentiality Impact Level",
        description = "The expected level of impact resulting from the unauthorized disclosure of the described information.",
        useName = "confidentiality-impact"
    )
    private Impact _confidentialityImpact;

    /**
     * The expected level of impact resulting from the unauthorized modification of the described information.
     */
    @BoundAssembly(
        formalName = "Integrity Impact Level",
        description = "The expected level of impact resulting from the unauthorized modification of the described information.",
        useName = "integrity-impact"
    )
    private Impact _integrityImpact;

    /**
     * The expected level of impact resulting from the disruption of access to or use of the described information or the information system.
     */
    @BoundAssembly(
        formalName = "Availability Impact Level",
        description = "The expected level of impact resulting from the disruption of access to or use of the described information or the information system.",
        useName = "availability-impact"
    )
    private Impact _availabilityImpact;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemInformation.InformationType} instance with no metadata.
     */
    public InformationType() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemInformation.InformationType} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public InformationType(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Information Type Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this information type elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>information type</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value, or {@code null} if not set
     */
    @Nullable
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Information Type Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this information type elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>information type</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set, or {@code null} to clear
     */
    public void setUuid(@Nullable UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal title field}".
     *
     * <p>
     * A human readable name for the information type. This title should be meaningful within the context of the system.
     *
     * @return the title value
     */
    @NonNull
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal title field}".
     *
     * <p>
     * A human readable name for the information type. This title should be meaningful within the context of the system.
     *
     * @param value
     *           the title value to set
     */
    public void setTitle(@NonNull MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Information Type Description}".
     *
     * <p>
     * A summary of how this information type is used within the system.
     *
     * @return the description value
     */
    @NonNull
    public MarkupMultiline getDescription() {
      return _description;
    }

    /**
     * Set the "{@literal Information Type Description}".
     *
     * <p>
     * A summary of how this information type is used within the system.
     *
     * @param value
     *           the description value to set
     */
    public void setDescription(@NonNull MarkupMultiline value) {
      _description = value;
    }

    /**
     * Get the "{@literal Information Type Categorization}".
     *
     * <p>
     * A set of information type identifiers qualified by the given identification <code>system</code> used, such as NIST SP 800-60.
     *
     * @return the categorization value
     */
    @NonNull
    public List<Categorization> getCategorizations() {
      if (_categorizations == null) {
        _categorizations = new LinkedList<>();
      }
      return ObjectUtils.notNull(_categorizations);
    }

    /**
     * Set the "{@literal Information Type Categorization}".
     *
     * <p>
     * A set of information type identifiers qualified by the given identification <code>system</code> used, such as NIST SP 800-60.
     *
     * @param value
     *           the categorization value to set
     */
    public void setCategorizations(@NonNull List<Categorization> value) {
      _categorizations = value;
    }

    /**
     * Add a new {@link Categorization} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addCategorization(Categorization item) {
      Categorization value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_categorizations == null) {
        _categorizations = new LinkedList<>();
      }
      return _categorizations.add(value);
    }

    /**
     * Remove the first matching {@link Categorization} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeCategorization(Categorization item) {
      Categorization value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _categorizations != null && _categorizations.remove(value);
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Confidentiality Impact Level}".
     *
     * <p>
     * The expected level of impact resulting from the unauthorized disclosure of the described information.
     *
     * @return the confidentiality-impact value, or {@code null} if not set
     */
    @Nullable
    public Impact getConfidentialityImpact() {
      return _confidentialityImpact;
    }

    /**
     * Set the "{@literal Confidentiality Impact Level}".
     *
     * <p>
     * The expected level of impact resulting from the unauthorized disclosure of the described information.
     *
     * @param value
     *           the confidentiality-impact value to set, or {@code null} to clear
     */
    public void setConfidentialityImpact(@Nullable Impact value) {
      _confidentialityImpact = value;
    }

    /**
     * Get the "{@literal Integrity Impact Level}".
     *
     * <p>
     * The expected level of impact resulting from the unauthorized modification of the described information.
     *
     * @return the integrity-impact value, or {@code null} if not set
     */
    @Nullable
    public Impact getIntegrityImpact() {
      return _integrityImpact;
    }

    /**
     * Set the "{@literal Integrity Impact Level}".
     *
     * <p>
     * The expected level of impact resulting from the unauthorized modification of the described information.
     *
     * @param value
     *           the integrity-impact value to set, or {@code null} to clear
     */
    public void setIntegrityImpact(@Nullable Impact value) {
      _integrityImpact = value;
    }

    /**
     * Get the "{@literal Availability Impact Level}".
     *
     * <p>
     * The expected level of impact resulting from the disruption of access to or use of the described information or the information system.
     *
     * @return the availability-impact value, or {@code null} if not set
     */
    @Nullable
    public Impact getAvailabilityImpact() {
      return _availabilityImpact;
    }

    /**
     * Set the "{@literal Availability Impact Level}".
     *
     * <p>
     * The expected level of impact resulting from the disruption of access to or use of the described information or the information system.
     *
     * @param value
     *           the availability-impact value to set, or {@code null} to clear
     */
    public void setAvailabilityImpact(@Nullable Impact value) {
      _availabilityImpact = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * A set of information type identifiers qualified by the given identification <code>system</code> used, such as NIST SP 800-60.
     */
    @MetaschemaAssembly(
        formalName = "Information Type Categorization",
        description = "A set of information type identifiers qualified by the given identification `system` used, such as NIST SP 800-60.",
        name = "categorization",
        moduleClass = OscalSspModule.class
    )
    public static class Categorization implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * Specifies the information type identification system used.
       */
      @BoundFlag(
          formalName = "Information Type Identification System",
          description = "Specifies the information type identification system used.",
          name = "system",
          required = true,
          typeAdapter = UriAdapter.class,
          remarks = "This value must be an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that serves as a [naming system identifier](https://pages.nist.gov/OSCAL/concepts/uri-use/#use-as-a-naming-system-identifier).",
          valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-information-type-categorization-system-values", level = IConstraint.Level.ERROR, allowOthers = true, values = @AllowedValue(value = "http://doi.org/10.6028/NIST.SP.800-60v2r1", description = "Based on the section identifiers in NIST [Special Publication 800-60 Volume II Revision 1](https://doi.org/10.6028/NIST.SP.800-60v2r1).")))
      )
      private URI _system;

      /**
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier qualified by the given identification <code>system</code> used, such as NIST SP 800-60. This identifier has <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope and can be used to reference this system elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. This id should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       */
      @BoundField(
          formalName = "Information Type Systematized Identifier",
          description = "A [human-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier qualified by the given identification `system` used, such as NIST SP 800-60. This identifier has [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope and can be used to reference this system elsewhere in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers). This id should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
          useName = "information-type-id",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "information-type-ids", inJson = JsonGroupAsBehavior.LIST),
          typeAdapter = StringAdapter.class
      )
      private List<String> _informationTypeIds;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemInformation.InformationType.Categorization} instance with no metadata.
       */
      public Categorization() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.SystemInformation.InformationType.Categorization} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public Categorization(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Information Type Identification System}".
       *
       * <p>
       * Specifies the information type identification system used.
       *
       * @return the system value
       */
      @NonNull
      public URI getSystem() {
        return _system;
      }

      /**
       * Set the "{@literal Information Type Identification System}".
       *
       * <p>
       * Specifies the information type identification system used.
       *
       * @param value
       *           the system value to set
       */
      public void setSystem(@NonNull URI value) {
        _system = value;
      }

      /**
       * Get the "{@literal Information Type Systematized Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier qualified by the given identification <code>system</code> used, such as NIST SP 800-60. This identifier has <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope and can be used to reference this system elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. This id should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @return the information-type-id value
       */
      @NonNull
      public List<String> getInformationTypeIds() {
        if (_informationTypeIds == null) {
          _informationTypeIds = new LinkedList<>();
        }
        return ObjectUtils.notNull(_informationTypeIds);
      }

      /**
       * Set the "{@literal Information Type Systematized Identifier}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#human-oriented">human-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier qualified by the given identification <code>system</code> used, such as NIST SP 800-60. This identifier has <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope and can be used to reference this system elsewhere in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ssp-identifiers">this or other OSCAL instances</a>. This id should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
       *
       * @param value
       *           the information-type-id value to set
       */
      public void setInformationTypeIds(@NonNull List<String> value) {
        _informationTypeIds = value;
      }

      /**
       * Add a new {@link String} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addInformationTypeId(String item) {
        String value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_informationTypeIds == null) {
          _informationTypeIds = new LinkedList<>();
        }
        return _informationTypeIds.add(value);
      }

      /**
       * Remove the first matching {@link String} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeInformationTypeId(String item) {
        String value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _informationTypeIds != null && _informationTypeIds.remove(value);
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }
}
