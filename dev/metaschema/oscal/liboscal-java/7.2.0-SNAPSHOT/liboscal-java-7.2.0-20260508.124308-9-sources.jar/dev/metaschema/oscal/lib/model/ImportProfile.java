// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_ssp_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UriReferenceAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Used to import the OSCAL profile representing the system's control baseline.
 */
@MetaschemaAssembly(
    formalName = "Import Profile",
    description = "Used to import the OSCAL profile representing the system's control baseline.",
    name = "import-profile",
    moduleClass = OscalSspModule.class
)
public class ImportProfile implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A resolvable URL reference to the profile or catalog to use as the system's control baseline.
   */
  @BoundFlag(
      formalName = "Profile Reference",
      description = "A resolvable URL reference to the profile or catalog to use as the system's control baseline.",
      name = "href",
      required = true,
      typeAdapter = UriReferenceAdapter.class,
      remarks = "This value may be one of:\n"
              + "\n"
              + "1. an [absolute URI](https://pages.nist.gov/OSCAL/concepts/uri-use/#absolute-uri) that points to a network resolvable resource,\n"
              + "2. a [relative reference](https://pages.nist.gov/OSCAL/concepts/uri-use/#relative-reference) pointing to a network resolvable resource whose base URI is the URI of the containing document, or\n"
              + "3. a bare URI fragment (i.e., \\`#uuid\\`) pointing to a `back-matter` resource in this or an imported document (see [linking to another OSCAL object](https://pages.nist.gov/OSCAL/concepts/uri-use/#linking-to-another-oscal-object)).\n"
              + "\n"
              + "If the resource is an OSCAL profile, it is expected that a tool will resolve the profile according to the OSCAL [profile resolution specification](https://pages.nist.gov/OSCAL/concepts/processing/profile-resolution/) to produce a resolved profile for use when processing the containing system security plan. This allows a system security plan processor to use the baseline as a catalog of controls.\n"
              + "\n"
              + "While it is possible to reference a previously resolved OSCAL profile as a catalog, this practice is discouraged since the unresolved form of the profile communicates more information about selections and changes to the underlying catalog. Furthermore, the underlying catalog can be maintained separately from the profile, which also has maintenance advantages for distinct maintainers, ensuring that the best available information is produced through profile resolution."
  )
  private URI _href;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImportProfile} instance with no metadata.
   */
  public ImportProfile() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ImportProfile} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ImportProfile(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Profile Reference}".
   *
   * <p>
   * A resolvable URL reference to the profile or catalog to use as the system's control baseline.
   *
   * @return the href value
   */
  @NonNull
  public URI getHref() {
    return _href;
  }

  /**
   * Set the "{@literal Profile Reference}".
   *
   * <p>
   * A resolvable URL reference to the profile or catalog to use as the system's control baseline.
   *
   * @param value
   *           the href value to set
   */
  public void setHref(@NonNull URI value) {
    _href = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
