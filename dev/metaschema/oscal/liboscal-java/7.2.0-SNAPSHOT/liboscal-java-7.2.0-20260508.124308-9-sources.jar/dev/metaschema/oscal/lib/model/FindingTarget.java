// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Captures an assessor's conclusions regarding the degree to which an objective is satisfied.
 */
@MetaschemaAssembly(
    formalName = "Objective Status",
    description = "Captures an assessor's conclusions regarding the degree to which an objective is satisfied.",
    name = "finding-target",
    moduleClass = OscalAssessmentCommonModule.class
)
public class FindingTarget implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Identifies the type of the target.
   */
  @BoundFlag(
      formalName = "Finding Target Type",
      description = "Identifies the type of the target.",
      name = "type",
      required = true,
      typeAdapter = StringAdapter.class,
      remarks = "The target will always be a reference to: 1) a control statement, or 2) a control objective. In the former case, there is always a single top-level statement within a control. Thus, if the entire control is targeted, this statement identifier can be used.",
      valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-finding-target-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "statement-id", description = "A reference to a control statement identifier within a control."), @AllowedValue(value = "objective-id", description = "A reference to a control objective identifier within a control.")}))
  )
  private String _type;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference for a specific target qualified by the <code>type</code>.
   */
  @BoundFlag(
      formalName = "Finding Target Identifier Reference",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference for a specific target qualified by the `type`.",
      name = "target-id",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _targetId;

  /**
   * The title for this objective status.
   */
  @BoundField(
      formalName = "Objective Status Title",
      description = "The title for this objective status.",
      useName = "title",
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of the assessor's conclusions regarding the degree to which an objective is satisfied.
   */
  @BoundField(
      formalName = "Objective Status Description",
      description = "A human-readable description of the assessor's conclusions regarding the degree to which an objective is satisfied.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * A determination of if the objective is satisfied or not within a given system.
   */
  @BoundAssembly(
      formalName = "Objective Status",
      description = "A determination of if the objective is satisfied or not within a given system.",
      useName = "status",
      minOccurs = 1
  )
  private Status _status;

  /**
   * Indicates the degree to which the a given control is implemented.
   */
  @BoundAssembly(
      formalName = "Implementation Status",
      description = "Indicates the degree to which the a given control is implemented.",
      useName = "implementation-status",
      remarks = "The `implementation-status` is used to qualify the `status` value to indicate the degree to which the control was found to be implemented."
  )
  private ImplementationStatus _implementationStatus;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.FindingTarget} instance with no metadata.
   */
  public FindingTarget() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.FindingTarget} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public FindingTarget(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Finding Target Type}".
   *
   * <p>
   * Identifies the type of the target.
   *
   * @return the type value
   */
  @NonNull
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Finding Target Type}".
   *
   * <p>
   * Identifies the type of the target.
   *
   * @param value
   *           the type value to set
   */
  public void setType(@NonNull String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Finding Target Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference for a specific target qualified by the <code>type</code>.
   *
   * @return the target-id value
   */
  @NonNull
  public String getTargetId() {
    return _targetId;
  }

  /**
   * Set the "{@literal Finding Target Identifier Reference}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference for a specific target qualified by the <code>type</code>.
   *
   * @param value
   *           the target-id value to set
   */
  public void setTargetId(@NonNull String value) {
    _targetId = value;
  }

  /**
   * Get the "{@literal Objective Status Title}".
   *
   * <p>
   * The title for this objective status.
   *
   * @return the title value, or {@code null} if not set
   */
  @Nullable
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Objective Status Title}".
   *
   * <p>
   * The title for this objective status.
   *
   * @param value
   *           the title value to set, or {@code null} to clear
   */
  public void setTitle(@Nullable MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Objective Status Description}".
   *
   * <p>
   * A human-readable description of the assessor's conclusions regarding the degree to which an objective is satisfied.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Objective Status Description}".
   *
   * <p>
   * A human-readable description of the assessor's conclusions regarding the degree to which an objective is satisfied.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Objective Status}".
   *
   * <p>
   * A determination of if the objective is satisfied or not within a given system.
   *
   * @return the status value
   */
  @NonNull
  public Status getStatus() {
    return _status;
  }

  /**
   * Set the "{@literal Objective Status}".
   *
   * <p>
   * A determination of if the objective is satisfied or not within a given system.
   *
   * @param value
   *           the status value to set
   */
  public void setStatus(@NonNull Status value) {
    _status = value;
  }

  /**
   * Get the "{@literal Implementation Status}".
   *
   * <p>
   * Indicates the degree to which the a given control is implemented.
   *
   * @return the implementation-status value, or {@code null} if not set
   */
  @Nullable
  public ImplementationStatus getImplementationStatus() {
    return _implementationStatus;
  }

  /**
   * Set the "{@literal Implementation Status}".
   *
   * <p>
   * Indicates the degree to which the a given control is implemented.
   *
   * @param value
   *           the implementation-status value to set, or {@code null} to clear
   */
  public void setImplementationStatus(@Nullable ImplementationStatus value) {
    _implementationStatus = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * A determination of if the objective is satisfied or not within a given system.
   */
  @MetaschemaAssembly(
      formalName = "Objective Status",
      description = "A determination of if the objective is satisfied or not within a given system.",
      name = "status",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class Status implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * An indication as to whether the objective is satisfied or not.
     */
    @BoundFlag(
        formalName = "Objective Status State",
        description = "An indication as to whether the objective is satisfied or not.",
        name = "state",
        required = true,
        typeAdapter = TokenAdapter.class,
        valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-finding-target-status-state-values", level = IConstraint.Level.ERROR, values = {@AllowedValue(value = "satisfied", description = "The objective has been completely satisfied."), @AllowedValue(value = "not-satisfied", description = "The objective has not been completely satisfied, but may be partially satisfied.")}))
    )
    private String _state;

    /**
     * The reason the objective was given it's status.
     */
    @BoundFlag(
        formalName = "Objective Status Reason",
        description = "The reason the objective was given it's status.",
        name = "reason",
        typeAdapter = TokenAdapter.class,
        remarks = "Reason may contain any value, and should be used to communicate additional information regarding the status.",
        valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-finding-target-reason-values", level = IConstraint.Level.ERROR, allowOthers = true, values = {@AllowedValue(value = "pass", description = "The target system or system component satisfied all the conditions."), @AllowedValue(value = "fail", description = "The target system or system component did not satisfy all the conditions."), @AllowedValue(value = "other", description = "Some other event took place that is not a pass or a fail.")}))
    )
    private String _reason;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.FindingTarget.Status} instance with no metadata.
     */
    public Status() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.FindingTarget.Status} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public Status(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Objective Status State}".
     *
     * <p>
     * An indication as to whether the objective is satisfied or not.
     *
     * @return the state value
     */
    @NonNull
    public String getState() {
      return _state;
    }

    /**
     * Set the "{@literal Objective Status State}".
     *
     * <p>
     * An indication as to whether the objective is satisfied or not.
     *
     * @param value
     *           the state value to set
     */
    public void setState(@NonNull String value) {
      _state = value;
    }

    /**
     * Get the "{@literal Objective Status Reason}".
     *
     * <p>
     * The reason the objective was given it's status.
     *
     * @return the reason value, or {@code null} if not set
     */
    @Nullable
    public String getReason() {
      return _reason;
    }

    /**
     * Set the "{@literal Objective Status Reason}".
     *
     * <p>
     * The reason the objective was given it's status.
     *
     * @param value
     *           the reason value to set, or {@code null} to clear
     */
    public void setReason(@Nullable String value) {
      _reason = value;
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }
  }
}
