// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Describes an individual finding.
 */
@MetaschemaAssembly(
    formalName = "Finding",
    description = "Describes an individual finding.",
    name = "finding",
    moduleClass = OscalAssessmentCommonModule.class
)
public class Finding implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this finding in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>finding</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   */
  @BoundFlag(
      formalName = "Finding Universally Unique Identifier",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this finding in [this or other OSCAL instances](https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers). The locally defined *UUID* of the `finding` can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The title for this finding.
   */
  @BoundField(
      formalName = "Finding Title",
      description = "The title for this finding.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A human-readable description of this finding.
   */
  @BoundField(
      formalName = "Finding Description",
      description = "A human-readable description of this finding.",
      useName = "description",
      minOccurs = 1,
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   */
  @BoundAssembly(
      formalName = "Origin",
      description = "Identifies the source of the finding, such as a tool, interviewed person, or activity.",
      useName = "origin",
      remarks = "Used to identify the individual and/or tool generated this finding.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "origins", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Origin> _origins;

  /**
   * Captures an assessor's conclusions regarding the degree to which an objective is satisfied.
   */
  @BoundAssembly(
      formalName = "Objective Status",
      description = "Captures an assessor's conclusions regarding the degree to which an objective is satisfied.",
      useName = "target",
      minOccurs = 1
  )
  private FindingTarget _target;

  /**
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the implementation statement in the SSP to which this finding is related.
   */
  @BoundField(
      formalName = "Implementation Statement UUID",
      description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to the implementation statement in the SSP to which this finding is related.",
      useName = "implementation-statement-uuid",
      typeAdapter = UuidAdapter.class
  )
  private UUID _implementationStatementUuid;

  /**
   * Relates the identified element to a set of referenced observations that were used to support its determination.
   */
  @BoundAssembly(
      formalName = "Related Observation",
      description = "Relates the identified element to a set of referenced observations that were used to support its determination.",
      useName = "related-observation",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "related-observations", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<RelatedObservation> _relatedObservations;

  /**
   * Relates the finding to a set of referenced risks that were used to determine the finding.
   */
  @BoundAssembly(
      formalName = "Associated Risk",
      description = "Relates the finding to a set of referenced risks that were used to determine the finding.",
      useName = "associated-risk",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "related-risks", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AssociatedRisk> _relatedRisks;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Finding} instance with no metadata.
   */
  public Finding() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Finding} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Finding(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Finding Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this finding in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>finding</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Finding Universally Unique Identifier}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this finding in <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#ar-identifiers">this or other OSCAL instances</a>. The locally defined <em>UUID</em> of the <code>finding</code> can be used to reference the data item locally or globally (e.g., in an imported OSCAL instance). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Finding Title}".
   *
   * <p>
   * The title for this finding.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Finding Title}".
   *
   * <p>
   * The title for this finding.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Finding Description}".
   *
   * <p>
   * A human-readable description of this finding.
   *
   * @return the description value
   */
  @NonNull
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Finding Description}".
   *
   * <p>
   * A human-readable description of this finding.
   *
   * @param value
   *           the description value to set
   */
  public void setDescription(@NonNull MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @return the origin value
   */
  @NonNull
  public List<Origin> getOrigins() {
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return ObjectUtils.notNull(_origins);
  }

  /**
   * Set the "{@literal Origin}".
   *
   * <p>
   * Identifies the source of the finding, such as a tool, interviewed person, or activity.
   *
   * @param value
   *           the origin value to set
   */
  public void setOrigins(@NonNull List<Origin> value) {
    _origins = value;
  }

  /**
   * Add a new {@link Origin} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_origins == null) {
      _origins = new LinkedList<>();
    }
    return _origins.add(value);
  }

  /**
   * Remove the first matching {@link Origin} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeOrigin(Origin item) {
    Origin value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _origins != null && _origins.remove(value);
  }

  /**
   * Get the "{@literal Objective Status}".
   *
   * <p>
   * Captures an assessor's conclusions regarding the degree to which an objective is satisfied.
   *
   * @return the target value
   */
  @NonNull
  public FindingTarget getTarget() {
    return _target;
  }

  /**
   * Set the "{@literal Objective Status}".
   *
   * <p>
   * Captures an assessor's conclusions regarding the degree to which an objective is satisfied.
   *
   * @param value
   *           the target value to set
   */
  public void setTarget(@NonNull FindingTarget value) {
    _target = value;
  }

  /**
   * Get the "{@literal Implementation Statement UUID}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the implementation statement in the SSP to which this finding is related.
   *
   * @return the implementation-statement-uuid value, or {@code null} if not set
   */
  @Nullable
  public UUID getImplementationStatementUuid() {
    return _implementationStatementUuid;
  }

  /**
   * Set the "{@literal Implementation Statement UUID}".
   *
   * <p>
   * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to the implementation statement in the SSP to which this finding is related.
   *
   * @param value
   *           the implementation-statement-uuid value to set, or {@code null} to clear
   */
  public void setImplementationStatementUuid(@Nullable UUID value) {
    _implementationStatementUuid = value;
  }

  /**
   * Get the "{@literal Related Observation}".
   *
   * <p>
   * Relates the identified element to a set of referenced observations that were used to support its determination.
   *
   * @return the related-observation value
   */
  @NonNull
  public List<RelatedObservation> getRelatedObservations() {
    if (_relatedObservations == null) {
      _relatedObservations = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedObservations);
  }

  /**
   * Set the "{@literal Related Observation}".
   *
   * <p>
   * Relates the identified element to a set of referenced observations that were used to support its determination.
   *
   * @param value
   *           the related-observation value to set
   */
  public void setRelatedObservations(@NonNull List<RelatedObservation> value) {
    _relatedObservations = value;
  }

  /**
   * Add a new {@link RelatedObservation} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addRelatedObservation(RelatedObservation item) {
    RelatedObservation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedObservations == null) {
      _relatedObservations = new LinkedList<>();
    }
    return _relatedObservations.add(value);
  }

  /**
   * Remove the first matching {@link RelatedObservation} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeRelatedObservation(RelatedObservation item) {
    RelatedObservation value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedObservations != null && _relatedObservations.remove(value);
  }

  /**
   * Get the "{@literal Associated Risk}".
   *
   * <p>
   * Relates the finding to a set of referenced risks that were used to determine the finding.
   *
   * @return the associated-risk value
   */
  @NonNull
  public List<AssociatedRisk> getRelatedRisks() {
    if (_relatedRisks == null) {
      _relatedRisks = new LinkedList<>();
    }
    return ObjectUtils.notNull(_relatedRisks);
  }

  /**
   * Set the "{@literal Associated Risk}".
   *
   * <p>
   * Relates the finding to a set of referenced risks that were used to determine the finding.
   *
   * @param value
   *           the associated-risk value to set
   */
  public void setRelatedRisks(@NonNull List<AssociatedRisk> value) {
    _relatedRisks = value;
  }

  /**
   * Add a new {@link AssociatedRisk} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAssociatedRisk(AssociatedRisk item) {
    AssociatedRisk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_relatedRisks == null) {
      _relatedRisks = new LinkedList<>();
    }
    return _relatedRisks.add(value);
  }

  /**
   * Remove the first matching {@link AssociatedRisk} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAssociatedRisk(AssociatedRisk item) {
    AssociatedRisk value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _relatedRisks != null && _relatedRisks.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
