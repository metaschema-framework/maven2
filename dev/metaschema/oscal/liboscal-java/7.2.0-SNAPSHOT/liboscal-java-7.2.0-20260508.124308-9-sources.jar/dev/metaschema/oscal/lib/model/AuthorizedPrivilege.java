// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_implementation-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.StringAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies a specific system privilege held by the user, along with an associated description and/or rationale for the privilege.
 */
@MetaschemaAssembly(
    formalName = "Privilege",
    description = "Identifies a specific system privilege held by the user, along with an associated description and/or rationale for the privilege.",
    name = "authorized-privilege",
    moduleClass = OscalImplementationCommonModule.class
)
public class AuthorizedPrivilege implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A human readable name for the privilege.
   */
  @BoundField(
      formalName = "Privilege Title",
      description = "A human readable name for the privilege.",
      useName = "title",
      minOccurs = 1,
      typeAdapter = MarkupLineAdapter.class
  )
  private MarkupLine _title;

  /**
   * A summary of the privilege's purpose within the system.
   */
  @BoundField(
      formalName = "Privilege Description",
      description = "A summary of the privilege's purpose within the system.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * Describes a function performed for a given authorized privilege by this user class.
   */
  @BoundField(
      formalName = "Functions Performed",
      description = "Describes a function performed for a given authorized privilege by this user class.",
      useName = "function-performed",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "functions-performed", inJson = JsonGroupAsBehavior.LIST),
      typeAdapter = StringAdapter.class
  )
  private List<String> _functionsPerformed;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AuthorizedPrivilege} instance with no metadata.
   */
  public AuthorizedPrivilege() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AuthorizedPrivilege} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public AuthorizedPrivilege(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Privilege Title}".
   *
   * <p>
   * A human readable name for the privilege.
   *
   * @return the title value
   */
  @NonNull
  public MarkupLine getTitle() {
    return _title;
  }

  /**
   * Set the "{@literal Privilege Title}".
   *
   * <p>
   * A human readable name for the privilege.
   *
   * @param value
   *           the title value to set
   */
  public void setTitle(@NonNull MarkupLine value) {
    _title = value;
  }

  /**
   * Get the "{@literal Privilege Description}".
   *
   * <p>
   * A summary of the privilege's purpose within the system.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Privilege Description}".
   *
   * <p>
   * A summary of the privilege's purpose within the system.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Functions Performed}".
   *
   * <p>
   * Describes a function performed for a given authorized privilege by this user class.
   *
   * @return the function-performed value
   */
  @NonNull
  public List<String> getFunctionsPerformed() {
    if (_functionsPerformed == null) {
      _functionsPerformed = new LinkedList<>();
    }
    return ObjectUtils.notNull(_functionsPerformed);
  }

  /**
   * Set the "{@literal Functions Performed}".
   *
   * <p>
   * Describes a function performed for a given authorized privilege by this user class.
   *
   * @param value
   *           the function-performed value to set
   */
  public void setFunctionsPerformed(@NonNull List<String> value) {
    _functionsPerformed = value;
  }

  /**
   * Add a new {@link String} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addFunctionPerformed(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_functionsPerformed == null) {
      _functionsPerformed = new LinkedList<>();
    }
    return _functionsPerformed.add(value);
  }

  /**
   * Remove the first matching {@link String} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeFunctionPerformed(String item) {
    String value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _functionsPerformed != null && _functionsPerformed.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
