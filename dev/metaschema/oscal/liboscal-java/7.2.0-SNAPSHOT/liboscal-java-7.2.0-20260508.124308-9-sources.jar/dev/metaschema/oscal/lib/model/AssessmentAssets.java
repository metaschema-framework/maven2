// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupLineAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
 */
@MetaschemaAssembly(
    formalName = "Assessment Assets",
    description = "Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.",
    name = "assessment-assets",
    moduleClass = OscalAssessmentCommonModule.class,
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-ssp-assessment-assets-component", level = IConstraint.Level.ERROR, target = "component", keyFields = @KeyField(target = "@uuid"), remarks = "Since multiple assessment `component` entries can be provided, each component must have a unique `uuid`."))
)
public class AssessmentAssets implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A defined component that can be part of an implemented system.
   */
  @BoundAssembly(
      formalName = "Component",
      description = "A defined component that can be part of an implemented system.",
      useName = "component",
      remarks = "Used to add any components for tools used during the assessment. These are represented here to avoid mixing with system components.\n"
              + "\n"
              + "The technology tools used by the assessor to perform the assessment, such as vulnerability scanners. In the assessment plan these are the intended tools. In the assessment results, these are the actual tools used, including any differences from the assessment plan.",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "components", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SystemComponent> _components;

  /**
   * Used to represent the toolset used to perform aspects of the assessment.
   */
  @BoundAssembly(
      formalName = "Assessment Platform",
      description = "Used to represent the toolset used to perform aspects of the assessment.",
      useName = "assessment-platform",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "assessment-platforms", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<AssessmentPlatform> _assessmentPlatforms;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentAssets} instance with no metadata.
   */
  public AssessmentAssets() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentAssets} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public AssessmentAssets(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @return the component value
   */
  @NonNull
  public List<SystemComponent> getComponents() {
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return ObjectUtils.notNull(_components);
  }

  /**
   * Set the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @param value
   *           the component value to set
   */
  public void setComponents(@NonNull List<SystemComponent> value) {
    _components = value;
  }

  /**
   * Add a new {@link SystemComponent} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addComponent(SystemComponent item) {
    SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return _components.add(value);
  }

  /**
   * Remove the first matching {@link SystemComponent} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeComponent(SystemComponent item) {
    SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _components != null && _components.remove(value);
  }

  /**
   * Get the "{@literal Assessment Platform}".
   *
   * <p>
   * Used to represent the toolset used to perform aspects of the assessment.
   *
   * @return the assessment-platform value
   */
  @NonNull
  public List<AssessmentPlatform> getAssessmentPlatforms() {
    if (_assessmentPlatforms == null) {
      _assessmentPlatforms = new LinkedList<>();
    }
    return ObjectUtils.notNull(_assessmentPlatforms);
  }

  /**
   * Set the "{@literal Assessment Platform}".
   *
   * <p>
   * Used to represent the toolset used to perform aspects of the assessment.
   *
   * @param value
   *           the assessment-platform value to set
   */
  public void setAssessmentPlatforms(@NonNull List<AssessmentPlatform> value) {
    _assessmentPlatforms = value;
  }

  /**
   * Add a new {@link AssessmentPlatform} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addAssessmentPlatform(AssessmentPlatform item) {
    AssessmentPlatform value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_assessmentPlatforms == null) {
      _assessmentPlatforms = new LinkedList<>();
    }
    return _assessmentPlatforms.add(value);
  }

  /**
   * Remove the first matching {@link AssessmentPlatform} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeAssessmentPlatform(AssessmentPlatform item) {
    AssessmentPlatform value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _assessmentPlatforms != null && _assessmentPlatforms.remove(value);
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }

  /**
   * Used to represent the toolset used to perform aspects of the assessment.
   */
  @MetaschemaAssembly(
      formalName = "Assessment Platform",
      description = "Used to represent the toolset used to perform aspects of the assessment.",
      name = "assessment-platform",
      moduleClass = OscalAssessmentCommonModule.class
  )
  public static class AssessmentPlatform implements IBoundObject {
    private final IMetaschemaData __metaschemaData;

    /**
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment platform elsewhere in this or other OSCAL instances. The locally defined <em>UUID</em> of the <code>assessment platform</code> can be used to reference the data item locally or globally (e.g., in an <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">imported OSCAL instance</a>). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     */
    @BoundFlag(
        formalName = "Assessment Platform Universally Unique Identifier",
        description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented), [globally unique](https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique) identifier with [cross-instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance) scope that can be used to reference this assessment platform elsewhere in this or other OSCAL instances. The locally defined *UUID* of the `assessment platform` can be used to reference the data item locally or globally (e.g., in an [imported OSCAL instance](https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope)). This UUID should be assigned [per-subject](https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency), which means it should be consistently used to identify the same subject across revisions of the document.",
        name = "uuid",
        required = true,
        typeAdapter = UuidAdapter.class
    )
    private UUID _uuid;

    /**
     * The title or name for the assessment platform.
     */
    @BoundField(
        formalName = "Assessment Platform Title",
        description = "The title or name for the assessment platform.",
        useName = "title",
        typeAdapter = MarkupLineAdapter.class
    )
    private MarkupLine _title;

    /**
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     */
    @BoundAssembly(
        formalName = "Property",
        description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
        useName = "prop",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Property> _props;

    /**
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     */
    @BoundAssembly(
        formalName = "Link",
        description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
        useName = "link",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<Link> _links;

    /**
     * The set of components that are used by the assessment platform.
     */
    @BoundAssembly(
        formalName = "Uses Component",
        description = "The set of components that are used by the assessment platform.",
        useName = "uses-component",
        maxOccurs = -1,
        groupAs = @GroupAs(name = "uses-components", inJson = JsonGroupAsBehavior.LIST)
    )
    private List<UsesComponent> _usesComponents;

    /**
     * Additional commentary about the containing object.
     */
    @BoundField(
        formalName = "Remarks",
        description = "Additional commentary about the containing object.",
        useName = "remarks",
        typeAdapter = MarkupMultilineAdapter.class
    )
    private MarkupMultiline _remarks;

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentAssets.AssessmentPlatform} instance with no metadata.
     */
    public AssessmentPlatform() {
      this(null);
    }

    /**
     * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentAssets.AssessmentPlatform} instance with the specified metadata.
     *
     * @param data
     *           the metaschema data, or {@code null} if none
     */
    public AssessmentPlatform(IMetaschemaData data) {
      this.__metaschemaData = data;
    }

    @Override
    public IMetaschemaData getMetaschemaData() {
      return __metaschemaData;
    }

    /**
     * Get the "{@literal Assessment Platform Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment platform elsewhere in this or other OSCAL instances. The locally defined <em>UUID</em> of the <code>assessment platform</code> can be used to reference the data item locally or globally (e.g., in an <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">imported OSCAL instance</a>). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @return the uuid value
     */
    @NonNull
    public UUID getUuid() {
      return _uuid;
    }

    /**
     * Set the "{@literal Assessment Platform Universally Unique Identifier}".
     *
     * <p>
     * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a>, <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#globally-unique">globally unique</a> identifier with <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#cross-instance">cross-instance</a> scope that can be used to reference this assessment platform elsewhere in this or other OSCAL instances. The locally defined <em>UUID</em> of the <code>assessment platform</code> can be used to reference the data item locally or globally (e.g., in an <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#scope">imported OSCAL instance</a>). This UUID should be assigned <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#consistency">per-subject</a>, which means it should be consistently used to identify the same subject across revisions of the document.
     *
     * @param value
     *           the uuid value to set
     */
    public void setUuid(@NonNull UUID value) {
      _uuid = value;
    }

    /**
     * Get the "{@literal Assessment Platform Title}".
     *
     * <p>
     * The title or name for the assessment platform.
     *
     * @return the title value, or {@code null} if not set
     */
    @Nullable
    public MarkupLine getTitle() {
      return _title;
    }

    /**
     * Set the "{@literal Assessment Platform Title}".
     *
     * <p>
     * The title or name for the assessment platform.
     *
     * @param value
     *           the title value to set, or {@code null} to clear
     */
    public void setTitle(@Nullable MarkupLine value) {
      _title = value;
    }

    /**
     * Get the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @return the prop value
     */
    @NonNull
    public List<Property> getProps() {
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return ObjectUtils.notNull(_props);
    }

    /**
     * Set the "{@literal Property}".
     *
     * <p>
     * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
     *
     * @param value
     *           the prop value to set
     */
    public void setProps(@NonNull List<Property> value) {
      _props = value;
    }

    /**
     * Add a new {@link Property} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_props == null) {
        _props = new LinkedList<>();
      }
      return _props.add(value);
    }

    /**
     * Remove the first matching {@link Property} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeProp(Property item) {
      Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _props != null && _props.remove(value);
    }

    /**
     * Get the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @return the link value
     */
    @NonNull
    public List<Link> getLinks() {
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return ObjectUtils.notNull(_links);
    }

    /**
     * Set the "{@literal Link}".
     *
     * <p>
     * A reference to a local or remote resource, that has a specific relation to the containing object.
     *
     * @param value
     *           the link value to set
     */
    public void setLinks(@NonNull List<Link> value) {
      _links = value;
    }

    /**
     * Add a new {@link Link} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_links == null) {
        _links = new LinkedList<>();
      }
      return _links.add(value);
    }

    /**
     * Remove the first matching {@link Link} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeLink(Link item) {
      Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _links != null && _links.remove(value);
    }

    /**
     * Get the "{@literal Uses Component}".
     *
     * <p>
     * The set of components that are used by the assessment platform.
     *
     * @return the uses-component value
     */
    @NonNull
    public List<UsesComponent> getUsesComponents() {
      if (_usesComponents == null) {
        _usesComponents = new LinkedList<>();
      }
      return ObjectUtils.notNull(_usesComponents);
    }

    /**
     * Set the "{@literal Uses Component}".
     *
     * <p>
     * The set of components that are used by the assessment platform.
     *
     * @param value
     *           the uses-component value to set
     */
    public void setUsesComponents(@NonNull List<UsesComponent> value) {
      _usesComponents = value;
    }

    /**
     * Add a new {@link UsesComponent} item to the underlying collection.
     * @param item the item to add
     * @return {@code true}
     */
    public boolean addUsesComponent(UsesComponent item) {
      UsesComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
      if (_usesComponents == null) {
        _usesComponents = new LinkedList<>();
      }
      return _usesComponents.add(value);
    }

    /**
     * Remove the first matching {@link UsesComponent} item from the underlying collection.
     * @param item the item to remove
     * @return {@code true} if the item was removed or {@code false} otherwise
     */
    public boolean removeUsesComponent(UsesComponent item) {
      UsesComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
      return _usesComponents != null && _usesComponents.remove(value);
    }

    /**
     * Get the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @return the remarks value, or {@code null} if not set
     */
    @Nullable
    public MarkupMultiline getRemarks() {
      return _remarks;
    }

    /**
     * Set the "{@literal Remarks}".
     *
     * <p>
     * Additional commentary about the containing object.
     *
     * @param value
     *           the remarks value to set, or {@code null} to clear
     */
    public void setRemarks(@Nullable MarkupMultiline value) {
      _remarks = value;
    }

    @Override
    public String toString() {
      return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
    }

    /**
     * The set of components that are used by the assessment platform.
     */
    @MetaschemaAssembly(
        formalName = "Uses Component",
        description = "The set of components that are used by the assessment platform.",
        name = "uses-component",
        moduleClass = OscalAssessmentCommonModule.class,
        modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-ssp-uses-component-responsible-party", level = IConstraint.Level.ERROR, target = "responsible-party", keyFields = @KeyField(target = "@role-id"), remarks = "Since `responsible-party` associates multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once."))
    )
    public static class UsesComponent implements IBoundObject {
      private final IMetaschemaData __metaschemaData;

      /**
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a component that is implemented as part of an inventory item.
       */
      @BoundFlag(
          formalName = "Component Universally Unique Identifier Reference",
          description = "A [machine-oriented](https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented) identifier reference to a component that is implemented as part of an inventory item.",
          name = "component-uuid",
          required = true,
          typeAdapter = UuidAdapter.class
      )
      private UUID _componentUuid;

      /**
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       */
      @BoundAssembly(
          formalName = "Property",
          description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
          useName = "prop",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Property> _props;

      /**
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       */
      @BoundAssembly(
          formalName = "Link",
          description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
          useName = "link",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<Link> _links;

      /**
       * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
       */
      @BoundAssembly(
          formalName = "Responsible Party",
          description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
          useName = "responsible-party",
          maxOccurs = -1,
          groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
      )
      private List<ResponsibleParty> _responsibleParties;

      /**
       * Additional commentary about the containing object.
       */
      @BoundField(
          formalName = "Remarks",
          description = "Additional commentary about the containing object.",
          useName = "remarks",
          typeAdapter = MarkupMultilineAdapter.class
      )
      private MarkupMultiline _remarks;

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentAssets.AssessmentPlatform.UsesComponent} instance with no metadata.
       */
      public UsesComponent() {
        this(null);
      }

      /**
       * Constructs a new {@code dev.metaschema.oscal.lib.model.AssessmentAssets.AssessmentPlatform.UsesComponent} instance with the specified metadata.
       *
       * @param data
       *           the metaschema data, or {@code null} if none
       */
      public UsesComponent(IMetaschemaData data) {
        this.__metaschemaData = data;
      }

      @Override
      public IMetaschemaData getMetaschemaData() {
        return __metaschemaData;
      }

      /**
       * Get the "{@literal Component Universally Unique Identifier Reference}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a component that is implemented as part of an inventory item.
       *
       * @return the component-uuid value
       */
      @NonNull
      public UUID getComponentUuid() {
        return _componentUuid;
      }

      /**
       * Set the "{@literal Component Universally Unique Identifier Reference}".
       *
       * <p>
       * A <a href="https://pages.nist.gov/OSCAL/concepts/identifier-use/#machine-oriented">machine-oriented</a> identifier reference to a component that is implemented as part of an inventory item.
       *
       * @param value
       *           the component-uuid value to set
       */
      public void setComponentUuid(@NonNull UUID value) {
        _componentUuid = value;
      }

      /**
       * Get the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @return the prop value
       */
      @NonNull
      public List<Property> getProps() {
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return ObjectUtils.notNull(_props);
      }

      /**
       * Set the "{@literal Property}".
       *
       * <p>
       * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
       *
       * @param value
       *           the prop value to set
       */
      public void setProps(@NonNull List<Property> value) {
        _props = value;
      }

      /**
       * Add a new {@link Property} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_props == null) {
          _props = new LinkedList<>();
        }
        return _props.add(value);
      }

      /**
       * Remove the first matching {@link Property} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeProp(Property item) {
        Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _props != null && _props.remove(value);
      }

      /**
       * Get the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @return the link value
       */
      @NonNull
      public List<Link> getLinks() {
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return ObjectUtils.notNull(_links);
      }

      /**
       * Set the "{@literal Link}".
       *
       * <p>
       * A reference to a local or remote resource, that has a specific relation to the containing object.
       *
       * @param value
       *           the link value to set
       */
      public void setLinks(@NonNull List<Link> value) {
        _links = value;
      }

      /**
       * Add a new {@link Link} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_links == null) {
          _links = new LinkedList<>();
        }
        return _links.add(value);
      }

      /**
       * Remove the first matching {@link Link} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeLink(Link item) {
        Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _links != null && _links.remove(value);
      }

      /**
       * Get the "{@literal Responsible Party}".
       *
       * <p>
       * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
       *
       * @return the responsible-party value
       */
      @NonNull
      public List<ResponsibleParty> getResponsibleParties() {
        if (_responsibleParties == null) {
          _responsibleParties = new LinkedList<>();
        }
        return ObjectUtils.notNull(_responsibleParties);
      }

      /**
       * Set the "{@literal Responsible Party}".
       *
       * <p>
       * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
       *
       * @param value
       *           the responsible-party value to set
       */
      public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
        _responsibleParties = value;
      }

      /**
       * Add a new {@link ResponsibleParty} item to the underlying collection.
       * @param item the item to add
       * @return {@code true}
       */
      public boolean addResponsibleParty(ResponsibleParty item) {
        ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
        if (_responsibleParties == null) {
          _responsibleParties = new LinkedList<>();
        }
        return _responsibleParties.add(value);
      }

      /**
       * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
       * @param item the item to remove
       * @return {@code true} if the item was removed or {@code false} otherwise
       */
      public boolean removeResponsibleParty(ResponsibleParty item) {
        ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
        return _responsibleParties != null && _responsibleParties.remove(value);
      }

      /**
       * Get the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @return the remarks value, or {@code null} if not set
       */
      @Nullable
      public MarkupMultiline getRemarks() {
        return _remarks;
      }

      /**
       * Set the "{@literal Remarks}".
       *
       * <p>
       * Additional commentary about the containing object.
       *
       * @param value
       *           the remarks value to set, or {@code null} to clear
       */
      public void setRemarks(@Nullable MarkupMultiline value) {
        _remarks = value;
      }

      @Override
      public String toString() {
        return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
      }
    }
  }
}
