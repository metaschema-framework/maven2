// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_assessment-common_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.HasCardinality;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.
 */
@MetaschemaAssembly(
    formalName = "Assessment-Specific Control Objective",
    description = "A local definition of a control objective for this assessment. Uses catalog syntax for control objective and assessment actions.",
    name = "local-objective",
    moduleClass = OscalAssessmentCommonModule.class,
    valueConstraints = @ValueConstraints(allowedValues = @AllowedValues(id = "oscal-assessment-objective-types", level = IConstraint.Level.ERROR, target = "part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@name", values = {@AllowedValue(value = "objective", description = "\\*\\*(deprecated)\\*\\* Use 'assessment-objective' instead.", deprecatedVersion = "1.0.1"), @AllowedValue(value = "assessment", description = "\\*\\*(deprecated)\\*\\* Use 'assessment-method' instead.", deprecatedVersion = "1.0.1"), @AllowedValue(value = "assessment-objective", description = "The part defines an assessment objective."), @AllowedValue(value = "assessment-method", description = "The part defines an assessment method.")})),
    modelConstraints = @AssemblyConstraints(cardinality = {@HasCardinality(id = "oscal-assessment-objective-cardinality", level = IConstraint.Level.ERROR, target = "part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name=('objective','assessment-objective')]", maxOccurs = 1), @HasCardinality(id = "oscal-assessment-method-cardinality", level = IConstraint.Level.ERROR, target = "part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name=('assessment','assessment-method')]/prop[has-oscal-namespace(('http://csrc.nist.gov/ns/oscal','http://csrc.nist.gov/ns/rmf')) and @name='method']", minOccurs = 1, maxOccurs = 1), @HasCardinality(id = "oscal-assessment-objects-cardinality", level = IConstraint.Level.ERROR, target = "part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name=('assessment','assessment-method')]/part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name=('objects','assessment-objects')]", minOccurs = 1, maxOccurs = 1), @HasCardinality(id = "oscal-assessment-method-id-cardinality", level = IConstraint.Level.ERROR, target = "part[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name=('objective','assessment-objective')]/prop[has-oscal-namespace('http://csrc.nist.gov/ns/oscal') and @name='method-id']", minOccurs = 1)})
)
public class LocalObjective implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   */
  @BoundFlag(
      formalName = "Control Identifier Reference",
      description = "A reference to a control with a corresponding `id` value. When referencing an externally defined `control`, the `Control Identifier Reference` must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).",
      name = "control-id",
      required = true,
      typeAdapter = TokenAdapter.class,
      remarks = "The specified `control-id` must be a valid value within the baseline identified by the target system's SSP via the `import-profile` statement."
  )
  private String _controlId;

  /**
   * A human-readable description of this control objective.
   */
  @BoundField(
      formalName = "Objective Description",
      description = "A human-readable description of this control objective.",
      useName = "description",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _description;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   */
  @BoundAssembly(
      formalName = "Part",
      description = "An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.",
      useName = "part",
      minOccurs = 1,
      maxOccurs = -1,
      groupAs = @GroupAs(name = "parts", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ControlPart> _parts;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.LocalObjective} instance with no metadata.
   */
  public LocalObjective() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.LocalObjective} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public LocalObjective(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @return the control-id value
   */
  @NonNull
  public String getControlId() {
    return _controlId;
  }

  /**
   * Set the "{@literal Control Identifier Reference}".
   *
   * <p>
   * A reference to a control with a corresponding <code>id</code> value. When referencing an externally defined <code>control</code>, the <code>Control Identifier Reference</code> must be used in the context of the external / imported OSCAL instance (e.g., uri-reference).
   *
   * @param value
   *           the control-id value to set
   */
  public void setControlId(@NonNull String value) {
    _controlId = value;
  }

  /**
   * Get the "{@literal Objective Description}".
   *
   * <p>
   * A human-readable description of this control objective.
   *
   * @return the description value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getDescription() {
    return _description;
  }

  /**
   * Set the "{@literal Objective Description}".
   *
   * <p>
   * A human-readable description of this control objective.
   *
   * @param value
   *           the description value to set, or {@code null} to clear
   */
  public void setDescription(@Nullable MarkupMultiline value) {
    _description = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Part}".
   *
   * <p>
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   *
   * @return the part value
   */
  @NonNull
  public List<ControlPart> getParts() {
    if (_parts == null) {
      _parts = new LinkedList<>();
    }
    return ObjectUtils.notNull(_parts);
  }

  /**
   * Set the "{@literal Part}".
   *
   * <p>
   * An annotated, markup-based textual element of a control's or catalog group's definition, or a child of another part.
   *
   * @param value
   *           the part value to set
   */
  public void setParts(@NonNull List<ControlPart> value) {
    _parts = value;
  }

  /**
   * Add a new {@link ControlPart} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addPart(ControlPart item) {
    ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_parts == null) {
      _parts = new LinkedList<>();
    }
    return _parts.add(value);
  }

  /**
   * Remove the first matching {@link ControlPart} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removePart(ControlPart item) {
    ControlPart value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _parts != null && _parts.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
