// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_poam_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Allows components, and inventory-items to be defined within the POA&amp;M for circumstances where no OSCAL-based SSP exists, or is not delivered with the POA&amp;M.
 */
@MetaschemaAssembly(
    formalName = "Local Definitions",
    description = "Allows components, and inventory-items to be defined within the POA\\&M for circumstances where no OSCAL-based SSP exists, or is not delivered with the POA\\&M.",
    name = "local-definitions",
    moduleClass = OscalPoamModule.class,
    modelConstraints = @AssemblyConstraints(unique = @IsUnique(id = "oscal-unique-poam-local-definitions-component", level = IConstraint.Level.ERROR, target = "component", keyFields = @KeyField(target = "@uuid"), remarks = "Since multiple `component` entries can be provided, each component must have a unique `uuid`."))
)
public class LocalDefinitions implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A defined component that can be part of an implemented system.
   */
  @BoundAssembly(
      formalName = "Component",
      description = "A defined component that can be part of an implemented system.",
      useName = "component",
      remarks = "Used to add any components, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "components", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<SystemComponent> _components;

  /**
   * A single managed inventory item within the system.
   */
  @BoundAssembly(
      formalName = "Inventory Item",
      description = "A single managed inventory item within the system.",
      useName = "inventory-item",
      remarks = "Used to add any inventory-items, not defined via the System Security Plan (AR-\\>AP-\\>SSP)",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "inventory-items", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<InventoryItem> _inventoryItems;

  /**
   * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
   */
  @BoundAssembly(
      formalName = "Assessment Assets",
      description = "Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.",
      useName = "assessment-assets",
      remarks = "Specifies components or assessment-platforms used in the assessment."
  )
  private AssessmentAssets _assessmentAssets;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.LocalDefinitions} instance with no metadata.
   */
  public LocalDefinitions() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.LocalDefinitions} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public LocalDefinitions(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @return the component value
   */
  @NonNull
  public List<SystemComponent> getComponents() {
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return ObjectUtils.notNull(_components);
  }

  /**
   * Set the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @param value
   *           the component value to set
   */
  public void setComponents(@NonNull List<SystemComponent> value) {
    _components = value;
  }

  /**
   * Add a new {@link SystemComponent} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addComponent(SystemComponent item) {
    SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return _components.add(value);
  }

  /**
   * Remove the first matching {@link SystemComponent} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeComponent(SystemComponent item) {
    SystemComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _components != null && _components.remove(value);
  }

  /**
   * Get the "{@literal Inventory Item}".
   *
   * <p>
   * A single managed inventory item within the system.
   *
   * @return the inventory-item value
   */
  @NonNull
  public List<InventoryItem> getInventoryItems() {
    if (_inventoryItems == null) {
      _inventoryItems = new LinkedList<>();
    }
    return ObjectUtils.notNull(_inventoryItems);
  }

  /**
   * Set the "{@literal Inventory Item}".
   *
   * <p>
   * A single managed inventory item within the system.
   *
   * @param value
   *           the inventory-item value to set
   */
  public void setInventoryItems(@NonNull List<InventoryItem> value) {
    _inventoryItems = value;
  }

  /**
   * Add a new {@link InventoryItem} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addInventoryItem(InventoryItem item) {
    InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_inventoryItems == null) {
      _inventoryItems = new LinkedList<>();
    }
    return _inventoryItems.add(value);
  }

  /**
   * Remove the first matching {@link InventoryItem} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeInventoryItem(InventoryItem item) {
    InventoryItem value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _inventoryItems != null && _inventoryItems.remove(value);
  }

  /**
   * Get the "{@literal Assessment Assets}".
   *
   * <p>
   * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
   *
   * @return the assessment-assets value, or {@code null} if not set
   */
  @Nullable
  public AssessmentAssets getAssessmentAssets() {
    return _assessmentAssets;
  }

  /**
   * Set the "{@literal Assessment Assets}".
   *
   * <p>
   * Identifies the assets used to perform this assessment, such as the assessment team, scanning tools, and assumptions.
   *
   * @param value
   *           the assessment-assets value to set, or {@code null} to clear
   */
  public void setAssessmentAssets(@Nullable AssessmentAssets value) {
    _assessmentAssets = value;
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
