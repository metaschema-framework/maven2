// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AssemblyConstraints;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.Index;
import dev.metaschema.databind.model.annotations.IsUnique;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.Let;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A collection of component descriptions, which may optionally be grouped by capability.
 */
@MetaschemaAssembly(
    formalName = "Component Definition",
    description = "A collection of component descriptions, which may optionally be grouped by capability.",
    name = "component-definition",
    moduleClass = OscalComponentDefinitionModule.class,
    rootName = "component-definition",
    valueConstraints = @ValueConstraints(lets = @Let(name = "all-imports", target = "import-component-definition ! recurse-depth('doc(resolve-uri(Q{http://csrc.nist.gov/ns/oscal/1.0}resolve-reference(@href)))/component-definition')")),
    modelConstraints = @AssemblyConstraints(index = {@Index(id = "oscal-index-system-component-uuid", level = IConstraint.Level.ERROR, target = "component", name = "index-system-component-uuid", keyFields = @KeyField(target = "@uuid"), remarks = "Since multiple `component` entries can be provided, each component must have a unique `uuid`."), @Index(id = "oscal-component-definition-index-metadata-scoped-role-id", formalName = "In-Scope Role Identifiers", description = "An index of role identifiers that are in-scope for the component-definition model. Roles are collected from imported component-definition. For a given role @id, a locally declared role takes precedence over a role that is imported, the role that was last imported.", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/role ! map:entry(@id,.))?*", name = "index-imports-metadata-role-id", keyFields = @KeyField(target = "@id")), @Index(id = "oscal-component-definition-index-metadata-scoped-location-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/location ! map:entry(@uuid,.))?*", name = "index-imports-metadata-location-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-component-definition-index-metadata-scoped-party-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-component-definition-index-metadata-scoped-party-organization-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports/metadata/party[@type='organization'] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-party-organization-uuid", keyFields = @KeyField(target = "@uuid")), @Index(id = "oscal-component-definition-index-metadata-scoped-property-uuid", level = IConstraint.Level.ERROR, target = "map:merge($all-imports//prop[@uuid] ! map:entry(@uuid,.))?*", name = "index-imports-metadata-property-uuid", keyFields = @KeyField(target = "@uuid"))}, unique = {@IsUnique(id = "oscal-unique-component-definition-capability", level = IConstraint.Level.ERROR, target = "capability", keyFields = @KeyField(target = "@uuid"), remarks = "A given `component` must not be referenced more than once within the same `capability`."), @IsUnique(id = "oscal-unique-document-id", formalName = "Unique Document Identifier", description = "Ensure all document identifiers have a unique combination of @scheme and value.", level = IConstraint.Level.ERROR, target = "document-id", keyFields = {@KeyField(target = "@scheme"), @KeyField}), @IsUnique(id = "oscal-unique-property-in-context-location", formalName = "Unique Properties", description = "Ensure all properties are unique for a given location using a unique combination of @ns, @name, @class. @group. and @value.", level = IConstraint.Level.ERROR, target = ".//prop", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@name"), @KeyField(target = "@ns"), @KeyField(target = "@class"), @KeyField(target = "@group"), @KeyField(target = "@value")}), @IsUnique(id = "oscal-unique-link-in-context-location", formalName = "Unique Links", description = "Ensure all links are unique for a given location using a unique combination of @href, @rel, and @media-type.", level = IConstraint.Level.ERROR, target = ".//link", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@href"), @KeyField(target = "@rel"), @KeyField(target = "@media-type"), @KeyField(target = "@resource-fragment")}), @IsUnique(id = "oscal-unique-responsibility-in-context-location", formalName = "Unique Responsibilities", description = "Ensure all responsible-roles and responsible-parties are unique for a given location using a unique combination of @role-id and the combination of @party-uuid values.", level = IConstraint.Level.ERROR, target = ".//(responsible-party|responsible-role)", keyFields = {@KeyField(target = "path(..)"), @KeyField(target = "@role-id"), @KeyField(target = "@party-uuid")}, remarks = "Since `responsible-party` and `responsible-role` associate multiple `party-uuid` entries with a single `role-id`, each role-id must be referenced only once.")})
)
public class ComponentDefinition extends AbstractOscalInstance implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * Provides a globally unique means to identify a given component definition instance.
   */
  @BoundFlag(
      formalName = "Component Definition Universally Unique Identifier",
      description = "Provides a globally unique means to identify a given component definition instance.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * Provides information about the containing document, and defines concepts that are shared across the document.
   */
  @BoundAssembly(
      formalName = "Document Metadata",
      description = "Provides information about the containing document, and defines concepts that are shared across the document.",
      useName = "metadata",
      minOccurs = 1
  )
  private Metadata _metadata;

  /**
   * Loads a component definition from another resource.
   */
  @BoundAssembly(
      formalName = "Import Component Definition",
      description = "Loads a component definition from another resource.",
      useName = "import-component-definition",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "import-component-definitions", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ImportComponentDefinition> _importComponentDefinitions;

  /**
   * A defined component that can be part of an implemented system.
   */
  @BoundAssembly(
      formalName = "Component",
      description = "A defined component that can be part of an implemented system.",
      useName = "component",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "components", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<DefinedComponent> _components;

  /**
   * A grouping of other components and/or capabilities.
   */
  @BoundAssembly(
      formalName = "Capability",
      description = "A grouping of other components and/or capabilities.",
      useName = "capability",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "capabilities", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Capability> _capabilities;

  /**
   * A collection of resources that may be referenced from within the OSCAL document instance.
   */
  @BoundAssembly(
      formalName = "Back matter",
      description = "A collection of resources that may be referenced from within the OSCAL document instance.",
      useName = "back-matter"
  )
  private BackMatter _backMatter;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ComponentDefinition} instance with no metadata.
   */
  public ComponentDefinition() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.ComponentDefinition} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public ComponentDefinition(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Component Definition Universally Unique Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given component definition instance.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Component Definition Universally Unique Identifier}".
   *
   * <p>
   * Provides a globally unique means to identify a given component definition instance.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @return the metadata value
   */
  @NonNull
  public Metadata getMetadata() {
    return _metadata;
  }

  /**
   * Set the "{@literal Document Metadata}".
   *
   * <p>
   * Provides information about the containing document, and defines concepts that are shared across the document.
   *
   * @param value
   *           the metadata value to set
   */
  public void setMetadata(@NonNull Metadata value) {
    _metadata = value;
  }

  /**
   * Get the "{@literal Import Component Definition}".
   *
   * <p>
   * Loads a component definition from another resource.
   *
   * @return the import-component-definition value
   */
  @NonNull
  public List<ImportComponentDefinition> getImportComponentDefinitions() {
    if (_importComponentDefinitions == null) {
      _importComponentDefinitions = new LinkedList<>();
    }
    return ObjectUtils.notNull(_importComponentDefinitions);
  }

  /**
   * Set the "{@literal Import Component Definition}".
   *
   * <p>
   * Loads a component definition from another resource.
   *
   * @param value
   *           the import-component-definition value to set
   */
  public void setImportComponentDefinitions(@NonNull List<ImportComponentDefinition> value) {
    _importComponentDefinitions = value;
  }

  /**
   * Add a new {@link ImportComponentDefinition} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addImportComponentDefinition(ImportComponentDefinition item) {
    ImportComponentDefinition value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_importComponentDefinitions == null) {
      _importComponentDefinitions = new LinkedList<>();
    }
    return _importComponentDefinitions.add(value);
  }

  /**
   * Remove the first matching {@link ImportComponentDefinition} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeImportComponentDefinition(ImportComponentDefinition item) {
    ImportComponentDefinition value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _importComponentDefinitions != null && _importComponentDefinitions.remove(value);
  }

  /**
   * Get the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @return the component value
   */
  @NonNull
  public List<DefinedComponent> getComponents() {
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return ObjectUtils.notNull(_components);
  }

  /**
   * Set the "{@literal Component}".
   *
   * <p>
   * A defined component that can be part of an implemented system.
   *
   * @param value
   *           the component value to set
   */
  public void setComponents(@NonNull List<DefinedComponent> value) {
    _components = value;
  }

  /**
   * Add a new {@link DefinedComponent} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addComponent(DefinedComponent item) {
    DefinedComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_components == null) {
      _components = new LinkedList<>();
    }
    return _components.add(value);
  }

  /**
   * Remove the first matching {@link DefinedComponent} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeComponent(DefinedComponent item) {
    DefinedComponent value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _components != null && _components.remove(value);
  }

  /**
   * Get the "{@literal Capability}".
   *
   * <p>
   * A grouping of other components and/or capabilities.
   *
   * @return the capability value
   */
  @NonNull
  public List<Capability> getCapabilities() {
    if (_capabilities == null) {
      _capabilities = new LinkedList<>();
    }
    return ObjectUtils.notNull(_capabilities);
  }

  /**
   * Set the "{@literal Capability}".
   *
   * <p>
   * A grouping of other components and/or capabilities.
   *
   * @param value
   *           the capability value to set
   */
  public void setCapabilities(@NonNull List<Capability> value) {
    _capabilities = value;
  }

  /**
   * Add a new {@link Capability} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addCapability(Capability item) {
    Capability value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_capabilities == null) {
      _capabilities = new LinkedList<>();
    }
    return _capabilities.add(value);
  }

  /**
   * Remove the first matching {@link Capability} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeCapability(Capability item) {
    Capability value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _capabilities != null && _capabilities.remove(value);
  }

  /**
   * Get the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @return the back-matter value, or {@code null} if not set
   */
  @Nullable
  public BackMatter getBackMatter() {
    return _backMatter;
  }

  /**
   * Set the "{@literal Back matter}".
   *
   * <p>
   * A collection of resources that may be referenced from within the OSCAL document instance.
   *
   * @param value
   *           the back-matter value to set, or {@code null} to clear
   */
  public void setBackMatter(@Nullable BackMatter value) {
    _backMatter = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
