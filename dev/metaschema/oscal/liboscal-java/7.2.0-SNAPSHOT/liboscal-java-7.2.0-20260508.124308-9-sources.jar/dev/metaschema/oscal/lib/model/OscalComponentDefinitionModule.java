// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_component_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.markup.MarkupLine;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.databind.IBindingContext;
import dev.metaschema.databind.model.AbstractBoundModule;
import dev.metaschema.databind.model.IBoundModule;
import dev.metaschema.databind.model.annotations.MetaschemaModule;
import java.net.URI;
import java.util.List;

/**
 * OSCAL Component Definition Model
 * <p>The OSCAL Component Definition Model can be used to describe the implementation of controls in a <code>component</code> or a set of components grouped as a <code>capability</code>. A component can be either a <em>technical component</em> , or a <em>documentary component</em>.</p>
 * <p>A technical component is a component that is implemented in hardware (physical or virtual) or software. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their hardware and software.</p>
 * <p>A documentary component is a component implemented for a documented process, procedure, or policy. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their process, procedure, or policy.</p>
 * <p>The information provided by a technical or documentary component can be used by component consumers to provide starting narratives for documenting control implementations in an OSCAL SSP.</p>
 * <p>The root of the OSCAL Implementation Layer Component Definition model is <code>component-definition</code>.</p>
 */
@MetaschemaModule(
    assemblies = {
        ComponentDefinition.class,
        ImportComponentDefinition.class,
        DefinedComponent.class,
        Capability.class,
        IncorporatesComponent.class,
        ComponentControlImplementation.class,
        ComponentImplementedRequirement.class,
        ComponentStatement.class
    },
    imports = OscalImplementationCommonModule.class,
    remarks = "The OSCAL Component Definition Model can be used to describe the implementation of controls in a `component` or a set of components grouped as a `capability`. A component can be either a *technical component* , or a *documentary component*.\n"
            + "\n"
            + "A technical component is a component that is implemented in hardware (physical or virtual) or software. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their hardware and software.\n"
            + "\n"
            + "A documentary component is a component implemented for a documented process, procedure, or policy. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their process, procedure, or policy.\n"
            + "\n"
            + "The information provided by a technical or documentary component can be used by component consumers to provide starting narratives for documenting control implementations in an OSCAL SSP.\n"
            + "\n"
            + "The root of the OSCAL Implementation Layer Component Definition model is `component-definition`."
)
public final class OscalComponentDefinitionModule extends AbstractBoundModule {
  private static final MarkupLine NAME = MarkupLine.fromMarkdown("OSCAL Component Definition Model");

  private static final String SHORT_NAME = "oscal-component-definition";

  private static final String VERSION = "1.2.1";

  private static final URI XML_NAMESPACE = URI.create("http://csrc.nist.gov/ns/oscal/1.0");

  private static final URI JSON_BASE_URI = URI.create("http://csrc.nist.gov/ns/oscal");

  private static final MarkupMultiline REMARKS = MarkupMultiline.fromMarkdown("The OSCAL Component Definition Model can be used to describe the implementation of controls in a `component` or a set of components grouped as a `capability`. A component can be either a *technical component* , or a *documentary component*.\n"
      + "\n"
      + "A technical component is a component that is implemented in hardware (physical or virtual) or software. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their hardware and software.\n"
      + "\n"
      + "A documentary component is a component implemented for a documented process, procedure, or policy. Suppliers may document components in an OSCAL component definition that describes the implementation of controls in their process, procedure, or policy.\n"
      + "\n"
      + "The information provided by a technical or documentary component can be used by component consumers to provide starting narratives for documenting control implementations in an OSCAL SSP.\n"
      + "\n"
      + "The root of the OSCAL Implementation Layer Component Definition model is `component-definition`.");

  /**
   * Construct a new module instance.
   *
   * @param importedModules
   *           modules imported by this module
   * @param bindingContext
   *           the binding context to associate with this module
   */
  public OscalComponentDefinitionModule(List<? extends IBoundModule> importedModules,
      IBindingContext bindingContext) {
    super(importedModules, bindingContext);
  }

  @Override
  public MarkupLine getName() {
    return NAME;
  }

  @Override
  public String getShortName() {
    return SHORT_NAME;
  }

  @Override
  public String getVersion() {
    return VERSION;
  }

  @Override
  public URI getXmlNamespace() {
    return XML_NAMESPACE;
  }

  @Override
  public URI getJsonBaseUri() {
    return JSON_BASE_URI;
  }

  @Override
  public MarkupMultiline getRemarks() {
    return REMARKS;
  }
}
