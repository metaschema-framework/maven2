/*
 * SPDX-FileCopyrightText: none
 * SPDX-License-Identifier: CC0-1.0
 */

package dev.metaschema.oscal.lib.model.control;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import dev.metaschema.oscal.lib.model.ControlCommonSelectControlById;
import dev.metaschema.oscal.lib.model.ProfileMatching;
import edu.umd.cs.findbugs.annotations.NonNull;

public abstract class AbstractControlCommonSelectControlById implements IControlCommonSelectControlById {
  // TODO: move implementation from profile resolver selection code here

  @NonNull
  public static Builder builder() {
    return new Builder();
  }

  public static class Builder {
    private boolean withChildControls; // false;
    private final List<String> withIds = new LinkedList<>();
    private final List<Pattern> matching = new LinkedList<>();

    @NonNull
    public Builder withChildControls(boolean value) {
      this.withChildControls = value;
      return this;
    }

    @NonNull
    public Builder withId(@NonNull String id) {
      withIds.add(id);
      return this;
    }

    @NonNull
    public Builder withIds(@NonNull Collection<String> ids) {
      withIds.addAll(ids);
      return this;
    }

    @NonNull
    public Builder matching(@NonNull Pattern pattern) {
      matching.add(pattern);
      return this;
    }

    @NonNull
    public ControlCommonSelectControlById build() {
      ControlCommonSelectControlById retval = new ControlCommonSelectControlById();
      retval.setWithChildControls(withChildControls ? "yes" : "no");
      retval.setWithIds(withIds);
      retval.setMatching(matching.stream()
          .map(pattern -> {
            ProfileMatching matching = new ProfileMatching();
            matching.setPattern(pattern.pattern());
            return matching;
          })
          .collect(Collectors.toList()));
      return retval;
    }
  }
}
