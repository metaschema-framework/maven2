// Generated from: ../../../../../../../../oscal/src/metaschema/oscal_metadata_metaschema.xml
// Do not edit - changes will be lost when regenerated.
package dev.metaschema.oscal.lib.model;

import dev.metaschema.core.datatype.adapter.DateTimeWithTZAdapter;
import dev.metaschema.core.datatype.adapter.TokenAdapter;
import dev.metaschema.core.datatype.adapter.UriAdapter;
import dev.metaschema.core.datatype.adapter.UuidAdapter;
import dev.metaschema.core.datatype.markup.MarkupMultiline;
import dev.metaschema.core.datatype.markup.MarkupMultilineAdapter;
import dev.metaschema.core.model.IBoundObject;
import dev.metaschema.core.model.IMetaschemaData;
import dev.metaschema.core.model.JsonGroupAsBehavior;
import dev.metaschema.core.model.constraint.IConstraint;
import dev.metaschema.core.util.ObjectUtils;
import dev.metaschema.databind.model.annotations.AllowedValue;
import dev.metaschema.databind.model.annotations.AllowedValues;
import dev.metaschema.databind.model.annotations.BoundAssembly;
import dev.metaschema.databind.model.annotations.BoundField;
import dev.metaschema.databind.model.annotations.BoundFlag;
import dev.metaschema.databind.model.annotations.GroupAs;
import dev.metaschema.databind.model.annotations.IndexHasKey;
import dev.metaschema.databind.model.annotations.KeyField;
import dev.metaschema.databind.model.annotations.MetaschemaAssembly;
import dev.metaschema.databind.model.annotations.ValueConstraints;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;
import java.net.URI;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * An action applied by a role within a given party to the content.
 */
@MetaschemaAssembly(
    formalName = "Action",
    description = "An action applied by a role within a given party to the content.",
    name = "action",
    moduleClass = OscalMetadataModule.class,
    valueConstraints = @ValueConstraints(allowedValues = {@AllowedValues(id = "oscal-metadata-action-system-values", level = IConstraint.Level.ERROR, target = "./system/@value", allowOthers = true, values = @AllowedValue(value = "http://csrc.nist.gov/ns/oscal", description = "This value identifies action types defined in the NIST OSCAL namespace.")), @AllowedValues(id = "oscal-metadata-action-type-values", level = IConstraint.Level.ERROR, target = "./type[has-oscal-namespace('http://csrc.nist.gov/ns/oscal')]/@value", values = {@AllowedValue(value = "approval", description = "An approval of a document instance's content."), @AllowedValue(value = "request-changes", description = "A request from the responsible party or parties to change the content.")})}, indexHasKey = {@IndexHasKey(id = "oscal-metadata-action-name-index-metadata-role-id", level = IConstraint.Level.ERROR, target = "responsible-party", indexName = "index-metadata-role-id", keyFields = @KeyField(target = "@role-id")), @IndexHasKey(id = "oscal-metadata-action-name-index-metadata-party-uuid", level = IConstraint.Level.ERROR, target = "responsible-party", indexName = "index-metadata-party-uuid", keyFields = @KeyField(target = "party-uuid"))})
)
public class Action implements IBoundObject {
  private final IMetaschemaData __metaschemaData;

  /**
   * A unique identifier that can be used to reference this defined action elsewhere in an OSCAL document. A UUID should be consistently used for a given location across revisions of the document.
   */
  @BoundFlag(
      formalName = "Action Universally Unique Identifier",
      description = "A unique identifier that can be used to reference this defined action elsewhere in an OSCAL document. A UUID should be consistently used for a given location across revisions of the document.",
      name = "uuid",
      required = true,
      typeAdapter = UuidAdapter.class
  )
  private UUID _uuid;

  /**
   * The date and time when the action occurred.
   */
  @BoundFlag(
      formalName = "Action Occurrence Date",
      description = "The date and time when the action occurred.",
      name = "date",
      typeAdapter = DateTimeWithTZAdapter.class
  )
  private ZonedDateTime _date;

  /**
   * The type of action documented by the assembly, such as an approval.
   */
  @BoundFlag(
      formalName = "Action Type",
      description = "The type of action documented by the assembly, such as an approval.",
      name = "type",
      required = true,
      typeAdapter = TokenAdapter.class
  )
  private String _type;

  /**
   * Specifies the action type system used.
   */
  @BoundFlag(
      formalName = "Action Type System",
      description = "Specifies the action type system used.",
      name = "system",
      required = true,
      typeAdapter = UriAdapter.class,
      remarks = "Provides a means to segment the value space for the `type`, so that different organizations and individuals can assert control over the allowed `action`'s `type`. This allows the semantics associated with a given `type` to be defined on an organization-by-organization basis.\n"
              + "\n"
              + "An organization MUST use a URI that they have control over. e.g., a domain registered to the organization in a URI, a registered uniform resource names (URN) namespace."
  )
  private URI _system;

  /**
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   */
  @BoundAssembly(
      formalName = "Property",
      description = "An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.",
      useName = "prop",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "props", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Property> _props;

  /**
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   */
  @BoundAssembly(
      formalName = "Link",
      description = "A reference to a local or remote resource, that has a specific relation to the containing object.",
      useName = "link",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "links", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<Link> _links;

  /**
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   */
  @BoundAssembly(
      formalName = "Responsible Party",
      description = "A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.",
      useName = "responsible-party",
      maxOccurs = -1,
      groupAs = @GroupAs(name = "responsible-parties", inJson = JsonGroupAsBehavior.LIST)
  )
  private List<ResponsibleParty> _responsibleParties;

  /**
   * Additional commentary about the containing object.
   */
  @BoundField(
      formalName = "Remarks",
      description = "Additional commentary about the containing object.",
      useName = "remarks",
      typeAdapter = MarkupMultilineAdapter.class
  )
  private MarkupMultiline _remarks;

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Action} instance with no metadata.
   */
  public Action() {
    this(null);
  }

  /**
   * Constructs a new {@code dev.metaschema.oscal.lib.model.Action} instance with the specified metadata.
   *
   * @param data
   *           the metaschema data, or {@code null} if none
   */
  public Action(IMetaschemaData data) {
    this.__metaschemaData = data;
  }

  @Override
  public IMetaschemaData getMetaschemaData() {
    return __metaschemaData;
  }

  /**
   * Get the "{@literal Action Universally Unique Identifier}".
   *
   * <p>
   * A unique identifier that can be used to reference this defined action elsewhere in an OSCAL document. A UUID should be consistently used for a given location across revisions of the document.
   *
   * @return the uuid value
   */
  @NonNull
  public UUID getUuid() {
    return _uuid;
  }

  /**
   * Set the "{@literal Action Universally Unique Identifier}".
   *
   * <p>
   * A unique identifier that can be used to reference this defined action elsewhere in an OSCAL document. A UUID should be consistently used for a given location across revisions of the document.
   *
   * @param value
   *           the uuid value to set
   */
  public void setUuid(@NonNull UUID value) {
    _uuid = value;
  }

  /**
   * Get the "{@literal Action Occurrence Date}".
   *
   * <p>
   * The date and time when the action occurred.
   *
   * @return the date value, or {@code null} if not set
   */
  @Nullable
  public ZonedDateTime getDate() {
    return _date;
  }

  /**
   * Set the "{@literal Action Occurrence Date}".
   *
   * <p>
   * The date and time when the action occurred.
   *
   * @param value
   *           the date value to set, or {@code null} to clear
   */
  public void setDate(@Nullable ZonedDateTime value) {
    _date = value;
  }

  /**
   * Get the "{@literal Action Type}".
   *
   * <p>
   * The type of action documented by the assembly, such as an approval.
   *
   * @return the type value
   */
  @NonNull
  public String getType() {
    return _type;
  }

  /**
   * Set the "{@literal Action Type}".
   *
   * <p>
   * The type of action documented by the assembly, such as an approval.
   *
   * @param value
   *           the type value to set
   */
  public void setType(@NonNull String value) {
    _type = value;
  }

  /**
   * Get the "{@literal Action Type System}".
   *
   * <p>
   * Specifies the action type system used.
   *
   * @return the system value
   */
  @NonNull
  public URI getSystem() {
    return _system;
  }

  /**
   * Set the "{@literal Action Type System}".
   *
   * <p>
   * Specifies the action type system used.
   *
   * @param value
   *           the system value to set
   */
  public void setSystem(@NonNull URI value) {
    _system = value;
  }

  /**
   * Get the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @return the prop value
   */
  @NonNull
  public List<Property> getProps() {
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return ObjectUtils.notNull(_props);
  }

  /**
   * Set the "{@literal Property}".
   *
   * <p>
   * An attribute, characteristic, or quality of the containing object expressed as a namespace qualified name/value pair.
   *
   * @param value
   *           the prop value to set
   */
  public void setProps(@NonNull List<Property> value) {
    _props = value;
  }

  /**
   * Add a new {@link Property} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_props == null) {
      _props = new LinkedList<>();
    }
    return _props.add(value);
  }

  /**
   * Remove the first matching {@link Property} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeProp(Property item) {
    Property value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _props != null && _props.remove(value);
  }

  /**
   * Get the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @return the link value
   */
  @NonNull
  public List<Link> getLinks() {
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return ObjectUtils.notNull(_links);
  }

  /**
   * Set the "{@literal Link}".
   *
   * <p>
   * A reference to a local or remote resource, that has a specific relation to the containing object.
   *
   * @param value
   *           the link value to set
   */
  public void setLinks(@NonNull List<Link> value) {
    _links = value;
  }

  /**
   * Add a new {@link Link} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_links == null) {
      _links = new LinkedList<>();
    }
    return _links.add(value);
  }

  /**
   * Remove the first matching {@link Link} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeLink(Link item) {
    Link value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _links != null && _links.remove(value);
  }

  /**
   * Get the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @return the responsible-party value
   */
  @NonNull
  public List<ResponsibleParty> getResponsibleParties() {
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return ObjectUtils.notNull(_responsibleParties);
  }

  /**
   * Set the "{@literal Responsible Party}".
   *
   * <p>
   * A reference to a set of persons and/or organizations that have responsibility for performing the referenced role in the context of the containing object.
   *
   * @param value
   *           the responsible-party value to set
   */
  public void setResponsibleParties(@NonNull List<ResponsibleParty> value) {
    _responsibleParties = value;
  }

  /**
   * Add a new {@link ResponsibleParty} item to the underlying collection.
   * @param item the item to add
   * @return {@code true}
   */
  public boolean addResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    if (_responsibleParties == null) {
      _responsibleParties = new LinkedList<>();
    }
    return _responsibleParties.add(value);
  }

  /**
   * Remove the first matching {@link ResponsibleParty} item from the underlying collection.
   * @param item the item to remove
   * @return {@code true} if the item was removed or {@code false} otherwise
   */
  public boolean removeResponsibleParty(ResponsibleParty item) {
    ResponsibleParty value = ObjectUtils.requireNonNull(item,"item cannot be null");
    return _responsibleParties != null && _responsibleParties.remove(value);
  }

  /**
   * Get the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @return the remarks value, or {@code null} if not set
   */
  @Nullable
  public MarkupMultiline getRemarks() {
    return _remarks;
  }

  /**
   * Set the "{@literal Remarks}".
   *
   * <p>
   * Additional commentary about the containing object.
   *
   * @param value
   *           the remarks value to set, or {@code null} to clear
   */
  public void setRemarks(@Nullable MarkupMultiline value) {
    _remarks = value;
  }

  @Override
  public String toString() {
    return ObjectUtils.notNull(new ReflectionToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).toString());
  }
}
